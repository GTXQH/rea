(window["webpackJsonp"] = window["webpackJsonp"] || []).push([
  ["pages_sub1-kefu-fine_list"],
  {
    "2e17": function (t, n, a) {
      "use strict";
      a.r(n);
      var i = a("86d0"),
        e = a.n(i);
      for (var s in i)
        ["default"].indexOf(s) < 0 &&
          (function (t) {
            a.d(n, t, function () {
              return i[t];
            });
          })(s);
      n["default"] = e.a;
    },
    "35a4": function (t, n, a) {
      "use strict";
      a.d(n, "b", function () {
        return e;
      }),
        a.d(n, "c", function () {
          return s;
        }),
        a.d(n, "a", function () {
          return i;
        });
      var i = { uvEmpty: a("caef").default, uvLoadMore: a("bd68").default },
        e = function () {
          var t = this,
            n = t.$createElement,
            a = t._self._c || n;
          return a(
            "v-uni-view",
            { staticClass: "content" },
            [
              a(
                "v-uni-view",
                { staticClass: "tab_box" },
                [
                  a(
                    "v-uni-view",
                    {
                      class: { tab: !0, cur: 0 == t.currentTab },
                      on: {
                        click: function (n) {
                          (arguments[0] = n = t.$handleEvent(n)),
                            t.switchTab(0);
                        },
                      },
                    },
                    [t._v("全部")],
                  ),
                  a(
                    "v-uni-view",
                    {
                      class: { tab: !0, cur: 1 == t.currentTab },
                      on: {
                        click: function (n) {
                          (arguments[0] = n = t.$handleEvent(n)),
                            t.switchTab(1);
                        },
                      },
                    },
                    [t._v("未缴费")],
                  ),
                  a(
                    "v-uni-view",
                    {
                      class: { tab: !0, cur: 2 == t.currentTab },
                      on: {
                        click: function (n) {
                          (arguments[0] = n = t.$handleEvent(n)),
                            t.switchTab(2);
                        },
                      },
                    },
                    [t._v("已缴费")],
                  ),
                ],
                1,
              ),
              t.canFine
                ? a(
                    "v-uni-view",
                    {
                      staticClass: "add_btn",
                      on: {
                        click: function (n) {
                          (arguments[0] = n = t.$handleEvent(n)),
                            t.goAdd.apply(void 0, arguments);
                        },
                      },
                    },
                    [a("v-uni-text", [t._v("+ 添加罚款")])],
                    1,
                  )
                : t._e(),
              t.list.length > 0
                ? a(
                    "v-uni-view",
                    { staticClass: "list", attrs: { id: "list" } },
                    t._l(t.list, function (n, i) {
                      return a(
                        "v-uni-view",
                        {
                          key: i,
                          staticClass: "col",
                          attrs: { text: n },
                          on: {
                            click: function (a) {
                              (arguments[0] = a = t.$handleEvent(a)),
                                t.showDetail(n);
                            },
                          },
                        },
                        [
                          a(
                            "v-uni-view",
                            { staticClass: "info" },
                            [
                              a("v-uni-view", { staticClass: "title" }, [
                                t._v(t._s(n.title)),
                              ]),
                              a("v-uni-view", { staticClass: "desc" }, [
                                t._v(
                                  "涉及打手：" +
                                    t._s(n.user_count) +
                                    "人 | 已缴纳：" +
                                    t._s(n.paid_count) +
                                    "人 | 未缴纳：" +
                                    t._s(n.unpaid_count) +
                                    "人",
                                ),
                              ]),
                              a("v-uni-view", { staticClass: "time" }, [
                                t._v("创建时间：" + t._s(n.create_time)),
                              ]),
                            ],
                            1,
                          ),
                          a(
                            "v-uni-view",
                            { staticClass: "right" },
                            [
                              a(
                                "v-uni-view",
                                {
                                  class: {
                                    status: !0,
                                    paid: 0 == n.unpaid_count,
                                    unpaid: n.unpaid_count > 0,
                                  },
                                },
                                [
                                  t._v(
                                    " " +
                                      t._s(
                                        0 == n.unpaid_count
                                          ? "全部已缴纳"
                                          : "待缴费",
                                      ) +
                                      " ",
                                  ),
                                ],
                              ),
                            ],
                            1,
                          ),
                        ],
                        1,
                      );
                    }),
                    1,
                  )
                : a("uv-empty", {
                    attrs: {
                      mode: "data",
                      text: "暂无罚款记录",
                      icon: "/static/imgs/no-data.png",
                    },
                  }),
              t.page > 1
                ? a("uv-load-more", { attrs: { status: t.status } })
                : t._e(),
              a("kefu-bar", { attrs: { selected: t.selected } }),
            ],
            1,
          );
        },
        s = [];
    },
    "86d0": function (t, n, a) {
      "use strict";
      a("6a54"),
        Object.defineProperty(n, "__esModule", { value: !0 }),
        (n.default = void 0),
        a("c223");
      var i = a("e74a"),
        e = {
          data: function () {
            return {
              list: [],
              page: 1,
              status: "loadmore",
              currentTab: 0,
              isLoading: !1,
              selected: 5,
              canFine: !0,
            };
          },
          onLoad: function () {
            this.getKefuInfo(), this.getFineList();
          },
          onShow: function () {
            this.list.length > 0 && this.resetAndReload();
          },
          onPullDownRefresh: function () {
            var t = this;
            uni.showLoading({ title: "刷新中" }),
              setTimeout(function () {
                uni.hideLoading(),
                  t.resetAndReload(),
                  uni.showToast({ title: "刷新成功", duration: 1e3 }),
                  uni.stopPullDownRefresh();
              }, 300);
          },
          onReachBottom: function () {
            "loading" == this.status ||
              "nomore" == this.status ||
              this.isLoading ||
              (this.page++, (this.status = "loading"), this.getFineList());
          },
          methods: {
            switchTab: function (t) {
              this.currentTab === t ||
                this.isLoading ||
                ((this.currentTab = t), this.resetAndReload());
            },
            resetAndReload: function () {
              this.isLoading ||
                ((this.page = 1),
                (this.list = []),
                (this.status = "loadmore"),
                this.getFineList());
            },
            getFineList: function () {
              var t = this;
              if (!this.isLoading) {
                (this.isLoading = !0), uni.showLoading({ title: "加载中.." });
                var n = "";
                1 == this.currentTab
                  ? (n = 0)
                  : 2 == this.currentTab && (n = 1),
                  (0, i.send)(
                    "/wechat/KefuFine/getFineList",
                    { page: this.page, status: n },
                    !1,
                  )
                    .then(function (n) {
                      (t.isLoading = !1), uni.hideLoading();
                      var a = n.status,
                        i = n.msg,
                        e = n.data;
                      if (1 != a) return uni.$uv.toast(i);
                      e.list.length > 0 &&
                        (1 === t.page
                          ? (t.list = e.list)
                          : (t.list = t.list.concat(e.list))),
                        1 == e.no_more
                          ? (t.status = "nomore")
                          : (t.status = "loadmore");
                    })
                    .catch(function () {
                      (t.isLoading = !1), uni.hideLoading();
                    });
              }
            },
            getKefuInfo: function () {
              var t = this;
              (0, i.send)("/wechat/Kefu/getKefuInfo", {}, !1)
                .then(function (n) {
                  1 == n.status && n.data && (t.canFine = 1 == n.data.can_fine);
                })
                .catch(function () {
                  t.canFine = !1;
                });
            },
            goAdd: function () {
              if (!this.canFine) return uni.$uv.toast("您没有罚款权限");
              uni.navigateTo({ url: "/pages_sub1/kefu/fine_add" });
            },
            showDetail: function (t) {
              uni.navigateTo({
                url: "/pages_sub1/kefu/fine_detail?id=" + t.id,
              });
            },
          },
        };
      n.default = e;
    },
    e438: function (t, n, a) {
      "use strict";
      a.r(n);
      var i = a("35a4"),
        e = a("2e17");
      for (var s in e)
        ["default"].indexOf(s) < 0 &&
          (function (t) {
            a.d(n, t, function () {
              return e[t];
            });
          })(s);
      a("f02f");
      var o = a("828b"),
        c = Object(o["a"])(
          e["default"],
          i["b"],
          i["c"],
          !1,
          null,
          "665ba8ac",
          null,
          !1,
          i["a"],
          void 0,
        );
      n["default"] = c.exports;
    },
    f02f: function (t, n, a) {
      "use strict";
      var i = a("f996"),
        e = a.n(i);
      e.a;
    },
    f2c0: function (t, n, a) {
      var i = a("c86c");
      (n = i(!1)),
        n.push([
          t.i,
          '@charset "UTF-8";\r\n/**\r\n * 这里是uni-app内置的常用样式变量\r\n *\r\n * uni-app 官方扩展插件及插件市场（https://ext.dcloud.net.cn）上很多三方插件均使用了这些样式变量\r\n * 如果你是插件开发者，建议你使用scss预处理，并在插件代码中直接使用这些变量（无需 import 这个文件），方便用户通过搭积木的方式开发整体风格一致的App\r\n *\r\n */\r\n/**\r\n * 如果你是App开发者（插件使用者），你可以通过修改这些变量来定制自己的插件主题，实现自定义主题功能\r\n *\r\n * 如果你的项目同样使用了scss预处理，你也可以直接在你的 scss 代码中使用如下变量，同时无需 import 这个文件\r\n */\r\n/* 颜色变量 */\r\n/* 行为相关颜色 */\r\n/* 文字基本颜色 */\r\n/* 背景颜色 */\r\n/* 边框颜色 */\r\n/* 尺寸变量 */\r\n/* 文字尺寸 */\r\n/* 图片尺寸 */\r\n/* Border Radius */\r\n/* 水平间距 */\r\n/* 垂直间距 */\r\n/* 透明度 */\r\n/* 文章场景相关 */.content[data-v-665ba8ac]{padding:0 %?30?% %?155?%}.tab_box[data-v-665ba8ac]{display:flex;background:#f7f8fa;border-radius:%?20?%;margin:%?30?% 0;padding:%?10?%}.tab_box .tab[data-v-665ba8ac]{flex:1;text-align:center;padding:%?20?%;border-radius:%?15?%;font-size:14px;color:#666;transition:all .3s}.tab_box .tab.cur[data-v-665ba8ac]{background:#fff;color:#000;font-weight:700;box-shadow:0 %?2?% %?8?% rgba(0,0,0,.1)}.add_btn[data-v-665ba8ac]{background:#ffe610;border-radius:%?20?%;padding:%?20?%;text-align:center;font-weight:700;font-size:15px;margin-bottom:%?30?%}.list .col[data-v-665ba8ac]{display:flex;justify-content:space-between;align-items:flex-start;padding:%?30?% 0;border-bottom:%?2?% solid #eee}.list .col .info[data-v-665ba8ac]{width:calc(100% - %?150?%)}.list .col .info .title[data-v-665ba8ac]{font-weight:700;font-size:15px;margin-bottom:%?10?%}.list .col .info .desc[data-v-665ba8ac]{font-size:12px;color:#999;margin-bottom:%?5?%}.list .col .info .time[data-v-665ba8ac]{font-size:12px;color:#999}.list .col .right[data-v-665ba8ac]{width:%?140?%;text-align:right}.list .col .right .status[data-v-665ba8ac]{font-size:12px}.list .col .right .status.paid[data-v-665ba8ac]{color:#6dff26}.list .col .right .status.unpaid[data-v-665ba8ac]{color:#fd6400}',
          "",
        ]),
        (t.exports = n);
    },
    f996: function (t, n, a) {
      var i = a("f2c0");
      i.__esModule && (i = i.default),
        "string" === typeof i && (i = [[t.i, i, ""]]),
        i.locals && (t.exports = i.locals);
      var e = a("967d").default;
      e("6acf9a19", i, !0, { sourceMap: !1, shadowMode: !1 });
    },
  },
]);
//# sourceMappingURL=pages_sub1-kefu-fine_list.76eb4492.js.map
