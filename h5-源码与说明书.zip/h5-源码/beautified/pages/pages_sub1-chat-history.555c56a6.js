(window["webpackJsonp"] = window["webpackJsonp"] || []).push([
  ["pages_sub1-chat-history"],
  {
    "0316": function (t, e, a) {
      "use strict";
      a.r(e);
      var o = a("ba1c"),
        i = a.n(o);
      for (var r in o)
        ["default"].indexOf(r) < 0 &&
          (function (t) {
            a.d(e, t, function () {
              return o[t];
            });
          })(r);
      e["default"] = i.a;
    },
    "05c2": function (t, e, a) {
      "use strict";
      a("6a54");
      var o = a("f5bd").default;
      Object.defineProperty(e, "__esModule", { value: !0 }),
        (e.default = void 0),
        a("473f"),
        a("bf0f"),
        a("f7a5"),
        a("5c47"),
        a("0506"),
        a("c223"),
        a("18f7"),
        a("de6c"),
        a("fd3c");
      var i = o(a("5de6")),
        r = o(a("9b1b")),
        n = o(a("2634")),
        s = o(a("2fdc")),
        c = o(a("4d8f0")),
        d = o(a("9463")),
        u = o(a("b92c")),
        l = o(a("7689")),
        _ = {
          name: "uv-tabs",
          emits: ["click", "change"],
          mixins: [c.default, d.default, l.default],
          data: function () {
            return {
              firstTime: !0,
              scrollLeft: 0,
              scrollViewWidth: 0,
              lineOffsetLeft: 0,
              tabsRect: { left: 0 },
              innerCurrent: 0,
              moving: !1,
            };
          },
          watch: {
            current: {
              immediate: !0,
              handler: function (t, e) {
                var a = this;
                t !== this.innerCurrent &&
                  ((this.innerCurrent = t),
                  this.$nextTick(function () {
                    a.resize();
                  }));
              },
            },
            list: function () {
              var t = this;
              this.$nextTick(function () {
                t.resize();
              });
            },
          },
          computed: {
            textStyle: function () {
              var t = this;
              return function (e) {
                var a = {},
                  o =
                    e == t.innerCurrent
                      ? t.$uv.addStyle(t.activeStyle)
                      : t.$uv.addStyle(t.inactiveStyle);
                return (
                  t.list[e].disabled && (a.color = "#c8c9cc"),
                  t.$uv.deepMerge(o, a)
                );
              };
            },
            propsBadge: function () {
              return u.default;
            },
          },
          mounted: function () {
            var t = this;
            return (0, s.default)(
              (0, n.default)().mark(function e() {
                return (0, n.default)().wrap(function (e) {
                  while (1)
                    switch ((e.prev = e.next)) {
                      case 0:
                        t.init();
                      case 1:
                      case "end":
                        return e.stop();
                    }
                }, e);
              }),
            )();
          },
          methods: {
            setLineLeft: function () {
              var t = this,
                e = this.list[this.innerCurrent];
              if (e) {
                var a = this.list.slice(0, this.innerCurrent).reduce(function (
                    t,
                    e,
                  ) {
                    return t + e.rect.width;
                  }, 0),
                  o = this.$uv.getPx(this.lineWidth);
                this.$uv.test.number(this.lineWidth) &&
                  this.$uv.unit &&
                  (o = this.$uv.getPx(
                    "".concat(this.lineWidth).concat(this.$uv.unit),
                  )),
                  (this.lineOffsetLeft = a + (e.rect.width - o) / 2),
                  this.firstTime &&
                    setTimeout(function () {
                      t.firstTime = !1;
                    }, 20);
              }
            },
            animation: function (t) {},
            clickHandler: function (t, e) {
              var a = this;
              this.$emit(
                "click",
                (0, r.default)((0, r.default)({}, t), {}, { index: e }),
              ),
                t.disabled ||
                  (this.innerCurrent != e &&
                    this.$emit(
                      "change",
                      (0, r.default)((0, r.default)({}, t), {}, { index: e }),
                    ),
                  (this.innerCurrent = e),
                  this.$nextTick(function () {
                    a.resize();
                  }));
            },
            init: function () {
              var t = this;
              this.$uv.sleep().then(function () {
                t.resize();
              });
            },
            setScrollLeft: function () {
              var t = this.list[this.innerCurrent],
                e = this.list.slice(0, this.innerCurrent).reduce(function (
                  t,
                  e,
                ) {
                  return t + e.rect.width;
                }, 0),
                a = this.$uv.sys().windowWidth,
                o =
                  e -
                  (this.tabsRect.width - t.rect.width) / 2 -
                  (a - this.tabsRect.right) / 2 +
                  this.tabsRect.left / 2;
              (o = Math.min(o, this.scrollViewWidth - this.tabsRect.width)),
                (this.scrollLeft = Math.max(0, o));
            },
            resize: function () {
              var t = this;
              0 !== this.list.length &&
                Promise.all([this.getTabsRect(), this.getAllItemRect()]).then(
                  function (e) {
                    var a = (0, i.default)(e, 2),
                      o = a[0],
                      r = a[1],
                      n = void 0 === r ? [] : r;
                    (t.tabsRect = o),
                      (t.scrollViewWidth = 0),
                      n.map(function (e, a) {
                        (t.scrollViewWidth += e.width), (t.list[a].rect = e);
                      }),
                      t.setLineLeft(),
                      t.setScrollLeft();
                  },
                );
            },
            getTabsRect: function () {
              var t = this;
              return new Promise(function (e) {
                t.queryRect("uv-tabs__wrapper__scroll-view").then(function (t) {
                  return e(t);
                });
              });
            },
            getAllItemRect: function () {
              var t = this;
              return new Promise(function (e) {
                var a = t.list.map(function (e, a) {
                  return t.queryRect(
                    "uv-tabs__wrapper__nav__item-".concat(a),
                    !0,
                  );
                });
                Promise.all(a).then(function (t) {
                  return e(t);
                });
              });
            },
            queryRect: function (t, e) {
              var a = this;
              return new Promise(function (e) {
                a.$uvGetRect(".".concat(t)).then(function (t) {
                  e(t);
                });
              });
            },
          },
        };
      e.default = _;
    },
    "28f5": function (t, e, a) {
      "use strict";
      a.d(e, "b", function () {
        return i;
      }),
        a.d(e, "c", function () {
          return r;
        }),
        a.d(e, "a", function () {
          return o;
        });
      var o = { uvBadge: a("0261").default },
        i = function () {
          var t = this,
            e = t.$createElement,
            a = t._self._c || e;
          return a(
            "v-uni-view",
            { staticClass: "uv-tabs", style: [t.$uv.addStyle(t.customStyle)] },
            [
              a(
                "v-uni-view",
                { staticClass: "uv-tabs__wrapper" },
                [
                  t._t("left"),
                  a(
                    "v-uni-view",
                    { staticClass: "uv-tabs__wrapper__scroll-view-wrapper" },
                    [
                      a(
                        "v-uni-scroll-view",
                        {
                          ref: "uv-tabs__wrapper__scroll-view",
                          staticClass: "uv-tabs__wrapper__scroll-view",
                          attrs: {
                            "scroll-x": t.scrollable,
                            "scroll-left": t.scrollLeft,
                            "scroll-with-animation": !0,
                            "show-scrollbar": !1,
                          },
                        },
                        [
                          a(
                            "v-uni-view",
                            {
                              ref: "uv-tabs__wrapper__nav",
                              staticClass: "uv-tabs__wrapper__nav",
                              style: { flex: t.scrollable ? "" : 1 },
                            },
                            [
                              t._l(t.list, function (e, o) {
                                return a(
                                  "v-uni-view",
                                  {
                                    key: o,
                                    ref: "uv-tabs__wrapper__nav__item-" + o,
                                    refInFor: !0,
                                    staticClass: "uv-tabs__wrapper__nav__item",
                                    class: [
                                      "uv-tabs__wrapper__nav__item-" + o,
                                      e.disabled &&
                                        "uv-tabs__wrapper__nav__item--disabled",
                                    ],
                                    style: [
                                      { flex: t.scrollable ? "" : 1 },
                                      t.$uv.addStyle(t.itemStyle),
                                    ],
                                    on: {
                                      click: function (a) {
                                        (arguments[0] = a = t.$handleEvent(a)),
                                          t.clickHandler(e, o);
                                      },
                                    },
                                  },
                                  [
                                    a(
                                      "v-uni-text",
                                      {
                                        staticClass:
                                          "uv-tabs__wrapper__nav__item__text",
                                        class: [
                                          e.disabled &&
                                            "uv-tabs__wrapper__nav__item__text--disabled",
                                        ],
                                        style: [t.textStyle(o)],
                                      },
                                      [t._v(t._s(e[t.keyName]))],
                                    ),
                                    a("uv-badge", {
                                      attrs: {
                                        show: !(
                                          !e.badge ||
                                          !(
                                            e.badge.show ||
                                            e.badge.isDot ||
                                            e.badge.value
                                          )
                                        ),
                                        isDot:
                                          (e.badge && e.badge.isDot) ||
                                          t.propsBadge.isDot,
                                        value:
                                          (e.badge && e.badge.value) ||
                                          t.propsBadge.value,
                                        max:
                                          (e.badge && e.badge.max) ||
                                          t.propsBadge.max,
                                        type:
                                          (e.badge && e.badge.type) ||
                                          t.propsBadge.type,
                                        showZero:
                                          (e.badge && e.badge.showZero) ||
                                          t.propsBadge.showZero,
                                        bgColor:
                                          (e.badge && e.badge.bgColor) ||
                                          t.propsBadge.bgColor,
                                        color:
                                          (e.badge && e.badge.color) ||
                                          t.propsBadge.color,
                                        shape:
                                          (e.badge && e.badge.shape) ||
                                          t.propsBadge.shape,
                                        numberType:
                                          (e.badge && e.badge.numberType) ||
                                          t.propsBadge.numberType,
                                        inverted:
                                          (e.badge && e.badge.inverted) ||
                                          t.propsBadge.inverted,
                                        customStyle: "margin-left: 4px;",
                                      },
                                    }),
                                  ],
                                  1,
                                );
                              }),
                              a("v-uni-view", {
                                ref: "uv-tabs__wrapper__nav__line",
                                staticClass: "uv-tabs__wrapper__nav__line",
                                style: [
                                  {
                                    width: t.$uv.addUnit(t.lineWidth),
                                    transform:
                                      "translate(" + t.lineOffsetLeft + "px)",
                                    transitionDuration:
                                      (t.firstTime ? 0 : t.duration) + "ms",
                                    height: t.firstTime
                                      ? 0
                                      : t.$uv.addUnit(t.lineHeight),
                                    background: t.lineColor,
                                    backgroundSize: t.lineBgSize,
                                  },
                                ],
                              }),
                            ],
                            2,
                          ),
                        ],
                        1,
                      ),
                    ],
                    1,
                  ),
                  t._t("right"),
                ],
                2,
              ),
            ],
            1,
          );
        },
        r = [];
    },
    "2b48": function (t, e, a) {
      "use strict";
      a.r(e);
      var o = a("28f5"),
        i = a("39c1");
      for (var r in i)
        ["default"].indexOf(r) < 0 &&
          (function (t) {
            a.d(e, t, function () {
              return i[t];
            });
          })(r);
      a("45c0");
      var n = a("828b"),
        s = Object(n["a"])(
          i["default"],
          o["b"],
          o["c"],
          !1,
          null,
          "6f5b1fc6",
          null,
          !1,
          o["a"],
          void 0,
        );
      e["default"] = s.exports;
    },
    3105: function (t, e, a) {
      var o = a("c86c");
      (e = o(!1)),
        e.push([
          t.i,
          '@charset "UTF-8";\r\n/**\r\n * 这里是uni-app内置的常用样式变量\r\n *\r\n * uni-app 官方扩展插件及插件市场（https://ext.dcloud.net.cn）上很多三方插件均使用了这些样式变量\r\n * 如果你是插件开发者，建议你使用scss预处理，并在插件代码中直接使用这些变量（无需 import 这个文件），方便用户通过搭积木的方式开发整体风格一致的App\r\n *\r\n */\r\n/**\r\n * 如果你是App开发者（插件使用者），你可以通过修改这些变量来定制自己的插件主题，实现自定义主题功能\r\n *\r\n * 如果你的项目同样使用了scss预处理，你也可以直接在你的 scss 代码中使用如下变量，同时无需 import 这个文件\r\n */\r\n/* 颜色变量 */\r\n/* 行为相关颜色 */\r\n/* 文字基本颜色 */\r\n/* 背景颜色 */\r\n/* 边框颜色 */\r\n/* 尺寸变量 */\r\n/* 文字尺寸 */\r\n/* 图片尺寸 */\r\n/* Border Radius */\r\n/* 水平间距 */\r\n/* 垂直间距 */\r\n/* 透明度 */\r\n/* 文章场景相关 */uni-view[data-v-6f5b1fc6], uni-scroll-view[data-v-6f5b1fc6], uni-swiper-item[data-v-6f5b1fc6]{display:flex;flex-direction:column;flex-shrink:0;flex-grow:0;flex-basis:auto;align-items:stretch;align-content:flex-start}.uv-tabs__wrapper[data-v-6f5b1fc6]{display:flex;flex-direction:row;align-items:center}.uv-tabs__wrapper__scroll-view-wrapper[data-v-6f5b1fc6]{flex:1;overflow:auto hidden}.uv-tabs__wrapper__scroll-view[data-v-6f5b1fc6]{display:flex;flex-direction:row;flex:1}.uv-tabs__wrapper__nav[data-v-6f5b1fc6]{display:flex;flex-direction:row;position:relative}.uv-tabs__wrapper__nav__item[data-v-6f5b1fc6]{padding:0 11px;display:flex;flex-direction:row;align-items:center;justify-content:center}.uv-tabs__wrapper__nav__item--disabled[data-v-6f5b1fc6]{cursor:not-allowed}.uv-tabs__wrapper__nav__item__text[data-v-6f5b1fc6]{font-size:15px;color:#606266}.uv-tabs__wrapper__nav__item__text--disabled[data-v-6f5b1fc6]{color:#c8c9cc!important}.uv-tabs__wrapper__nav__line[data-v-6f5b1fc6]{height:3px;background:#3c9cff;width:30px;position:absolute;bottom:2px;border-radius:100px;transition-property:-webkit-transform;transition-property:transform;transition-property:transform,-webkit-transform;transition-duration:.3s}',
          "",
        ]),
        (t.exports = e);
    },
    "39c1": function (t, e, a) {
      "use strict";
      a.r(e);
      var o = a("05c2"),
        i = a.n(o);
      for (var r in o)
        ["default"].indexOf(r) < 0 &&
          (function (t) {
            a.d(e, t, function () {
              return o[t];
            });
          })(r);
      e["default"] = i.a;
    },
    "410f": function (t, e, a) {
      var o = a("f6c4");
      o.__esModule && (o = o.default),
        "string" === typeof o && (o = [[t.i, o, ""]]),
        o.locals && (t.exports = o.locals);
      var i = a("967d").default;
      i("187ee272", o, !0, { sourceMap: !1, shadowMode: !1 });
    },
    "45c0": function (t, e, a) {
      "use strict";
      var o = a("62a9"),
        i = a.n(o);
      i.a;
    },
    "62a9": function (t, e, a) {
      var o = a("3105");
      o.__esModule && (o = o.default),
        "string" === typeof o && (o = [[t.i, o, ""]]),
        o.locals && (t.exports = o.locals);
      var i = a("967d").default;
      i("0bdeecc7", o, !0, { sourceMap: !1, shadowMode: !1 });
    },
    7689: function (t, e, a) {
      "use strict";
      a("6a54");
      var o = a("f5bd").default;
      Object.defineProperty(e, "__esModule", { value: !0 }),
        (e.default = void 0),
        a("64aa");
      var i,
        r,
        n = o(a("9b1b")),
        s = {
          props: (0, n.default)(
            {
              duration: { type: Number, default: 300 },
              list: {
                type: Array,
                default: function () {
                  return [];
                },
              },
              lineColor: { type: String, default: "#3c9cff" },
              activeStyle: {
                type: [String, Object],
                default: function () {
                  return { color: "#303133" };
                },
              },
              inactiveStyle: {
                type: [String, Object],
                default: function () {
                  return { color: "#606266" };
                },
              },
              lineWidth: { type: [String, Number], default: 20 },
              lineHeight: { type: [String, Number], default: 3 },
              lineBgSize: { type: String, default: "cover" },
              itemStyle: {
                type: [String, Object],
                default: function () {
                  return { height: "44px" };
                },
              },
              scrollable: { type: Boolean, default: !0 },
              current: { type: [Number, String], default: 0 },
              keyName: { type: String, default: "name" },
            },
            null === (i = uni.$uv) ||
              void 0 === i ||
              null === (r = i.props) ||
              void 0 === r
              ? void 0
              : r.tabs,
          ),
        };
      e.default = s;
    },
    "8bcb": function (t, e, a) {
      "use strict";
      a.r(e);
      var o = a("f007"),
        i = a("0316");
      for (var r in i)
        ["default"].indexOf(r) < 0 &&
          (function (t) {
            a.d(e, t, function () {
              return i[t];
            });
          })(r);
      a("b7d1");
      var n = a("828b"),
        s = Object(n["a"])(
          i["default"],
          o["b"],
          o["c"],
          !1,
          null,
          "44aebc55",
          null,
          !1,
          o["a"],
          void 0,
        );
      e["default"] = s.exports;
    },
    b7d1: function (t, e, a) {
      "use strict";
      var o = a("410f"),
        i = a.n(o);
      i.a;
    },
    ba1c: function (t, e, a) {
      "use strict";
      a("6a54");
      var o = a("f5bd").default;
      Object.defineProperty(e, "__esModule", { value: !0 }),
        (e.default = void 0);
      var i = o(a("39d8"));
      a("5c47"), a("e838"), a("bf0f"), a("2797"), a("a1c1");
      var r,
        n = a("e74a"),
        s =
          (o(a("2609")),
          {
            data: function () {
              return {
                gridShow: !1,
                emoShow: !1,
                id: 0,
                server_name: "",
                content: "",
                send_msg: "",
                user_id: 0,
                user: [],
                info: [],
                log: [],
                emoji: [],
                pics: [],
                msg: "",
                standHeight: 15,
                current: 0,
                log_kefu_list: [],
                log_kefu_log: [],
                log_kefu_id: 0,
              };
            },
            onLoad: function (t) {
              (this.id = t.id), this.getMobileKefuLogList();
            },
            onShow: function () {},
            onPullDownRefresh: function () {
              var t = this;
              uni.showLoading({ title: "刷新中" }),
                setTimeout(function () {
                  uni.hideLoading(),
                    t.getMobileKefuLogList(),
                    uni.showToast({ title: "刷新成功", duration: 1e3 }),
                    uni.stopPullDownRefresh();
                }, 300);
            },
            methods:
              ((r = {
                changeTabs: function (t) {
                  this.current = t.index;
                },
                getHeight: function () {
                  var t = this;
                  this.$nextTick(function () {
                    var e = uni.createSelectorQuery().in(t);
                    e.select("#standHeight")
                      .boundingClientRect(function (e) {
                        (t.standHeight = parseFloat(e.height) + 55),
                          t.scrollToBottom();
                      })
                      .exec();
                  });
                },
                hideGrid: function () {
                  (this.emoShow = !1), (this.gridShow = !1), this.getHeight();
                },
                toggleGrid: function () {
                  (this.gridShow = !this.gridShow),
                    (this.emoShow = !1),
                    this.getHeight();
                },
                emoGrid: function () {
                  (this.emoShow = !this.emoShow),
                    (this.gridShow = !1),
                    this.getHeight();
                },
                orderPopShow: function () {
                  this.$refs.orderPop.open();
                },
                TransferPopShow: function () {
                  this.$refs.transferPop.open();
                },
                close: function () {
                  this.$refs.orderPop.close(), this.$refs.transferPop.close();
                },
              }),
              (0, i.default)(r, "changeTabs", function (t) {
                (this.current = t.index),
                  (this.log_kefu_id = t.id),
                  this.getMobileKefuLogList();
              }),
              (0, i.default)(r, "getMobileKefuLogList", function () {
                var t = this,
                  e = this;
                (0, n.send)(
                  "/wechat/Chat/getMobileKefuLogList",
                  { chat_id: this.id, log_kefu_id: this.log_kefu_id },
                  !1,
                ).then(function (a) {
                  var o = a.status,
                    i = a.msg,
                    r = a.data;
                  if (1 != o) return uni.$uv.toast(i);
                  (t.log_kefu_list = r.kefu_list),
                    (t.log_kefu_log = r.log.log),
                    (t.user = r.user),
                    (t.emoji = r.emoji),
                    t.log_kefu_log.forEach(function (t, a) {
                      1 == t.type && (t.content = e.handleMessageText(t));
                    });
                });
              }),
              (0, i.default)(r, "handleMessageText", function (t) {
                var e = {};
                this.emoji.forEach(function (t) {
                  e[t.name] = t.path;
                });
                var a = t.content.replace(/\[([^\s\]]+?)\]/g, function (t, a) {
                  var o = "[".concat(a, "]");
                  return e[o]
                    ? '<img class="emoji-img" style="display:inline-block;width:22px;height:22px;margin-left:3px;position: relative;top: 3px;" alt="' +
                        a +
                        '" title="' +
                        a +
                        '" src="' +
                        e[o] +
                        '">'
                    : t;
                });
                return a;
              }),
              (0, i.default)(r, "preImg", function (t) {
                uni.previewImage({ current: t, urls: [t] });
              }),
              (0, i.default)(r, "jump", function (t) {
                uni.navigateTo({ url: t });
              }),
              r),
          });
      e.default = s;
    },
    f007: function (t, e, a) {
      "use strict";
      a.d(e, "b", function () {
        return i;
      }),
        a.d(e, "c", function () {
          return r;
        }),
        a.d(e, "a", function () {
          return o;
        });
      var o = {
          uvIcon: a("1a07").default,
          uvTabs: a("2b48").default,
          uvParse: a("c96a").default,
        },
        i = function () {
          var t = this,
            e = t.$createElement,
            a = t._self._c || e;
          return a(
            "v-uni-view",
            { staticClass: "content" },
            [
              a(
                "v-uni-view",
                { staticClass: "top_box" },
                [
                  a("uv-icon", {
                    attrs: { name: "arrow-left", color: "#000", size: "18" },
                    on: {
                      click: function (e) {
                        (arguments[0] = e = t.$handleEvent(e)), t.jumpRuturn();
                      },
                    },
                  }),
                  a("v-uni-view", { staticClass: "name u-line-1" }, [
                    t._v(t._s(t.info.user_nickname)),
                  ]),
                ],
                1,
              ),
              a(
                "v-uni-view",
                { staticClass: "tabs_box" },
                [
                  a("uv-tabs", {
                    attrs: {
                      current: t.current,
                      list: t.log_kefu_list,
                      lineColor: "#000",
                      activeStyle: {
                        color: "#000",
                        fontWeight: "bold",
                        transform: "scale(1.02)",
                      },
                      scrollable: !0,
                    },
                    on: {
                      change: function (e) {
                        (arguments[0] = e = t.$handleEvent(e)),
                          t.changeTabs.apply(void 0, arguments);
                      },
                    },
                  }),
                ],
                1,
              ),
              a(
                "v-uni-view",
                { staticClass: "good_card", staticStyle: { display: "none" } },
                [
                  a(
                    "v-uni-view",
                    { staticClass: "order_num_box flex_box" },
                    [
                      a(
                        "v-uni-view",
                        {
                          staticClass: "order_num flex_box",
                          on: {
                            click: function (e) {
                              (arguments[0] = e = t.$handleEvent(e)),
                                t.copyOrderNum(t.info.order_no);
                            },
                          },
                        },
                        [
                          a("v-uni-view", {}, [t._v("订单编号：")]),
                          a("v-uni-view", { staticClass: "num" }, [
                            t._v(t._s(t.info.order_no)),
                          ]),
                          a("v-uni-view", { staticClass: "copy_btn" }, [
                            t._v("复制"),
                          ]),
                        ],
                        1,
                      ),
                      a("v-uni-view", { staticClass: "status" }, [
                        t._v(t._s(t.info.status_text)),
                      ]),
                    ],
                    1,
                  ),
                  a(
                    "v-uni-view",
                    { staticClass: "msg_box" },
                    [
                      a(
                        "v-uni-view",
                        { staticClass: "goods_msg flex_box" },
                        [
                          a("img", {
                            staticClass: "img",
                            attrs: {
                              src: "https://qshp.pw.mao07.tech/uploads/20250211/Flwil22P-Zq9C3TX55m8yjGxLa1A.jpg",
                            },
                          }),
                          a(
                            "v-uni-view",
                            { staticClass: "txt" },
                            [
                              a(
                                "v-uni-view",
                                { staticClass: "price_box flex_box" },
                                [
                                  a(
                                    "v-uni-view",
                                    { staticClass: "price" },
                                    [
                                      a("v-uni-text", { staticClass: "unit" }, [
                                        t._v("￥"),
                                      ]),
                                      a("v-uni-text", [t._v("19.9")]),
                                    ],
                                    1,
                                  ),
                                  a("v-uni-view", { staticClass: "num" }, [
                                    t._v("x 1"),
                                  ]),
                                ],
                                1,
                              ),
                              a(
                                "v-uni-view",
                                { staticClass: "name uv-line-2" },
                                [t._v("火焰刀")],
                              ),
                              a(
                                "v-uni-view",
                                { staticClass: "intro uv-line-2" },
                                [
                                  t._v(
                                    "每日体验单【随机送2把火焰刀】每日体验单【随机送2把火焰刀】每日体验单【随机送2把火焰刀】每日体验单【随机送2把火焰刀】",
                                  ),
                                ],
                              ),
                            ],
                            1,
                          ),
                        ],
                        1,
                      ),
                      a(
                        "v-uni-view",
                        { staticClass: "tips flex_box" },
                        [
                          a("v-uni-view", { staticClass: "tit" }, [
                            t._v("实付款"),
                          ]),
                          a(
                            "v-uni-view",
                            { staticClass: "price" },
                            [
                              a("v-uni-text", { staticClass: "unit" }, [
                                t._v("￥"),
                              ]),
                              a("v-uni-text", [t._v("16.8")]),
                            ],
                            1,
                          ),
                        ],
                        1,
                      ),
                      a(
                        "v-uni-view",
                        { staticClass: "tips flex_box" },
                        [
                          a("v-uni-view", { staticClass: "tit" }, [
                            t._v("游戏ID"),
                          ]),
                          a(
                            "v-uni-view",
                            [
                              t._v("22223333333333 "),
                              a("v-uni-text", { staticClass: "copy_btn" }, [
                                t._v("复制"),
                              ]),
                            ],
                            1,
                          ),
                        ],
                        1,
                      ),
                      a(
                        "v-uni-view",
                        { staticClass: "tips flex_box" },
                        [
                          a("v-uni-view", { staticClass: "tit" }, [
                            t._v("文字ID"),
                          ]),
                          a(
                            "v-uni-view",
                            [
                              t._v("55558888888 "),
                              a("v-uni-text", { staticClass: "copy_btn" }, [
                                t._v("复制"),
                              ]),
                            ],
                            1,
                          ),
                        ],
                        1,
                      ),
                    ],
                    1,
                  ),
                ],
                1,
              ),
              a(
                "v-uni-view",
                { staticClass: "chat_box" },
                [
                  t._l(t.log_kefu_log, function (e, o) {
                    return [
                      -1 == e.type
                        ? a(
                            "v-uni-view",
                            { key: o + "_0", staticClass: "time" },
                            [t._v(t._s(e.display_time))],
                          )
                        : 4 == e.type
                          ? a("v-uni-view", { staticClass: "time" }, [
                              t._v(t._s(e.content)),
                            ])
                          : [
                              2 != e.from
                                ? [
                                    a(
                                      "v-uni-view",
                                      { staticClass: "haoyou_box" },
                                      [
                                        a("img", {
                                          staticClass: "head",
                                          attrs: { src: e.avatar, alt: "" },
                                        }),
                                        1 == e.type
                                          ? a("uv-parse", {
                                              staticClass: "qipao",
                                              attrs: {
                                                content: e.content,
                                                "preview-img": !1,
                                                selectable: !0,
                                              },
                                            })
                                          : t._e(),
                                        2 == e.type
                                          ? a("img", {
                                              staticClass: "tu",
                                              attrs: {
                                                src: e.content,
                                                alt: "",
                                              },
                                              on: {
                                                click: function (a) {
                                                  (arguments[0] = a =
                                                    t.$handleEvent(a)),
                                                    t.preImg(e.content);
                                                },
                                              },
                                            })
                                          : t._e(),
                                        3 == e.type && e.order
                                          ? a(
                                              "v-uni-view",
                                              {
                                                staticClass: "order_card",
                                                on: {
                                                  click: function (a) {
                                                    (arguments[0] = a =
                                                      t.$handleEvent(a)),
                                                      t.jump(
                                                        "/pages_sub1/kefu/info?id=" +
                                                          e.order.id,
                                                      );
                                                  },
                                                },
                                              },
                                              [
                                                a(
                                                  "v-uni-view",
                                                  {
                                                    staticClass:
                                                      "con_box flex_box",
                                                  },
                                                  [
                                                    a("img", {
                                                      staticClass: "img",
                                                      attrs: {
                                                        src: e.order
                                                          .goods_thumb,
                                                      },
                                                    }),
                                                    a(
                                                      "v-uni-view",
                                                      { staticClass: "tit" },
                                                      [
                                                        a(
                                                          "v-uni-view",
                                                          {
                                                            staticClass:
                                                              "name to-line-1",
                                                          },
                                                          [
                                                            t._v(
                                                              " " +
                                                                t._s(
                                                                  e.order
                                                                    .goods_name,
                                                                ) +
                                                                " ",
                                                            ),
                                                          ],
                                                        ),
                                                        a(
                                                          "v-uni-view",
                                                          {
                                                            staticClass:
                                                              "status",
                                                          },
                                                          [
                                                            t._v(
                                                              t._s(
                                                                e.order
                                                                  .status_text,
                                                              ),
                                                            ),
                                                          ],
                                                        ),
                                                      ],
                                                      1,
                                                    ),
                                                  ],
                                                  1,
                                                ),
                                                a(
                                                  "v-uni-view",
                                                  { staticClass: "order_box" },
                                                  [
                                                    a(
                                                      "v-uni-view",
                                                      {
                                                        staticClass:
                                                          "order_num",
                                                      },
                                                      [
                                                        t._v(
                                                          "订单编号: " +
                                                            t._s(
                                                              e.order.order_no,
                                                            ),
                                                        ),
                                                      ],
                                                    ),
                                                  ],
                                                  1,
                                                ),
                                              ],
                                              1,
                                            )
                                          : t._e(),
                                      ],
                                      1,
                                    ),
                                  ]
                                : t._e(),
                              2 == e.from
                                ? [
                                    a(
                                      "v-uni-view",
                                      { staticClass: "wo_box" },
                                      [
                                        1 == e.type
                                          ? a("uv-parse", {
                                              staticClass: "qipao",
                                              attrs: {
                                                content: e.content,
                                                "preview-img": !1,
                                                selectable: !0,
                                              },
                                            })
                                          : t._e(),
                                        2 == e.type
                                          ? a("img", {
                                              staticClass: "tu",
                                              attrs: {
                                                src: e.content,
                                                alt: "",
                                              },
                                              on: {
                                                click: function (a) {
                                                  (arguments[0] = a =
                                                    t.$handleEvent(a)),
                                                    t.preImg(e.content);
                                                },
                                              },
                                            })
                                          : t._e(),
                                        a("img", {
                                          staticClass: "head",
                                          attrs: {
                                            src: e.kefu_avatar,
                                            alt: "",
                                          },
                                        }),
                                      ],
                                      1,
                                    ),
                                  ]
                                : t._e(),
                            ],
                    ];
                  }),
                ],
                2,
              ),
            ],
            1,
          );
        },
        r = [];
    },
    f6c4: function (t, e, a) {
      var o = a("c86c");
      (e = o(!1)),
        e.push([
          t.i,
          '@charset "UTF-8";\r\n/**\r\n * 这里是uni-app内置的常用样式变量\r\n *\r\n * uni-app 官方扩展插件及插件市场（https://ext.dcloud.net.cn）上很多三方插件均使用了这些样式变量\r\n * 如果你是插件开发者，建议你使用scss预处理，并在插件代码中直接使用这些变量（无需 import 这个文件），方便用户通过搭积木的方式开发整体风格一致的App\r\n *\r\n */\r\n/**\r\n * 如果你是App开发者（插件使用者），你可以通过修改这些变量来定制自己的插件主题，实现自定义主题功能\r\n *\r\n * 如果你的项目同样使用了scss预处理，你也可以直接在你的 scss 代码中使用如下变量，同时无需 import 这个文件\r\n */\r\n/* 颜色变量 */\r\n/* 行为相关颜色 */\r\n/* 文字基本颜色 */\r\n/* 背景颜色 */\r\n/* 边框颜色 */\r\n/* 尺寸变量 */\r\n/* 文字尺寸 */\r\n/* 图片尺寸 */\r\n/* Border Radius */\r\n/* 水平间距 */\r\n/* 垂直间距 */\r\n/* 透明度 */\r\n/* 文章场景相关 */.content[data-v-44aebc55]{background:#f8f8f8;min-height:100vh;padding-top:%?120?%}.top_box[data-v-44aebc55]{position:fixed;top:0;left:0;right:0;z-index:10;padding:0 %?30?% 0 %?58?%;height:%?100?%;line-height:%?100?%;background:#fff;max-width:480px;width:100%;margin:0 auto}.top_box[data-v-44aebc55] .uv-icon{position:absolute;left:0;top:0;width:%?54?%;height:%?102?%;justify-content:center}.top_box .name[data-v-44aebc55]{font-size:16px;text-align:center}.tabs_box[data-v-44aebc55]{background:#fff;padding-bottom:%?10?%;border-top:%?2?% solid #eee;position:fixed;z-index:10;left:0;right:0;top:%?100?%;max-width:480px;width:100%;margin:0 auto}.good_card[data-v-44aebc55]{margin:%?30?% %?30?% 0;border-radius:%?10?%;box-shadow:0 0 %?20?% #ddd}.good_card .order_num_box[data-v-44aebc55]{padding:%?30?% 0;margin:0 %?30?%;border-bottom:%?2?% solid #eee}.good_card .order_num_box uni-view[data-v-44aebc55]{font-size:13px;white-space:nowrap}.good_card .order_num_box .order_num[data-v-44aebc55]{justify-content:flex-start;flex:1}.good_card .order_num_box .order_num .num[data-v-44aebc55]{font-weight:700}.good_card .order_num_box .order_num .copy_btn[data-v-44aebc55]{margin-left:%?12?%;color:#2979ff}.good_card .order_num_box .status[data-v-44aebc55]{font-size:12px;font-weight:700}.good_card .msg_box[data-v-44aebc55]{padding:0 %?30?%}.good_card .msg_box .goods_msg[data-v-44aebc55]{margin:%?35?% auto %?45?%;padding-bottom:%?4?%}.good_card .msg_box .goods_msg .img[data-v-44aebc55]{width:%?120?%;height:%?120?%;border-radius:%?10?%;position:relative;top:%?4?%}.good_card .msg_box .goods_msg .txt[data-v-44aebc55]{width:calc(100% - %?145?%)}.good_card .msg_box .goods_msg .txt .price_box .price[data-v-44aebc55]{color:#fd2c28;font-weight:700;font-size:18px}.good_card .msg_box .goods_msg .txt .price_box .price .unit[data-v-44aebc55]{font-size:13px}.good_card .msg_box .goods_msg .txt .name[data-v-44aebc55]{margin:%?6?% auto %?2?%;font-weight:700}.good_card .msg_box .goods_msg .txt .intro[data-v-44aebc55]{font-size:13px;color:#999}.good_card .msg_box .tips[data-v-44aebc55]{margin:%?28?% auto}.good_card .msg_box .tips uni-view[data-v-44aebc55]{color:#999;font-size:14.4px}.good_card .msg_box .tips .tit[data-v-44aebc55]{color:#444}.good_card .msg_box .tips .remark[data-v-44aebc55]{flex:1;text-align:right;margin-left:%?150?%}.good_card .msg_box .tips .copy_btn[data-v-44aebc55]{margin-left:%?14?%;color:#2979ff}.good_card .msg_box .tips .real_money[data-v-44aebc55]{color:#fd2c28;font-weight:700;font-size:15px}.good_card .msg_box .tips .real_money .unit[data-v-44aebc55]{font-size:11px}.good_card .msg_box .tips .price[data-v-44aebc55]{color:#fd2c28;font-weight:700;font-size:18px}.good_card .msg_box .tips .price .unit[data-v-44aebc55]{font-size:13px}.chat_box[data-v-44aebc55]{padding:0 %?30?% %?30?%;overflow-y:auto;\r\n  /* 兼容iPhoneX */margin-bottom:0;margin-bottom:constant(safe-area-inset-bottom);margin-bottom:env(safe-area-inset-bottom)}.chat_box .time[data-v-44aebc55]{text-align:center;font-size:12px;color:#9d9d9d;margin:%?48?% auto %?25?%}.chat_box .haoyou_box[data-v-44aebc55], .chat_box .wo_box[data-v-44aebc55]{display:flex;align-items:flex-start;justify-content:flex-start;margin:%?25?% 0}.chat_box .haoyou_box img[data-v-44aebc55], .chat_box .wo_box img[data-v-44aebc55]{margin:0}.chat_box .haoyou_box .head[data-v-44aebc55], .chat_box .wo_box .head[data-v-44aebc55]{width:%?84?%;height:%?84?%;border-radius:100%;margin:0 %?20?% 0 0}.chat_box .haoyou_box .qipao[data-v-44aebc55], .chat_box .wo_box .qipao[data-v-44aebc55]{margin-top:%?16?%;padding:%?16?% %?24?%;line-height:1.4;border-radius:0 %?25?% %?25?% %?25?%;background:#fff;max-width:calc(100% - %?208?%)}.chat_box .haoyou_box .tu[data-v-44aebc55], .chat_box .wo_box .tu[data-v-44aebc55]{width:%?165?%;height:%?165?%;margin-top:%?16?%}.chat_box .haoyou_box .order_card[data-v-44aebc55], .chat_box .wo_box .order_card[data-v-44aebc55]{background-color:#fff;padding:0 %?30?%;border-radius:%?10?%}.chat_box .haoyou_box .order_card[data-v-44aebc55]:last-child, .chat_box .wo_box .order_card[data-v-44aebc55]:last-child{border-bottom:none}.chat_box .haoyou_box .order_card .con_box[data-v-44aebc55], .chat_box .wo_box .order_card .con_box[data-v-44aebc55]{padding:%?26?% 0 %?18?%;margin-bottom:%?8?%}.chat_box .haoyou_box .order_card .con_box .img[data-v-44aebc55], .chat_box .wo_box .order_card .con_box .img[data-v-44aebc55]{width:%?114?%;height:%?114?%;margin:0;border-radius:%?10?%}.chat_box .haoyou_box .order_card .con_box .tit[data-v-44aebc55], .chat_box .wo_box .order_card .con_box .tit[data-v-44aebc55]{width:calc(100% - %?138?%)}.chat_box .haoyou_box .order_card .con_box .tit uni-view[data-v-44aebc55], .chat_box .wo_box .order_card .con_box .tit uni-view[data-v-44aebc55]{font-size:12.2px;color:#999}.chat_box .haoyou_box .order_card .con_box .tit .name[data-v-44aebc55], .chat_box .wo_box .order_card .con_box .tit .name[data-v-44aebc55]{color:#333;font-size:13px;font-weight:700;margin-top:%?2?%}.chat_box .haoyou_box .order_card .con_box .tit .status[data-v-44aebc55], .chat_box .wo_box .order_card .con_box .tit .status[data-v-44aebc55]{margin-top:%?25?%;color:red}.chat_box .haoyou_box .order_card .con_box .tit .des[data-v-44aebc55], .chat_box .wo_box .order_card .con_box .tit .des[data-v-44aebc55]{margin:%?6?% auto %?12?%}.chat_box .haoyou_box .order_card .con_box .tit .price_box .price[data-v-44aebc55], .chat_box .wo_box .order_card .con_box .tit .price_box .price[data-v-44aebc55]{color:#fd2c28}.chat_box .haoyou_box .order_card .order_box[data-v-44aebc55], .chat_box .wo_box .order_card .order_box[data-v-44aebc55]{border-top:%?2?% solid #eee;display:flex;justify-content:space-between;align-items:center;margin-bottom:%?22?%}.chat_box .haoyou_box .order_card .order_box .order_num[data-v-44aebc55], .chat_box .wo_box .order_card .order_box .order_num[data-v-44aebc55]{margin-top:%?8?%;color:#999;text-align:center;font-size:13px}.chat_box .haoyou_box .order_card .order_box .btn_box uni-view[data-v-44aebc55], .chat_box .wo_box .order_card .order_box .btn_box uni-view[data-v-44aebc55]{display:inline-block;float:right;background:#ffe610;color:#000;padding:0 %?20?%;min-width:%?130?%;text-align:center;font-size:11px;font-weight:700;height:%?56?%;line-height:%?56?%;border-radius:%?56?%;margin-left:%?26?%}.chat_box .haoyou_box .order_card .order_box .btn_box uni-view.cancel[data-v-44aebc55], .chat_box .wo_box .order_card .order_box .btn_box uni-view.cancel[data-v-44aebc55]{background:#eee;color:#777}.chat_box .wo_box[data-v-44aebc55]{justify-content:flex-end}.chat_box .wo_box .head[data-v-44aebc55]{margin:0 0 0 %?20?%}.chat_box .wo_box .qipao[data-v-44aebc55]{border-radius:%?25?% 0 %?25?% %?25?%}',
          "",
        ]),
        (t.exports = e);
    },
  },
]);
//# sourceMappingURL=pages_sub1-chat-history.555c56a6.js.map
