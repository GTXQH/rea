(window["webpackJsonp"] = window["webpackJsonp"] || []).push([
  ["pages-index-search"],
  {
    "05c2": function (t, e, i) {
      "use strict";
      i("6a54");
      var a = i("f5bd").default;
      Object.defineProperty(e, "__esModule", { value: !0 }),
        (e.default = void 0),
        i("473f"),
        i("bf0f"),
        i("f7a5"),
        i("5c47"),
        i("0506"),
        i("c223"),
        i("18f7"),
        i("de6c"),
        i("fd3c");
      var n = a(i("5de6")),
        s = a(i("9b1b")),
        r = a(i("2634")),
        o = a(i("2fdc")),
        l = a(i("4d8f0")),
        d = a(i("9463")),
        u = a(i("b92c")),
        c = a(i("7689")),
        f = {
          name: "uv-tabs",
          emits: ["click", "change"],
          mixins: [l.default, d.default, c.default],
          data: function () {
            return {
              firstTime: !0,
              scrollLeft: 0,
              scrollViewWidth: 0,
              lineOffsetLeft: 0,
              tabsRect: { left: 0 },
              innerCurrent: 0,
              moving: !1,
            };
          },
          watch: {
            current: {
              immediate: !0,
              handler: function (t, e) {
                var i = this;
                t !== this.innerCurrent &&
                  ((this.innerCurrent = t),
                  this.$nextTick(function () {
                    i.resize();
                  }));
              },
            },
            list: function () {
              var t = this;
              this.$nextTick(function () {
                t.resize();
              });
            },
          },
          computed: {
            textStyle: function () {
              var t = this;
              return function (e) {
                var i = {},
                  a =
                    e == t.innerCurrent
                      ? t.$uv.addStyle(t.activeStyle)
                      : t.$uv.addStyle(t.inactiveStyle);
                return (
                  t.list[e].disabled && (i.color = "#c8c9cc"),
                  t.$uv.deepMerge(a, i)
                );
              };
            },
            propsBadge: function () {
              return u.default;
            },
          },
          mounted: function () {
            var t = this;
            return (0, o.default)(
              (0, r.default)().mark(function e() {
                return (0, r.default)().wrap(function (e) {
                  while (1)
                    switch ((e.prev = e.next)) {
                      case 0:
                        t.init();
                      case 1:
                      case "end":
                        return e.stop();
                    }
                }, e);
              }),
            )();
          },
          methods: {
            setLineLeft: function () {
              var t = this,
                e = this.list[this.innerCurrent];
              if (e) {
                var i = this.list.slice(0, this.innerCurrent).reduce(function (
                    t,
                    e,
                  ) {
                    return t + e.rect.width;
                  }, 0),
                  a = this.$uv.getPx(this.lineWidth);
                this.$uv.test.number(this.lineWidth) &&
                  this.$uv.unit &&
                  (a = this.$uv.getPx(
                    "".concat(this.lineWidth).concat(this.$uv.unit),
                  )),
                  (this.lineOffsetLeft = i + (e.rect.width - a) / 2),
                  this.firstTime &&
                    setTimeout(function () {
                      t.firstTime = !1;
                    }, 20);
              }
            },
            animation: function (t) {},
            clickHandler: function (t, e) {
              var i = this;
              this.$emit(
                "click",
                (0, s.default)((0, s.default)({}, t), {}, { index: e }),
              ),
                t.disabled ||
                  (this.innerCurrent != e &&
                    this.$emit(
                      "change",
                      (0, s.default)((0, s.default)({}, t), {}, { index: e }),
                    ),
                  (this.innerCurrent = e),
                  this.$nextTick(function () {
                    i.resize();
                  }));
            },
            init: function () {
              var t = this;
              this.$uv.sleep().then(function () {
                t.resize();
              });
            },
            setScrollLeft: function () {
              var t = this.list[this.innerCurrent],
                e = this.list.slice(0, this.innerCurrent).reduce(function (
                  t,
                  e,
                ) {
                  return t + e.rect.width;
                }, 0),
                i = this.$uv.sys().windowWidth,
                a =
                  e -
                  (this.tabsRect.width - t.rect.width) / 2 -
                  (i - this.tabsRect.right) / 2 +
                  this.tabsRect.left / 2;
              (a = Math.min(a, this.scrollViewWidth - this.tabsRect.width)),
                (this.scrollLeft = Math.max(0, a));
            },
            resize: function () {
              var t = this;
              0 !== this.list.length &&
                Promise.all([this.getTabsRect(), this.getAllItemRect()]).then(
                  function (e) {
                    var i = (0, n.default)(e, 2),
                      a = i[0],
                      s = i[1],
                      r = void 0 === s ? [] : s;
                    (t.tabsRect = a),
                      (t.scrollViewWidth = 0),
                      r.map(function (e, i) {
                        (t.scrollViewWidth += e.width), (t.list[i].rect = e);
                      }),
                      t.setLineLeft(),
                      t.setScrollLeft();
                  },
                );
            },
            getTabsRect: function () {
              var t = this;
              return new Promise(function (e) {
                t.queryRect("uv-tabs__wrapper__scroll-view").then(function (t) {
                  return e(t);
                });
              });
            },
            getAllItemRect: function () {
              var t = this;
              return new Promise(function (e) {
                var i = t.list.map(function (e, i) {
                  return t.queryRect(
                    "uv-tabs__wrapper__nav__item-".concat(i),
                    !0,
                  );
                });
                Promise.all(i).then(function (t) {
                  return e(t);
                });
              });
            },
            queryRect: function (t, e) {
              var i = this;
              return new Promise(function (e) {
                i.$uvGetRect(".".concat(t)).then(function (t) {
                  e(t);
                });
              });
            },
          },
        };
      e.default = f;
    },
    "0da1": function (t, e, i) {
      var a = i("9d2e");
      a.__esModule && (a = a.default),
        "string" === typeof a && (a = [[t.i, a, ""]]),
        a.locals && (t.exports = a.locals);
      var n = i("967d").default;
      n("3abdb4ee", a, !0, { sourceMap: !1, shadowMode: !1 });
    },
    "28f5": function (t, e, i) {
      "use strict";
      i.d(e, "b", function () {
        return n;
      }),
        i.d(e, "c", function () {
          return s;
        }),
        i.d(e, "a", function () {
          return a;
        });
      var a = { uvBadge: i("0261").default },
        n = function () {
          var t = this,
            e = t.$createElement,
            i = t._self._c || e;
          return i(
            "v-uni-view",
            { staticClass: "uv-tabs", style: [t.$uv.addStyle(t.customStyle)] },
            [
              i(
                "v-uni-view",
                { staticClass: "uv-tabs__wrapper" },
                [
                  t._t("left"),
                  i(
                    "v-uni-view",
                    { staticClass: "uv-tabs__wrapper__scroll-view-wrapper" },
                    [
                      i(
                        "v-uni-scroll-view",
                        {
                          ref: "uv-tabs__wrapper__scroll-view",
                          staticClass: "uv-tabs__wrapper__scroll-view",
                          attrs: {
                            "scroll-x": t.scrollable,
                            "scroll-left": t.scrollLeft,
                            "scroll-with-animation": !0,
                            "show-scrollbar": !1,
                          },
                        },
                        [
                          i(
                            "v-uni-view",
                            {
                              ref: "uv-tabs__wrapper__nav",
                              staticClass: "uv-tabs__wrapper__nav",
                              style: { flex: t.scrollable ? "" : 1 },
                            },
                            [
                              t._l(t.list, function (e, a) {
                                return i(
                                  "v-uni-view",
                                  {
                                    key: a,
                                    ref: "uv-tabs__wrapper__nav__item-" + a,
                                    refInFor: !0,
                                    staticClass: "uv-tabs__wrapper__nav__item",
                                    class: [
                                      "uv-tabs__wrapper__nav__item-" + a,
                                      e.disabled &&
                                        "uv-tabs__wrapper__nav__item--disabled",
                                    ],
                                    style: [
                                      { flex: t.scrollable ? "" : 1 },
                                      t.$uv.addStyle(t.itemStyle),
                                    ],
                                    on: {
                                      click: function (i) {
                                        (arguments[0] = i = t.$handleEvent(i)),
                                          t.clickHandler(e, a);
                                      },
                                    },
                                  },
                                  [
                                    i(
                                      "v-uni-text",
                                      {
                                        staticClass:
                                          "uv-tabs__wrapper__nav__item__text",
                                        class: [
                                          e.disabled &&
                                            "uv-tabs__wrapper__nav__item__text--disabled",
                                        ],
                                        style: [t.textStyle(a)],
                                      },
                                      [t._v(t._s(e[t.keyName]))],
                                    ),
                                    i("uv-badge", {
                                      attrs: {
                                        show: !(
                                          !e.badge ||
                                          !(
                                            e.badge.show ||
                                            e.badge.isDot ||
                                            e.badge.value
                                          )
                                        ),
                                        isDot:
                                          (e.badge && e.badge.isDot) ||
                                          t.propsBadge.isDot,
                                        value:
                                          (e.badge && e.badge.value) ||
                                          t.propsBadge.value,
                                        max:
                                          (e.badge && e.badge.max) ||
                                          t.propsBadge.max,
                                        type:
                                          (e.badge && e.badge.type) ||
                                          t.propsBadge.type,
                                        showZero:
                                          (e.badge && e.badge.showZero) ||
                                          t.propsBadge.showZero,
                                        bgColor:
                                          (e.badge && e.badge.bgColor) ||
                                          t.propsBadge.bgColor,
                                        color:
                                          (e.badge && e.badge.color) ||
                                          t.propsBadge.color,
                                        shape:
                                          (e.badge && e.badge.shape) ||
                                          t.propsBadge.shape,
                                        numberType:
                                          (e.badge && e.badge.numberType) ||
                                          t.propsBadge.numberType,
                                        inverted:
                                          (e.badge && e.badge.inverted) ||
                                          t.propsBadge.inverted,
                                        customStyle: "margin-left: 4px;",
                                      },
                                    }),
                                  ],
                                  1,
                                );
                              }),
                              i("v-uni-view", {
                                ref: "uv-tabs__wrapper__nav__line",
                                staticClass: "uv-tabs__wrapper__nav__line",
                                style: [
                                  {
                                    width: t.$uv.addUnit(t.lineWidth),
                                    transform:
                                      "translate(" + t.lineOffsetLeft + "px)",
                                    transitionDuration:
                                      (t.firstTime ? 0 : t.duration) + "ms",
                                    height: t.firstTime
                                      ? 0
                                      : t.$uv.addUnit(t.lineHeight),
                                    background: t.lineColor,
                                    backgroundSize: t.lineBgSize,
                                  },
                                ],
                              }),
                            ],
                            2,
                          ),
                        ],
                        1,
                      ),
                    ],
                    1,
                  ),
                  t._t("right"),
                ],
                2,
              ),
            ],
            1,
          );
        },
        s = [];
    },
    "2b48": function (t, e, i) {
      "use strict";
      i.r(e);
      var a = i("28f5"),
        n = i("39c1");
      for (var s in n)
        ["default"].indexOf(s) < 0 &&
          (function (t) {
            i.d(e, t, function () {
              return n[t];
            });
          })(s);
      i("45c0");
      var r = i("828b"),
        o = Object(r["a"])(
          n["default"],
          a["b"],
          a["c"],
          !1,
          null,
          "6f5b1fc6",
          null,
          !1,
          a["a"],
          void 0,
        );
      e["default"] = o.exports;
    },
    3105: function (t, e, i) {
      var a = i("c86c");
      (e = a(!1)),
        e.push([
          t.i,
          '@charset "UTF-8";\r\n/**\r\n * 这里是uni-app内置的常用样式变量\r\n *\r\n * uni-app 官方扩展插件及插件市场（https://ext.dcloud.net.cn）上很多三方插件均使用了这些样式变量\r\n * 如果你是插件开发者，建议你使用scss预处理，并在插件代码中直接使用这些变量（无需 import 这个文件），方便用户通过搭积木的方式开发整体风格一致的App\r\n *\r\n */\r\n/**\r\n * 如果你是App开发者（插件使用者），你可以通过修改这些变量来定制自己的插件主题，实现自定义主题功能\r\n *\r\n * 如果你的项目同样使用了scss预处理，你也可以直接在你的 scss 代码中使用如下变量，同时无需 import 这个文件\r\n */\r\n/* 颜色变量 */\r\n/* 行为相关颜色 */\r\n/* 文字基本颜色 */\r\n/* 背景颜色 */\r\n/* 边框颜色 */\r\n/* 尺寸变量 */\r\n/* 文字尺寸 */\r\n/* 图片尺寸 */\r\n/* Border Radius */\r\n/* 水平间距 */\r\n/* 垂直间距 */\r\n/* 透明度 */\r\n/* 文章场景相关 */uni-view[data-v-6f5b1fc6], uni-scroll-view[data-v-6f5b1fc6], uni-swiper-item[data-v-6f5b1fc6]{display:flex;flex-direction:column;flex-shrink:0;flex-grow:0;flex-basis:auto;align-items:stretch;align-content:flex-start}.uv-tabs__wrapper[data-v-6f5b1fc6]{display:flex;flex-direction:row;align-items:center}.uv-tabs__wrapper__scroll-view-wrapper[data-v-6f5b1fc6]{flex:1;overflow:auto hidden}.uv-tabs__wrapper__scroll-view[data-v-6f5b1fc6]{display:flex;flex-direction:row;flex:1}.uv-tabs__wrapper__nav[data-v-6f5b1fc6]{display:flex;flex-direction:row;position:relative}.uv-tabs__wrapper__nav__item[data-v-6f5b1fc6]{padding:0 11px;display:flex;flex-direction:row;align-items:center;justify-content:center}.uv-tabs__wrapper__nav__item--disabled[data-v-6f5b1fc6]{cursor:not-allowed}.uv-tabs__wrapper__nav__item__text[data-v-6f5b1fc6]{font-size:15px;color:#606266}.uv-tabs__wrapper__nav__item__text--disabled[data-v-6f5b1fc6]{color:#c8c9cc!important}.uv-tabs__wrapper__nav__line[data-v-6f5b1fc6]{height:3px;background:#3c9cff;width:30px;position:absolute;bottom:2px;border-radius:100px;transition-property:-webkit-transform;transition-property:transform;transition-property:transform,-webkit-transform;transition-duration:.3s}',
          "",
        ]),
        (t.exports = e);
    },
    "31a4": function (t, e, i) {
      "use strict";
      i.r(e);
      var a = i("758f"),
        n = i("da6d");
      for (var s in n)
        ["default"].indexOf(s) < 0 &&
          (function (t) {
            i.d(e, t, function () {
              return n[t];
            });
          })(s);
      i("cc5d");
      var r = i("828b"),
        o = Object(r["a"])(
          n["default"],
          a["b"],
          a["c"],
          !1,
          null,
          "3f647a98",
          null,
          !1,
          a["a"],
          void 0,
        );
      e["default"] = o.exports;
    },
    3744: function (t, e, i) {
      t.exports = i.p + "static/vip.png";
    },
    "39c1": function (t, e, i) {
      "use strict";
      i.r(e);
      var a = i("05c2"),
        n = i.n(a);
      for (var s in a)
        ["default"].indexOf(s) < 0 &&
          (function (t) {
            i.d(e, t, function () {
              return a[t];
            });
          })(s);
      e["default"] = n.a;
    },
    "45c0": function (t, e, i) {
      "use strict";
      var a = i("62a9"),
        n = i.n(a);
      n.a;
    },
    "62a9": function (t, e, i) {
      var a = i("3105");
      a.__esModule && (a = a.default),
        "string" === typeof a && (a = [[t.i, a, ""]]),
        a.locals && (t.exports = a.locals);
      var n = i("967d").default;
      n("0bdeecc7", a, !0, { sourceMap: !1, shadowMode: !1 });
    },
    "758f": function (t, e, i) {
      "use strict";
      i.d(e, "b", function () {
        return n;
      }),
        i.d(e, "c", function () {
          return s;
        }),
        i.d(e, "a", function () {
          return a;
        });
      var a = {
          uvInput: i("f723").default,
          uvIcon: i("1a07").default,
          uvTabs: i("2b48").default,
          uvEmpty: i("caef").default,
          uvLoadMore: i("bd68").default,
        },
        n = function () {
          var t = this,
            e = t.$createElement,
            a = t._self._c || e;
          return a(
            "v-uni-view",
            { staticClass: "content" },
            [
              a(
                "v-uni-view",
                { staticClass: "new_search_box" },
                [
                  a("uv-input", {
                    staticClass: "new_search",
                    attrs: {
                      placeholder: "请输入您要搜索的商品名称",
                      border: "surround",
                      shape: "circle",
                      clearable: !0,
                      fontSize: "14px",
                    },
                    on: {
                      confirm: function (e) {
                        (arguments[0] = e = t.$handleEvent(e)),
                          t.searchFun.apply(void 0, arguments);
                      },
                    },
                    scopedSlots: t._u([
                      {
                        key: "suffix",
                        fn: function () {
                          return [
                            a(
                              "v-uni-view",
                              {
                                staticClass: "btn flex_box",
                                on: {
                                  click: function (e) {
                                    (arguments[0] = e = t.$handleEvent(e)),
                                      t.searchFun.apply(void 0, arguments);
                                  },
                                },
                              },
                              [
                                a("uv-icon", {
                                  attrs: {
                                    name: "search",
                                    color: "#fff",
                                    size: "20",
                                  },
                                }),
                              ],
                              1,
                            ),
                          ];
                        },
                        proxy: !0,
                      },
                    ]),
                    model: {
                      value: t.keyword,
                      callback: function (e) {
                        t.keyword = e;
                      },
                      expression: "keyword",
                    },
                  }),
                ],
                1,
              ),
              t._e(),
              0 == t.current
                ? a(
                    "v-uni-view",
                    [
                      t.list.length > 0
                        ? a(
                            "v-uni-view",
                            { staticClass: "goods_list" },
                            t._l(t.list, function (e, i) {
                              return a(
                                "v-uni-view",
                                {
                                  key: i,
                                  staticClass: "col",
                                  attrs: { text: e },
                                },
                                [
                                  a(
                                    "v-uni-view",
                                    {
                                      on: {
                                        click: function (i) {
                                          (arguments[0] = i =
                                            t.$handleEvent(i)),
                                            t.jumpGoods(e);
                                        },
                                      },
                                    },
                                    [
                                      a(
                                        "v-uni-view",
                                        { staticClass: "img_box" },
                                        [
                                          "mp-weixin" == t.palte
                                            ? a("img", {
                                                style: {
                                                  width: t.picWidth + "px",
                                                  height: t.picWidth + "px",
                                                },
                                                attrs: {
                                                  src: e.thumb
                                                    ? e.thumb
                                                    : e.cat3
                                                      ? e.cat3.thumb
                                                      : "",
                                                },
                                              })
                                            : t._e(),
                                          "h5" == t.palte
                                            ? a("img", {
                                                attrs: {
                                                  src: e.thumb
                                                    ? e.thumb
                                                    : e.cat3
                                                      ? e.cat3.thumb
                                                      : "",
                                                },
                                              })
                                            : t._e(),
                                        ],
                                      ),
                                      a(
                                        "v-uni-view",
                                        {
                                          class:
                                            e.raffle_show_id &&
                                            0 != e.raffle_show_id
                                              ? "name choujiang_box uv-line-2"
                                              : "name vipgoods_box uv-line-2",
                                        },
                                        [
                                          e.raffle_show_id &&
                                          0 != e.raffle_show_id
                                            ? a(
                                                "v-uni-text",
                                                { staticClass: "tag" },
                                                [t._v("幸运转盘")],
                                              )
                                            : 1 == e.is_vip && 1 == t.vip_status
                                              ? a(
                                                  "v-uni-text",
                                                  { staticClass: "tag" },
                                                  [t._v("会员商品")],
                                                )
                                              : t._e(),
                                          t._v(" " + t._s(e.title) + " "),
                                        ],
                                        1,
                                      ),
                                      a(
                                        "v-uni-view",
                                        { staticClass: "intro uv-line-3" },
                                        [t._v(t._s(e.intro))],
                                      ),
                                      a(
                                        "v-uni-view",
                                        { staticClass: "price_box flex_box" },
                                        [
                                          a(
                                            "v-uni-view",
                                            { staticClass: "new_price" },
                                            [
                                              a(
                                                "v-uni-text",
                                                { staticClass: "icon" },
                                                [t._v("￥")],
                                              ),
                                              a(
                                                "v-uni-text",
                                                { staticClass: "num" },
                                                [t._v(t._s(e.price))],
                                              ),
                                            ],
                                            1,
                                          ),
                                          e.raffle_show_id &&
                                          0 != e.raffle_show_id
                                            ? t._e()
                                            : a(
                                                "v-uni-view",
                                                { staticClass: "old_price" },
                                                [t._v(t._s(e.priced))],
                                              ),
                                          e.sale_num2 > 0
                                            ? a(
                                                "v-uni-view",
                                                { staticClass: "sales_box" },
                                                [
                                                  t._v(
                                                    "销量: " +
                                                      t._s(e.sale_num2),
                                                  ),
                                                ],
                                              )
                                            : a("v-uni-view", {
                                                staticClass: "sales_box",
                                              }),
                                        ],
                                        1,
                                      ),
                                    ],
                                    1,
                                  ),
                                ],
                                1,
                              );
                            }),
                            1,
                          )
                        : a("uv-empty", {
                            attrs: {
                              mode: "data",
                              text: "暂无数据",
                              icon: "/static/imgs/no-data.png",
                            },
                          }),
                      t.page > 1
                        ? a("uv-load-more", { attrs: { status: t.status } })
                        : t._e(),
                    ],
                    1,
                  )
                : a(
                    "v-uni-view",
                    [
                      t.list.length > 0
                        ? a(
                            "v-uni-view",
                            { staticClass: "list" },
                            t._l(t.list, function (e, n) {
                              return a(
                                "v-uni-view",
                                {
                                  key: n,
                                  staticClass: "item",
                                  attrs: { text: e },
                                },
                                [
                                  a(
                                    "v-uni-view",
                                    { staticClass: "msg_box flex_box" },
                                    [
                                      a(
                                        "v-uni-view",
                                        {
                                          staticClass: "head",
                                          on: {
                                            click: function (i) {
                                              (arguments[0] = i =
                                                t.$handleEvent(i)),
                                                t.jump(
                                                  "/pages/index/seller?id=" +
                                                    e.id,
                                                );
                                            },
                                          },
                                        },
                                        [
                                          a("img", {
                                            attrs: { src: e.avatar },
                                          }),
                                        ],
                                      ),
                                      a(
                                        "v-uni-view",
                                        { staticClass: "des_box flex_box" },
                                        [
                                          a(
                                            "v-uni-view",
                                            {
                                              staticClass: "user",
                                              on: {
                                                click: function (i) {
                                                  (arguments[0] = i =
                                                    t.$handleEvent(i)),
                                                    t.jump(
                                                      "/pages/index/seller?id=" +
                                                        e.id,
                                                    );
                                                },
                                              },
                                            },
                                            [
                                              a(
                                                "v-uni-view",
                                                {
                                                  class: {
                                                    name_box: !0,
                                                    flex_box: !0,
                                                    is_vip: e.seller_vip
                                                      ? 1
                                                      : 0,
                                                  },
                                                },
                                                [
                                                  a(
                                                    "v-uni-view",
                                                    {
                                                      staticClass:
                                                        "nickname uv-line-1",
                                                    },
                                                    [t._v(t._s(e.nickname))],
                                                  ),
                                                  1 == e.seller_vip
                                                    ? a("img", {
                                                        staticClass: "vip",
                                                        attrs: {
                                                          src: i("3744"),
                                                        },
                                                      })
                                                    : t._e(),
                                                ],
                                                1,
                                              ),
                                              a(
                                                "v-uni-view",
                                                { staticClass: "fans_box" },
                                                [
                                                  a(
                                                    "v-uni-view",
                                                    { staticClass: "xinyong" },
                                                    [t._v("信用良好")],
                                                  ),
                                                  a(
                                                    "v-uni-view",
                                                    { staticClass: "fans" },
                                                    [
                                                      t._v(
                                                        t._s(e.fans) + "粉丝",
                                                      ),
                                                    ],
                                                  ),
                                                ],
                                                1,
                                              ),
                                            ],
                                            1,
                                          ),
                                          a(
                                            "v-uni-view",
                                            {
                                              class: e.follow_status
                                                ? "btn cancle"
                                                : "btn",
                                              on: {
                                                click: function (i) {
                                                  (arguments[0] = i =
                                                    t.$handleEvent(i)),
                                                    t.followSeller(e.id);
                                                },
                                              },
                                            },
                                            [
                                              t._v(
                                                " " +
                                                  t._s(
                                                    e.follow_status
                                                      ? "取消关注"
                                                      : "关注",
                                                  ),
                                              ),
                                            ],
                                          ),
                                        ],
                                        1,
                                      ),
                                    ],
                                    1,
                                  ),
                                  e.goods.length > 0
                                    ? a(
                                        "v-uni-view",
                                        { staticClass: "grid" },
                                        t._l(e.goods, function (e, i) {
                                          return a(
                                            "v-uni-view",
                                            {
                                              key: i,
                                              staticClass: "tu",
                                              attrs: { text: e },
                                              on: {
                                                click: function (i) {
                                                  (arguments[0] = i =
                                                    t.$handleEvent(i)),
                                                    t.jump(
                                                      "/pages/index/goods?id=" +
                                                        e.id,
                                                    );
                                                },
                                              },
                                            },
                                            [
                                              a("img", {
                                                attrs: {
                                                  src: e.cat3
                                                    ? e.cat3.thumb
                                                    : "",
                                                },
                                              }),
                                              a(
                                                "v-uni-view",
                                                { staticClass: "price" },
                                                [t._v("￥" + t._s(e.price))],
                                              ),
                                            ],
                                            1,
                                          );
                                        }),
                                        1,
                                      )
                                    : t._e(),
                                ],
                                1,
                              );
                            }),
                            1,
                          )
                        : a("uv-empty", {
                            attrs: {
                              mode: "data",
                              text: "暂无数据",
                              icon: "/static/imgs/no-data.png",
                            },
                          }),
                      t.page > 1
                        ? a("uv-load-more", { attrs: { status: t.status } })
                        : t._e(),
                    ],
                    1,
                  ),
            ],
            1,
          );
        },
        s = [];
    },
    7689: function (t, e, i) {
      "use strict";
      i("6a54");
      var a = i("f5bd").default;
      Object.defineProperty(e, "__esModule", { value: !0 }),
        (e.default = void 0),
        i("64aa");
      var n,
        s,
        r = a(i("9b1b")),
        o = {
          props: (0, r.default)(
            {
              duration: { type: Number, default: 300 },
              list: {
                type: Array,
                default: function () {
                  return [];
                },
              },
              lineColor: { type: String, default: "#3c9cff" },
              activeStyle: {
                type: [String, Object],
                default: function () {
                  return { color: "#303133" };
                },
              },
              inactiveStyle: {
                type: [String, Object],
                default: function () {
                  return { color: "#606266" };
                },
              },
              lineWidth: { type: [String, Number], default: 20 },
              lineHeight: { type: [String, Number], default: 3 },
              lineBgSize: { type: String, default: "cover" },
              itemStyle: {
                type: [String, Object],
                default: function () {
                  return { height: "44px" };
                },
              },
              scrollable: { type: Boolean, default: !0 },
              current: { type: [Number, String], default: 0 },
              keyName: { type: String, default: "name" },
            },
            null === (n = uni.$uv) ||
              void 0 === n ||
              null === (s = n.props) ||
              void 0 === s
              ? void 0
              : s.tabs,
          ),
        };
      e.default = o;
    },
    "9d2e": function (t, e, i) {
      var a = i("c86c");
      (e = a(!1)),
        e.push([
          t.i,
          '@charset "UTF-8";\r\n/**\r\n * 这里是uni-app内置的常用样式变量\r\n *\r\n * uni-app 官方扩展插件及插件市场（https://ext.dcloud.net.cn）上很多三方插件均使用了这些样式变量\r\n * 如果你是插件开发者，建议你使用scss预处理，并在插件代码中直接使用这些变量（无需 import 这个文件），方便用户通过搭积木的方式开发整体风格一致的App\r\n *\r\n */\r\n/**\r\n * 如果你是App开发者（插件使用者），你可以通过修改这些变量来定制自己的插件主题，实现自定义主题功能\r\n *\r\n * 如果你的项目同样使用了scss预处理，你也可以直接在你的 scss 代码中使用如下变量，同时无需 import 这个文件\r\n */\r\n/* 颜色变量 */\r\n/* 行为相关颜色 */\r\n/* 文字基本颜色 */\r\n/* 背景颜色 */\r\n/* 边框颜色 */\r\n/* 尺寸变量 */\r\n/* 文字尺寸 */\r\n/* 图片尺寸 */\r\n/* Border Radius */\r\n/* 水平间距 */\r\n/* 垂直间距 */\r\n/* 透明度 */\r\n/* 文章场景相关 */.new_search_box[data-v-3f647a98] .uv-input{margin:%?30?% %?30?% %?20?%;background:#fff!important;padding:%?4?%!important;padding-left:%?18?%!important}.new_search_box[data-v-3f647a98] .uv-input.uv-border{border:%?4?% solid #000!important}.new_search_box[data-v-3f647a98] .uv-input .uv-input__content__clear{margin-right:%?8?%!important}.new_search_box[data-v-3f647a98] .uv-input .btn{width:%?88?%!important;height:%?56?%!important;border-radius:%?56?%!important;background:#000!important;justify-content:center!important}.new_search_box[data-v-3f647a98] .uv-input .btn .uv-icon__icon{font-weight:700!important}[data-v-3f647a98] .uv-tabs{max-width:55%;margin:%?40?% auto %?35?%}[data-v-3f647a98] .uv-tabs__wrapper__nav__item{position:relative;z-index:2}[data-v-3f647a98] .uv-tabs__wrapper__nav__line{width:%?94?%!important;height:%?20?%!important;z-index:1;bottom:%?8?%!important;margin-left:%?-27?%!important}.goods_list[data-v-3f647a98]{margin-top:%?20?%;padding:0 %?20?% %?35?%;display:grid;grid-gap:%?10?%;grid-template-columns:repeat(2,1fr)}.goods_list .col[data-v-3f647a98]{background:#fff;border-radius:%?12?%;box-shadow:0 0 %?10?% #ddd;margin:%?5?%;overflow:hidden}.goods_list .col .img_box[data-v-3f647a98]{width:100%;aspect-ratio:1/1;border-radius:%?10?% %?10?% 0 0;position:relative;background:#f7f8fa;overflow:hidden}.goods_list .col .img_box img[data-v-3f647a98]{width:100%;height:100%;display:block;object-fit:cover}.goods_list .col .name[data-v-3f647a98]{margin:%?24?% auto %?8?%;padding:0 %?14?%;font-weight:700;line-height:%?36?%!important}.goods_list .col .choujiang_box .tag[data-v-3f647a98]{display:inline-block;font-weight:400;border:%?2?% solid #ff2525;border-radius:%?8?%;color:#ff2525;padding:%?3?% %?8?%;font-size:12px;margin-right:%?8?%}.goods_list .col .vipgoods_box .tag[data-v-3f647a98]{display:inline-block;background:linear-gradient(90deg,#f53c04,#f54f01);color:#fff;border-radius:%?8?%;padding:%?0?% %?8?%;height:%?42?%;line-height:%?42?%;font-size:12px;margin-right:%?8?%}.goods_list .col .intro[data-v-3f647a98]{padding:0 %?14?%;color:#999;font-size:13.6px}.goods_list .col .price_box[data-v-3f647a98]{padding:0 %?14?%;display:flex;align-items:center;margin:%?8?% auto %?14?%}.goods_list .col .price_box .new_price[data-v-3f647a98]{color:#fd2c28}.goods_list .col .price_box .new_price .icon[data-v-3f647a98]{font-size:13px;font-weight:700}.goods_list .col .price_box .new_price .num[data-v-3f647a98]{font-size:17px;font-weight:700}.goods_list .col .price_box .old_price[data-v-3f647a98]{font-size:12px;color:#999;text-decoration:line-through;margin-left:%?9?%;-webkit-transform:scale(.9);transform:scale(.9);-webkit-transform-origin:left;transform-origin:left}.goods_list .col .price_box .sales_box[data-v-3f647a98]{color:#999;text-align:right;font-size:12px;margin-left:auto}.list[data-v-3f647a98]{padding:0 %?30?%}.list .item[data-v-3f647a98]{margin-bottom:%?52?%}.list .item .msg_box .head[data-v-3f647a98]{width:%?82?%;height:%?82?%;border-radius:%?82?%}.list .item .msg_box .des_box[data-v-3f647a98]{width:calc(100% - %?105?%)}.list .item .msg_box .des_box .btn[data-v-3f647a98]{background:#ffe610;border:%?4?% solid #000;min-width:%?135?%;height:%?66?%;line-height:%?58?%;border-radius:%?66?%;text-align:center;font-weight:700}.list .item .msg_box .des_box .btn.cancle[data-v-3f647a98]{padding:0 %?24?%;background:#eee;border-color:#eee;color:#666}.list .item .msg_box .des_box .user[data-v-3f647a98]{height:%?82?%;width:calc(100% - %?200?%);display:flex;flex-direction:column;align-items:flex-start;justify-content:space-between}.list .item .msg_box .des_box .user .name_box[data-v-3f647a98]{width:100%;justify-content:flex-start}.list .item .msg_box .des_box .user .name_box .nickname[data-v-3f647a98]{font-weight:700;font-size:14.6px}.list .item .msg_box .des_box .user .name_box .vip[data-v-3f647a98]{margin-left:%?10?%;height:%?40?%;width:%?40?%}.list .item .msg_box .des_box .user .name_box.is_vip .nickname[data-v-3f647a98]{color:red}.list .item .msg_box .des_box .user .fans_box[data-v-3f647a98]{display:flex;justify-content:flex-start;align-items:center}.list .item .msg_box .des_box .user .fans_box .xinyong[data-v-3f647a98]{padding:0 %?8?%;height:%?35?%;line-height:%?35?%;border-radius:%?35?%;background:#fff1d4;color:#fd6400;font-size:11px;white-space:nowrap;margin-right:%?20?%;max-width:%?190?%}.list .item .msg_box .des_box .user .fans_box .fans[data-v-3f647a98]{font-size:12px;color:#999}.list .item .grid[data-v-3f647a98]{margin-top:%?32?%;display:grid;grid-template-columns:repeat(3,1fr);grid-gap:%?2?%;border-radius:%?20?%;margin-left:%?105?%}.list .item .grid .tu[data-v-3f647a98]{position:relative}.list .item .grid .tu[data-v-3f647a98]:last-child{border-radius:0 %?20?% %?20?% 0}.list .item .grid .tu .img[data-v-3f647a98]{width:%?220?%;height:%?220?%}.list .item .grid .tu .price[data-v-3f647a98]{position:absolute;right:%?5?%;bottom:%?5?%;background:rgba(0,0,0,.3);color:#fff;padding:%?4?% %?6?%;border-radius:%?15?%;font-size:12px;font-weight:700}',
          "",
        ]),
        (t.exports = e);
    },
    cc5d: function (t, e, i) {
      "use strict";
      var a = i("0da1"),
        n = i.n(a);
      n.a;
    },
    d3f2: function (t, e, i) {
      "use strict";
      i("6a54");
      var a = i("f5bd").default;
      Object.defineProperty(e, "__esModule", { value: !0 }),
        (e.default = void 0);
      var n = a(i("b7c7"));
      i("bf0f"), i("2797"), i("aa9c");
      var s = i("e74a"),
        r = {
          data: function () {
            return {
              picWidth: 0,
              palte: "h5",
              searchTimer: null,
              seller_id: 0,
              list: [],
              keyword: "",
              area: [
                { type: 1, name: "商品" },
                { type: 2, name: "打手" },
              ],
              current: 0,
              type: 1,
              page: 1,
              no_more: 0,
              status: "loading",
              vip_status: 0,
            };
          },
          computed: {
            height: function () {
              return uni.getSystemInfoSync().windowHeight - uni.upx2px(100);
            },
          },
          onLoad: function (t) {
            t && t.keyword && (this.keyword = decodeURIComponent(t.keyword)),
              this.getViewWidth(),
              this.getSearchList();
          },
          onPullDownRefresh: function () {
            var t = this;
            uni.showLoading({ title: "刷新中" }),
              setTimeout(function () {
                uni.hideLoading(),
                  (t.page = 1),
                  (t.no_more = 0),
                  (t.status = "loading"),
                  t.getSearchList(),
                  uni.showToast({ title: "刷新成功", duration: 1e3 }),
                  uni.stopPullDownRefresh();
              }, 300);
          },
          onReachBottom: function (t) {
            this.loadMoreFun();
          },
          methods: {
            followSeller: function (t) {
              (this.seller_id = t), uni.$uv.throttle(this.followSellerFun, 500);
            },
            followSellerFun: function () {
              var t = this;
              uni.showLoading({ title: "加载中.." }),
                (0, s.send)(
                  "/wechat/UserFans/followSeller",
                  { seller_id: this.seller_id },
                  !1,
                ).then(function (e) {
                  uni.hideLoading();
                  var i = e.status,
                    a = e.msg;
                  e.data;
                  if (1 != i) return uni.$uv.toast(a);
                  t.list.forEach(function (e) {
                    e.id == t.seller_id &&
                      ((e.follow_status = 1 == e.follow_status ? 0 : 1),
                      (e.fans =
                        1 == e.follow_status ? e.fans + 1 : e.fans - 1));
                  });
                });
            },
            searchFun: function () {
              var t = this;
              this.searchTimer && clearTimeout(this.searchTimer),
                (this.searchTimer = setTimeout(function () {
                  (t.page = 1),
                    (t.no_more = 0),
                    (t.status = "loading"),
                    t.getSearchList();
                }, 100));
            },
            getViewWidth: function () {
              var t = uni.getSystemInfoSync().windowWidth;
              t > 480 && (t = 480);
              this.picWidth = (t - 37) / 2;
            },
            loadMoreFun: function () {
              0 == this.no_more && (this.page++, this.getSearchList()),
                console.log("到底了");
            },
            changeTabs: function (t) {
              (this.current = t.index),
                (this.type = t.type),
                (this.page = 1),
                (this.list = []),
                (this.no_more = 0),
                this.getSearchList();
            },
            getSearchList: function () {
              var t = this;
              uni.showLoading({ title: "加载中.." }),
                (0, s.send)(
                  "/wechat/Goods/getSearchList",
                  { keyword: this.keyword, page: this.page, type: this.type },
                  !1,
                ).then(function (e) {
                  uni.hideLoading();
                  var i,
                    a = e.status,
                    s = e.msg,
                    r = e.data;
                  if (1 != a) return uni.$uv.toast(s);
                  ((t.vip_status = r.vip_status || 0), t.page > 1)
                    ? (i = t.list).push.apply(i, (0, n.default)(r.list))
                    : (t.list = r.list);
                  1 == r.no_more &&
                    ((t.status = "nomore"), (t.no_more = r.no_more));
                });
            },
            jumpGoods: function (t) {
              var e = "/pages/index/goods?id=" + t.id;
              t.raffle_show_id &&
                0 != t.raffle_show_id &&
                (e = "/pages/active/goods?id=" + t.raffle_show_id),
                this.jump(e);
            },
            jump: function (t) {
              uni.navigateTo({ url: t });
            },
          },
        };
      e.default = r;
    },
    da6d: function (t, e, i) {
      "use strict";
      i.r(e);
      var a = i("d3f2"),
        n = i.n(a);
      for (var s in a)
        ["default"].indexOf(s) < 0 &&
          (function (t) {
            i.d(e, t, function () {
              return a[t];
            });
          })(s);
      e["default"] = n.a;
    },
  },
]);
//# sourceMappingURL=pages-index-search.6d20e684.js.map
