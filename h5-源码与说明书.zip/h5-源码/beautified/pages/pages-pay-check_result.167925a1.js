(window["webpackJsonp"] = window["webpackJsonp"] || []).push([
  ["pages-pay-check_result"],
  {
    "026c": function (n, e, t) {
      "use strict";
      t.d(e, "b", function () {
        return u;
      }),
        t.d(e, "c", function () {
          return i;
        }),
        t.d(e, "a", function () {});
      var u = function () {
          var n = this.$createElement,
            e = this._self._c || n;
          return e("v-uni-view", { staticClass: "content" });
        },
        i = [];
    },
    "09db": function (n, e, t) {
      "use strict";
      t.r(e);
      var u = t("026c"),
        i = t("748a");
      for (var a in i)
        ["default"].indexOf(a) < 0 &&
          (function (n) {
            t.d(e, n, function () {
              return i[n];
            });
          })(a);
      var c = t("828b"),
        r = Object(c["a"])(
          i["default"],
          u["b"],
          u["c"],
          !1,
          null,
          null,
          null,
          !1,
          u["a"],
          void 0,
        );
      e["default"] = r.exports;
    },
    "748a": function (n, e, t) {
      "use strict";
      t.r(e);
      var u = t("8c7e"),
        i = t.n(u);
      for (var a in u)
        ["default"].indexOf(a) < 0 &&
          (function (n) {
            t.d(e, n, function () {
              return u[n];
            });
          })(a);
      e["default"] = i.a;
    },
    "8c7e": function (n, e, t) {
      "use strict";
      t("6a54"),
        Object.defineProperty(e, "__esModule", { value: !0 }),
        (e.default = void 0),
        t("4626"),
        t("5ac7");
      t("e74a");
      var u = {
        data: function () {
          return {
            tabBar: [
              "/pages/index/index",
              "/pages/cat/index",
              "/pages/follow/index",
              "/pages/user/index",
            ],
          };
        },
        onLoad: function (n) {
          this.paySucessJump();
        },
        methods: {
          paySucessJump: function (n) {
            var e = this,
              t = uni.getStorageSync("pay_ok_jump");
            uni.showLoading({ title: "正在检查支付结果, 请稍等..." }),
              setTimeout(function () {
                uni.hideLoading(),
                  e.tabBar.includes(t)
                    ? uni.switchTab({ url: t })
                    : uni.redirectTo({ url: t });
              }, 1500);
          },
        },
      };
      e.default = u;
    },
  },
]);
//# sourceMappingURL=pages-pay-check_result.167925a1.js.map
