(window["webpackJsonp"] = window["webpackJsonp"] || []).push([
  ["pages-user-login"],
  {
    "0b1b": function (t, n, e) {
      var i = e("8ad7");
      i.__esModule && (i = i.default),
        "string" === typeof i && (i = [[t.i, i, ""]]),
        i.locals && (t.exports = i.locals);
      var a = e("967d").default;
      a("48987218", i, !0, { sourceMap: !1, shadowMode: !1 });
    },
    "0bfd": function (t, n, e) {
      "use strict";
      e.r(n);
      var i = e("a327"),
        a = e("3f56");
      for (var o in a)
        ["default"].indexOf(o) < 0 &&
          (function (t) {
            e.d(n, t, function () {
              return a[t];
            });
          })(o);
      e("3fce");
      var r = e("828b"),
        u = Object(r["a"])(
          a["default"],
          i["b"],
          i["c"],
          !1,
          null,
          "5949ff20",
          null,
          !1,
          i["a"],
          void 0,
        );
      n["default"] = u.exports;
    },
    "1d95": function (t, n, e) {
      "use strict";
      e.r(n);
      var i = e("3176"),
        a = e.n(i);
      for (var o in i)
        ["default"].indexOf(o) < 0 &&
          (function (t) {
            e.d(n, t, function () {
              return i[t];
            });
          })(o);
      n["default"] = a.a;
    },
    "22f3": function (t, n, e) {
      "use strict";
      e("6a54");
      var i = e("f5bd").default;
      Object.defineProperty(n, "__esModule", { value: !0 }),
        (n.default = void 0),
        e("64aa");
      var a,
        o,
        r = i(e("9b1b")),
        u = {
          props: (0, r.default)(
            {
              loadingText: { type: [String, Number], default: "" },
              image: { type: String, default: "" },
              loadingMode: { type: String, default: "circle" },
              loading: { type: Boolean, default: !1 },
              bgColor: { type: String, default: "#fff" },
              color: { type: String, default: "#C8C8C8" },
              fontSize: { type: [String, Number], default: 16 },
              iconSize: { type: [String, Number], default: 26 },
              loadingColor: { type: String, default: "#C8C8C8" },
              duration: { type: [String, Number], default: 300 },
            },
            null === (a = uni.$uv) ||
              void 0 === a ||
              null === (o = a.props) ||
              void 0 === o
              ? void 0
              : o.loadingPage,
          ),
        };
      n.default = u;
    },
    3176: function (t, n, e) {
      "use strict";
      e("6a54"),
        Object.defineProperty(n, "__esModule", { value: !0 }),
        (n.default = void 0),
        e("5ef2"),
        e("5c47"),
        e("af8f"),
        e("c223"),
        e("bf0f"),
        e("18f7"),
        e("de6c"),
        e("dc89"),
        e("2425"),
        e("4626"),
        e("5ac7"),
        e("c9b5"),
        e("ab80"),
        e("0506");
      var i = e("e74a"),
        a = e("15b8"),
        o = {
          data: function () {
            return {
              user: [],
              captcha: "",
              cap_num: 1,
              mobile: "",
              code: "",
              msgCode: "",
              tips: "",
              seconds: 60,
              agree: 1,
            };
          },
          computed: {},
          onLoad: function (t) {
            var n = t.back_url,
              e = t.share_code;
            e && uni.setStorageSync("share_code", e),
              uni.setStorageSync("back_url", n),
              this.login();
          },
          methods: {
            codeChange: function (t) {
              this.tips = t;
            },
            getCode: function () {
              var t = this;
              return "" == this.mobile
                ? uni.showModal({ content: "请输入手机号" })
                : this.verifyMobile()
                  ? "" == this.code
                    ? uni.showModal({ content: "请输入图形验证码" })
                    : void (this.$refs.code.canGetCode
                        ? (uni.showLoading({ title: "正在获取验证码" }),
                          setTimeout(function () {
                            uni.hideLoading(),
                              uni.$uv.throttle(t.sendCode, 1500);
                          }, 500))
                        : uni.$uv.toast("倒计时结束后再发送"))
                  : uni.showModal({ content: "请输入正确的手机号" });
            },
            sendCode: function () {
              var t = this;
              uni.showLoading({ title: "加载中.." }),
                (0, i.send)(
                  "/wechat/MsgCode/sendCode",
                  {
                    mobile: this.mobile,
                    code: this.code,
                    cap_num: this.cap_num,
                  },
                  !1,
                ).then(function (n) {
                  uni.hideLoading();
                  var e = n.status,
                    i = n.msg;
                  n.data;
                  if (1 != e) return t.getCaptchaCodeFun(), uni.$uv.toast(i);
                  uni.$uv.toast("验证码已发送"), t.$refs.code.start();
                });
            },
            end: function () {
              this.getCaptchaCodeFun();
            },
            start: function () {},
            isWeChatBrowser: function () {
              var t = navigator.userAgent.toLowerCase();
              return -1 !== t.indexOf("micromessenger");
            },
            login: function () {
              var t = this,
                n = uni.getStorageSync("token");
              if ((null != n && "" !== n && "undefined" != n) || 0 != a.dubug)
                uni.showLoading({ title: "加载中.." }),
                  (0, i.send)(
                    "/wechat/User/getLoginInfo",
                    { label: "user" },
                    !1,
                  ).then(function (e) {
                    uni.hideLoading();
                    var i = e.status,
                      a = e.msg;
                    e.data;
                    if (1 != i) return uni.$uv.toast(a);
                    t.returnDomainUrl(n);
                  });
              else {
                var e = this.isWeChatBrowser();
                1 == e && this.userLogin();
              }
            },
            getCaptchaCode: function () {
              uni.$uv.throttle(this.getCaptchaCodeFun, 800);
            },
            getCaptchaCodeFun: function () {
              var t = this;
              (this.cap_num = 1 == this.cap_num ? 2 : 1),
                uni.showLoading({ title: "加载中.." }),
                (0, i.send)(
                  "/wechat/User/getCaptchaCode",
                  { cap_num: this.cap_num },
                  !1,
                ).then(function (n) {
                  uni.hideLoading();
                  var e = n.status,
                    i = n.msg,
                    a = n.data;
                  if (1 != e) return uni.$uv.toast(i);
                  t.captcha = a;
                });
            },
            jump: function (t) {
              uni.navigateTo({ url: t });
            },
            getUrlCode: function () {
              var t = location.search,
                n = new Object();
              if (-1 != t.indexOf("?"))
                for (
                  var e = t.substr(1), i = e.split("&"), a = 0;
                  a < i.length;
                  a++
                )
                  n[i[a].split("=")[0]] = i[a].split("=")[1];
              return n;
            },
            userLogin: function () {
              var t = this,
                n = window.location.href,
                e = this.getUrlCode().code,
                o = uni.getStorageSync("wechatCode");
              if (null == e || "" === e || "undefined" == e || e == o)
                (0, i.send)(
                  "/wechat/Wechat/getConfigInfo",
                  { label: "config" },
                  !1,
                ).then(function (t) {
                  uni.hideLoading();
                  var e = t.status,
                    i = t.msg,
                    a = t.data;
                  if (1 != e) return uni.$uv.toast(i);
                  var o = a.appid,
                    r = encodeURIComponent(n);
                  uni.setStorageSync("wechatCode", 0);
                  window.location.href =
                    "https://open.weixin.qq.com/connect/oauth2/authorize" +
                    "?appid="
                      .concat(o, "&redirect_uri=")
                      .concat(
                        r,
                        "&response_type=code&scope=snsapi_userinfo&state=123#wechat_redirect",
                      );
                });
              else {
                uni.setStorageSync("wechatCode", e);
                var r = uni.getStorageSync("share_code");
                uni.showLoading({ title: "加载中.." }),
                  (0, a.sendPost)({
                    url: "/wechat/user/login",
                    method: "POST",
                    data: { code: e, share_code: r },
                  }).then(function (n) {
                    uni.hideLoading();
                    var e = n.status,
                      i = (n.msg, n.data);
                    if (1 != e) return console.log("获取用户信息失败"), !0;
                    uni.setStorageSync("token", i.token),
                      t.returnDomainUrl(i.token);
                  });
              }
            },
            returnDomainUrl: function (t) {
              var n = uni.getStorageSync("back_url"),
                e = new URL(n);
              e.hash.includes("?")
                ? (e.hash += "&token=" + t)
                : (e.hash += "?token=" + t),
                (window.location.href = e.toString());
            },
            verifyMobile: function () {
              return !!/^1[3-9]\d{9}$/.test(this.mobile);
            },
            agreeXieyi: function () {
              this.agree = this.agree ? 0 : 1;
            },
            loginUser: function () {
              return "" == this.mobile
                ? uni.showModal({ content: "请输入手机号" })
                : this.verifyMobile()
                  ? "" == this.msgCode
                    ? uni.showModal({ content: "请输入短信验证码" })
                    : 0 == this.agree
                      ? uni.showModal({ content: "请先同意用户协议和隐私政策" })
                      : void uni.$uv.throttle(this.loginUserFun, 1500)
                  : uni.showModal({ content: "请输入正确的手机号" });
            },
            loginUserFun: function () {
              var t = this;
              uni.showLoading({ title: "正在登录中.." }),
                (0, i.send)(
                  "/wechat/User/loginUser",
                  { mobile: this.mobile, msgCode: this.msgCode },
                  !1,
                ).then(function (n) {
                  uni.hideLoading();
                  var e = n.status,
                    i = n.msg,
                    a = n.data;
                  if (1 != e) return uni.$uv.toast(i);
                  uni.setStorageSync("token", a.token), t.returnBack();
                });
            },
            getLastPath: function () {
              var t = getCurrentPages(),
                n = t[t.length - 2];
              if (null != n) {
                var e = n.$page.fullPath,
                  i = n.route;
                uni.setStorageSync("backFullPath", e),
                  uni.setStorageSync("backPath", i);
              } else
                uni.setStorageSync("backFullPath", ""),
                  uni.setStorageSync("backPath", "");
            },
            returnBack: function () {
              uni.$uv.toast("登录成功");
              var t = uni.getStorageSync("backFullPath"),
                n = uni.getStorageSync("backPath"),
                e = [
                  "pages/index/index",
                  "pages/cat/index",
                  "pages/follow/index",
                  "pages/user/index",
                ];
              console.log(n),
                setTimeout(function () {
                  "" == n || null == n || void 0 == n || "pages/user/login" == n
                    ? uni.switchTab({ url: "/pages/user/index" })
                    : e.includes(n)
                      ? uni.switchTab({ url: t })
                      : uni.redirectTo({ url: t });
                }, 1e3);
            },
          },
        };
      n.default = o;
    },
    "3f56": function (t, n, e) {
      "use strict";
      e.r(n);
      var i = e("ff4c"),
        a = e.n(i);
      for (var o in i)
        ["default"].indexOf(o) < 0 &&
          (function (t) {
            e.d(n, t, function () {
              return i[t];
            });
          })(o);
      n["default"] = a.a;
    },
    "3fce": function (t, n, e) {
      "use strict";
      var i = e("4f0f"),
        a = e.n(i);
      a.a;
    },
    "4f0f": function (t, n, e) {
      var i = e("f729");
      i.__esModule && (i = i.default),
        "string" === typeof i && (i = [[t.i, i, ""]]),
        i.locals && (t.exports = i.locals);
      var a = e("967d").default;
      a("917e812e", i, !0, { sourceMap: !1, shadowMode: !1 });
    },
    "8ad7": function (t, n, e) {
      var i = e("c86c");
      (n = i(!1)),
        n.push([
          t.i,
          '@charset "UTF-8";\r\n/**\r\n * 这里是uni-app内置的常用样式变量\r\n *\r\n * uni-app 官方扩展插件及插件市场（https://ext.dcloud.net.cn）上很多三方插件均使用了这些样式变量\r\n * 如果你是插件开发者，建议你使用scss预处理，并在插件代码中直接使用这些变量（无需 import 这个文件），方便用户通过搭积木的方式开发整体风格一致的App\r\n *\r\n */\r\n/**\r\n * 如果你是App开发者（插件使用者），你可以通过修改这些变量来定制自己的插件主题，实现自定义主题功能\r\n *\r\n * 如果你的项目同样使用了scss预处理，你也可以直接在你的 scss 代码中使用如下变量，同时无需 import 这个文件\r\n */\r\n/* 颜色变量 */\r\n/* 行为相关颜色 */\r\n/* 文字基本颜色 */\r\n/* 背景颜色 */\r\n/* 边框颜色 */\r\n/* 尺寸变量 */\r\n/* 文字尺寸 */\r\n/* 图片尺寸 */\r\n/* Border Radius */\r\n/* 水平间距 */\r\n/* 垂直间距 */\r\n/* 透明度 */\r\n/* 文章场景相关 */.content[data-v-42321b1b]{height:100vh;padding:21.5% 10% 10%}.head[data-v-42321b1b]{width:%?155?%;height:%?155?%;border-radius:100%;margin:0 auto %?80?%}[data-v-42321b1b] .uv-input{margin:%?58?% auto}.pic_box[data-v-42321b1b]{margin:%?58?% auto}.pic_box[data-v-42321b1b] .uv-input{margin:%?0?%}.pic_box img[data-v-42321b1b]{width:%?140?%;height:%?70?%;border:%?2?% solid #ddd;margin-left:%?30?%}.code_box .get_code_btn[data-v-42321b1b]{margin-left:%?10?%;font-size:13px}.sub_btn[data-v-42321b1b]{background:#ffe610;height:%?90?%;line-height:%?90?%;border-radius:%?90?%;font-size:15px;font-weight:700;text-align:center;margin:%?106?% auto %?26?%}.xiyi_box[data-v-42321b1b]{justify-content:center;align-items:flex-start}.xiyi_box .check_box[data-v-42321b1b]{width:%?40?%;height:%?40?%;border-radius:%?40?%;justify-content:center;border:%?2?% solid #ccc;margin-right:%?15?%}.xiyi_box .tit[data-v-42321b1b]{max-width:calc(100% - %?55?%);text-align:center;font-size:12px;color:#999}.xiyi_box .tit uni-text[data-v-42321b1b]{font-size:12px;color:#2979ff}',
          "",
        ]),
        (t.exports = n);
    },
    a327: function (t, n, e) {
      "use strict";
      e.d(n, "b", function () {
        return a;
      }),
        e.d(n, "c", function () {
          return o;
        }),
        e.d(n, "a", function () {
          return i;
        });
      var i = { uvLoadingIcon: e("17f5").default },
        a = function () {
          var t = this,
            n = t.$createElement,
            e = t._self._c || n;
          return t.showLoading
            ? e(
                "v-uni-view",
                {
                  staticClass: "uv-loading-page uv-flex-column",
                  style: [t.loadingPageStyle],
                },
                [
                  "" != t.image
                    ? e("v-uni-image", {
                        staticClass: "uv-loading-page__img",
                        style: [
                          {
                            width: t.$uv.addUnit(t.iconSize),
                            height: t.$uv.addUnit(t.iconSize),
                          },
                        ],
                        attrs: { src: t.image, mode: "widthFit" },
                      })
                    : e("uv-loading-icon", {
                        attrs: {
                          mode: t.loadingMode,
                          size: t.iconSize,
                          color: t.loadingColor,
                        },
                      }),
                  t._t("default", [
                    e(
                      "v-uni-text",
                      {
                        staticClass: "uv-loading-page__text",
                        style: [
                          {
                            fontSize: t.$uv.addUnit(t.fontSize),
                            color: t.color,
                          },
                        ],
                      },
                      [t._v(t._s(t.loadingText))],
                    ),
                  ]),
                ],
                2,
              )
            : t._e();
        },
        o = [];
    },
    a573: function (t, n, e) {
      "use strict";
      var i = e("0b1b"),
        a = e.n(i);
      a.a;
    },
    a9dc: function (t, n, e) {
      "use strict";
      e.r(n);
      var i = e("c32e"),
        a = e("1d95");
      for (var o in a)
        ["default"].indexOf(o) < 0 &&
          (function (t) {
            e.d(n, t, function () {
              return a[t];
            });
          })(o);
      e("a573");
      var r = e("828b"),
        u = Object(r["a"])(
          a["default"],
          i["b"],
          i["c"],
          !1,
          null,
          "42321b1b",
          null,
          !1,
          i["a"],
          void 0,
        );
      n["default"] = u.exports;
    },
    c32e: function (t, n, e) {
      "use strict";
      e.d(n, "b", function () {
        return a;
      }),
        e.d(n, "c", function () {
          return o;
        }),
        e.d(n, "a", function () {
          return i;
        });
      var i = { uvLoadingPage: e("0bfd").default },
        a = function () {
          var t = this.$createElement,
            n = this._self._c || t;
          return n(
            "v-uni-view",
            { staticClass: "content" },
            [
              n("uv-loading-page", {
                attrs: {
                  loading: !0,
                  "loading-text": "正在登录中...",
                  "font-size": "24rpx",
                  bgColor: "#666",
                },
              }),
            ],
            1,
          );
        },
        o = [];
    },
    f729: function (t, n, e) {
      var i = e("c86c");
      (n = i(!1)),
        n.push([
          t.i,
          '@charset "UTF-8";\r\n/**\r\n * 这里是uni-app内置的常用样式变量\r\n *\r\n * uni-app 官方扩展插件及插件市场（https://ext.dcloud.net.cn）上很多三方插件均使用了这些样式变量\r\n * 如果你是插件开发者，建议你使用scss预处理，并在插件代码中直接使用这些变量（无需 import 这个文件），方便用户通过搭积木的方式开发整体风格一致的App\r\n *\r\n */\r\n/**\r\n * 如果你是App开发者（插件使用者），你可以通过修改这些变量来定制自己的插件主题，实现自定义主题功能\r\n *\r\n * 如果你的项目同样使用了scss预处理，你也可以直接在你的 scss 代码中使用如下变量，同时无需 import 这个文件\r\n */\r\n/* 颜色变量 */\r\n/* 行为相关颜色 */\r\n/* 文字基本颜色 */\r\n/* 背景颜色 */\r\n/* 边框颜色 */\r\n/* 尺寸变量 */\r\n/* 文字尺寸 */\r\n/* 图片尺寸 */\r\n/* Border Radius */\r\n/* 水平间距 */\r\n/* 垂直间距 */\r\n/* 透明度 */\r\n/* 文章场景相关 */uni-view[data-v-5949ff20], uni-scroll-view[data-v-5949ff20], uni-swiper-item[data-v-5949ff20]{display:flex;flex-direction:column;flex-shrink:0;flex-grow:0;flex-basis:auto;align-items:stretch;align-content:flex-start}.uv-loading-page[data-v-5949ff20]{flex:1;justify-content:center;align-items:center;padding-bottom:150px;transition-property:opacity}.uv-loading-page__text[data-v-5949ff20]{margin-top:10px}',
          "",
        ]),
        (t.exports = n);
    },
    ff4c: function (t, n, e) {
      "use strict";
      e("6a54");
      var i = e("f5bd").default;
      Object.defineProperty(n, "__esModule", { value: !0 }),
        (n.default = void 0);
      var a = i(e("4d8f0")),
        o = i(e("9463")),
        r = i(e("22f3")),
        u = {
          name: "uv-loading-page",
          mixins: [a.default, o.default, r.default],
          data: function () {
            return { showLoading: !1, opacity: 1 };
          },
          watch: {
            loading: {
              immediate: !0,
              handler: function (t) {
                var n = this;
                t
                  ? ((this.showLoading = !0), (this.opacity = 1))
                  : ((this.opacity = 0),
                    this.$nextTick(function () {
                      n.$uv.sleep(n.duration).then(function (t) {
                        n.showLoading = !1;
                      });
                    }));
              },
            },
          },
          computed: {
            loadingPageStyle: function () {
              var t = {
                position: "fixed",
                top: "0",
                left: "0",
                right: "0",
                bottom: "0",
                zIndex: "999",
                "background-color": this.bgColor,
                "transition-duration": "".concat(this.duration, "ms"),
                opacity: this.opacity,
              };
              return this.$uv.deepMerge(t, this.$uv.addStyle(this.customStyle));
            },
          },
        };
      n.default = u;
    },
  },
]);
//# sourceMappingURL=pages-user-login.6e82339e.js.map
