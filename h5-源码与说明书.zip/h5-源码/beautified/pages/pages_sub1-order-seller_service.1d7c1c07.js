(window["webpackJsonp"] = window["webpackJsonp"] || []).push([
  ["pages_sub1-order-seller_service"],
  {
    "0b4f": function (t, e, i) {
      "use strict";
      i.r(e);
      var a = i("f598"),
        n = i.n(a);
      for (var s in a)
        ["default"].indexOf(s) < 0 &&
          (function (t) {
            i.d(e, t, function () {
              return a[t];
            });
          })(s);
      e["default"] = n.a;
    },
    "26c4": function (t, e, i) {
      "use strict";
      var a = i("5132"),
        n = i.n(a);
      n.a;
    },
    "280d": function (t, e, i) {
      "use strict";
      i.d(e, "b", function () {
        return n;
      }),
        i.d(e, "c", function () {
          return s;
        }),
        i.d(e, "a", function () {
          return a;
        });
      var a = { uvDivider: i("4589").default },
        n = function () {
          var t = this,
            e = t.$createElement,
            i = t._self._c || e;
          return i(
            "v-uni-view",
            { staticClass: "content" },
            [
              i(
                "v-uni-view",
                { staticClass: "top_box flex_box" },
                [
                  i(
                    "v-uni-view",
                    {
                      staticClass: "order_num flex_box",
                      on: {
                        click: function (e) {
                          (arguments[0] = e = t.$handleEvent(e)),
                            t.copyOrderNum(t.order.order_no);
                        },
                      },
                    },
                    [
                      i("v-uni-view", {}, [t._v("订单编号：")]),
                      i("v-uni-view", { staticClass: "num" }, [
                        t._v(t._s(t.order.order_no)),
                      ]),
                      i("v-uni-view", { staticClass: "copy_btn" }, [
                        t._v("复制"),
                      ]),
                    ],
                    1,
                  ),
                  i("v-uni-view", { staticClass: "status" }, [
                    t._v(t._s(t.order.status_text)),
                  ]),
                ],
                1,
              ),
              i(
                "v-uni-view",
                {
                  staticClass: "goods_msg flex_box",
                  on: {
                    click: function (e) {
                      (arguments[0] = e = t.$handleEvent(e)),
                        t.jump("/pages/index/goods?id=" + t.order.goods_id);
                    },
                  },
                },
                [
                  i("img", {
                    staticClass: "img",
                    attrs: { src: t.order.goods ? t.order.goods.thumb : "" },
                  }),
                  i(
                    "v-uni-view",
                    { staticClass: "txt" },
                    [
                      i("v-uni-view", { staticClass: "name uv-line-2" }, [
                        t._v(t._s(t.order.goods_name)),
                      ]),
                      i(
                        "v-uni-view",
                        { staticClass: "price_box flex_box" },
                        [
                          i(
                            "v-uni-view",
                            { staticClass: "price" },
                            [
                              i("v-uni-text", { staticClass: "unit" }, [
                                t._v("￥"),
                              ]),
                              i("v-uni-text", [t._v(t._s(t.order.money))]),
                            ],
                            1,
                          ),
                          i("v-uni-view", { staticClass: "num" }, [
                            t._v("x " + t._s(t.order.num)),
                          ]),
                        ],
                        1,
                      ),
                    ],
                    1,
                  ),
                ],
                1,
              ),
              i("uv-divider", {
                staticClass: "block_title",
                attrs: { text: "打手服务证明", textSize: "13" },
              }),
              i(
                "v-uni-view",
                { staticClass: "reason_box flex_box" },
                [
                  i("v-uni-view", { staticClass: "tit" }, [t._v("证明文字")]),
                  i("v-uni-view", { staticClass: "txt img_box" }, [
                    t._v(" " + t._s(t.order.service_txt) + " "),
                  ]),
                ],
                1,
              ),
              i(
                "v-uni-view",
                { staticClass: "reason_box flex_box" },
                [
                  i("v-uni-view", { staticClass: "tit" }, [t._v("证明图片")]),
                  i(
                    "v-uni-view",
                    { staticClass: "txt img_box" },
                    t._l(t.order.service_imgs, function (e, a) {
                      return i("img", {
                        key: a,
                        attrs: { text: e, src: e },
                        on: {
                          click: function (i) {
                            (arguments[0] = i = t.$handleEvent(i)),
                              t.previewImage(e, t.order.service_imgs);
                          },
                        },
                      });
                    }),
                    0,
                  ),
                ],
                1,
              ),
              i("uv-divider", {
                staticClass: "block_title",
                attrs: { text: "买家申请信息", textSize: "13" },
              }),
              i(
                "v-uni-view",
                [
                  i(
                    "v-uni-view",
                    { staticClass: "reason_box flex_box remarks_box" },
                    [
                      i("v-uni-view", { staticClass: "tit" }, [
                        t._v("申请理由"),
                      ]),
                      i("v-uni-view", { staticClass: "txt" }, [
                        t._v(t._s(t.service.des)),
                      ]),
                    ],
                    1,
                  ),
                  i(
                    "v-uni-view",
                    { staticClass: "reason_box flex_box" },
                    [
                      i("v-uni-view", { staticClass: "tit" }, [
                        t._v("上传图片"),
                      ]),
                      i(
                        "v-uni-view",
                        { staticClass: "txt img_box" },
                        t._l(t.service.pics, function (e, a) {
                          return i("img", {
                            key: a,
                            attrs: { text: e, src: e },
                            on: {
                              click: function (i) {
                                (arguments[0] = i = t.$handleEvent(i)),
                                  t.previewImage(e, t.service.pics);
                              },
                            },
                          });
                        }),
                        0,
                      ),
                    ],
                    1,
                  ),
                  i(
                    "v-uni-view",
                    { staticClass: "reason_box flex_box remarks_box" },
                    [
                      i("v-uni-view", { staticClass: "tit" }, [
                        t._v("申请时间"),
                      ]),
                      i("v-uni-view", { staticClass: "txt" }, [
                        t._v(t._s(t.service.add_time)),
                      ]),
                    ],
                    1,
                  ),
                ],
                1,
              ),
              2 == t.status
                ? i(
                    "v-uni-view",
                    [
                      i("uv-divider", {
                        staticClass: "block_title",
                        attrs: { text: "客服审核信息", textSize: "13" },
                      }),
                      i(
                        "v-uni-view",
                        { staticClass: "reason_box flex_box remarks_box" },
                        [
                          i("v-uni-view", { staticClass: "tit" }, [
                            t._v("审核状态"),
                          ]),
                          i("v-uni-view", { staticClass: "txt" }, [
                            t._v(
                              t._s(
                                1 == t.service.kefu_status
                                  ? "已同意"
                                  : "已拒绝",
                              ),
                            ),
                          ]),
                        ],
                        1,
                      ),
                      i(
                        "v-uni-view",
                        { staticClass: "reason_box flex_box remarks_box" },
                        [
                          i("v-uni-view", { staticClass: "tit" }, [
                            t._v("审核理由"),
                          ]),
                          i("v-uni-view", { staticClass: "txt" }, [
                            t._v(t._s(t.service.kefu_des)),
                          ]),
                        ],
                        1,
                      ),
                      i(
                        "v-uni-view",
                        { staticClass: "reason_box flex_box remarks_box" },
                        [
                          i("v-uni-view", { staticClass: "tit" }, [
                            t._v("审核时间"),
                          ]),
                          i("v-uni-view", { staticClass: "txt" }, [
                            t._v(t._s(t.service.kefu_time)),
                          ]),
                        ],
                        1,
                      ),
                    ],
                    1,
                  )
                : t._e(),
              i(
                "v-uni-view",
                { staticClass: "btn_box" },
                [
                  1 == t.status
                    ? i("v-uni-view", { staticClass: "sub_btn dis" }, [
                        t._v("客服审核中"),
                      ])
                    : t._e(),
                ],
                1,
              ),
            ],
            1,
          );
        },
        s = [];
    },
    "2d21": function (t, e, i) {
      "use strict";
      var a = i("db37"),
        n = i.n(a);
      n.a;
    },
    "3a07": function (t, e, i) {
      var a = i("c86c");
      (e = a(!1)),
        e.push([
          t.i,
          '@charset "UTF-8";\r\n/**\r\n * 这里是uni-app内置的常用样式变量\r\n *\r\n * uni-app 官方扩展插件及插件市场（https://ext.dcloud.net.cn）上很多三方插件均使用了这些样式变量\r\n * 如果你是插件开发者，建议你使用scss预处理，并在插件代码中直接使用这些变量（无需 import 这个文件），方便用户通过搭积木的方式开发整体风格一致的App\r\n *\r\n */\r\n/**\r\n * 如果你是App开发者（插件使用者），你可以通过修改这些变量来定制自己的插件主题，实现自定义主题功能\r\n *\r\n * 如果你的项目同样使用了scss预处理，你也可以直接在你的 scss 代码中使用如下变量，同时无需 import 这个文件\r\n */\r\n/* 颜色变量 */\r\n/* 行为相关颜色 */\r\n/* 文字基本颜色 */\r\n/* 背景颜色 */\r\n/* 边框颜色 */\r\n/* 尺寸变量 */\r\n/* 文字尺寸 */\r\n/* 图片尺寸 */\r\n/* Border Radius */\r\n/* 水平间距 */\r\n/* 垂直间距 */\r\n/* 透明度 */\r\n/* 文章场景相关 */uni-view[data-v-c2d489ac], uni-scroll-view[data-v-c2d489ac], uni-swiper-item[data-v-c2d489ac]{display:flex;flex-direction:column;flex-shrink:0;flex-grow:0;flex-basis:auto;align-items:stretch;align-content:flex-start}.uv-divider[data-v-c2d489ac]{display:flex;flex-direction:row;flex-direction:row;align-items:center;margin:15px 0}.uv-divider__text[data-v-c2d489ac]{margin:0 15px}.uv-divider__dot[data-v-c2d489ac]{font-size:12px;margin:0 12px;color:#c0c4cc}',
          "",
        ]),
        (t.exports = e);
    },
    4589: function (t, e, i) {
      "use strict";
      i.r(e);
      var a = i("bc7d"),
        n = i("4ab8");
      for (var s in n)
        ["default"].indexOf(s) < 0 &&
          (function (t) {
            i.d(e, t, function () {
              return n[t];
            });
          })(s);
      i("26c4");
      var r = i("828b"),
        o = Object(r["a"])(
          n["default"],
          a["b"],
          a["c"],
          !1,
          null,
          "c2d489ac",
          null,
          !1,
          a["a"],
          void 0,
        );
      e["default"] = o.exports;
    },
    "4ab8": function (t, e, i) {
      "use strict";
      i.r(e);
      var a = i("6811"),
        n = i.n(a);
      for (var s in a)
        ["default"].indexOf(s) < 0 &&
          (function (t) {
            i.d(e, t, function () {
              return a[t];
            });
          })(s);
      e["default"] = n.a;
    },
    5132: function (t, e, i) {
      var a = i("3a07");
      a.__esModule && (a = a.default),
        "string" === typeof a && (a = [[t.i, a, ""]]),
        a.locals && (t.exports = a.locals);
      var n = i("967d").default;
      n("71a84af6", a, !0, { sourceMap: !1, shadowMode: !1 });
    },
    6811: function (t, e, i) {
      "use strict";
      i("6a54");
      var a = i("f5bd").default;
      Object.defineProperty(e, "__esModule", { value: !0 }),
        (e.default = void 0);
      var n = a(i("4d8f0")),
        s = a(i("9463")),
        r = a(i("caf4")),
        o = {
          name: "uv-divider",
          mixins: [n.default, s.default, r.default],
          emits: ["click"],
          computed: {
            textStyle: function () {
              var t = {};
              return (
                (t.fontSize = this.$uv.addUnit(this.textSize)),
                (t.color = this.textColor),
                t
              );
            },
            leftLineStyle: function () {
              var t = {};
              return (
                "left" === this.textPosition
                  ? (t.width = "80rpx")
                  : (t.flex = 1),
                t
              );
            },
            rightLineStyle: function () {
              var t = {};
              return (
                "right" === this.textPosition
                  ? (t.width = "80rpx")
                  : (t.flex = 1),
                t
              );
            },
          },
          methods: {
            click: function () {
              this.$emit("click");
            },
          },
        };
      e.default = o;
    },
    bc7d: function (t, e, i) {
      "use strict";
      i.d(e, "b", function () {
        return n;
      }),
        i.d(e, "c", function () {
          return s;
        }),
        i.d(e, "a", function () {
          return a;
        });
      var a = { uvLine: i("73b2").default },
        n = function () {
          var t = this,
            e = t.$createElement,
            i = t._self._c || e;
          return i(
            "v-uni-view",
            {
              staticClass: "uv-divider",
              style: [t.$uv.addStyle(t.customStyle)],
              on: {
                click: function (e) {
                  (arguments[0] = e = t.$handleEvent(e)),
                    t.click.apply(void 0, arguments);
                },
              },
            },
            [
              i("uv-line", {
                attrs: {
                  color: t.lineColor,
                  customStyle: t.leftLineStyle,
                  hairline: t.hairline,
                  dashed: t.dashed,
                },
              }),
              t.dot
                ? i("v-uni-text", { staticClass: "uv-divider__dot" }, [
                    t._v("●"),
                  ])
                : t.text
                  ? i(
                      "v-uni-text",
                      { staticClass: "uv-divider__text", style: [t.textStyle] },
                      [t._v(t._s(t.text))],
                    )
                  : t._e(),
              i("uv-line", {
                attrs: {
                  color: t.lineColor,
                  customStyle: t.rightLineStyle,
                  hairline: t.hairline,
                  dashed: t.dashed,
                },
              }),
            ],
            1,
          );
        },
        s = [];
    },
    caf4: function (t, e, i) {
      "use strict";
      i("6a54");
      var a = i("f5bd").default;
      Object.defineProperty(e, "__esModule", { value: !0 }),
        (e.default = void 0),
        i("64aa");
      var n,
        s,
        r = a(i("9b1b")),
        o = {
          props: (0, r.default)(
            {
              dashed: { type: Boolean, default: !1 },
              hairline: { type: Boolean, default: !0 },
              dot: { type: Boolean, default: !1 },
              textPosition: { type: String, default: "center" },
              text: { type: [String, Number], default: "" },
              textSize: { type: [String, Number], default: 14 },
              textColor: { type: String, default: "#909399" },
              lineColor: { type: String, default: "#dcdfe6" },
            },
            null === (n = uni.$uv) ||
              void 0 === n ||
              null === (s = n.props) ||
              void 0 === s
              ? void 0
              : s.divider,
          ),
        };
      e.default = o;
    },
    d24a: function (t, e, i) {
      var a = i("c86c");
      (e = a(!1)),
        e.push([
          t.i,
          '@charset "UTF-8";\r\n/**\r\n * 这里是uni-app内置的常用样式变量\r\n *\r\n * uni-app 官方扩展插件及插件市场（https://ext.dcloud.net.cn）上很多三方插件均使用了这些样式变量\r\n * 如果你是插件开发者，建议你使用scss预处理，并在插件代码中直接使用这些变量（无需 import 这个文件），方便用户通过搭积木的方式开发整体风格一致的App\r\n *\r\n */\r\n/**\r\n * 如果你是App开发者（插件使用者），你可以通过修改这些变量来定制自己的插件主题，实现自定义主题功能\r\n *\r\n * 如果你的项目同样使用了scss预处理，你也可以直接在你的 scss 代码中使用如下变量，同时无需 import 这个文件\r\n */\r\n/* 颜色变量 */\r\n/* 行为相关颜色 */\r\n/* 文字基本颜色 */\r\n/* 背景颜色 */\r\n/* 边框颜色 */\r\n/* 尺寸变量 */\r\n/* 文字尺寸 */\r\n/* 图片尺寸 */\r\n/* Border Radius */\r\n/* 水平间距 */\r\n/* 垂直间距 */\r\n/* 透明度 */\r\n/* 文章场景相关 */.uv-divider[data-v-677c8d50]{background:#f8f8f8;padding:%?36?% %?30?%}.content[data-v-677c8d50]{padding-bottom:%?155?%}.top_box[data-v-677c8d50]{padding:%?30?% 0;margin:0 %?30?%;border-bottom:%?2?% solid #eee}.top_box uni-view[data-v-677c8d50]{font-size:13px;white-space:nowrap}.top_box .order_num[data-v-677c8d50]{justify-content:flex-start;flex:1}.top_box .order_num .num[data-v-677c8d50]{font-weight:700}.top_box .order_num .copy_btn[data-v-677c8d50]{margin-left:%?12?%;color:#2979ff}.top_box .status[data-v-677c8d50]{font-size:12px;font-weight:700}.goods_msg[data-v-677c8d50]{padding:%?35?% %?30?% %?10?%}.goods_msg .img[data-v-677c8d50]{width:%?120?%;height:%?120?%;border-radius:%?10?%}.goods_msg .txt[data-v-677c8d50]{width:calc(100% - %?145?%)}.goods_msg .txt .name[data-v-677c8d50]{font-size:16px}.goods_msg .txt .price_box[data-v-677c8d50]{margin-top:%?14?%}.goods_msg .txt .price_box .price[data-v-677c8d50]{color:#fd2c28;font-weight:700;font-size:17px}.goods_msg .txt .price_box .price .unit[data-v-677c8d50]{font-size:12px}.goods_msg .txt .price_box .num[data-v-677c8d50]{font-size:15px}.item[data-v-677c8d50]{padding:%?30?%}[data-v-677c8d50] .uv-form-item .uni-textarea-textarea{font-size:14px}[data-v-677c8d50] .uv-form-item .uni-textarea-placeholder{font-size:14px}[data-v-677c8d50] .uv-form-item.remarks_box .uv-form-item__body__left{align-items:flex-start!important}[data-v-677c8d50] .uv-form-item__body{padding:%?0?%!important}[data-v-677c8d50] .uv-form-item__body__left{width:auto!important;margin-right:%?24?%!important;position:relative;font-weight:700;width:%?145?%!important;white-space:nowrap}[data-v-677c8d50] .uv-form-item__body__left__content{padding:0!important}[data-v-677c8d50] .uv-form-item__body__left__content__label span{display:inline-block;position:relative;z-index:10}[data-v-677c8d50] .uv-form-item__body__left__content__label span::before{z-index:-1;display:block;content:"";width:72%;height:%?20?%;border-radius:%?20?%;background:#ffe610;position:absolute;left:50%;bottom:%?6?%;-webkit-transform:translate(-50%);transform:translate(-50%)}[data-v-677c8d50] .uv-form-item__body__right__message{margin-left:%?170?%!important;margin-top:%?4?%!important}.btn_box[data-v-677c8d50]{position:fixed;max-width:480px;width:100%;margin:0 auto;box-shadow:0 0 %?10?% #ddd;left:0;right:0;bottom:0;background:#fff;z-index:20}.btn_box .sub_btn[data-v-677c8d50]{margin:%?20?% %?30?%;background:#ffe610;height:%?90?%;line-height:%?90?%;border-radius:%?90?%;font-size:15px;font-weight:700;text-align:center}.btn_box .sub_btn.dis[data-v-677c8d50]{background:#eee;color:#666}.reason_box[data-v-677c8d50]{padding:%?30?%}.reason_box.remarks_box[data-v-677c8d50]{align-items:flex-start}.reason_box .tit[data-v-677c8d50]{font-size:15px;font-weight:700;position:relative;z-index:10}.reason_box .tit[data-v-677c8d50]::before{z-index:-1;display:block;content:"";width:72%;height:%?20?%;border-radius:%?20?%;background:#ffe610;position:absolute;left:50%;bottom:%?6?%;-webkit-transform:translate(-50%);transform:translate(-50%)}.reason_box .txt[data-v-677c8d50]{width:calc(100% - %?170?%)}.reason_box .txt.img_box[data-v-677c8d50]{display:grid;grid-template-columns:repeat(3,1fr);grid-gap:%?25?%}.reason_box .txt.img_box img[data-v-677c8d50]{border-radius:%?15?%;width:%?162?%;height:%?162?%}.line_box[data-v-677c8d50]{background:#f8f8f8;width:100%;height:%?14?%;margin:%?30?% auto}',
          "",
        ]),
        (t.exports = e);
    },
    db37: function (t, e, i) {
      var a = i("d24a");
      a.__esModule && (a = a.default),
        "string" === typeof a && (a = [[t.i, a, ""]]),
        a.locals && (t.exports = a.locals);
      var n = i("967d").default;
      n("52c09cd0", a, !0, { sourceMap: !1, shadowMode: !1 });
    },
    e557: function (t, e, i) {
      "use strict";
      i.r(e);
      var a = i("280d"),
        n = i("0b4f");
      for (var s in n)
        ["default"].indexOf(s) < 0 &&
          (function (t) {
            i.d(e, t, function () {
              return n[t];
            });
          })(s);
      i("2d21");
      var r = i("828b"),
        o = Object(r["a"])(
          n["default"],
          a["b"],
          a["c"],
          !1,
          null,
          "677c8d50",
          null,
          !1,
          a["a"],
          void 0,
        );
      e["default"] = o.exports;
    },
    f598: function (t, e, i) {
      "use strict";
      i("6a54");
      var a = i("f5bd").default;
      Object.defineProperty(e, "__esModule", { value: !0 }),
        (e.default = void 0);
      var n = a(i("9b1b")),
        s = a(i("2634")),
        r = a(i("2fdc"));
      i("0c26"), i("dd2b"), i("c223"), i("fd3c"), i("aa9c");
      var o = i("e74a"),
        d = a(i("2609")),
        c = i("15b8"),
        u = {
          data: function () {
            return {
              id: 0,
              order: [],
              service: [],
              form: { s_des: "", s_pics: [], s_status: 1 },
              rules: {
                s_des: {
                  type: "string",
                  required: !0,
                  message: "请输入审核理由",
                  trigger: ["blur", "change"],
                },
                s_pics: {
                  type: "array",
                  required: !1,
                  message: "请上传图片",
                  trigger: ["blur", "change"],
                },
              },
              verList: [
                { label: "同意", name: 1 },
                { label: "拒绝", name: 2 },
              ],
              status: 0,
              palte: "h5",
            };
          },
          onLoad: function (t) {
            (this.id = t.id), this.getSellerServiceInfo();
          },
          onPullDownRefresh: function () {
            var t = this;
            uni.showLoading({ title: "刷新中" }),
              setTimeout(function () {
                uni.hideLoading(),
                  t.getSellerServiceInfo(),
                  uni.showToast({ title: "刷新成功", duration: 1e3 }),
                  uni.stopPullDownRefresh();
              }, 300);
          },
          methods: {
            getSellerServiceInfo: function () {
              var t = this;
              uni.showLoading({ title: "加载中.." }),
                (0, o.send)(
                  "/wechat/OrderService/getSellerServiceInfo",
                  { id: this.id },
                  !1,
                ).then(function (e) {
                  uni.hideLoading();
                  var i = e.status,
                    a = e.msg,
                    n = e.data;
                  if (1 != i) return uni.$uv.toast(a);
                  (t.order = n.order),
                    (t.service = n.service),
                    (t.status = n.status),
                    t.initUpload(n.up_config);
                });
            },
            copyOrderNum: function (t) {
              uni.setClipboardData({
                data: t.trim(),
                success: function () {
                  uni.$uv.toast("复制成功");
                },
                fail: function () {
                  uni.$uv.toast("复制失败");
                },
              });
            },
            submit: function () {
              console.log(this.form);
              var t = this;
              this.$refs.form
                .validate()
                .then(function (e) {
                  uni.$uv.throttle(t.vertifyService, 1500);
                })
                .catch(function (t) {});
            },
            vertifyService: function () {
              var t = this;
              uni.showLoading({ title: "加载中.." }),
                (0, o.send)(
                  "/wechat/OrderService/vertifyService",
                  {
                    id: this.id,
                    s_des: this.form.s_des,
                    s_pics: this.form.s_pics,
                    s_status: this.form.s_status,
                  },
                  !1,
                ).then(function (e) {
                  uni.hideLoading();
                  var i = e.status,
                    a = e.msg;
                  e.data;
                  if (1 != i) return uni.$uv.toast(a);
                  uni.$uv.toast(a),
                    setTimeout(function () {
                      t.getSellerServiceInfo();
                    }, 2e3);
                });
            },
            upImg: function (t, e) {
              var i = this;
              return (0, r.default)(
                (0, s.default)().mark(function a() {
                  var n;
                  return (0, s.default)().wrap(function (a) {
                    while (1)
                      switch ((a.prev = a.next)) {
                        case 0:
                          return (a.next = 2), (0, c.uploadCompressImgs)(t);
                        case 2:
                          (n = a.sent),
                            (0, o.send)(
                              "/wechat/Files/uploadBase64",
                              { label: "service", file: n },
                              !1,
                            ).then(function (t) {
                              t.status;
                              var a = t.msg,
                                n = t.data;
                              if (1 != t.code)
                                return (i.form.s_pics = []), uni.$uv.toast(a);
                              var s = i.form.s_pics[e];
                              i.form.s_pics.splice(
                                e,
                                1,
                                Object.assign(s, {
                                  status: "success",
                                  message: "",
                                  url: n.fullurl,
                                }),
                              );
                            });
                        case 4:
                        case "end":
                          return a.stop();
                      }
                  }, a);
                }),
              )();
            },
            selectPic: function (t) {
              var e = this,
                i = [].concat(t.file),
                a = this.form.s_pics.length;
              i.map(function (t) {
                e.form.s_pics.push(
                  (0, n.default)(
                    (0, n.default)({}, t),
                    {},
                    { status: "uploading", message: "上传中" },
                  ),
                );
              });
              for (var s = 0; s < i.length; s++)
                "h5" == this.palte && this.upImg(i[s].url, a),
                  "mp-weixin" == this.palte && this.selectWeappPic(i[s].url, a),
                  a++;
            },
            initUpload: function (t) {
              "mp-weixin" == this.palte &&
                (this.uploader = new d.default({
                  domain: t.domain,
                  tokenUrl: t.token_url,
                  quality: 0.6,
                  prefix: t.prefix,
                }));
            },
            selectWeappPic: function (t, e) {
              var i = this;
              return (0, r.default)(
                (0, s.default)().mark(function a() {
                  var n, r;
                  return (0, s.default)().wrap(
                    function (a) {
                      while (1)
                        switch ((a.prev = a.next)) {
                          case 0:
                            return (
                              (a.prev = 0),
                              (a.next = 3),
                              i.uploader.uploadWechatAvatar({ avatarUrl: t })
                            );
                          case 3:
                            (n = a.sent),
                              console.log(n),
                              (r = i.form.s_pics[e]),
                              i.form.s_pics.splice(
                                e,
                                1,
                                Object.assign(r, {
                                  status: "success",
                                  message: "",
                                  url: n.url,
                                }),
                              ),
                              (a.next = 13);
                            break;
                          case 9:
                            (a.prev = 9),
                              (a.t0 = a["catch"](0)),
                              uni.showToast({
                                title:
                                  "发送失败: " + (a.t0.message || "未知错误"),
                                icon: "none",
                              }),
                              console.error("发送失败:", a.t0);
                          case 13:
                          case "end":
                            return a.stop();
                        }
                    },
                    a,
                    null,
                    [[0, 9]],
                  );
                }),
              )();
            },
            deletePic: function (t) {
              console.log(this.form.s_pics),
                console.log(t),
                this.form.s_pics.splice(t.index, 1);
            },
            previewImage: function (t, e) {
              uni.previewImage({ current: t, urls: e });
            },
            jump: function (t) {
              uni.navigateTo({ url: t });
            },
          },
        };
      e.default = u;
    },
  },
]);
//# sourceMappingURL=pages_sub1-order-seller_service.1d7c1c07.js.map
