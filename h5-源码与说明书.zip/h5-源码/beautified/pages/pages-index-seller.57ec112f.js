(window["webpackJsonp"] = window["webpackJsonp"] || []).push([
  ["pages-index-seller"],
  {
    "141d": function (t, e, i) {
      var a = i("c86c");
      (e = a(!1)),
        e.push([
          t.i,
          '@charset "UTF-8";\r\n/**\r\n * 这里是uni-app内置的常用样式变量\r\n *\r\n * uni-app 官方扩展插件及插件市场（https://ext.dcloud.net.cn）上很多三方插件均使用了这些样式变量\r\n * 如果你是插件开发者，建议你使用scss预处理，并在插件代码中直接使用这些变量（无需 import 这个文件），方便用户通过搭积木的方式开发整体风格一致的App\r\n *\r\n */\r\n/**\r\n * 如果你是App开发者（插件使用者），你可以通过修改这些变量来定制自己的插件主题，实现自定义主题功能\r\n *\r\n * 如果你的项目同样使用了scss预处理，你也可以直接在你的 scss 代码中使用如下变量，同时无需 import 这个文件\r\n */\r\n/* 颜色变量 */\r\n/* 行为相关颜色 */\r\n/* 文字基本颜色 */\r\n/* 背景颜色 */\r\n/* 边框颜色 */\r\n/* 尺寸变量 */\r\n/* 文字尺寸 */\r\n/* 图片尺寸 */\r\n/* Border Radius */\r\n/* 水平间距 */\r\n/* 垂直间距 */\r\n/* 透明度 */\r\n/* 文章场景相关 */uni-view[data-v-17bb3196], uni-scroll-view[data-v-17bb3196], uni-swiper-item[data-v-17bb3196]{display:flex;flex-direction:column;flex-shrink:0;flex-grow:0;flex-basis:auto;align-items:stretch;align-content:flex-start}.uv-rate[data-v-17bb3196]{display:flex;flex-direction:row;align-items:center;margin:0;padding:0;touch-action:none}.uv-rate__content[data-v-17bb3196]{display:flex;flex-direction:row}.uv-rate__content__item[data-v-17bb3196]{position:relative}.uv-rate__content__item__icon-wrap--half[data-v-17bb3196]{position:absolute;overflow:hidden;top:0;left:0}.uv-icon[data-v-17bb3196]{box-sizing:border-box}',
          "",
        ]),
        (t.exports = e);
    },
    "280a": function (t, e, i) {
      "use strict";
      i("6a54");
      var a = i("f5bd").default;
      Object.defineProperty(e, "__esModule", { value: !0 }),
        (e.default = void 0);
      var n = a(i("2634")),
        o = a(i("2fdc"));
      i("64aa");
      var s = a(i("4d8f0")),
        r = a(i("9463")),
        d = a(i("4d4c")),
        l = {
          name: "uv-rate",
          mixins: [s.default, r.default, d.default],
          data: function () {
            return {
              elId: "",
              elClass: "",
              rateBoxLeft: 0,
              activeIndex: 0,
              rateWidth: 0,
              moving: !1,
            };
          },
          watch: {
            value: function (t) {
              this.activeIndex = t;
            },
            modelValue: function (t) {
              this.activeIndex = t;
            },
          },
          created: function () {
            (this.activeIndex = Number(this.value || this.modelValue)),
              (this.elId = this.$uv.guid()),
              (this.elClass = this.$uv.guid());
          },
          mounted: function () {
            this.init();
          },
          methods: {
            init: function () {
              var t = this;
              this.$uv.sleep(200).then(function () {
                t.getRateItemRect(), t.getRateIconWrapRect();
              });
            },
            getRateItemRect: function () {
              var t = this;
              return (0, o.default)(
                (0, n.default)().mark(function e() {
                  return (0, n.default)().wrap(function (e) {
                    while (1)
                      switch ((e.prev = e.next)) {
                        case 0:
                          return (e.next = 2), t.$uv.sleep();
                        case 2:
                          t.$uvGetRect("#" + t.elId).then(function (e) {
                            t.rateBoxLeft = e.left;
                          });
                        case 3:
                        case "end":
                          return e.stop();
                      }
                  }, e);
                }),
              )();
            },
            getRateIconWrapRect: function () {
              var t = this;
              this.$uvGetRect("." + this.elClass).then(function (e) {
                t.rateWidth = e.width;
              });
            },
            touchMove: function (t) {
              if (this.touchable) {
                this.preventEvent(t);
                var e =
                  (t.changedTouches && t.changedTouches[0].pageX) ||
                  (t.detail && t.detail.pageX);
                this.getActiveIndex(e);
              }
            },
            touchEnd: function (t) {
              if (this.touchable) {
                this.preventEvent(t);
                var e =
                  (t.changedTouches && t.changedTouches[0].pageX) ||
                  (t.detail && t.detail.pageX);
                this.getActiveIndex(e);
              }
            },
            clickHandler: function (t, e) {
              if ("ios" !== this.$uv.os() || !this.moving) {
                this.preventEvent(t);
                var i;
                (i =
                  (t.changedTouches && t.changedTouches[0].pageX) ||
                  (t.detail && t.detail.pageX)),
                  this.getActiveIndex(i, !0);
              }
            },
            changeEvent: function () {
              this.$emit("change", this.activeIndex),
                this.$emit("input", this.activeIndex),
                this.$emit("update:modelValue", this.activeIndex);
            },
            getActiveIndex: function (t) {
              var e = this,
                i =
                  arguments.length > 1 &&
                  void 0 !== arguments[1] &&
                  arguments[1];
              if (!this.disabled && !this.readonly) {
                var a = this.rateWidth * this.count + this.rateBoxLeft;
                t = this.$uv.range(this.rateBoxLeft, a, t) - this.rateBoxLeft;
                var n,
                  o = t;
                if (this.allowHalf) {
                  n = Math.floor(o / this.rateWidth);
                  var s = o % this.rateWidth;
                  s <= this.rateWidth / 2 && s > 0
                    ? (n += 0.5)
                    : s > this.rateWidth / 2 && n++;
                } else {
                  n = Math.floor(o / this.rateWidth);
                  var r = o % this.rateWidth;
                  i ? r > 0 && n++ : r > this.rateWidth / 2 && n++;
                }
                (this.activeIndex = Math.min(n, this.count)),
                  this.activeIndex < this.minCount &&
                    (this.activeIndex = this.minCount),
                  this.changeEvent(),
                  setTimeout(function () {
                    e.moving = !0;
                  }, 10),
                  setTimeout(function () {
                    e.moving = !1;
                  }, 10);
              }
            },
          },
        };
      e.default = l;
    },
    "298e": function (t, e, i) {
      "use strict";
      i.d(e, "b", function () {
        return n;
      }),
        i.d(e, "c", function () {
          return o;
        }),
        i.d(e, "a", function () {
          return a;
        });
      var a = {
          uvLoadingIcon: i("17f5").default,
          uvIcon: i("1a07").default,
          uvRate: i("5f70").default,
        },
        n = function () {
          var t = this,
            e = t.$createElement,
            i = t._self._c || e;
          return i(
            "v-uni-view",
            { staticClass: "content" },
            [
              t.loading
                ? i(
                    "v-uni-view",
                    { staticClass: "page_loading" },
                    [
                      i(
                        "v-uni-view",
                        { staticClass: "loading_inner" },
                        [
                          i("uv-loading-icon", {
                            attrs: {
                              mode: "circle",
                              color: "#999",
                              size: "28",
                            },
                          }),
                          i("v-uni-text", { staticClass: "loading_text" }, [
                            t._v("加载中..."),
                          ]),
                        ],
                        1,
                      ),
                    ],
                    1,
                  )
                : t._e(),
              i(
                "v-uni-view",
                { staticClass: "hero" },
                [
                  t.bg_images.length > 0
                    ? i(
                        "v-uni-swiper",
                        {
                          staticClass: "hero_swiper",
                          attrs: {
                            autoplay: t.album.length > 0,
                            circular: !0,
                            "indicator-dots": t.album.length > 1,
                            "indicator-color": "rgba(255,255,255,0.4)",
                            "indicator-active-color": "#fff",
                            interval: 4e3,
                          },
                        },
                        t._l(t.bg_images, function (t, e) {
                          return i(
                            "v-uni-swiper-item",
                            { key: e },
                            [
                              i("v-uni-image", {
                                staticClass: "hero_img",
                                attrs: { src: t, mode: "aspectFill" },
                              }),
                            ],
                            1,
                          );
                        }),
                        1,
                      )
                    : i("v-uni-image", {
                        staticClass: "hero_img",
                        attrs: { src: t.info.avatar, mode: "aspectFill" },
                      }),
                  i("v-uni-view", { staticClass: "hero_bottom_fade" }),
                ],
                1,
              ),
              t.info.id
                ? i(
                    "v-uni-view",
                    { staticClass: "seller_card" },
                    [
                      t.star_info.star_num > 0 || t.star_info.order_num > 0
                        ? i(
                            "v-uni-view",
                            { staticClass: "star_bar" },
                            [
                              i(
                                "v-uni-view",
                                { staticClass: "sb_item" },
                                [
                                  t.star_info.star_num > 0
                                    ? i(
                                        "v-uni-view",
                                        { staticClass: "sb_val" },
                                        [
                                          i(
                                            "v-uni-text",
                                            { staticClass: "sb_star" },
                                            [t._v("★")],
                                          ),
                                          i(
                                            "v-uni-text",
                                            { staticClass: "sb_num" },
                                            [t._v(t._s(t.star_info.star_avg))],
                                          ),
                                        ],
                                        1,
                                      )
                                    : i(
                                        "v-uni-text",
                                        { staticClass: "sb_none" },
                                        [t._v("暂无")],
                                      ),
                                  i("v-uni-text", { staticClass: "sb_label" }, [
                                    t._v("评分"),
                                  ]),
                                ],
                                1,
                              ),
                              i("v-uni-view", { staticClass: "sb_divider" }),
                              i(
                                "v-uni-view",
                                { staticClass: "sb_item" },
                                [
                                  t.star_info.star_num > 0
                                    ? i(
                                        "v-uni-text",
                                        { staticClass: "sb_num" },
                                        [t._v(t._s(t.star_info.star_num))],
                                      )
                                    : i(
                                        "v-uni-text",
                                        { staticClass: "sb_none" },
                                        [t._v("暂无")],
                                      ),
                                  i("v-uni-text", { staticClass: "sb_label" }, [
                                    t._v("评论单量"),
                                  ]),
                                ],
                                1,
                              ),
                              i("v-uni-view", { staticClass: "sb_divider" }),
                              i(
                                "v-uni-view",
                                { staticClass: "sb_item" },
                                [
                                  i("v-uni-text", { staticClass: "sb_num" }, [
                                    t._v(t._s(t.star_info.order_num)),
                                  ]),
                                  i("v-uni-text", { staticClass: "sb_label" }, [
                                    t._v("服务单量"),
                                  ]),
                                ],
                                1,
                              ),
                            ],
                            1,
                          )
                        : t._e(),
                      i(
                        "v-uni-view",
                        { staticClass: "avatar_box" },
                        [
                          i("v-uni-image", {
                            staticClass: "avatar",
                            attrs: { src: t.info.avatar, mode: "aspectFill" },
                          }),
                        ],
                        1,
                      ),
                      i(
                        "v-uni-view",
                        { staticClass: "seller_info" },
                        [
                          i(
                            "v-uni-view",
                            { staticClass: "name_row" },
                            [
                              i("v-uni-text", { staticClass: "nickname" }, [
                                t._v(t._s(t.info.nickname)),
                              ]),
                              1 == t.info.sex
                                ? i("v-uni-text", { staticClass: "sex_icon" }, [
                                    t._v("♂"),
                                  ])
                                : 2 == t.info.sex
                                  ? i(
                                      "v-uni-text",
                                      { staticClass: "sex_icon girl" },
                                      [t._v("♀")],
                                    )
                                  : t._e(),
                              void 0 !== t.info.online
                                ? i(
                                    "v-uni-view",
                                    {
                                      staticClass: "order_status",
                                      class:
                                        0 == t.info.online
                                          ? "rest"
                                          : 1 == t.info.order_status
                                            ? "busy"
                                            : "available",
                                    },
                                    [
                                      i("v-uni-text", { staticClass: "dot" }),
                                      i("v-uni-text", [
                                        t._v(
                                          t._s(
                                            0 == t.info.online
                                              ? "休息中"
                                              : 1 == t.info.order_status
                                                ? "服务中"
                                                : "可接单",
                                          ),
                                        ),
                                      ]),
                                    ],
                                    1,
                                  )
                                : t._e(),
                            ],
                            1,
                          ),
                          t.tags.length > 0
                            ? i(
                                "v-uni-view",
                                {
                                  staticClass: "tag_list",
                                  class: {
                                    boy: 1 == t.info.sex,
                                    girl: 2 == t.info.sex,
                                  },
                                },
                                t._l(t.tags, function (e, a) {
                                  return i(
                                    "v-uni-view",
                                    { key: a, staticClass: "tag_item" },
                                    [t._v(t._s(e.name))],
                                  );
                                }),
                                1,
                              )
                            : t._e(),
                          t.info.voice_url
                            ? i(
                                "v-uni-view",
                                {
                                  staticClass: "voice_bar",
                                  class: {
                                    boy: 1 == t.info.sex,
                                    girl: 2 == t.info.sex,
                                    playing: t.voicePlaying,
                                  },
                                  on: {
                                    click: function (e) {
                                      (arguments[0] = e = t.$handleEvent(e)),
                                        t.playVoice.apply(void 0, arguments);
                                    },
                                  },
                                },
                                [
                                  i(
                                    "v-uni-view",
                                    { staticClass: "voice_play" },
                                    [
                                      i("uv-icon", {
                                        attrs: {
                                          name: t.voicePlaying
                                            ? "pause"
                                            : "play-right-fill",
                                          color: "#fff",
                                          size: "16",
                                        },
                                      }),
                                    ],
                                    1,
                                  ),
                                  i(
                                    "v-uni-view",
                                    {
                                      staticClass: "wave_progress",
                                      class: { playing: t.voicePlaying },
                                    },
                                    [
                                      i("v-uni-view", {
                                        staticClass: "wave_inner",
                                        style: { width: t.voiceProgress + "%" },
                                      }),
                                      i(
                                        "v-uni-view",
                                        { staticClass: "wave_lines" },
                                        t._l(4, function (t, e) {
                                          return i("v-uni-view", {
                                            key: e,
                                            staticClass: "wl",
                                          });
                                        }),
                                        1,
                                      ),
                                    ],
                                    1,
                                  ),
                                  i(
                                    "v-uni-text",
                                    { staticClass: "voice_time" },
                                    [t._v(t._s(t.voiceRemain))],
                                  ),
                                ],
                                1,
                              )
                            : t._e(),
                        ],
                        1,
                      ),
                    ],
                    1,
                  )
                : t._e(),
              t.info.intro
                ? i(
                    "v-uni-view",
                    { staticClass: "intro_section" },
                    [
                      i("v-uni-view", { staticClass: "section_title" }, [
                        t._v("TA的介绍"),
                      ]),
                      i("v-uni-view", { staticClass: "intro_text" }, [
                        t._v(t._s(t.info.intro)),
                      ]),
                    ],
                    1,
                  )
                : t._e(),
              0 == t.info.seller_ban
                ? i(
                    "v-uni-view",
                    { staticClass: "tabs_section" },
                    [
                      i(
                        "v-uni-view",
                        { staticClass: "tab_header" },
                        [
                          i(
                            "v-uni-view",
                            {
                              staticClass: "tab_item",
                              class: { active: 0 == t.currentTab },
                              on: {
                                click: function (e) {
                                  (arguments[0] = e = t.$handleEvent(e)),
                                    t.changeTab(0);
                                },
                              },
                            },
                            [t._v("TA的相册")],
                          ),
                          1 != t.hide_seller_comment
                            ? i(
                                "v-uni-view",
                                {
                                  staticClass: "tab_item",
                                  class: { active: 1 == t.currentTab },
                                  on: {
                                    click: function (e) {
                                      (arguments[0] = e = t.$handleEvent(e)),
                                        t.changeTab(1);
                                    },
                                  },
                                },
                                [
                                  t._v("TA的评价"),
                                  t.comment_total > 0
                                    ? i(
                                        "v-uni-text",
                                        { staticClass: "tab_comment_num" },
                                        [
                                          t._v(
                                            "(" + t._s(t.comment_total) + ")",
                                          ),
                                        ],
                                      )
                                    : t._e(),
                                ],
                                1,
                              )
                            : t._e(),
                          i(
                            "v-uni-view",
                            {
                              staticClass: "tab_item",
                              class: { active: 2 == t.currentTab },
                              on: {
                                click: function (e) {
                                  (arguments[0] = e = t.$handleEvent(e)),
                                    t.changeTab(2);
                                },
                              },
                            },
                            [t._v("TA的故事")],
                          ),
                        ],
                        1,
                      ),
                      0 == t.currentTab
                        ? i(
                            "v-uni-view",
                            { staticClass: "tab_content" },
                            [
                              t.album.length > 0
                                ? i(
                                    "v-uni-view",
                                    { staticClass: "album_grid" },
                                    t._l(t.album, function (e, a) {
                                      return i("v-uni-image", {
                                        key: a,
                                        staticClass: "album_item",
                                        attrs: {
                                          src: e.image,
                                          mode: "aspectFill",
                                        },
                                        on: {
                                          click: function (e) {
                                            (arguments[0] = e =
                                              t.$handleEvent(e)),
                                              t.previewAlbum(a);
                                          },
                                        },
                                      });
                                    }),
                                    1,
                                  )
                                : i(
                                    "v-uni-view",
                                    { staticClass: "empty_state" },
                                    [
                                      i("uv-icon", {
                                        attrs: {
                                          name: "photo",
                                          color: "#ccc",
                                          size: "60",
                                        },
                                      }),
                                      i(
                                        "v-uni-text",
                                        { staticClass: "empty_text" },
                                        [t._v("暂无相册")],
                                      ),
                                    ],
                                    1,
                                  ),
                            ],
                            1,
                          )
                        : 1 == t.currentTab
                          ? i(
                              "v-uni-view",
                              { staticClass: "tab_content" },
                              [
                                t.comment_list.length > 0
                                  ? i(
                                      "v-uni-view",
                                      { staticClass: "comment_list" },
                                      t._l(t.comment_list, function (e, a) {
                                        return i(
                                          "v-uni-view",
                                          {
                                            key: a,
                                            staticClass: "comment_col",
                                          },
                                          [
                                            i(
                                              "v-uni-view",
                                              { staticClass: "top flex_box" },
                                              [
                                                i(
                                                  "v-uni-view",
                                                  { staticClass: "head_box" },
                                                  [
                                                    e.user &&
                                                    e.user.avatar_frame
                                                      ? i("img", {
                                                          staticClass:
                                                            "head_frame",
                                                          attrs: {
                                                            src: e.user
                                                              .avatar_frame,
                                                          },
                                                        })
                                                      : t._e(),
                                                    i("img", {
                                                      staticClass: "img",
                                                      attrs: {
                                                        src: e.user
                                                          ? e.user.avatar
                                                          : "",
                                                      },
                                                    }),
                                                  ],
                                                ),
                                                i(
                                                  "v-uni-view",
                                                  { staticClass: "u_info" },
                                                  [
                                                    i(
                                                      "v-uni-view",
                                                      {
                                                        staticClass:
                                                          "name_row flex_box",
                                                      },
                                                      [
                                                        i(
                                                          "v-uni-view",
                                                          {
                                                            staticClass:
                                                              "name uv-line-1",
                                                          },
                                                          [
                                                            t._v(
                                                              t._s(
                                                                e.user
                                                                  ? e.user
                                                                      .nickname
                                                                  : "匿名用户",
                                                              ),
                                                            ),
                                                          ],
                                                        ),
                                                        e.user &&
                                                        e.user.level_icon
                                                          ? i("img", {
                                                              staticClass:
                                                                "level",
                                                              attrs: {
                                                                mode: "aspectFit",
                                                                src: e.user
                                                                  .level_icon,
                                                              },
                                                            })
                                                          : t._e(),
                                                        i(
                                                          "v-uni-view",
                                                          {
                                                            staticClass: "time",
                                                          },
                                                          [
                                                            t._v(
                                                              t._s(e.add_time),
                                                            ),
                                                          ],
                                                        ),
                                                      ],
                                                      1,
                                                    ),
                                                    i(
                                                      "v-uni-view",
                                                      {
                                                        staticClass:
                                                          "star_row flex_box",
                                                      },
                                                      [
                                                        i(
                                                          "v-uni-view",
                                                          {
                                                            staticClass:
                                                              "star_label",
                                                          },
                                                          [t._v("评分")],
                                                        ),
                                                        i("uv-rate", {
                                                          attrs: {
                                                            value: e.star,
                                                            size: "14",
                                                            gutter: "2",
                                                            readonly: !0,
                                                          },
                                                        }),
                                                      ],
                                                      1,
                                                    ),
                                                  ],
                                                  1,
                                                ),
                                              ],
                                              1,
                                            ),
                                            i(
                                              "v-uni-view",
                                              { staticClass: "des_wrap" },
                                              [
                                                i(
                                                  "v-uni-view",
                                                  {
                                                    staticClass: "des",
                                                    class: {
                                                      clamp: !t.des_expand[a],
                                                    },
                                                  },
                                                  [t._v(t._s(e.des))],
                                                ),
                                                t.isDesOver(e.des) &&
                                                !t.des_expand[a]
                                                  ? i(
                                                      "v-uni-view",
                                                      {
                                                        staticClass:
                                                          "des_toggle abs",
                                                        on: {
                                                          click: function (e) {
                                                            (arguments[0] = e =
                                                              t.$handleEvent(
                                                                e,
                                                              )),
                                                              t.toggleDesExpand(
                                                                a,
                                                              );
                                                          },
                                                        },
                                                      },
                                                      [
                                                        i("v-uni-text", [
                                                          t._v("展开"),
                                                        ]),
                                                        i("uv-icon", {
                                                          attrs: {
                                                            name: "arrow-down",
                                                            color: "#666",
                                                            size: "12",
                                                          },
                                                        }),
                                                      ],
                                                      1,
                                                    )
                                                  : t._e(),
                                                t.isDesOver(e.des) &&
                                                t.des_expand[a]
                                                  ? i(
                                                      "v-uni-view",
                                                      {
                                                        staticClass:
                                                          "des_toggle bottom flex_box",
                                                        on: {
                                                          click: function (e) {
                                                            (arguments[0] = e =
                                                              t.$handleEvent(
                                                                e,
                                                              )),
                                                              t.toggleDesExpand(
                                                                a,
                                                              );
                                                          },
                                                        },
                                                      },
                                                      [
                                                        i("v-uni-text", [
                                                          t._v("收起"),
                                                        ]),
                                                        i("uv-icon", {
                                                          attrs: {
                                                            name: "arrow-up",
                                                            color: "#666",
                                                            size: "12",
                                                          },
                                                        }),
                                                      ],
                                                      1,
                                                    )
                                                  : t._e(),
                                              ],
                                              1,
                                            ),
                                            e.imgs && e.imgs.length > 0
                                              ? i(
                                                  "v-uni-view",
                                                  {
                                                    staticClass:
                                                      "c_imgs flex_box",
                                                  },
                                                  t._l(e.imgs, function (a, n) {
                                                    return i("img", {
                                                      key: n,
                                                      staticClass: "c_img",
                                                      attrs: {
                                                        src: a,
                                                        mode: "aspectFill",
                                                      },
                                                      on: {
                                                        click: function (i) {
                                                          (arguments[0] = i =
                                                            t.$handleEvent(i)),
                                                            t.previewCommentImage(
                                                              e,
                                                              n,
                                                            );
                                                        },
                                                      },
                                                    });
                                                  }),
                                                  0,
                                                )
                                              : t._e(),
                                            e.goods && 1 == e.goods.is_raffle
                                              ? i(
                                                  "v-uni-view",
                                                  {
                                                    staticClass:
                                                      "g_row flex_box raffle_row",
                                                    on: {
                                                      click: function (i) {
                                                        (arguments[0] = i =
                                                          t.$handleEvent(i)),
                                                          t.jump(
                                                            "/pages/active/goods?id=" +
                                                              e.goods.raffle_id,
                                                          );
                                                      },
                                                    },
                                                  },
                                                  [
                                                    i("img", {
                                                      staticClass: "g_thumb",
                                                      attrs: {
                                                        src: e.goods
                                                          .raffle_thumb,
                                                        mode: "aspectFill",
                                                      },
                                                    }),
                                                    i(
                                                      "v-uni-view",
                                                      {
                                                        staticClass:
                                                          "g_title uv-line-1",
                                                      },
                                                      [
                                                        t._v(
                                                          t._s(
                                                            e.goods
                                                              .raffle_title ||
                                                              e.goods.title,
                                                          ),
                                                        ),
                                                      ],
                                                    ),
                                                    i(
                                                      "v-uni-view",
                                                      {
                                                        staticClass:
                                                          "raffle_tag",
                                                      },
                                                      [t._v("转盘")],
                                                    ),
                                                    i("uv-icon", {
                                                      staticClass: "g_arrow",
                                                      attrs: {
                                                        name: "arrow-right",
                                                        color: "#bbb",
                                                        size: "14",
                                                      },
                                                    }),
                                                  ],
                                                  1,
                                                )
                                              : e.goods
                                                ? i(
                                                    "v-uni-view",
                                                    {
                                                      staticClass:
                                                        "g_row flex_box",
                                                      on: {
                                                        click: function (i) {
                                                          (arguments[0] = i =
                                                            t.$handleEvent(i)),
                                                            t.jump(
                                                              "/pages/index/goods?id=" +
                                                                e.goods.id,
                                                            );
                                                        },
                                                      },
                                                    },
                                                    [
                                                      i("img", {
                                                        staticClass: "g_thumb",
                                                        attrs: {
                                                          src: e.goods.thumb,
                                                          mode: "aspectFill",
                                                        },
                                                      }),
                                                      i(
                                                        "v-uni-view",
                                                        {
                                                          staticClass:
                                                            "g_title uv-line-1",
                                                        },
                                                        [
                                                          t._v(
                                                            t._s(e.goods.title),
                                                          ),
                                                        ],
                                                      ),
                                                    ],
                                                    1,
                                                  )
                                                : t._e(),
                                          ],
                                          1,
                                        );
                                      }),
                                      1,
                                    )
                                  : 1 == t.comment_loaded
                                    ? i(
                                        "v-uni-view",
                                        { staticClass: "empty_state" },
                                        [
                                          i("uv-icon", {
                                            attrs: {
                                              name: "list",
                                              color: "#ccc",
                                              size: "60",
                                            },
                                          }),
                                          i(
                                            "v-uni-text",
                                            { staticClass: "empty_text" },
                                            [t._v("暂无评价")],
                                          ),
                                        ],
                                        1,
                                      )
                                    : t._e(),
                              ],
                              1,
                            )
                          : i(
                              "v-uni-view",
                              { staticClass: "tab_content" },
                              [
                                t.goods.length > 0
                                  ? i(
                                      "v-uni-view",
                                      { staticClass: "story_list" },
                                      t._l(t.goods, function (e, a) {
                                        return i(
                                          "v-uni-view",
                                          {
                                            key: a,
                                            staticClass: "story_card",
                                            on: {
                                              click: function (i) {
                                                (arguments[0] = i =
                                                  t.$handleEvent(i)),
                                                  t.jump(
                                                    "/pages/index/goods?id=" +
                                                      e.id,
                                                  );
                                              },
                                            },
                                          },
                                          [
                                            i("v-uni-image", {
                                              staticClass: "story_thumb",
                                              attrs: {
                                                src: e.thumb || e.pics,
                                                mode: "aspectFill",
                                                "lazy-load": !0,
                                              },
                                            }),
                                            i(
                                              "v-uni-view",
                                              { staticClass: "story_info" },
                                              [
                                                i(
                                                  "v-uni-view",
                                                  {
                                                    staticClass:
                                                      "story_title uv-line-1",
                                                  },
                                                  [t._v(t._s(e.title))],
                                                ),
                                                i(
                                                  "v-uni-view",
                                                  {
                                                    staticClass:
                                                      "story_intro uv-line-2",
                                                  },
                                                  [t._v(t._s(e.intro))],
                                                ),
                                                i(
                                                  "v-uni-view",
                                                  {
                                                    staticClass: "story_price",
                                                  },
                                                  [
                                                    t._v(
                                                      "￥" +
                                                        t._s(
                                                          e.price || e.priced,
                                                        ),
                                                    ),
                                                  ],
                                                ),
                                              ],
                                              1,
                                            ),
                                          ],
                                          1,
                                        );
                                      }),
                                      1,
                                    )
                                  : i(
                                      "v-uni-view",
                                      { staticClass: "empty_state" },
                                      [
                                        i("uv-icon", {
                                          attrs: {
                                            name: "list",
                                            color: "#ccc",
                                            size: "60",
                                          },
                                        }),
                                        i(
                                          "v-uni-text",
                                          { staticClass: "empty_text" },
                                          [t._v("暂无故事")],
                                        ),
                                      ],
                                      1,
                                    ),
                              ],
                              1,
                            ),
                    ],
                    1,
                  )
                : t._e(),
              0 == t.info.seller_ban &&
              1 == t.currentTab &&
              t.comment_list.length > 0 &&
              1 == t.comment_no_more
                ? i("v-uni-view", { staticClass: "load_more_out" }, [
                    t._v("没有更多了"),
                  ])
                : t._e(),
              1 == t.info.seller_ban
                ? i(
                    "v-uni-view",
                    { staticClass: "banned_tip" },
                    [i("v-uni-text", [t._v("该打手已被封禁")])],
                    1,
                  )
                : t._e(),
              0 == t.info.seller_ban
                ? i(
                    "v-uni-view",
                    { staticClass: "bottom_bar" },
                    [
                      i(
                        "v-uni-view",
                        {
                          staticClass: "order_btn",
                          on: {
                            click: function (e) {
                              (arguments[0] = e = t.$handleEvent(e)),
                                t.showOrderPopup.apply(void 0, arguments);
                            },
                          },
                        },
                        [i("v-uni-text", [t._v("点单")])],
                        1,
                      ),
                    ],
                    1,
                  )
                : t._e(),
              i("goodsSelect", {
                attrs: { show: t.showGoodsSelect, seller_id: t.seller_id },
                on: {
                  select: function (e) {
                    (arguments[0] = e = t.$handleEvent(e)),
                      t.onGoodsSelect.apply(void 0, arguments);
                  },
                  close: function (e) {
                    (arguments[0] = e = t.$handleEvent(e)),
                      (t.showGoodsSelect = !1);
                  },
                },
              }),
            ],
            1,
          );
        },
        o = [];
    },
    "336a": function (t, e, i) {
      "use strict";
      var a = i("dba3"),
        n = i.n(a);
      n.a;
    },
    "43f9": function (t, e, i) {
      "use strict";
      i.r(e);
      var a = i("280a"),
        n = i.n(a);
      for (var o in a)
        ["default"].indexOf(o) < 0 &&
          (function (t) {
            i.d(e, t, function () {
              return a[t];
            });
          })(o);
      e["default"] = n.a;
    },
    "4d4c": function (t, e, i) {
      "use strict";
      i("6a54");
      var a = i("f5bd").default;
      Object.defineProperty(e, "__esModule", { value: !0 }),
        (e.default = void 0),
        i("64aa");
      var n,
        o,
        s = a(i("9b1b")),
        r = {
          props: (0, s.default)(
            {
              value: { type: [String, Number], default: 0 },
              modelValue: { type: [String, Number], default: 0 },
              count: { type: [String, Number], default: 5 },
              disabled: { type: Boolean, default: !1 },
              readonly: { type: Boolean, default: !1 },
              size: { type: [String, Number], default: 18 },
              inactiveColor: { type: String, default: "#b2b2b2" },
              activeColor: { type: String, default: "#FA3534" },
              gutter: { type: [String, Number], default: 4 },
              minCount: { type: [String, Number], default: 1 },
              allowHalf: { type: Boolean, default: !1 },
              activeIcon: { type: String, default: "star-fill" },
              inactiveIcon: { type: String, default: "star" },
              touchable: { type: Boolean, default: !1 },
            },
            null === (n = uni.$uv) ||
              void 0 === n ||
              null === (o = n.props) ||
              void 0 === o
              ? void 0
              : o.rate,
          ),
        };
      e.default = r;
    },
    "5f70": function (t, e, i) {
      "use strict";
      i.r(e);
      var a = i("9ccd"),
        n = i("43f9");
      for (var o in n)
        ["default"].indexOf(o) < 0 &&
          (function (t) {
            i.d(e, t, function () {
              return n[t];
            });
          })(o);
      i("336a");
      var s = i("828b"),
        r = Object(s["a"])(
          n["default"],
          a["b"],
          a["c"],
          !1,
          null,
          "17bb3196",
          null,
          !1,
          a["a"],
          void 0,
        );
      e["default"] = r.exports;
    },
    "63ab": function (t, e, i) {
      "use strict";
      var a = i("8203"),
        n = i.n(a);
      n.a;
    },
    8203: function (t, e, i) {
      var a = i("b2f7");
      a.__esModule && (a = a.default),
        "string" === typeof a && (a = [[t.i, a, ""]]),
        a.locals && (t.exports = a.locals);
      var n = i("967d").default;
      n("7d45736c", a, !0, { sourceMap: !1, shadowMode: !1 });
    },
    "9ccd": function (t, e, i) {
      "use strict";
      i.d(e, "b", function () {
        return n;
      }),
        i.d(e, "c", function () {
          return o;
        }),
        i.d(e, "a", function () {
          return a;
        });
      var a = { uvIcon: i("1a07").default },
        n = function () {
          var t = this,
            e = t.$createElement,
            i = t._self._c || e;
          return i(
            "v-uni-view",
            {
              ref: "uv-rate",
              staticClass: "uv-rate",
              style: [t.$uv.addStyle(t.customStyle)],
              attrs: { id: t.elId },
            },
            [
              i(
                "v-uni-view",
                {
                  staticClass: "uv-rate__content",
                  on: {
                    touchmove: function (e) {
                      e.stopPropagation(),
                        (arguments[0] = e = t.$handleEvent(e)),
                        t.touchMove.apply(void 0, arguments);
                    },
                    touchend: function (e) {
                      e.stopPropagation(),
                        (arguments[0] = e = t.$handleEvent(e)),
                        t.touchEnd.apply(void 0, arguments);
                    },
                  },
                },
                t._l(Number(t.count), function (e, a) {
                  return i(
                    "v-uni-view",
                    {
                      key: a,
                      staticClass: "uv-rate__content__item",
                      class: [t.elClass],
                    },
                    [
                      i(
                        "v-uni-view",
                        {
                          ref: "uv-rate__content__item__icon-wrap",
                          refInFor: !0,
                          staticClass: "uv-rate__content__item__icon-wrap",
                          on: {
                            click: function (e) {
                              e.stopPropagation(),
                                (arguments[0] = e = t.$handleEvent(e)),
                                t.clickHandler(e, a + 1);
                            },
                          },
                        },
                        [
                          i("uv-icon", {
                            attrs: {
                              name:
                                Math.floor(t.activeIndex) > a
                                  ? t.activeIcon
                                  : t.inactiveIcon,
                              color: t.disabled
                                ? "#c8c9cc"
                                : Math.floor(t.activeIndex) > a
                                  ? t.activeColor
                                  : t.inactiveColor,
                              "custom-style": {
                                "padding-left": t.$uv.addUnit(t.gutter / 2),
                                "padding-right": t.$uv.addUnit(t.gutter / 2),
                              },
                              size: t.size,
                            },
                          }),
                        ],
                        1,
                      ),
                      t.allowHalf
                        ? i(
                            "v-uni-view",
                            {
                              ref: "uv-rate__content__item__icon-wrap",
                              refInFor: !0,
                              staticClass:
                                "uv-rate__content__item__icon-wrap uv-rate__content__item__icon-wrap--half",
                              style: [
                                { width: t.$uv.addUnit(t.rateWidth / 2) },
                              ],
                              on: {
                                click: function (e) {
                                  e.stopPropagation(),
                                    (arguments[0] = e = t.$handleEvent(e)),
                                    t.clickHandler(e, a + 1);
                                },
                              },
                            },
                            [
                              i("uv-icon", {
                                attrs: {
                                  name:
                                    Math.ceil(t.activeIndex) > a
                                      ? t.activeIcon
                                      : t.inactiveIcon,
                                  color: t.disabled
                                    ? "#c8c9cc"
                                    : Math.ceil(t.activeIndex) > a
                                      ? t.activeColor
                                      : t.inactiveColor,
                                  "custom-style": {
                                    "padding-left": t.$uv.addUnit(t.gutter / 2),
                                    "padding-right": t.$uv.addUnit(
                                      t.gutter / 2,
                                    ),
                                  },
                                  size: t.size,
                                },
                              }),
                            ],
                            1,
                          )
                        : t._e(),
                    ],
                    1,
                  );
                }),
                1,
              ),
            ],
            1,
          );
        },
        o = [];
    },
    b2f7: function (t, e, i) {
      var a = i("c86c");
      (e = a(!1)),
        e.push([
          t.i,
          '@charset "UTF-8";\r\n/**\r\n * 这里是uni-app内置的常用样式变量\r\n *\r\n * uni-app 官方扩展插件及插件市场（https://ext.dcloud.net.cn）上很多三方插件均使用了这些样式变量\r\n * 如果你是插件开发者，建议你使用scss预处理，并在插件代码中直接使用这些变量（无需 import 这个文件），方便用户通过搭积木的方式开发整体风格一致的App\r\n *\r\n */\r\n/**\r\n * 如果你是App开发者（插件使用者），你可以通过修改这些变量来定制自己的插件主题，实现自定义主题功能\r\n *\r\n * 如果你的项目同样使用了scss预处理，你也可以直接在你的 scss 代码中使用如下变量，同时无需 import 这个文件\r\n */\r\n/* 颜色变量 */\r\n/* 行为相关颜色 */\r\n/* 文字基本颜色 */\r\n/* 背景颜色 */\r\n/* 边框颜色 */\r\n/* 尺寸变量 */\r\n/* 文字尺寸 */\r\n/* 图片尺寸 */\r\n/* Border Radius */\r\n/* 水平间距 */\r\n/* 垂直间距 */\r\n/* 透明度 */\r\n/* 文章场景相关 */uni-page-body[data-v-6165d532]{background:#f5f5f5}body.?%PAGE?%[data-v-6165d532]{background:#f5f5f5}.page_loading[data-v-6165d532]{position:fixed;left:0;top:0;right:0;bottom:0;background:#f5f5f5;display:flex;align-items:center;justify-content:center;z-index:999}.page_loading .loading_inner[data-v-6165d532]{display:flex;flex-direction:column;align-items:center}.page_loading .loading_text[data-v-6165d532]{font-size:13px;color:#999;margin-top:%?16?%}.content[data-v-6165d532]{padding-bottom:%?160?%}\r\n/* 顶部背景区 */.hero[data-v-6165d532]{position:relative;height:%?380?%;overflow:hidden}.hero .hero_swiper[data-v-6165d532]{position:absolute;top:0;left:0;width:100%;height:100%}.hero .hero_img[data-v-6165d532]{position:absolute;top:0;left:0;width:100%;height:100%}.hero .hero_bottom_fade[data-v-6165d532]{position:absolute;bottom:0;left:0;width:100%;height:%?200?%;background:linear-gradient(180deg,hsla(0,0%,100%,0),hsla(0,0%,100%,.95))}\r\n/* 打手信息卡片 */.seller_card[data-v-6165d532]{display:flex;flex-wrap:wrap;align-items:flex-start;padding:%?24?% %?24?%;width:calc(100% - %?60?%);margin:%?-80?% %?30?% %?20?%;background:#fff;border-radius:%?24?%;box-shadow:0 %?8?% %?30?% rgba(0,0,0,.1);position:relative;z-index:3}.star_bar[data-v-6165d532]{width:100%;display:flex;align-items:center;background:#f7f8fa;border-radius:%?16?%;padding:%?20?% 0;margin-bottom:%?20?%;box-sizing:border-box}.star_bar .sb_item[data-v-6165d532]{flex:1;display:flex;flex-direction:column;align-items:center;min-width:0}.star_bar .sb_item .sb_val[data-v-6165d532]{display:flex;align-items:baseline}.star_bar .sb_item .sb_val .sb_star[data-v-6165d532]{color:#ffb800;font-size:%?26?%;margin-right:%?6?%}.star_bar .sb_item .sb_num[data-v-6165d532]{font-size:%?32?%;font-weight:700;color:#333}.star_bar .sb_item .sb_none[data-v-6165d532]{font-size:%?30?%;color:#c0c4cc}.star_bar .sb_item .sb_label[data-v-6165d532]{font-size:%?22?%;color:#999;margin-top:%?6?%}.star_bar .sb_divider[data-v-6165d532]{width:%?1?%;height:%?44?%;background:#e8e8e8;flex-shrink:0}.avatar_box[data-v-6165d532]{position:relative;margin-right:%?24?%;flex-shrink:0}.avatar_box .avatar[data-v-6165d532]{width:%?140?%;height:%?140?%;border-radius:%?16?%;border:none}.seller_info[data-v-6165d532]{flex:1;min-width:0}.name_row[data-v-6165d532]{display:flex;align-items:center;margin-bottom:%?12?%}.name_row .nickname[data-v-6165d532]{font-size:15px;font-weight:700;color:#333;max-width:%?300?%;overflow:hidden;text-overflow:ellipsis;white-space:nowrap}.name_row .sex_icon[data-v-6165d532]{margin-left:%?8?%;font-size:16px;color:#479afa;font-weight:700}.name_row .sex_icon.girl[data-v-6165d532]{color:#ff7bac}.name_row .order_status[data-v-6165d532]{margin-left:auto;font-size:13px;font-weight:700;display:flex;align-items:center}.name_row .order_status .dot[data-v-6165d532]{display:inline-block;width:%?16?%;height:%?16?%;border-radius:50%;margin-right:%?8?%}.name_row .order_status.busy[data-v-6165d532]{color:#ff7a00}.name_row .order_status.busy .dot[data-v-6165d532]{background:#ff7a00}.name_row .order_status.available[data-v-6165d532]{color:#6dff26}.name_row .order_status.available .dot[data-v-6165d532]{background:#6dff26}.name_row .order_status.rest[data-v-6165d532]{color:#999}.name_row .order_status.rest .dot[data-v-6165d532]{background:#ccc}.tag_list[data-v-6165d532]{display:flex;flex-wrap:wrap;margin-bottom:%?12?%}.tag_list .tag_item[data-v-6165d532]{padding:%?4?% %?16?%;font-size:11px;border-radius:%?20?%;margin-right:%?10?%;margin-bottom:%?6?%}.tag_list.boy .tag_item[data-v-6165d532]{background:rgba(74,144,217,.15);color:#479afa}.tag_list.girl .tag_item[data-v-6165d532]{background:rgba(255,123,172,.15);color:#ff7bac}.voice_bar[data-v-6165d532]{display:flex;align-items:center;padding:%?8?% %?16?%;border-radius:%?100?%;background:#f0f0f0;width:-webkit-fit-content;width:fit-content;max-width:100%\r\n  /* 小程序版：多条错落竖条波浪动画（撑满） */}.voice_bar .voice_play[data-v-6165d532]{width:%?44?%;height:%?44?%;border-radius:50%;display:flex;align-items:center;justify-content:center;flex-shrink:0;background:#ffe610}.voice_bar.boy .voice_play[data-v-6165d532]{background:#479afa}.voice_bar.girl .voice_play[data-v-6165d532]{background:#ff7bac}.voice_bar .wave_progress[data-v-6165d532]{width:%?140?%;position:relative;height:%?36?%;margin:0 %?12?%;overflow:hidden;border-radius:%?8?%;background:#ddd}.voice_bar .wave_progress .wave_inner[data-v-6165d532]{position:absolute;left:0;top:0;height:100%;border-radius:%?8?%;transition:width .1s linear;background:#ffe610;overflow:hidden}.voice_bar .wave_progress .wave_lines[data-v-6165d532]{position:absolute;left:0;top:0;right:0;bottom:0;display:flex;align-items:center;justify-content:space-around;z-index:2}.voice_bar .wave_progress .wave_lines .wl[data-v-6165d532]{width:%?4?%;height:50%;border-radius:%?4?%;background:#999}.voice_bar .wave_progress.playing .wave_lines .wl[data-v-6165d532]{background:#fff}.voice_bar .wave_progress.playing .wl[data-v-6165d532]:nth-child(1){-webkit-animation:wv1-data-v-6165d532 .8s ease-in-out infinite;animation:wv1-data-v-6165d532 .8s ease-in-out infinite}.voice_bar .wave_progress.playing .wl[data-v-6165d532]:nth-child(2){-webkit-animation:wv2-data-v-6165d532 .8s ease-in-out infinite;animation:wv2-data-v-6165d532 .8s ease-in-out infinite}.voice_bar .wave_progress.playing .wl[data-v-6165d532]:nth-child(3){-webkit-animation:wv3-data-v-6165d532 .8s ease-in-out infinite;animation:wv3-data-v-6165d532 .8s ease-in-out infinite}.voice_bar .wave_progress.playing .wl[data-v-6165d532]:nth-child(4){-webkit-animation:wv4-data-v-6165d532 .8s ease-in-out infinite;animation:wv4-data-v-6165d532 .8s ease-in-out infinite}.voice_bar.boy .wave_inner[data-v-6165d532]{background:#479afa}.voice_bar.girl .wave_inner[data-v-6165d532]{background:#ff7bac}.voice_bar .wave_lines.mp[data-v-6165d532]{width:%?140?%;flex-shrink:0;display:flex;align-items:center;justify-content:space-between;height:%?36?%;margin:0 %?12?%}.voice_bar .wave_lines.mp .wl[data-v-6165d532]{flex:1;margin:0 %?2?%;border-radius:%?2?%;background:#bbb}.voice_bar .wave_lines.mp .wl[data-v-6165d532]:nth-child(1){height:30%}.voice_bar .wave_lines.mp .wl[data-v-6165d532]:nth-child(2){height:60%}.voice_bar .wave_lines.mp .wl[data-v-6165d532]:nth-child(3){height:90%}.voice_bar .wave_lines.mp .wl[data-v-6165d532]:nth-child(4){height:50%}.voice_bar .wave_lines.mp .wl[data-v-6165d532]:nth-child(5){height:100%}.voice_bar .wave_lines.mp .wl[data-v-6165d532]:nth-child(6){height:65%}.voice_bar .wave_lines.mp .wl[data-v-6165d532]:nth-child(7){height:35%}.voice_bar .wave_lines.mp .wl[data-v-6165d532]:nth-child(8){height:75%}.voice_bar .wave_lines.mp .wl[data-v-6165d532]:nth-child(9){height:45%}.voice_bar .wave_lines.mp.playing .wl[data-v-6165d532]{background:#ffe610}.voice_bar .wave_lines.mp.playing .wl[data-v-6165d532]:nth-child(1){-webkit-animation:wv1-data-v-6165d532 .7s ease-in-out infinite;animation:wv1-data-v-6165d532 .7s ease-in-out infinite}.voice_bar .wave_lines.mp.playing .wl[data-v-6165d532]:nth-child(2){-webkit-animation:wv2-data-v-6165d532 .7s ease-in-out infinite;animation:wv2-data-v-6165d532 .7s ease-in-out infinite}.voice_bar .wave_lines.mp.playing .wl[data-v-6165d532]:nth-child(3){-webkit-animation:wv3-data-v-6165d532 .7s ease-in-out infinite;animation:wv3-data-v-6165d532 .7s ease-in-out infinite}.voice_bar .wave_lines.mp.playing .wl[data-v-6165d532]:nth-child(4){-webkit-animation:wv4-data-v-6165d532 .7s ease-in-out infinite;animation:wv4-data-v-6165d532 .7s ease-in-out infinite}.voice_bar .wave_lines.mp.playing .wl[data-v-6165d532]:nth-child(5){-webkit-animation:wv1-data-v-6165d532 .7s ease-in-out .05s infinite;animation:wv1-data-v-6165d532 .7s ease-in-out .05s infinite}.voice_bar .wave_lines.mp.playing .wl[data-v-6165d532]:nth-child(6){-webkit-animation:wv2-data-v-6165d532 .7s ease-in-out .1s infinite;animation:wv2-data-v-6165d532 .7s ease-in-out .1s infinite}.voice_bar .wave_lines.mp.playing .wl[data-v-6165d532]:nth-child(7){-webkit-animation:wv3-data-v-6165d532 .7s ease-in-out .15s infinite;animation:wv3-data-v-6165d532 .7s ease-in-out .15s infinite}.voice_bar .wave_lines.mp.playing .wl[data-v-6165d532]:nth-child(8){-webkit-animation:wv4-data-v-6165d532 .7s ease-in-out .2s infinite;animation:wv4-data-v-6165d532 .7s ease-in-out .2s infinite}.voice_bar .wave_lines.mp.playing .wl[data-v-6165d532]:nth-child(9){-webkit-animation:wv1-data-v-6165d532 .7s ease-in-out .25s infinite;animation:wv1-data-v-6165d532 .7s ease-in-out .25s infinite}.voice_bar.boy .wave_lines.mp.playing .wl[data-v-6165d532]{background:#479afa}.voice_bar.girl .wave_lines.mp.playing .wl[data-v-6165d532]{background:#ff7bac}.voice_bar .voice_time[data-v-6165d532]{font-size:12px;color:#999;white-space:nowrap;min-width:%?32?%;text-align:right}.voice_bar.boy .voice_time[data-v-6165d532]{color:#479afa}.voice_bar.girl .voice_time[data-v-6165d532]{color:#ff7bac}@-webkit-keyframes wv1-data-v-6165d532{0%, 100%{height:40%}50%{height:90%}}@keyframes wv1-data-v-6165d532{0%, 100%{height:40%}50%{height:90%}}@-webkit-keyframes wv2-data-v-6165d532{0%, 100%{height:60%}50%{height:30%}}@keyframes wv2-data-v-6165d532{0%, 100%{height:60%}50%{height:30%}}@-webkit-keyframes wv3-data-v-6165d532{0%, 100%{height:30%}50%{height:80%}}@keyframes wv3-data-v-6165d532{0%, 100%{height:30%}50%{height:80%}}@-webkit-keyframes wv4-data-v-6165d532{0%, 100%{height:70%}50%{height:40%}}@keyframes wv4-data-v-6165d532{0%, 100%{height:70%}50%{height:40%}}\r\n/* TA的介绍 */.intro_section[data-v-6165d532]{margin:%?20?% %?30?% %?20?%;background:#fff;border-radius:%?20?%;padding:%?24?%;position:relative;z-index:3;box-shadow:0 %?4?% %?20?% rgba(0,0,0,.06)}.intro_section .section_title[data-v-6165d532]{font-size:15px;font-weight:700;margin-bottom:%?16?%;position:relative;padding-left:%?16?%}.intro_section .section_title[data-v-6165d532]::before{content:"";position:absolute;left:0;top:50%;-webkit-transform:translateY(-50%);transform:translateY(-50%);width:%?6?%;height:%?24?%;background:#ffe610;border-radius:%?6?%}.intro_section .intro_text[data-v-6165d532]{color:#333;font-size:14px;line-height:1.6;white-space:pre-line}\r\n/* Tabs */.tabs_section[data-v-6165d532]{margin:0 %?30?%;background:#fff;border-radius:%?20?%;overflow:hidden;box-shadow:0 %?4?% %?20?% rgba(0,0,0,.06)}.tab_header[data-v-6165d532]{display:flex;border-bottom:%?2?% solid #f2f2f2}.tab_header .tab_comment_num[data-v-6165d532]{font-size:12px;font-weight:400;color:#999}.tab_header .tab_item[data-v-6165d532]{flex:1;text-align:center;padding:%?24?% 0;font-size:15px;color:#999;position:relative;font-weight:700}.tab_header .tab_item.active[data-v-6165d532]{color:#000}.tab_header .tab_item.active[data-v-6165d532]::after{content:"";position:absolute;bottom:0;left:50%;-webkit-transform:translateX(-50%);transform:translateX(-50%);width:%?60?%;height:%?4?%;background:#ffe610;border-radius:%?4?%}.tab_content[data-v-6165d532]{padding:%?24?%}\r\n/* 相册网格 */.album_grid[data-v-6165d532]{display:grid;grid-template-columns:repeat(3,1fr);grid-gap:%?10?%}.album_grid .album_item[data-v-6165d532]{width:100%;height:%?220?%;border-radius:%?12?%;overflow:hidden;background:#f5f5f5}\r\n/* 故事列表 */.story_list .story_card[data-v-6165d532]{display:flex;padding:%?16?% 0;border-bottom:%?2?% solid #f7f7f7}.story_list .story_card[data-v-6165d532]:last-child{border-bottom:none}.story_list .story_card .story_thumb[data-v-6165d532]{width:%?160?%;height:%?160?%;border-radius:%?12?%;margin-right:%?20?%;flex-shrink:0}.story_list .story_card .story_info[data-v-6165d532]{flex:1;display:flex;flex-direction:column;justify-content:space-between}.story_list .story_card .story_info .story_title[data-v-6165d532]{font-size:14px;font-weight:700;color:#333}.story_list .story_card .story_info .story_intro[data-v-6165d532]{font-size:12px;color:#999;line-height:1.4}.story_list .story_card .story_info .story_price[data-v-6165d532]{color:#fd2c28;font-weight:700;font-size:14px}\r\n/* 评价列表 */.comment_list .comment_col[data-v-6165d532]{padding:%?26?% %?24?% %?20?%;border-bottom:%?2?% solid #f5f5f5}.comment_list .comment_col[data-v-6165d532]:last-child{border-bottom:none}.comment_list .comment_col .top[data-v-6165d532]{justify-content:flex-start;overflow:visible}.comment_list .comment_col .top .head_box[data-v-6165d532]{position:relative;width:%?116?%;height:%?116?%;margin-left:%?-20?%;margin-right:%?14?%;flex-shrink:0}.comment_list .comment_col .top .head_box .img[data-v-6165d532]{position:absolute;left:50%;top:50%;-webkit-transform:translate(-50%,-50%);transform:translate(-50%,-50%);z-index:1;width:%?82?%;height:%?82?%;border-radius:50%}.comment_list .comment_col .top .head_box .head_frame[data-v-6165d532]{position:absolute;left:0;top:0;width:%?116?%;height:%?116?%;z-index:2;pointer-events:none}.comment_list .comment_col .top .u_info[data-v-6165d532]{flex:1;min-width:0}.comment_list .comment_col .top .u_info .name_row[data-v-6165d532]{justify-content:flex-start;margin-bottom:%?8?%}.comment_list .comment_col .top .u_info .name_row .name[data-v-6165d532]{flex:0 1 auto;min-width:0;max-width:9em;font-size:14px;font-weight:700}.comment_list .comment_col .top .u_info .name_row .level[data-v-6165d532]{flex-shrink:0;display:block;width:%?94?%;height:%?40?%;object-fit:contain;margin-left:%?15?%}.comment_list .comment_col .top .u_info .name_row .time[data-v-6165d532]{margin-left:auto;flex-shrink:0;font-size:12px;color:#999;font-weight:400}.comment_list .comment_col .top .u_info .star_row[data-v-6165d532]{justify-content:flex-start}.comment_list .comment_col .top .u_info .star_row .star_label[data-v-6165d532]{flex-shrink:0;font-size:12px;color:#999;margin-right:%?8?%}.comment_list .comment_col .des_wrap[data-v-6165d532]{position:relative;margin-top:%?5?%;padding-left:%?110?%;box-sizing:border-box}.comment_list .comment_col .des_wrap .des[data-v-6165d532]{font-size:14px;line-height:1.6;word-break:break-all}.comment_list .comment_col .des_wrap .des.clamp[data-v-6165d532]{display:-webkit-box;-webkit-box-orient:vertical;-webkit-line-clamp:3;overflow:hidden}.comment_list .comment_col .des_wrap .des_toggle[data-v-6165d532]{color:#666}.comment_list .comment_col .des_wrap .des_toggle uni-text[data-v-6165d532]{margin-right:%?4?%}.comment_list .comment_col .des_wrap .des_toggle.abs[data-v-6165d532]{position:absolute;right:0;bottom:0;z-index:1;display:flex;align-items:center;font-size:14px;line-height:1.6;padding-left:%?60?%;background:linear-gradient(90deg,hsla(0,0%,100%,0),#fff %?50?%)}.comment_list .comment_col .des_wrap .des_toggle.bottom[data-v-6165d532]{justify-content:flex-end;margin-top:%?6?%;font-size:12px}.comment_list .comment_col .c_imgs[data-v-6165d532]{margin-top:%?20?%;padding-left:%?110?%;box-sizing:border-box;justify-content:flex-start;flex-wrap:wrap}.comment_list .comment_col .c_imgs .c_img[data-v-6165d532]{flex-shrink:0;width:%?168?%;height:%?168?%;border-radius:%?10?%;margin:0 %?12?% %?12?% 0}.comment_list .comment_col .g_row[data-v-6165d532]{margin-top:%?16?%;margin-left:%?110?%;justify-content:flex-start;background:#f7f8fa;border-radius:%?10?%;padding:%?12?% %?16?%}.comment_list .comment_col .g_row .g_thumb[data-v-6165d532]{flex-shrink:0;width:%?56?%;height:%?56?%;border-radius:%?8?%;margin-right:%?14?%}.comment_list .comment_col .g_row .g_title[data-v-6165d532]{flex:1;min-width:0;font-size:12px;color:#666}.comment_list .comment_col .g_row.raffle_row[data-v-6165d532]{background:linear-gradient(90deg,#fff7e6,#fff);border:%?1?% solid #ffd9a3}.comment_list .comment_col .g_row .raffle_tag[data-v-6165d532]{flex-shrink:0;margin-right:%?8?%;padding:%?2?% %?12?%;font-size:11px;color:#fff;background:linear-gradient(90deg,#ffb300,#ff7a00);border-radius:%?20?%}.comment_list .comment_col .g_row .g_arrow[data-v-6165d532]{flex-shrink:0;margin-left:%?4?%}.load_more_out[data-v-6165d532]{text-align:center;color:#999;font-size:12px;padding:%?24?% 0 %?10?%}.empty_state[data-v-6165d532]{display:flex;flex-direction:column;align-items:center;padding:%?60?% 0}.empty_state .empty_text[data-v-6165d532]{color:#ccc;font-size:13px;margin-top:%?16?%}.banned_tip[data-v-6165d532]{text-align:center;padding:%?60?% %?30?%;color:#999;font-size:14px}\r\n/* 底部操作栏 */.bottom_bar[data-v-6165d532]{position:fixed;left:0;right:0;bottom:0;padding:%?20?% %?30?%;padding-bottom:calc(%?20?% + env(safe-area-inset-bottom));background:#fff;box-shadow:0 %?-4?% %?20?% rgba(0,0,0,.06);z-index:99}.bottom_bar .order_btn[data-v-6165d532]{display:flex;align-items:center;justify-content:center;height:%?88?%;background:#ffe610;border:%?4?% solid #000;border-radius:%?88?%}.bottom_bar .order_btn uni-text[data-v-6165d532]{font-size:16px;color:#000;font-weight:700}',
          "",
        ]),
        (t.exports = e);
    },
    ba6c: function (t, e, i) {
      "use strict";
      i.r(e);
      var a = i("c511"),
        n = i.n(a);
      for (var o in a)
        ["default"].indexOf(o) < 0 &&
          (function (t) {
            i.d(e, t, function () {
              return a[t];
            });
          })(o);
      e["default"] = n.a;
    },
    c511: function (t, e, i) {
      "use strict";
      i("6a54");
      var a = i("f5bd").default;
      Object.defineProperty(e, "__esModule", { value: !0 }),
        (e.default = void 0);
      var n = a(i("b7c7"));
      i("8f71"), i("bf0f"), i("fd3c"), i("aa9c"), i("c223");
      var o = i("e74a"),
        s = i("15b8"),
        r = {
          data: function () {
            return {
              tabs: [{ name: "TA的相册" }, { name: "TA的故事" }],
              currentTab: 0,
              hide_seller_comment: 0,
              seller_id: 0,
              user_id: 0,
              bg_img: "",
              goods: [],
              comment: [],
              follow_status: 0,
              info: {},
              page: 1,
              no_more: 0,
              status: "loading",
              base_url: s.baseUrl,
              album: [],
              tags: [],
              voicePlaying: !1,
              voiceProgress: 0,
              voiceRemain: "",
              voiceTimer: null,
              innerAudioContext: null,
              showGoodsSelect: !1,
              autoOpen: !1,
              loading: !0,
              comment_list: [],
              comment_page: 1,
              comment_no_more: 0,
              comment_total: 0,
              comment_loaded: 0,
              comment_loading: 0,
              des_expand: {},
              star_info: {},
            };
          },
          onLoad: function (t) {
            (this.seller_id = t.id),
              (this.autoOpen = "1" == t.autoOpen),
              this.getEvaluateConfig();
          },
          onShow: function () {
            this.seller_id && this.getSellerInfo();
          },
          onHide: function () {
            this.stopVoice();
          },
          onUnload: function () {
            this.stopVoice();
          },
          onPullDownRefresh: function () {
            var t = this;
            uni.showLoading({ title: "刷新中" }),
              setTimeout(function () {
                uni.hideLoading(), t.getSellerInfo(), uni.stopPullDownRefresh();
              }, 300);
          },
          onReachBottom: function () {
            1 == this.currentTab && this.getDarenCommentList();
          },
          computed: {
            bg_images: function () {
              var t = [];
              return (
                this.album &&
                  this.album.length > 0 &&
                  (t = this.album
                    .map(function (t) {
                      return t.image;
                    })
                    .filter(function (t) {
                      return t;
                    })),
                t
              );
            },
          },
          methods: {
            getSellerStarInfo: function () {
              var t = this;
              (0, o.send)(
                "/wechat/Daren/getSellerStarInfo",
                { seller_id: this.seller_id },
                !1,
              ).then(function (e) {
                var i = e.status,
                  a = e.data;
                1 == i && (t.star_info = a || {});
              });
            },
            getEvaluateConfig: function () {
              var t = this;
              uni.$evaluateConfig
                ? (this.hide_seller_comment =
                    1 == uni.$evaluateConfig.hide_seller_comment ? 1 : 0)
                : (0, o.send)("/wechat/Wechat/getEvaluateConfig", {}, !1)
                    .then(function (e) {
                      (uni.$evaluateConfig = e.data || {}),
                        (t.hide_seller_comment =
                          1 == uni.$evaluateConfig.hide_seller_comment ? 1 : 0);
                    })
                    .catch(function () {});
            },
            getSellerInfo: function () {
              var t = this;
              (this.loading = !0),
                (0, o.send)(
                  "/wechat/Daren/getDarenInfo",
                  { seller_id: this.seller_id, page: this.page },
                  !1,
                ).then(function (e) {
                  t.loading = !1;
                  var i = e.status,
                    a = e.msg,
                    n = e.data;
                  if (1 != i) return uni.$uv.toast(a);
                  (t.info = n.info || {}),
                    (t.album = n.album || []),
                    (t.tags = n.tags || []),
                    (t.follow_status = n.follow_status),
                    (t.user_id = n.user_id),
                    (t.bg_img = n.bg_img || ""),
                    (t.goods = n.goods || []),
                    (t.voiceRemain = t.info.voice_duration
                      ? t.info.voice_duration + "s"
                      : ""),
                    0 == t.comment_loaded && t.getDarenCommentList(),
                    t.getSellerStarInfo(),
                    t.autoOpen &&
                      ((t.autoOpen = !1),
                      setTimeout(function () {
                        t.$nextTick(function () {
                          t.showOrderPopup();
                        });
                      }, 1e3));
                });
            },
            getSellerGoodsList: function () {
              var t = this;
              (0, o.send)(
                "/wechat/Daren/getDarenGoodsList",
                { seller_id: this.seller_id, page: this.page },
                !1,
              ).then(function (e) {
                var i,
                  a = e.status,
                  o = e.msg,
                  s = e.data;
                if (1 != a) return uni.$uv.toast(o);
                t.page > 1
                  ? (i = t.goods).push.apply(i, (0, n.default)(s.goods))
                  : (t.goods = s.goods);
              });
            },
            changeTab: function (t) {
              (this.currentTab = t),
                1 == t &&
                  0 == this.comment_loaded &&
                  this.getDarenCommentList();
            },
            getDarenCommentList: function () {
              var t = this;
              1 != this.hide_seller_comment &&
                (1 == this.comment_loading ||
                  (1 == this.comment_loaded && 1 == this.comment_no_more) ||
                  ((this.comment_loading = 1),
                  (0, o.send)(
                    "/wechat/Daren/getDarenCommentList",
                    { seller_id: this.seller_id, page: this.comment_page },
                    !1,
                  )
                    .then(function (e) {
                      t.comment_loading = 0;
                      var i = e.status,
                        a = e.msg,
                        n = e.data;
                      if (1 != i)
                        return (t.comment_loaded = 1), uni.$uv.toast(a);
                      (t.comment_list = t.comment_list.concat(n.comment)),
                        (t.comment_total = n.total),
                        (t.comment_no_more = n.no_more),
                        (t.comment_loaded = 1),
                        t.comment_page++;
                    })
                    .catch(function () {
                      t.comment_loading = 0;
                    })));
            },
            previewCommentImage: function (t, e) {
              uni.previewImage({ current: t.imgs[e], urls: t.imgs });
            },
            isDesOver: function (t) {
              return !!t && t.length >= 55;
            },
            toggleDesExpand: function (t) {
              this.$set(this.des_expand, t, !this.des_expand[t]);
            },
            playVoice: function () {
              var t = this;
              if (this.info.voice_url)
                if (this.voicePlaying) this.stopVoice();
                else {
                  this.stopVoice(),
                    (this.innerAudioContext = uni.createInnerAudioContext()),
                    (this.innerAudioContext.src = this.info.voice_url),
                    (this.voicePlaying = !0),
                    (this.voiceProgress = 0);
                  var e = this.info.voice_duration || 0;
                  (this.voiceRemain = e + "s"),
                    (this.voiceTimer = setInterval(function () {
                      if (t.innerAudioContext && t.voicePlaying) {
                        e <= 0 &&
                          t.innerAudioContext.duration > 0 &&
                          (e = t.innerAudioContext.duration);
                        var i = t.innerAudioContext.currentTime || 0;
                        e > 0 &&
                          ((t.voiceProgress = Math.min(100, (i / e) * 100)),
                          (t.voiceRemain =
                            Math.max(0, Math.ceil(e - i)) + "s"));
                      }
                    }, 200)),
                    this.innerAudioContext.onTimeUpdate(function () {
                      t.innerAudioContext &&
                        e > 0 &&
                        ((t.voiceProgress =
                          (t.innerAudioContext.currentTime / e) * 100),
                        t.voiceProgress > 100 && (t.voiceProgress = 100),
                        (t.voiceRemain =
                          Math.max(
                            0,
                            Math.ceil(e - t.innerAudioContext.currentTime),
                          ) + "s"));
                    }),
                    this.innerAudioContext.onEnded(function () {
                      t.clearVoiceTimer(),
                        (t.voicePlaying = !1),
                        (t.voiceProgress = 0),
                        (t.voiceRemain = (t.info.voice_duration || 0) + "s");
                    }),
                    this.innerAudioContext.onError(function () {
                      t.clearVoiceTimer(),
                        (t.voicePlaying = !1),
                        (t.voiceProgress = 0),
                        (t.voiceRemain = (t.info.voice_duration || 0) + "s");
                    }),
                    this.innerAudioContext.play();
                }
            },
            clearVoiceTimer: function () {
              this.voiceTimer &&
                (clearInterval(this.voiceTimer), (this.voiceTimer = null));
            },
            stopVoice: function () {
              this.clearVoiceTimer(),
                this.innerAudioContext &&
                  (this.innerAudioContext.stop(),
                  this.innerAudioContext.destroy(),
                  (this.innerAudioContext = null)),
                (this.voicePlaying = !1),
                (this.voiceProgress = 0),
                (this.voiceRemain = this.info.voice_duration
                  ? this.info.voice_duration + "s"
                  : "");
            },
            showOrderPopup: function () {
              var t = this;
              0 != this.info.online
                ? 1 != this.info.online || 1 != this.info.order_status
                  ? (this.showGoodsSelect = !0)
                  : uni.showModal({
                      title: "提示",
                      content:
                        "该达人正在服务老板，可优先指定排队，超时未接单将自动重派大厅",
                      confirmText: "确认下单",
                      cancelText: "取消",
                      success: function (e) {
                        e.confirm && (t.showGoodsSelect = !0);
                      },
                    })
                : uni.showToast({
                    title: "当前达人休息中，欢迎稍后再来下单～",
                    icon: "none",
                    duration: 2500,
                  });
            },
            onGoodsSelect: function (t) {
              (this.showGoodsSelect = !1),
                uni.navigateTo({
                  url:
                    "/pages/pay/submit?id=" +
                    t +
                    "&seller_id=" +
                    this.seller_id,
                });
            },
            previewAlbum: function (t) {
              var e = this.album.map(function (t) {
                return t.image;
              });
              uni.previewImage({ urls: e, current: e[t] });
            },
            jump: function (t) {
              uni.navigateTo({ url: t });
            },
          },
        };
      e.default = r;
    },
    dba3: function (t, e, i) {
      var a = i("141d");
      a.__esModule && (a = a.default),
        "string" === typeof a && (a = [[t.i, a, ""]]),
        a.locals && (t.exports = a.locals);
      var n = i("967d").default;
      n("685d51ef", a, !0, { sourceMap: !1, shadowMode: !1 });
    },
    f817: function (t, e, i) {
      "use strict";
      i.r(e);
      var a = i("298e"),
        n = i("ba6c");
      for (var o in n)
        ["default"].indexOf(o) < 0 &&
          (function (t) {
            i.d(e, t, function () {
              return n[t];
            });
          })(o);
      i("63ab");
      var s = i("828b"),
        r = Object(s["a"])(
          n["default"],
          a["b"],
          a["c"],
          !1,
          null,
          "6165d532",
          null,
          !1,
          a["a"],
          void 0,
        );
      e["default"] = r.exports;
    },
  },
]);
//# sourceMappingURL=pages-index-seller.57ec112f.js.map
