(window["webpackJsonp"] = window["webpackJsonp"] || []).push([
  ["pages-alipay-paid"],
  {
    5224: function (t, n, e) {
      "use strict";
      e.r(n);
      var i = e("f2c0a"),
        a = e("80ee");
      for (var o in a)
        ["default"].indexOf(o) < 0 &&
          (function (t) {
            e.d(n, t, function () {
              return a[t];
            });
          })(o);
      e("95e8");
      var r = e("828b"),
        u = Object(r["a"])(
          a["default"],
          i["b"],
          i["c"],
          !1,
          null,
          "6dc5f29c",
          null,
          !1,
          i["a"],
          void 0,
        );
      n["default"] = u.exports;
    },
    "80ee": function (t, n, e) {
      "use strict";
      e.r(n);
      var i = e("92f7"),
        a = e.n(i);
      for (var o in i)
        ["default"].indexOf(o) < 0 &&
          (function (t) {
            e.d(n, t, function () {
              return i[t];
            });
          })(o);
      n["default"] = a.a;
    },
    "92f7": function (t, n, e) {
      "use strict";
      e("6a54"),
        Object.defineProperty(n, "__esModule", { value: !0 }),
        (n.default = void 0),
        e("4626");
      var i = e("e74a"),
        a = e("15b8"),
        o = {
          data: function () {
            return {
              order_no: "",
              price: 0,
              base_url: a.baseUrl,
              palte: "h5",
              isHidden: !1,
              isEpayAlipay: !1,
            };
          },
          onLoad: function (t) {
            if (
              ("h5" != this.palte && uni.setNavigationBarTitle({ title: "" }),
              t.epay_alipay)
            ) {
              this.isEpayAlipay = !0;
              var n = uni.getStorageSync("last_epay_order_no");
              n && this.queryOrderStatus();
            }
          },
          onHide: function () {
            this.isHidden = !0;
          },
          onShow: function () {
            "h5" != this.palte && uni.setNavigationBarTitle({ title: "" }),
              this.isHidden && this.isEpayAlipay && this.queryOrderStatus(),
              (this.isHidden = !1);
          },
          onPullDownRefresh: function () {
            uni.showLoading({ title: "刷新中" }),
              setTimeout(function () {
                uni.hideLoading(),
                  uni.showToast({ title: "刷新成功", duration: 1e3 }),
                  uni.stopPullDownRefresh();
              }, 300);
          },
          methods: {
            queryOrderStatus: function () {
              var t = uni.getStorageSync("last_epay_order_no");
              if (!t) return uni.$uv.toast("请先返回微信, 在微信内操作");
              uni.showLoading({ title: "正在查询支付结果..." }),
                (0, i.send)(
                  "/wechat/Pay/queryOrderStatus",
                  { order_no: t },
                  !1,
                  1,
                )
                  .then(function (t) {
                    uni.hideLoading();
                    var n = t.status,
                      e = t.msg,
                      i = t.data;
                    if (1 != n) return uni.$uv.toast(e || "查询失败");
                    if (!i || 1 != i.status || !i.jump)
                      return uni.$uv.toast(
                        "订单还未完成支付, 请稍后在订单中心查看",
                      );
                    uni.removeStorageSync("last_epay_order_no"),
                      uni.removeStorageSync("last_epay_pay_type"),
                      uni.removeStorageSync("last_epay_type"),
                      uni.removeStorageSync("last_epay_id"),
                      uni.$uv.toast("支付成功");
                    var a = [
                      "/pages/index/index",
                      "/pages/cat/index",
                      "/pages/follow/index",
                      "/pages/user/index",
                    ];
                    setTimeout(function () {
                      a.includes(i.jump)
                        ? uni.switchTab({ url: i.jump })
                        : uni.redirectTo({ url: i.jump });
                    }, 1500);
                  })
                  .catch(function () {
                    uni.hideLoading();
                  });
            },
          },
        };
      n.default = o;
    },
    "95e8": function (t, n, e) {
      "use strict";
      var i = e("b939"),
        a = e.n(i);
      a.a;
    },
    b939: function (t, n, e) {
      var i = e("c51b");
      i.__esModule && (i = i.default),
        "string" === typeof i && (i = [[t.i, i, ""]]),
        i.locals && (t.exports = i.locals);
      var a = e("967d").default;
      a("07dad670", i, !0, { sourceMap: !1, shadowMode: !1 });
    },
    c51b: function (t, n, e) {
      var i = e("c86c");
      (n = i(!1)),
        n.push([
          t.i,
          '@charset "UTF-8";\r\n/**\r\n * 这里是uni-app内置的常用样式变量\r\n *\r\n * uni-app 官方扩展插件及插件市场（https://ext.dcloud.net.cn）上很多三方插件均使用了这些样式变量\r\n * 如果你是插件开发者，建议你使用scss预处理，并在插件代码中直接使用这些变量（无需 import 这个文件），方便用户通过搭积木的方式开发整体风格一致的App\r\n *\r\n */\r\n/**\r\n * 如果你是App开发者（插件使用者），你可以通过修改这些变量来定制自己的插件主题，实现自定义主题功能\r\n *\r\n * 如果你的项目同样使用了scss预处理，你也可以直接在你的 scss 代码中使用如下变量，同时无需 import 这个文件\r\n */\r\n/* 颜色变量 */\r\n/* 行为相关颜色 */\r\n/* 文字基本颜色 */\r\n/* 背景颜色 */\r\n/* 边框颜色 */\r\n/* 尺寸变量 */\r\n/* 文字尺寸 */\r\n/* 图片尺寸 */\r\n/* Border Radius */\r\n/* 水平间距 */\r\n/* 垂直间距 */\r\n/* 透明度 */\r\n/* 文章场景相关 */.content[data-v-6dc5f29c]{height:100vh;background:#efefef;text-align:center;flex-direction:column;padding:20% %?20?% 19%;position:relative}.jiantou[data-v-6dc5f29c]{position:absolute;width:auto;height:%?134?%;top:%?10?%;right:%?45?%}.title uni-view[data-v-6dc5f29c]{font-size:15px}.safari[data-v-6dc5f29c]{width:71%;height:auto;margin:%?74?% auto}.bottom_box .done[data-v-6dc5f29c]{justify-content:center}.bottom_box .done .zhi[data-v-6dc5f29c]{width:%?55?%;height:%?55?%;margin-right:%?20?%}.bottom_box .done uni-view[data-v-6dc5f29c]{font-size:19.6px}.bottom_box .pay[data-v-6dc5f29c]{justify-content:center;margin-top:%?32?%}.bottom_box .pay .btn[data-v-6dc5f29c]{margin-left:%?25?%;background:#02a9f1;color:#fff;width:%?160?%;font-size:13px;height:%?60?%;line-height:%?60?%;border-radius:%?18?%}',
          "",
        ]),
        (t.exports = n);
    },
    f2c0a: function (t, n, e) {
      "use strict";
      e.d(n, "b", function () {
        return i;
      }),
        e.d(n, "c", function () {
          return a;
        }),
        e.d(n, "a", function () {});
      var i = function () {
          var t = this,
            n = t.$createElement,
            e = t._self._c || n;
          return "h5" == t.palte
            ? e(
                "v-uni-view",
                { staticClass: "content flex_box" },
                [
                  e(
                    "v-uni-view",
                    { staticClass: "bottom_box" },
                    [
                      e(
                        "v-uni-view",
                        { staticClass: "done flex_box" },
                        [
                          e("img", {
                            staticClass: "zhi",
                            attrs: {
                              src: t.base_url + "/files/imgs/alipay/alipay.png",
                            },
                          }),
                          e("v-uni-view", [t._v("已完成支付?")]),
                        ],
                        1,
                      ),
                      e(
                        "v-uni-view",
                        { staticClass: "pay flex_box" },
                        [
                          e("v-uni-view", [
                            t._v("请确认完成支付后,返回微信点击"),
                          ]),
                          e(
                            "v-uni-view",
                            {
                              staticClass: "btn",
                              on: {
                                click: function (n) {
                                  (arguments[0] = n = t.$handleEvent(n)),
                                    t.queryOrderStatus();
                                },
                              },
                            },
                            [t._v("完成付款")],
                          ),
                        ],
                        1,
                      ),
                    ],
                    1,
                  ),
                ],
                1,
              )
            : t._e();
        },
        a = [];
    },
  },
]);
//# sourceMappingURL=pages-alipay-paid.feb7f280.js.map
