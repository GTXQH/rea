(window["webpackJsonp"] = window["webpackJsonp"] || []).push([
  ["pages-cat-index"],
  {
    "2da3": function (t, i, a) {
      "use strict";
      a.d(i, "b", function () {
        return s;
      }),
        a.d(i, "c", function () {
          return o;
        }),
        a.d(i, "a", function () {
          return e;
        });
      var e = {
          uvSticky: a("9d51").default,
          uvTabs: a("2b48").default,
          uvVtabs: a("0c1b").default,
          uvVtabsItem: a("c9ab").default,
          uvIcon: a("1a07").default,
          uvPopup: a("ce8a").default,
        },
        s = function () {
          var t = this,
            i = t.$createElement,
            e = t._self._c || i;
          return e(
            "v-uni-view",
            { staticClass: "content" },
            [
              e(
                "uv-sticky",
                { attrs: { bgColor: "#fff" } },
                [
                  e("uv-tabs", {
                    attrs: {
                      list: t.tabs,
                      current: t.current,
                      lineColor: "#000",
                      activeStyle: {
                        color: "#000",
                        fontWeight: "bold",
                        transform: "scale(1.02)",
                      },
                    },
                    on: {
                      change: function (i) {
                        (arguments[0] = i = t.$handleEvent(i)),
                          t.changeTabs.apply(void 0, arguments);
                      },
                    },
                  }),
                ],
                1,
              ),
              2 != t.cat_tpl
                ? [
                    e(
                      "uv-vtabs",
                      {
                        attrs: {
                          chain: t.chain,
                          list: t.list,
                          height: t.height,
                          hdHeight: "100rpx",
                        },
                        on: {
                          change: function (i) {
                            (arguments[0] = i = t.$handleEvent(i)),
                              t.change.apply(void 0, arguments);
                          },
                        },
                      },
                      [
                        t._l(t.list, function (i, a) {
                          return [
                            e(
                              "uv-vtabs-item",
                              { key: a, attrs: { index: a } },
                              [
                                e("v-uni-view", { staticClass: "title" }, [
                                  t._v(t._s(i.name)),
                                ]),
                                e(
                                  "v-uni-view",
                                  { staticClass: "grid" },
                                  t._l(i.child, function (i, a) {
                                    return e(
                                      "v-uni-view",
                                      {
                                        key: a,
                                        staticClass: "col",
                                        on: {
                                          click: function (a) {
                                            (arguments[0] = a =
                                              t.$handleEvent(a)),
                                              t.jump(
                                                "/pages/cat/list?id=" +
                                                  i.id +
                                                  "&cat3_name=" +
                                                  i.name,
                                              );
                                          },
                                        },
                                      },
                                      [
                                        e("img", { attrs: { src: i.thumb } }),
                                        e(
                                          "v-uni-view",
                                          { staticClass: "tit" },
                                          [t._v(t._s(i.name))],
                                        ),
                                      ],
                                      1,
                                    );
                                  }),
                                  1,
                                ),
                              ],
                              1,
                            ),
                          ];
                        }),
                        1 == t.home_copy_right ? e("copy-right") : t._e(),
                      ],
                      2,
                    ),
                  ]
                : [
                    e(
                      "uv-vtabs",
                      {
                        attrs: {
                          chain: t.chain,
                          list: t.list,
                          height: t.height,
                          hdHeight: "100rpx",
                        },
                        on: {
                          change: function (i) {
                            (arguments[0] = i = t.$handleEvent(i)),
                              t.change.apply(void 0, arguments);
                          },
                        },
                      },
                      [
                        t._l(t.list, function (i, a) {
                          return [
                            e(
                              "uv-vtabs-item",
                              { key: a, attrs: { index: a } },
                              [
                                e("v-uni-view", { staticClass: "title" }, [
                                  t._v(t._s(i.name)),
                                ]),
                                e(
                                  "v-uni-view",
                                  { staticClass: "list" },
                                  t._l(i.goods, function (i, a) {
                                    return i
                                      ? e(
                                          "v-uni-view",
                                          {
                                            key: a,
                                            staticClass: "col flex_box",
                                            on: {
                                              click: function (a) {
                                                (arguments[0] = a =
                                                  t.$handleEvent(a)),
                                                  t.specsOpen(i);
                                              },
                                            },
                                          },
                                          [
                                            e("img", {
                                              attrs: { src: i ? i.thumb : "" },
                                            }),
                                            e(
                                              "v-uni-view",
                                              { staticClass: "txt" },
                                              [
                                                e(
                                                  "v-uni-view",
                                                  {
                                                    staticClass:
                                                      "tit to-line-1",
                                                  },
                                                  [
                                                    t._v(
                                                      t._s(
                                                        i
                                                          ? i.title.length > 8
                                                            ? i.title.slice(
                                                                0,
                                                                8,
                                                              ) + "..."
                                                            : i.title
                                                          : "",
                                                      ),
                                                    ),
                                                  ],
                                                ),
                                                e(
                                                  "v-uni-view",
                                                  {
                                                    staticClass:
                                                      "des to-line-2",
                                                  },
                                                  [
                                                    t._v(
                                                      t._s(i ? i.intro : ""),
                                                    ),
                                                  ],
                                                ),
                                                e(
                                                  "v-uni-view",
                                                  {
                                                    staticClass:
                                                      "cart_box flex_box",
                                                  },
                                                  [
                                                    e(
                                                      "v-uni-view",
                                                      {
                                                        staticClass:
                                                          "price_box",
                                                      },
                                                      [
                                                        e(
                                                          "v-uni-text",
                                                          {
                                                            staticClass:
                                                              "new_price",
                                                          },
                                                          [
                                                            t._v(
                                                              "￥" +
                                                                t._s(
                                                                  i
                                                                    ? i.price
                                                                    : "",
                                                                ),
                                                            ),
                                                          ],
                                                        ),
                                                        i.priced
                                                          ? e(
                                                              "v-uni-text",
                                                              {
                                                                staticClass:
                                                                  "old_price",
                                                              },
                                                              [
                                                                t._v(
                                                                  "￥" +
                                                                    t._s(
                                                                      i
                                                                        ? i.priced
                                                                        : "",
                                                                    ),
                                                                ),
                                                              ],
                                                            )
                                                          : t._e(),
                                                      ],
                                                      1,
                                                    ),
                                                    e("uv-icon", {
                                                      attrs: {
                                                        name: "shopping-cart",
                                                        color: "#fd2c28",
                                                        size: "24",
                                                      },
                                                    }),
                                                  ],
                                                  1,
                                                ),
                                              ],
                                              1,
                                            ),
                                          ],
                                          1,
                                        )
                                      : t._e();
                                  }),
                                  1,
                                ),
                              ],
                              1,
                            ),
                          ];
                        }),
                        1 == t.home_copy_right ? e("copy-right") : t._e(),
                      ],
                      2,
                    ),
                  ],
              e("tab-bar", { attrs: { selected: t.selected } }),
              2 == t.cat_tpl
                ? e(
                    "uv-popup",
                    {
                      ref: "specsPop",
                      attrs: {
                        mode: "bottom",
                        bgColor: "none",
                        zIndex: "10075",
                      },
                    },
                    [
                      e(
                        "v-uni-view",
                        { staticClass: "specsShow" },
                        [
                          "" == t.child_goods
                            ? e(
                                "v-uni-view",
                                { staticClass: "goods_msg flex_box" },
                                [
                                  e("img", {
                                    staticClass: "img",
                                    attrs: { src: t.goods.thumb },
                                    on: {
                                      click: function (i) {
                                        (arguments[0] = i = t.$handleEvent(i)),
                                          t.previewImage(t.goods.thumb);
                                      },
                                    },
                                  }),
                                  e(
                                    "v-uni-view",
                                    { staticClass: "txt" },
                                    [
                                      e(
                                        "v-uni-view",
                                        { staticClass: "name uv-line-1" },
                                        [t._v(t._s(t.goods.title))],
                                      ),
                                      e(
                                        "v-uni-view",
                                        { staticClass: "price_box flex_box" },
                                        [
                                          e(
                                            "v-uni-view",
                                            { staticClass: "new_price" },
                                            [
                                              e(
                                                "v-uni-text",
                                                { staticClass: "unit" },
                                                [t._v("￥")],
                                              ),
                                              e("v-uni-text", [
                                                t._v(t._s(t.goods.price)),
                                              ]),
                                            ],
                                            1,
                                          ),
                                          e(
                                            "v-uni-view",
                                            { staticClass: "old_price" },
                                            [
                                              1 == t.goods_show_priced
                                                ? [t._v("￥")]
                                                : t._e(),
                                              t._v(
                                                " " +
                                                  t._s(t.goods.priced) +
                                                  " ",
                                              ),
                                            ],
                                            2,
                                          ),
                                        ],
                                        1,
                                      ),
                                    ],
                                    1,
                                  ),
                                ],
                                1,
                              )
                            : e(
                                "v-uni-view",
                                { staticClass: "goods_msg flex_box" },
                                [
                                  e("img", {
                                    staticClass: "img",
                                    attrs: { src: t.child_goods.thumb },
                                    on: {
                                      click: function (i) {
                                        (arguments[0] = i = t.$handleEvent(i)),
                                          t.previewImage(t.child_goods.thumb);
                                      },
                                    },
                                  }),
                                  e(
                                    "v-uni-view",
                                    { staticClass: "txt" },
                                    [
                                      e(
                                        "v-uni-view",
                                        { staticClass: "name uv-line-1" },
                                        [t._v(t._s(t.child_goods.title))],
                                      ),
                                      e(
                                        "v-uni-view",
                                        { staticClass: "price_box flex_box" },
                                        [
                                          e(
                                            "v-uni-view",
                                            { staticClass: "new_price" },
                                            [
                                              e(
                                                "v-uni-text",
                                                { staticClass: "unit" },
                                                [t._v("￥")],
                                              ),
                                              e("v-uni-text", [
                                                t._v(t._s(t.child_goods.price)),
                                              ]),
                                            ],
                                            1,
                                          ),
                                          e(
                                            "v-uni-view",
                                            { staticClass: "old_price" },
                                            [
                                              1 == t.goods_show_priced
                                                ? [t._v("￥")]
                                                : t._e(),
                                              t._v(
                                                " " +
                                                  t._s(t.child_goods.priced) +
                                                  " ",
                                              ),
                                            ],
                                            2,
                                          ),
                                        ],
                                        1,
                                      ),
                                    ],
                                    1,
                                  ),
                                ],
                                1,
                              ),
                          e(
                            "v-uni-view",
                            { staticClass: "reason_box" },
                            [
                              e("v-uni-view", { staticClass: "tit" }, [
                                t._v(
                                  t._s(
                                    1 == t.goods.is_raffle
                                      ? "转盘规格"
                                      : "商品规格",
                                  ),
                                ),
                              ]),
                              e(
                                "v-uni-view",
                                { staticClass: "specs_grid" },
                                t._l(t.goods_list, function (i, a) {
                                  return e(
                                    "v-uni-view",
                                    {
                                      key: a,
                                      class: {
                                        col: !0,
                                        cur:
                                          (1 == t.goods.is_raffle
                                            ? t.child_goods.id
                                            : t.goods.id) == i.id,
                                      },
                                      on: {
                                        click: function (a) {
                                          (arguments[0] = a =
                                            t.$handleEvent(a)),
                                            t.selectGoods(i);
                                        },
                                      },
                                    },
                                    [t._v(t._s(i.title))],
                                  );
                                }),
                                1,
                              ),
                            ],
                            1,
                          ),
                          t.child_list.length > 0 && 1 != t.goods.is_raffle
                            ? e(
                                "v-uni-view",
                                { staticClass: "reason_box" },
                                [
                                  e("v-uni-view", { staticClass: "tit" }, [
                                    t._v("详细规格"),
                                  ]),
                                  e(
                                    "v-uni-view",
                                    { staticClass: "specs_grid" },
                                    t._l(t.child_list, function (i, a) {
                                      return e(
                                        "v-uni-view",
                                        {
                                          key: a,
                                          class: {
                                            col: !0,
                                            cur: t.child_goods.id == i.id,
                                          },
                                          on: {
                                            click: function (a) {
                                              (arguments[0] = a =
                                                t.$handleEvent(a)),
                                                t.selectChildGoods(i);
                                            },
                                          },
                                        },
                                        [t._v(t._s(i.title))],
                                      );
                                    }),
                                    1,
                                  ),
                                ],
                                1,
                              )
                            : t._e(),
                          e(
                            "v-uni-view",
                            { staticClass: "daohang_box flex_box" },
                            [
                              e(
                                "v-uni-view",
                                {
                                  staticClass: "kefu_box",
                                  on: {
                                    click: function (i) {
                                      (arguments[0] = i = t.$handleEvent(i)),
                                        t.jumpKefu();
                                    },
                                  },
                                },
                                [
                                  e("img", {
                                    staticClass: "picture",
                                    attrs: { src: a("fd7e"), alt: "" },
                                  }),
                                  e("v-uni-view", { staticClass: "kefu" }, [
                                    t._v("客服"),
                                  ]),
                                ],
                                1,
                              ),
                              "mp-weixin" == t.palte &&
                              3 == t.kefu.kefu_weapp_type
                                ? e("v-uni-button", {
                                    staticClass: "up_button",
                                    attrs: {
                                      "open-type": "contact",
                                      bindcontact: "handleContact",
                                    },
                                  })
                                : t._e(),
                              1 == t.store_close.online
                                ? [
                                    1 == t.goods.is_raffle
                                      ? [
                                          e(
                                            "v-uni-view",
                                            {
                                              staticClass: "xiadan",
                                              on: {
                                                click: function (i) {
                                                  (arguments[0] = i =
                                                    t.$handleEvent(i)),
                                                    t.sub.apply(
                                                      void 0,
                                                      arguments,
                                                    );
                                                },
                                              },
                                            },
                                            [t._v("立即下单")],
                                          ),
                                        ]
                                      : "上架中" == t.goods.status_text
                                        ? [
                                            1 == t.goods.limit1
                                              ? e(
                                                  "v-uni-view",
                                                  {
                                                    staticClass:
                                                      "xiadan cancel",
                                                  },
                                                  [t._v("24小时之内限制下1单")],
                                                )
                                              : 0 != t.goods.raffle_id
                                                ? e(
                                                    "v-uni-view",
                                                    {
                                                      staticClass:
                                                        "xiadan cancel",
                                                    },
                                                    [
                                                      t._v(
                                                        "当前商品暂不允许下单",
                                                      ),
                                                    ],
                                                  )
                                                : e(
                                                    "v-uni-view",
                                                    {
                                                      staticClass: "xiadan",
                                                      on: {
                                                        click: function (i) {
                                                          (arguments[0] = i =
                                                            t.$handleEvent(i)),
                                                            t.sub.apply(
                                                              void 0,
                                                              arguments,
                                                            );
                                                        },
                                                      },
                                                    },
                                                    [t._v("立即下单")],
                                                  ),
                                          ]
                                        : "已售罄" == t.goods.status_text
                                          ? e(
                                              "v-uni-view",
                                              { staticClass: "xiadan cancel" },
                                              [t._v("商品已售罄")],
                                            )
                                          : "" == t.goods
                                            ? e(
                                                "v-uni-view",
                                                {
                                                  staticClass: "xiadan cancel",
                                                },
                                                [t._v("请选择商品规格")],
                                              )
                                            : e(
                                                "v-uni-view",
                                                {
                                                  staticClass: "xiadan cancel",
                                                },
                                                [
                                                  t._v(
                                                    "商品" +
                                                      t._s(t.goods.status_text),
                                                  ),
                                                ],
                                              ),
                                  ]
                                : e(
                                    "v-uni-view",
                                    { staticClass: "xiadan cancel" },
                                    [t._v("商家已打烊")],
                                  ),
                            ],
                            2,
                          ),
                        ],
                        1,
                      ),
                    ],
                    1,
                  )
                : t._e(),
            ],
            2,
          );
        },
        o = [];
    },
    "31f4": function (t, i, a) {
      var e = a("70c4");
      e.__esModule && (e = e.default),
        "string" === typeof e && (e = [[t.i, e, ""]]),
        e.locals && (t.exports = e.locals);
      var s = a("967d").default;
      s("0dc7b451", e, !0, { sourceMap: !1, shadowMode: !1 });
    },
    5340: function (t, i, a) {
      "use strict";
      a("6a54"),
        Object.defineProperty(i, "__esModule", { value: !0 }),
        (i.default = void 0),
        a("bd06");
      var e = a("e74a"),
        s = a("a5ed5"),
        o =
          (a("4fbd"),
          {
            data: function () {
              return {
                cat_tpl: 0,
                list: [],
                chain: !0,
                tabs: [],
                select_tab: 1,
                selected: 1,
                current: 0,
                home_copy_right: 0,
                cat1_id: 0,
                child_list: [],
                cat2_id: 0,
                goods_list: [],
                goods: [],
                child_goods: [],
                num: 1,
                store_close: [],
                kefu: [],
                palte: "h5",
                goods_show_priced: 0,
                sub_status: 1,
                raffle_order_type: 0,
              };
            },
            computed: {
              height: function () {
                return uni.getSystemInfoSync().windowHeight - uni.upx2px(100);
              },
            },
            onPullDownRefresh: function () {
              var t = this;
              uni.showLoading({ title: "刷新中" }),
                setTimeout(function () {
                  uni.hideLoading(),
                    t.loadCatList(),
                    uni.showToast({ title: "刷新成功", duration: 1e3 }),
                    uni.stopPullDownRefresh();
                }, 300);
            },
            onLoad: function () {
              (this.cat_tpl = uni.getStorageSync("cat_tpl") || 0),
                this.loadCatList();
            },
            onShow: function () {},
            methods: {
              loadCatList: function () {
                2 == this.cat_tpl ? this.getCatList2() : this.getCatList();
              },
              changeTabs: function (t) {
                2 == this.cat_tpl
                  ? ((this.cat1_id = t.id),
                    uni.setStorageSync("cat1_id", this.cat1_id),
                    this.getCatList2())
                  : ((this.select_tab = t.id),
                    uni.setStorageSync("cat1_id", this.select_tab),
                    this.getCatListByLevel1());
              },
              change: function (t) {},
              getIndexById: function (t, i) {
                return t.findIndex(function (t) {
                  return t.id === i;
                });
              },
              jump: function (t) {
                uni.navigateTo({ url: t });
              },
              getCatList: function () {
                var t = this;
                uni.showLoading({ title: "加载中.." }),
                  (0, e.send)(
                    "/wechat/Cat/getCatList",
                    { label: "cat" },
                    !1,
                  ).then(function (i) {
                    uni.hideLoading();
                    var a = i.status,
                      e = i.msg,
                      s = i.data;
                    if (1 != a) return uni.$uv.toast(e);
                    (t.tabs = s.cat),
                      (t.list = s.list),
                      (t.home_copy_right = s.home_copy_right),
                      0 == s.auth_status && t.showArrears();
                  });
              },
              getCatListByLevel1: function () {
                var t = this;
                uni.showLoading({ title: "加载中.." }),
                  (0, e.send)(
                    "/wechat/Cat/getCatListByLevel1",
                    { cat_id: this.select_tab },
                    !1,
                  ).then(function (i) {
                    uni.hideLoading();
                    var a = i.status,
                      e = i.msg,
                      s = i.data;
                    if (1 != a) return uni.$uv.toast(e);
                    (t.list = s),
                      (t.current = t.getIndexById(t.tabs, t.select_tab));
                  });
              },
              getCatList2: function () {
                var t = this;
                uni.showLoading({ title: "加载中.." }),
                  (0, e.send)(
                    "/wechat/Cat/getCatList2",
                    { label: "cat", cat1_id: this.cat1_id },
                    !1,
                  ).then(function (i) {
                    uni.hideLoading();
                    var a = i.status,
                      e = i.msg,
                      s = i.data;
                    if (1 != a) return uni.$uv.toast(e);
                    (t.tabs = s.cat),
                      (t.list = s.list),
                      (t.store_close = s.store_close),
                      (t.kefu = s.kefu),
                      (t.home_copy_right = s.home_copy_right),
                      0 != t.cat1_id &&
                        (t.current = t.getIndexById(t.tabs, t.cat1_id)),
                      0 == s.auth_status && t.showArrears();
                  });
              },
              specsOpen: function (t) {
                var i = this;
                1 == t.is_raffle
                  ? ((this.goods = t),
                    (this.child_goods = ""),
                    (this.child_list = []),
                    (this.goods_list = []),
                    (0, e.send)(
                      "/wechat/Raffle/getChildRaffleList",
                      { id: t.id },
                      !1,
                    ).then(function (t) {
                      var a = t.status,
                        e = (t.msg, t.data);
                      1 == a && e.list && e.list.length > 0
                        ? ((i.goods_list = e.list),
                          (i.raffle_order_type = e.order_type),
                          i.$refs.specsPop.open())
                        : ((i.raffle_order_type = e.order_type || 0), i.sub());
                    }))
                  : ((this.cat2_id = t.cat2_id),
                    (this.goods_list = []),
                    (this.goods = []),
                    (this.child_goods = []),
                    (this.child_list = []),
                    this.getGoodsListInCat());
              },
              getGoodsListInCat: function () {
                var t = this;
                uni.showLoading({ title: "加载中.." }),
                  (0, e.send)(
                    "/wechat/Goods/getGoodsListInCat",
                    { cat2_id: this.cat2_id },
                    !1,
                  ).then(function (i) {
                    uni.hideLoading();
                    var a = i.status,
                      e = i.msg,
                      s = i.data;
                    return 1 != a
                      ? uni.$uv.toast(e)
                      : s.list && 0 != s.list.length
                        ? ((t.goods_list = s.list),
                          (t.goods = t.goods_list[0]),
                          (t.goods_show_priced = s.goods_show_priced),
                          (t.child_goods = []),
                          t.getChildGoodsList(t.goods),
                          void t.$refs.specsPop.open())
                        : uni.$uv.toast("该分类下暂无商品规格");
                  });
              },
              jumpKefu: function () {
                "h5" == this.palte
                  ? 1 == this.kefu.kefu_h5_type || 3 == this.kefu.kefu_h5_type
                    ? (window.location.href = this.kefu.kefu_link)
                    : uni.switchTab({ url: "/pages/chat/list" })
                  : ((1 != this.kefu.kefu_weapp_type &&
                      4 != this.kefu.kefu_weapp_type) ||
                      wx.openCustomerServiceChat({
                        extInfo: { url: this.kefu.kefu_link },
                        corpId: this.kefu.kefu_corp_id,
                        success: function (t) {
                          console.log(t);
                        },
                      }),
                    2 == this.kefu.kefu_weapp_type &&
                      uni.switchTab({ url: "/pages/chat/list" }));
              },
              sub: function () {
                var t = this,
                  i = this;
                if (0 != this.sub_status)
                  return 1 == this.goods.is_raffle &&
                    this.goods_list.length > 0 &&
                    "" == this.child_goods
                    ? uni.$uv.toast("请选择转盘规格")
                    : 1 != this.goods.is_raffle &&
                        0 != this.goods.raffle_id &&
                        null != this.goods.raffle_id
                      ? uni.$uv.toast("抽奖商品不允许下单")
                      : 1 != this.goods.is_raffle &&
                          this.child_list.length > 0 &&
                          "" == this.child_goods
                        ? uni.$uv.toast("请选择详细规格")
                        : void (0, e.send)(
                            "/wechat/User/checkUserLoginStatus",
                            { label: "" },
                            !1,
                          ).then(function (a) {
                            var e = a.status,
                              o = a.msg,
                              n = a.data;
                            if (1 != e) return uni.$uv.toast(o);
                            if (1 == t.goods.is_vip && 0 == n.user_vip)
                              return uni.showModal({
                                title: "温馨提示",
                                content: "加入会员, 享会员折扣商品哦",
                                confirmColor: "#e64340",
                                confirmText: "点我开通",
                                cancelText: "暂不开通",
                                success: function (t) {
                                  t.confirm && i.jump("/pages/pay/vip");
                                },
                              });
                            if (1 == t.goods.is_raffle) {
                              var d =
                                  "" != t.child_goods
                                    ? t.child_goods.id
                                    : t.goods.id,
                                c =
                                  "" != t.child_goods &&
                                  void 0 !== t.child_goods.order_type
                                    ? t.child_goods.order_type
                                    : t.raffle_order_type;
                              1 == c
                                ? (0, s.goRaffle)(d)
                                : t.jump("/pages/pay/raffle?id=" + d);
                            } else
                              "" == t.child_goods
                                ? t.jump("/pages/pay/submit?id=" + t.goods.id)
                                : t.jump(
                                    "/pages/pay/submit?id=" + t.child_goods.id,
                                  );
                          });
              },
              previewImage: function (t) {
                var i = t;
                uni.previewImage({ current: i, urls: [t] });
              },
              selectGoods: function (t) {
                1 == this.goods.is_raffle
                  ? (this.child_goods = t)
                  : ((this.goods = t),
                    (this.child_goods = []),
                    (this.sub_status = 0),
                    this.getChildGoodsList(t));
              },
              getChildGoodsList: function (t) {
                var i = this;
                (0, e.send)(
                  "/wechat/Goods/getChildGoodsList",
                  { id: t.id },
                  !1,
                ).then(function (t) {
                  uni.hideLoading(), (i.sub_status = 1);
                  var a = t.status,
                    e = (t.msg, t.data);
                  i.child_list = 1 == a ? e : [];
                });
              },
              selectChildGoods: function (t) {
                this.child_goods = t;
              },
              showArrears: function () {
                var t = this;
                return uni.showModal({
                  title: "温馨提示",
                  content:
                    "您好，目前系统处于欠费状态，暂时无法提交新订单。烦请客户尽快完成系统费用补缴，待系统恢复后即可正常发起下单操作。",
                  showCancel: !1,
                  success: function (i) {
                    i.confirm && t.loadCatList();
                  },
                });
              },
            },
          });
      i.default = o;
    },
    "70c4": function (t, i, a) {
      var e = a("c86c");
      (i = e(!1)),
        i.push([
          t.i,
          '@charset "UTF-8";\r\n/**\r\n * 这里是uni-app内置的常用样式变量\r\n *\r\n * uni-app 官方扩展插件及插件市场（https://ext.dcloud.net.cn）上很多三方插件均使用了这些样式变量\r\n * 如果你是插件开发者，建议你使用scss预处理，并在插件代码中直接使用这些变量（无需 import 这个文件），方便用户通过搭积木的方式开发整体风格一致的App\r\n *\r\n */\r\n/**\r\n * 如果你是App开发者（插件使用者），你可以通过修改这些变量来定制自己的插件主题，实现自定义主题功能\r\n *\r\n * 如果你的项目同样使用了scss预处理，你也可以直接在你的 scss 代码中使用如下变量，同时无需 import 这个文件\r\n */\r\n/* 颜色变量 */\r\n/* 行为相关颜色 */\r\n/* 文字基本颜色 */\r\n/* 背景颜色 */\r\n/* 边框颜色 */\r\n/* 尺寸变量 */\r\n/* 文字尺寸 */\r\n/* 图片尺寸 */\r\n/* Border Radius */\r\n/* 水平间距 */\r\n/* 垂直间距 */\r\n/* 透明度 */\r\n/* 文章场景相关 */.content[data-v-1d2f49a4]{height:100vh;overflow:hidden}[data-v-1d2f49a4] .uv-sticky{top:0!important}[data-v-1d2f49a4] .uv-tabs{border-bottom:%?2?% solid #ddd}[data-v-1d2f49a4] .uv-tabs__wrapper__nav__item{min-width:20%;padding:0}[data-v-1d2f49a4] .uv-vtabs{height:calc(100vh - 95px)!important}[data-v-1d2f49a4] .uv-vtabs__bar{height:inherit!important;width:103px}[data-v-1d2f49a4] .uv-vtabs__bar-item{height:%?110?%;max-height:63px;line-height:%?110?%;text-align:center!important;border-bottom:%?2?% solid #eee}[data-v-1d2f49a4] .uv-vtabs__bar-item span{text-align:center!important;white-space:nowrap;text-overflow:ellipsis;display:block}[data-v-1d2f49a4] .uv-vtabs__bar-item-active{background:inherit!important}[data-v-1d2f49a4] .uv-vtabs__bar-item-active .uv-vtabs__bar-item--line{width:72%!important;height:%?20?%!important;border-radius:%?20?%;background:#ffe610!important;left:50%!important;top:47.4%!important;-webkit-transform:translate(-50%)!important;transform:translate(-50%)!important;z-index:1!important}[data-v-1d2f49a4] .uv-vtabs__bar-item-active--value{position:relative!important;z-index:2!important;color:#000!important;font-weight:700!important}[data-v-1d2f49a4] .uv-vtabs__content{height:calc(100vh - 120px)!important;padding:%?25?% %?20?% %?25?% %?25?%!important\r\n  /* 模板1: 网格分类 */\r\n  /* 模板2: 商品列表 */}[data-v-1d2f49a4] .uv-vtabs__content .title{font-weight:700;font-size:15px}[data-v-1d2f49a4] .uv-vtabs__content .grid{margin:%?24?% auto %?30?%;display:grid;grid-gap:%?20?% %?15?%;grid-template-columns:1fr 1fr 1fr}[data-v-1d2f49a4] .uv-vtabs__content .grid .col img{width:%?160?%;height:%?160?%;max-width:91px;max-height:91px;margin:0 auto;border-radius:%?10?%;background:#f7f8fa}[data-v-1d2f49a4] .uv-vtabs__content .grid .col .tit{white-space:nowrap;font-size:13px;text-align:center;margin:%?12?% auto %?12?%}[data-v-1d2f49a4] .uv-vtabs__content .list{margin:%?24?% auto %?12?%}[data-v-1d2f49a4] .uv-vtabs__content .list .col{margin-bottom:%?17?%}[data-v-1d2f49a4] .uv-vtabs__content .list .col img{width:%?150?%;height:%?150?%;margin:0;border-radius:%?10?%;background:#f7f8fa}[data-v-1d2f49a4] .uv-vtabs__content .list .col .txt{width:calc(100% - %?170?%)}[data-v-1d2f49a4] .uv-vtabs__content .list .col .txt .tit{font-size:13px;font-weight:700;margin:%?2?% auto 0}[data-v-1d2f49a4] .uv-vtabs__content .list .col .txt .des{font-size:12px;color:#999;margin:%?6?% auto %?4?%}[data-v-1d2f49a4] .uv-vtabs__content .list .col .txt .cart_box .price_box{max-width:calc(100% - %?60?%)}[data-v-1d2f49a4] .uv-vtabs__content .list .col .txt .cart_box .price_box .new_price{color:#fd2c28;font-weight:700}[data-v-1d2f49a4] .uv-vtabs__content .list .col .txt .cart_box .price_box .old_price{text-decoration:line-through;color:#999;font-size:12px;margin-left:%?12?%}\r\n/* 商品规格弹窗 (cat_tpl==2) */[data-v-1d2f49a4] .uv-popup__content{max-width:480px;width:100%}.specsShow[data-v-1d2f49a4]{background:#fff;border-radius:%?30?% %?30?% 0 0}.specsShow .goods_msg[data-v-1d2f49a4]{padding:%?32?% %?0?%;margin:%?0?% %?30?%;border-bottom:%?2?% solid #eee}.specsShow .goods_msg .img[data-v-1d2f49a4]{width:%?110?%;height:%?110?%;border-radius:%?10?%}.specsShow .goods_msg .txt[data-v-1d2f49a4]{width:calc(100% - %?135?%)}.specsShow .goods_msg .txt .name[data-v-1d2f49a4]{font-weight:700;font-size:15px}.specsShow .goods_msg .txt .price_box[data-v-1d2f49a4]{margin-top:%?14?%;justify-content:flex-start}.specsShow .goods_msg .txt .price_box .new_price[data-v-1d2f49a4]{color:#fd2c28;font-weight:700;font-size:17px}.specsShow .goods_msg .txt .price_box .new_price .unit[data-v-1d2f49a4]{font-size:12px}.specsShow .goods_msg .txt .price_box .old_price[data-v-1d2f49a4]{color:#999;margin-left:%?14?%;text-decoration:line-through}.specsShow .reason_box[data-v-1d2f49a4]{margin:%?32?% %?30?% %?50?%}.specsShow .reason_box .tit[data-v-1d2f49a4]{font-size:15px;font-weight:700;position:relative;z-index:10;display:inline-block;text-align:center}.specsShow .reason_box .tit[data-v-1d2f49a4]::before{z-index:-1;display:block;content:"";width:72%;height:%?20?%;border-radius:%?20?%;background:#ffe610;position:absolute;left:50%;bottom:%?6?%;-webkit-transform:translate(-50%);transform:translate(-50%)}.specsShow .reason_box .specs_grid[data-v-1d2f49a4]{margin:%?28?% auto 0;min-height:%?140?%;overflow-y:scroll}.specsShow .reason_box .specs_grid .col[data-v-1d2f49a4]{display:inline-block;float:left;margin-bottom:%?24?%;margin-right:%?24?%;padding:0 %?16?%;height:%?54?%;line-height:%?54?%;font-size:12px;text-overflow:ellipsis;white-space:nowrap;background:#eee;border-radius:%?10?%;color:#555;text-align:center;flex:0 0 auto}.specsShow .reason_box .specs_grid .col.cur[data-v-1d2f49a4]{background:#ffe610;color:#000}.specsShow .daohang_box[data-v-1d2f49a4]{background:#fff;box-shadow:0 0 %?10?% #ddd;padding:%?20?% %?30?%;position:relative}.specsShow .daohang_box .kefu_box .picture[data-v-1d2f49a4]{height:%?40?%;width:%?40?%;margin:0 auto %?2?%}.specsShow .daohang_box .kefu_box .kefu[data-v-1d2f49a4]{font-size:12px}.specsShow .daohang_box .up_button[data-v-1d2f49a4]{background-color:initial!important;font-size:12.2px;position:absolute;top:0;bottom:0;left:0;z-index:30!important;width:14vw!important;text-align:center!important;padding:0!important;line-height:%?340?%!important;-webkit-tap-highlight-color:transparent!important}.specsShow .daohang_box uni-button[data-v-1d2f49a4]::after{border:none!important;box-shadow:none!important;border-radius:0!important;display:none!important}.specsShow .daohang_box .xiadan[data-v-1d2f49a4]{background:#ffe610;width:calc(100% - %?80?%);height:%?90?%;line-height:%?90?%;border-radius:%?90?%;font-size:15px;font-weight:700;text-align:center}.specsShow .daohang_box .xiadan.cancel[data-v-1d2f49a4]{background:#dadada}',
          "",
        ]),
        (t.exports = i);
    },
    "78a4": function (t, i, a) {
      "use strict";
      a.r(i);
      var e = a("5340"),
        s = a.n(e);
      for (var o in e)
        ["default"].indexOf(o) < 0 &&
          (function (t) {
            a.d(i, t, function () {
              return e[t];
            });
          })(o);
      i["default"] = s.a;
    },
    a5ed5: function (t, i, a) {
      "use strict";
      a("6a54"),
        Object.defineProperty(i, "__esModule", { value: !0 }),
        (i.goRaffle = function (t) {
          return (0, e.send)(
            "/wechat/Raffle/getRaffleStyle",
            { label: "raffle", raffle_id: t },
            !1,
          )
            .then(function (i) {
              1 == i.status && i.data && 2 == i.data.style
                ? uni.navigateTo({
                    url: "/pages_sub1/active/lucky_draw?raffle_id=" + t,
                  })
                : uni.navigateTo({
                    url: "/pages/active/turntable?raffle_id=" + t,
                  });
            })
            .catch(function () {
              uni.navigateTo({ url: "/pages/active/turntable?raffle_id=" + t });
            });
        });
      var e = a("e74a");
    },
    b907: function (t, i, a) {
      "use strict";
      var e = a("31f4"),
        s = a.n(e);
      s.a;
    },
    f282: function (t, i, a) {
      "use strict";
      a.r(i);
      var e = a("2da3"),
        s = a("78a4");
      for (var o in s)
        ["default"].indexOf(o) < 0 &&
          (function (t) {
            a.d(i, t, function () {
              return s[t];
            });
          })(o);
      a("b907");
      var n = a("828b"),
        d = Object(n["a"])(
          s["default"],
          e["b"],
          e["c"],
          !1,
          null,
          "1d2f49a4",
          null,
          !1,
          e["a"],
          void 0,
        );
      i["default"] = d.exports;
    },
    fd7e: function (t, i) {
      t.exports =
        "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAGQAAABkCAYAAABw4pVUAAAAAXNSR0IArs4c6QAACrBJREFUeF7tnV1sFUUUgM+WIvITwIABBGMB++ODJj6BBmMbExJ/YjD6QoRA44MPoiZqgi+mrS+SGENEfZVC0JAYY/yLPzFQxED0weCTbQm2BrBFUbFQQCisnMudup17ZubM7Mze3d5uQu5N2Z2dPd+cnzlzdm4ExTgaAKAVAPDztvInfsdDfOL3wcTj4Hf8d6D8N/zek/fHjXLaQRTyZgC4vwzCVzcFFISUS0B5AiIgbJJGvS8YVDsIZde1+3VL2hXyntq28wCkEwCyhKASCMJpr7ZZqxYQoQ0djkNR+Ar5M+lP0Oe4HEJrcKBkflQDCD6oDQghIBQOOmUbx4yAxD/hj5LQdALH+3aVzVlmYLIEgoLYz/QPIUepiNjQTHK0CAcAmrJkBBcMUFZAOFoREoJKgNxAIrO+hQbC0YqqmAaJEFdrsK9tIbUlJBCTVuQiqiFUB+c/6ONUviaotoQCsrM8sdPF/lWJYpjG3xQFBoMSAgg6bpWzRAeJKl+Uw2RyMQrzOrB8AsHOo2aoYHjvfEZUTdri9bl8AlFpRl59hS1PHGj4jNSBqRcMjVMfvoDoYCxP3cv8NKAzYV40xQcQFYyi+Qsu9qBQ0gJRhbaTFYaApoKS2jynAaKyqZMdBgeK8+QxDZABYvKEI2Qy+QyTGUNNQTnIh/OgdAWi8hsII5MknElSGf6/ylI4OXkXIJhawPmGfKCa2qTGU8ks/rmlAeqhAWJogKic5ohhEKLrAyJq7M2sL+XJobyk4ORPXIBQpspbHK6iVAawGSDmrbMjHIh7AOoORE292L+Qh2pSbG26bIFQUVVQv1ECMe1qB0QRaqbbIeBcqeuK7ugNZVJV/sTKctgA8XJDrkQTGmGzuqhvvmTSol0wBt2BwFDm3GrA2gChMrjWKskBEh9tab1mmlRpCk4THDDtAfyMan6CaRWW2bQBEhNP6T2qio+2dALEHWdHr8LFf2MYuxLDkpvr00MAgKHfx6C+PoJZMyOYfWNdSVuixl6v2dpyclUeTGwt4QKhfId3Rx4fbS6F0y+99ge88e5f4xCaV9wAH+y4Be5snuEE5tCPF+DJF4Zg8OTl8etf2bIAXn1+IcZjXQGgUNMCli/hAqEiK6/aEfc37UTH/dupMVi65liF4J/ZMB/e7ljkBGTDi0Pw3icjFdeePdIIc2bXhYBCzU1Y5p0DhHJUXrUj6TP6Bi5By9rKye/6R+bC+9uXOAF56KkT8MW3oxXXDh9eCYsW1gNcd/Y+fYoqDDZqCQcI5cyNDXMlJzvwqgDBziKUK1Gbx+iLGsjG2TsHCOXMOdexmAi/IU6uGpDrHeiJGvt8LTFT0wSjczcJNqi5ivtbNkMUT0jDVBkI+pM2j+GwtXM3AQlrrvqbB8bzUGUVyRbI7bBo4TRZk31qibXZMgGhoivTNTxTRWgHXpgDID61hDJb2mjLJFzZf3iLrkSYK9PLBZA47o6a+r0ULZQLI5KVOFo/ogNCqRs7BWBSk/hoMxUsQP/AJWgmwt6N6+bC7tfdwt5Hnz4Jn+47V9GlocMrYTGGvfIRw2DU1Odroc3Kj+iAUP7Dy2SQcuZJmax64lf44aeLE8SEMBCKy/HOnjOwpevUhEsfuGcWfLP7Vk1z3pw7NUlUThtsgWAcrTpQFVnv7anMlWj4/MUY9n42AiPnrkIUAdzVPAPaVs9yYTF+zVcHR6H32CVAtbxpXh1sXDcP6rQG2yqlknwPRe7nfADYLv1ROR/RdYly6ByhGOteTUA4Nwl+jtmPmCoadV1U+mIdENLGWwhCWbovTwYt2szyVF34q6ti5PRRGWmFBIIdI6HExPyD8xQZn6MCoqopsOneMACQEYoKiGp10Oam4tyK0aCKsFwaD3YNHWml1QzRXYxYZlJ9twWiewkSO6t6b29CVFFgDVH5VZQLDjxqvR7lIlfpjAHAdBsg1Eg4AgB3G0YkahaugcsFCROcWCF8SKVTV62Xc6oUzwLAHEl25BRCpSFrAOCg1MDHALCOYSKMWc6CAkmT1/sbADD8TR5WQCihGnP5ibvJs9MJ6QKxbs6AW71T4qhdqueSo07WCmD5AY4DwLJqAqFG07g2Bq8q8YFxLFouLValyeuxl8BtnLqNhuiBlMpAY6pI2YcovbQRNfYlZZPWYuQbCEos136k0qHXApD/i+GwPKdhKRkFehnt9o1UJBYnPxChJcvbfmkdPHEZNj8+D3ZuW2wvOw9XtG04Dj3fn4eGZdNhYN9yai2kNoA83Dp72+c9o1uFTDueXQCdz2HxWnZH+8vD0P3hP+M3XHvvnPVfHzq3V+pBbQCRyy5xhKKWtK5Kl2rn4kStQO1ghKM1AwTrbA+fvxCvFkIpmY39K7gyTXWeMFWJRlRp8doBUn5PcUIInIXp6txxGrre+pOjHXhOTQHBB67IE4WEIvuNMhVdNWbNAUGZVBQDhIBCmCm8tykNUpNAyAJldPD79+iKEXhuBOc67VuHS+GtdJhg1KTJGvfp1I5C6Og3PTa3NFexnUAiCAxrCX/B0Yxkv+RUj00qKf+pE824VhYPIBjUGISjC40RAk42d300MmGOId3TpuivJk2WzMi0RWBpZo0HwkEApSFfaZIo9i4Ff2nS71TByH0A8J3cOZsiB46tFe37qglOU2pDgbAxM/L11BoPZ7VQVRRhtUBFRj3l7flMOyRQy7825oESpGppmOPRRZ1Y2v3dXd7R1xWLkMqg0xBVB3DzetWbq6rR4GIiVGAQOO7moKoWFBWU+AsItjth6wCrKk6oLTRMmv0lADxI3UwHREdXPHSyTd0u0aYqe85I152DfQ21Q0PyvroNPvE87AP2xXQ41fZio0bHarpzeS9C1kvzjLaqfYpqYwDbfikHKGfkpoGS1nfYPmgW56eFopUJB4irpqSJaLIQbJp7mHyErm3tG8xcIHgD0Qnd9kjGyvc0UsjhtSL6E7+PleziaQCQV9uMUwcbIMmbUY4rC6eaQybjXUrKBGVBzcWM0aYrkDwLJg99c96maQqIf3yq6YJRO7ArU0D8A1HNVViyZp3kv8+TtsXUG4ROAfE3NlSmyhhZJbswBcQfEC97GU8B8QNEBYPlyKc0xA8E0YrXHySY0pB0cFRO3PnX3KaAuAPRvZHrvONe0YFgZJP8nXUhXlycCpny172r7gyjyBNDTrY1VKJT95OAqWAUFYjty/vO9lyyZmQhX+IcL8sNRTNZtjCEvJx+OiIhbNOilBcYRdMQ3Ro/xzW7aArHNKY2U0Wdh+h+DU5sbSEqUXA3CarowmZJ2bR0nVbryEFUFJOl0g6dqVCVMeHsWVdbZvIVKEjj/rsclaXOKQoQ1/2DKa2i0hnCNOHmOaYyHm/+oshAXPd/pDQrmX3l+AhfgQFLaYqiIWlqheVCZ1HkpyvsSwov1Hym0D5EBmJjw133jkSBBTVPRTZZ2t2FDLbAdu/ITDVC7ntRTBYVMXHWGkyha9VMk2oQFQUINUM3TfQ4E0l08CIRmYu6sqIAwQFFhbAq86LKxp65to/ym55fU2BFT9yTigREl8cSO2qLdLzq+b2mObhCtjmvSEDwuWx8giwHjs+xkV2Qc4sGxBVK5uGrK60iAsFnFXvhmtIcQRKArsLmXFdUIPhswl+I1yOSr7Xhe5BCmzhyyM05/wGhNOiSLHV8XgAAAABJRU5ErkJggg==";
    },
  },
]);
//# sourceMappingURL=pages-cat-index.f57e5ae8.js.map
