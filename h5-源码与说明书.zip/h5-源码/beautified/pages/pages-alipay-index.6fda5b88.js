(window["webpackJsonp"] = window["webpackJsonp"] || []).push([
  ["pages-alipay-index"],
  {
    "026d": function (t, i, n) {
      var e = n("3619");
      e.__esModule && (e = e.default),
        "string" === typeof e && (e = [[t.i, e, ""]]),
        e.locals && (t.exports = e.locals);
      var a = n("967d").default;
      a("12c7b357", e, !0, { sourceMap: !1, shadowMode: !1 });
    },
    "0307": function (t, i, n) {
      "use strict";
      n("6a54"),
        Object.defineProperty(i, "__esModule", { value: !0 }),
        (i.default = void 0),
        n("5ef2"),
        n("4626");
      var e = n("e74a"),
        a = n("15b8"),
        s = {
          data: function () {
            return {
              isHidden: !1,
              id: 0,
              pay_type: 2,
              type: 0,
              token: "",
              sub_info: {},
              base_url: a.baseUrl,
              palte: "h5",
            };
          },
          onLoad: function (t) {
            "h5" != this.palte && uni.setNavigationBarTitle({ title: "" }),
              (this.id = t.id),
              (this.token = t.token),
              (this.type = t.type),
              (this.pay_type = t.pay_type),
              (1 != this.type && 6 != this.type) ||
                ((this.sub_info.id = t.id),
                (this.sub_info.num = t.num),
                (this.sub_info.game_area = t.game_area),
                (this.sub_info.seller_id = t.seller_id),
                (this.sub_info.num_id = t.num_id),
                (this.sub_info.remark = t.remark),
                (this.sub_info.invite = t.invite)),
              this.init();
          },
          onHide: function () {
            this.isHidden = !0;
          },
          onShow: function () {
            this.isHidden &&
              (console.log("从后台返回页面"), this.queryOrderStatus()),
              (this.isHidden = !1);
          },
          onPullDownRefresh: function () {
            uni.showLoading({ title: "刷新中" }),
              setTimeout(function () {
                uni.hideLoading(),
                  uni.showToast({ title: "刷新成功", duration: 1e3 }),
                  uni.stopPullDownRefresh();
              }, 300);
          },
          methods: {
            init: function () {
              var t = this.isWeChatBrowser();
              0 == t && this.submit();
            },
            isWeChatBrowser: function () {
              var t = navigator.userAgent.toLowerCase();
              return -1 !== t.indexOf("micromessenger");
            },
            jump: function (t) {
              uni.navigateTo({ url: t });
            },
            submit: function () {
              uni.$uv.throttle(this.alipay, 500);
            },
            alipay: function () {
              var t = this;
              uni.showLoading({ title: "加载中.." }),
                (0, e.post2)(
                  "/wechat/Pay/pay",
                  {
                    id: this.id,
                    type: this.type,
                    pay_type: this.pay_type,
                    submit: this.sub_info,
                    token: this.token,
                  },
                  !1,
                ).then(function (i) {
                  uni.hideLoading();
                  var n = i.status,
                    e = i.msg,
                    a = i.data;
                  if (1 != n) return uni.$uv.toast(e);
                  if (
                    (uni.setStorageSync("order_no", a.order_no),
                    2 == t.pay_type)
                  ) {
                    var s = document.createElement("div");
                    (s.innerHTML = a.form),
                      document.body.appendChild(s),
                      document.forms["alipaysubmit"].submit();
                  }
                  6 == t.pay_type &&
                    (uni.$uv.toast("正在跳转..."),
                    console.log(a.pay_url),
                    (window.location.href = a.pay_url));
                });
            },
            queryOrderStatus: function () {
              var t = [
                "/pages/index/index",
                "/pages/cat/index",
                "/pages/follow/index",
                "/pages/user/index",
              ];
              (0, e.post2)(
                "/wechat/Pay/queryOrderStatus",
                { token: this.token, order_no: uni.getStorageSync("order_no") },
                !1,
              ).then(function (i) {
                var n = i.status,
                  e = i.msg,
                  a = i.data;
                return 1 != n
                  ? uni.$uv.toast(e)
                  : 0 == a.status
                    ? uni.$uv.toast("订单还未完成支付")
                    : (uni.$uv.toast("支付成功"),
                      void setTimeout(function () {
                        t.includes(a.jump)
                          ? uni.switchTab({ url: a.jump })
                          : uni.redirectTo({ url: a.jump });
                      }, 1500));
              });
            },
          },
        };
      i.default = s;
    },
    "065b": function (t, i, n) {
      "use strict";
      n.r(i);
      var e = n("7668"),
        a = n("45e9");
      for (var s in a)
        ["default"].indexOf(s) < 0 &&
          (function (t) {
            n.d(i, t, function () {
              return a[t];
            });
          })(s);
      n("25b0");
      var o = n("828b"),
        r = Object(o["a"])(
          a["default"],
          e["b"],
          e["c"],
          !1,
          null,
          "b3b80028",
          null,
          !1,
          e["a"],
          void 0,
        );
      i["default"] = r.exports;
    },
    "25b0": function (t, i, n) {
      "use strict";
      var e = n("026d"),
        a = n.n(e);
      a.a;
    },
    3619: function (t, i, n) {
      var e = n("c86c");
      (i = e(!1)),
        i.push([
          t.i,
          '@charset "UTF-8";\r\n/**\r\n * 这里是uni-app内置的常用样式变量\r\n *\r\n * uni-app 官方扩展插件及插件市场（https://ext.dcloud.net.cn）上很多三方插件均使用了这些样式变量\r\n * 如果你是插件开发者，建议你使用scss预处理，并在插件代码中直接使用这些变量（无需 import 这个文件），方便用户通过搭积木的方式开发整体风格一致的App\r\n *\r\n */\r\n/**\r\n * 如果你是App开发者（插件使用者），你可以通过修改这些变量来定制自己的插件主题，实现自定义主题功能\r\n *\r\n * 如果你的项目同样使用了scss预处理，你也可以直接在你的 scss 代码中使用如下变量，同时无需 import 这个文件\r\n */\r\n/* 颜色变量 */\r\n/* 行为相关颜色 */\r\n/* 文字基本颜色 */\r\n/* 背景颜色 */\r\n/* 边框颜色 */\r\n/* 尺寸变量 */\r\n/* 文字尺寸 */\r\n/* 图片尺寸 */\r\n/* Border Radius */\r\n/* 水平间距 */\r\n/* 垂直间距 */\r\n/* 透明度 */\r\n/* 文章场景相关 */.content[data-v-b3b80028]{height:100vh;background:#efefef;text-align:center;flex-direction:column;padding:20% %?20?% 19%;position:relative}.jiantou[data-v-b3b80028]{position:absolute;width:%?116?%;height:%?134?%;top:%?10?%;right:%?45?%}.title uni-view[data-v-b3b80028]{font-size:15px}.safari[data-v-b3b80028]{width:%?500?%;height:%?307?%;margin:%?74?% auto}.bottom_box .done[data-v-b3b80028]{justify-content:center}.bottom_box .done .zhi[data-v-b3b80028]{width:%?55?%;height:%?55?%;margin-right:%?20?%}.bottom_box .done uni-view[data-v-b3b80028]{font-size:19.6px}.bottom_box .pay[data-v-b3b80028]{justify-content:center;margin-top:%?32?%}.bottom_box .pay .btn[data-v-b3b80028]{margin-left:%?25?%;background:#02a9f1;color:#fff;width:%?160?%;font-size:13px;height:%?60?%;line-height:%?60?%;border-radius:%?18?%}',
          "",
        ]),
        (t.exports = i);
    },
    "45e9": function (t, i, n) {
      "use strict";
      n.r(i);
      var e = n("0307"),
        a = n.n(e);
      for (var s in e)
        ["default"].indexOf(s) < 0 &&
          (function (t) {
            n.d(i, t, function () {
              return e[t];
            });
          })(s);
      i["default"] = a.a;
    },
    7668: function (t, i, n) {
      "use strict";
      n.d(i, "b", function () {
        return e;
      }),
        n.d(i, "c", function () {
          return a;
        }),
        n.d(i, "a", function () {});
      var e = function () {
          var t = this,
            i = t.$createElement,
            n = t._self._c || i;
          return "h5" == t.palte
            ? n(
                "v-uni-view",
                { staticClass: "content flex_box" },
                [
                  n("img", {
                    staticClass: "jiantou",
                    attrs: {
                      src: t.base_url + "/files/imgs/alipay/jiantou.png",
                    },
                  }),
                  n(
                    "v-uni-view",
                    {},
                    [
                      n(
                        "v-uni-view",
                        { staticClass: "title" },
                        [
                          n("v-uni-view", [
                            t._v("请点击右上角“···”选择“在Safari中打开”"),
                          ]),
                          n("v-uni-view", [t._v("在浏览器中完成支付宝支付")]),
                        ],
                        1,
                      ),
                      n("img", {
                        staticClass: "safari",
                        attrs: {
                          src: t.base_url + "/files/imgs/alipay/safari.png",
                        },
                      }),
                    ],
                    1,
                  ),
                  n(
                    "v-uni-view",
                    { staticClass: "bottom_box" },
                    [
                      n(
                        "v-uni-view",
                        { staticClass: "done flex_box" },
                        [
                          n("img", {
                            staticClass: "zhi",
                            attrs: {
                              src: t.base_url + "/files/imgs/alipay/alipay.png",
                            },
                          }),
                          n("v-uni-view", [t._v("已完成支付?")]),
                        ],
                        1,
                      ),
                      n(
                        "v-uni-view",
                        { staticClass: "pay flex_box" },
                        [
                          n("v-uni-view", [t._v("请确认完成支付后,点击")]),
                          n(
                            "v-uni-view",
                            {
                              staticClass: "btn",
                              on: {
                                click: function (i) {
                                  (arguments[0] = i = t.$handleEvent(i)),
                                    t.queryOrderStatus();
                                },
                              },
                            },
                            [t._v("完成付款")],
                          ),
                        ],
                        1,
                      ),
                    ],
                    1,
                  ),
                ],
                1,
              )
            : t._e();
        },
        a = [];
    },
  },
]);
//# sourceMappingURL=pages-alipay-index.6fda5b88.js.map
