(window["webpackJsonp"] = window["webpackJsonp"] || []).push([
  ["pages_sub1-order-info"],
  {
    "145e": function (i, e) {
      i.exports =
        "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAEoAAABACAYAAAC9S+EXAAAAGXRFWHRTb2Z0d2FyZQBBZG9iZSBJbWFnZVJlYWR5ccllPAAAA3dpVFh0WE1MOmNvbS5hZG9iZS54bXAAAAAAADw/eHBhY2tldCBiZWdpbj0i77u/IiBpZD0iVzVNME1wQ2VoaUh6cmVTek5UY3prYzlkIj8+IDx4OnhtcG1ldGEgeG1sbnM6eD0iYWRvYmU6bnM6bWV0YS8iIHg6eG1wdGs9IkFkb2JlIFhNUCBDb3JlIDkuMS1jMDAxIDc5LjE0NjI4OTk3NzcsIDIwMjMvMDYvMjUtMjM6NTc6MTQgICAgICAgICI+IDxyZGY6UkRGIHhtbG5zOnJkZj0iaHR0cDovL3d3dy53My5vcmcvMTk5OS8wMi8yMi1yZGYtc3ludGF4LW5zIyI+IDxyZGY6RGVzY3JpcHRpb24gcmRmOmFib3V0PSIiIHhtbG5zOnhtcE1NPSJodHRwOi8vbnMuYWRvYmUuY29tL3hhcC8xLjAvbW0vIiB4bWxuczpzdFJlZj0iaHR0cDovL25zLmFkb2JlLmNvbS94YXAvMS4wL3NUeXBlL1Jlc291cmNlUmVmIyIgeG1sbnM6eG1wPSJodHRwOi8vbnMuYWRvYmUuY29tL3hhcC8xLjAvIiB4bXBNTTpPcmlnaW5hbERvY3VtZW50SUQ9InhtcC5kaWQ6NmYxZjUzOTEtODYwOS02NTQ1LWJmMmUtZGI1YTlhNTBhYzY2IiB4bXBNTTpEb2N1bWVudElEPSJ4bXAuZGlkOkU0Q0VFMDZDMjZDQTExRjE4Q0Y1QjMwMkYyRjU2RTMxIiB4bXBNTTpJbnN0YW5jZUlEPSJ4bXAuaWlkOkU0Q0VFMDZCMjZDQTExRjE4Q0Y1QjMwMkYyRjU2RTMxIiB4bXA6Q3JlYXRvclRvb2w9IkFkb2JlIFBob3Rvc2hvcCAyNS4wIChXaW5kb3dzKSI+IDx4bXBNTTpEZXJpdmVkRnJvbSBzdFJlZjppbnN0YW5jZUlEPSJ4bXAuaWlkOjlmNzcxMjA0LTVlNTMtMjc0Ni04NGRmLWExMzY1OTAwMmJiYiIgc3RSZWY6ZG9jdW1lbnRJRD0ieG1wLmRpZDo2ZjFmNTM5MS04NjA5LTY1NDUtYmYyZS1kYjVhOWE1MGFjNjYiLz4gPC9yZGY6RGVzY3JpcHRpb24+IDwvcmRmOlJERj4gPC94OnhtcG1ldGE+IDw/eHBhY2tldCBlbmQ9InIiPz4TL8/LAAACn0lEQVR42uycTYhNYRjH33sIaTJDKZONSON7YTEbVhYWJCmUjXwtTFmQlY8RQ2wQEYNJkoaIpSwsiDJlFLJQVqbGiMmYpnxlXL/nGjU0necdjDn33v+v/ptbM/f063nee973PPfm8q+qOkMIz8kT8ojcC9VdL4L4hRyi8gO8/pLcJNfIXcR9k6iBRfWnjZwjpxD2TqJ8egqyQjiMsE6J8nlPdpIz5dSSyR/8TVVfZT0IHeOnS5RPLWlF1iqJ8hlHriLrAMlJlM8uch5ZIyXKZx25iKwREuWzhjSWYhsmQ/A/N5F6iYpjL1W1QqIibmT71qsaifKpIM3IGiVRPvPJwXLd6w2WXrKQfWGLKiodu69qogVHS5TPbLJNrRfHBzKTFmxTRaUzNtihn1ovipWsVQskKu5G9Ggx7gWTYXhPO/ArusO+/7mY98eeG85iYf+qikrHzto3qKLiaC8Iq+76qIpKZzKpU0XF8ZZMo6p6VFHpTCRbVVFxdJOpWZ9rSDJwDZVkhyoqjk+kJssb5iQj1zGG7FPrxbGWPeBciYq7lkMSFcdSqmqRRMVxPIvDHlkUNSeLW5us3B78jo0/2jFMhyoqHRt/PKbWi2M1a9UyiYrjLLImSJTPJHJaouJbcL1ExXESWfMkyseeMtuYdqVE+dj0XvNwTR0XkyhjCTkhUXHUUVX7JSqO3ciql6g4GpC1p9w3xYOhkWxhA92rikpnM7lOdVVIlM9y0oKsGRLlYwO1D5G1cSgG1UpJlGHt10RuIWuKRPksJk+Rtf1fzbeXwqeehz19tkf2V/7mW/XlIOonz8gRchlhnyXK53WwY5sQLiCsXaJ8rA3vkEvkBtK6JcrnC7lPbhc+MUN4jLi8RPm8KdyT2Q9g/PipqNbvAgwAJivLjh1gJNUAAAAASUVORK5CYII=";
    },
    "1ca1": function (i, e, t) {
      var a = t("c86c"),
        n = t("2ec5"),
        s = t("145e");
      e = a(!1);
      var o = n(s);
      e.push([
        i.i,
        '@charset "UTF-8";\r\n/**\r\n * 这里是uni-app内置的常用样式变量\r\n *\r\n * uni-app 官方扩展插件及插件市场（https://ext.dcloud.net.cn）上很多三方插件均使用了这些样式变量\r\n * 如果你是插件开发者，建议你使用scss预处理，并在插件代码中直接使用这些变量（无需 import 这个文件），方便用户通过搭积木的方式开发整体风格一致的App\r\n *\r\n */\r\n/**\r\n * 如果你是App开发者（插件使用者），你可以通过修改这些变量来定制自己的插件主题，实现自定义主题功能\r\n *\r\n * 如果你的项目同样使用了scss预处理，你也可以直接在你的 scss 代码中使用如下变量，同时无需 import 这个文件\r\n */\r\n/* 颜色变量 */\r\n/* 行为相关颜色 */\r\n/* 文字基本颜色 */\r\n/* 背景颜色 */\r\n/* 边框颜色 */\r\n/* 尺寸变量 */\r\n/* 文字尺寸 */\r\n/* 图片尺寸 */\r\n/* Border Radius */\r\n/* 水平间距 */\r\n/* 垂直间距 */\r\n/* 透明度 */\r\n/* 文章场景相关 */\r\n/* 增值服务明细 */.order_service_box[data-v-de3f47cc]{padding:0 %?30?% %?30?%}.order_service_box .show_more[data-v-de3f47cc]{text-align:center;color:#ff6a00;font-size:14px;margin-top:%?12?%;padding-top:%?12?%;border-top:%?1?% dashed #eee}.order_service_box .order_service_title[data-v-de3f47cc]{font-size:15px;color:#333;font-weight:700;margin:%?30?% auto %?10?%}.order_service_box .order_service_item[data-v-de3f47cc]{padding:%?20?% 0;border-bottom:%?2?% solid #f2f2f2}.order_service_box .order_service_item[data-v-de3f47cc]:last-child{border-bottom:none}.order_service_box .order_service_item .os_img[data-v-de3f47cc]{width:%?80?%;height:%?80?%;border-radius:%?8?%;margin-right:%?16?%;flex-shrink:0}.order_service_box .order_service_item .os_info[data-v-de3f47cc]{flex:1;min-width:0;margin-right:%?16?%}.order_service_box .order_service_item .os_info .os_name[data-v-de3f47cc]{font-size:13.5px;color:#333}.order_service_box .order_service_item .os_info .os_intro[data-v-de3f47cc]{font-size:12.4px;color:#999;margin-top:%?6?%}.order_service_box .order_service_item .os_right[data-v-de3f47cc]{display:flex;flex-direction:column;align-items:flex-end;flex-shrink:0}.order_service_box .order_service_item .os_right .os_num[data-v-de3f47cc]{font-size:12.4px;color:#999;margin-bottom:%?4?%}.order_service_box .order_service_item .os_right .os_price[data-v-de3f47cc]{color:#fd2c28;font-weight:700;font-size:14.4px}.againShow[data-v-de3f47cc]{background:#fff;border-radius:%?30?%;padding:%?0?% %?46?% %?30?%;text-align:center}.againShow .title[data-v-de3f47cc]{font-weight:700;padding:%?40?% 0;font-size:17px}.againShow .type_list[data-v-de3f47cc]{margin:%?12?% auto}.againShow .type_list .col[data-v-de3f47cc]{display:flex;align-items:center;justify-content:space-between;border-radius:%?10?%;padding:%?16?%;margin-bottom:%?30?%;background:#f8f8f8;border:%?4?% solid #ddd}.againShow .type_list .col[data-v-de3f47cc]:last-child{margin-bottom:0}.againShow .type_list .col .tit[data-v-de3f47cc]{margin:0 %?6?%}.againShow .type_list .col .circle[data-v-de3f47cc]{display:flex;align-items:center;justify-content:center;width:%?40?%;height:%?40?%;border-radius:100%;border:%?2?% solid #ddd;background:#fff}.againShow .type_list .col.cur[data-v-de3f47cc]{background:#ffe610;border-color:#000}.againShow .btn_box[data-v-de3f47cc]{margin:%?62?% auto %?15?%}.againShow .btn_box uni-view[data-v-de3f47cc]{background:#ffe610;width:42%;font-size:16px;font-weight:700;height:%?80?%;line-height:%?80?%;border-radius:%?80?%}.againShow .btn_box uni-view.cancle[data-v-de3f47cc]{background:#eee;color:#999}.seller_msg_box[data-v-de3f47cc]{margin:%?30?% auto 0;align-items:flex-start}.seller_msg_box .head[data-v-de3f47cc]{width:%?72?%;height:%?72?%;border-radius:100%}.seller_msg_box .txt[data-v-de3f47cc]{width:calc(100% - %?97?%)}.seller_msg_box .txt .nickname[data-v-de3f47cc]{height:%?72?%;line-height:%?72?%;font-size:15px}.seller_msg_box .txt .img_box[data-v-de3f47cc]{margin:%?4?% auto %?20?%;display:grid;grid-template-columns:repeat(3,1fr);grid-gap:%?30?%}.seller_msg_box .txt .img_box img[data-v-de3f47cc]{border-radius:%?15?%;width:%?162?%;height:%?162?%}.seller_msg_box .txt .tips[data-v-de3f47cc]{color:#999;margin:%?6?% auto}.status_box[data-v-de3f47cc]{padding:%?20?% %?30?% %?30?%;border-bottom:%?14?% solid #f8f8f8}.status_box .status[data-v-de3f47cc]{justify-content:flex-start}.status_box .status .icon_loading[data-v-de3f47cc]{display:inline-block;margin:0 %?14?% 0 0;width:%?38?%;height:%?38?%}.status_box .status .tit[data-v-de3f47cc]{font-weight:700;font-size:16px}.status_box .intro[data-v-de3f47cc]{color:#999;margin-top:%?10?%}.line_box[data-v-de3f47cc]{background:#f8f8f8;width:100%;height:%?14?%;margin:0 auto}.block_title[data-v-de3f47cc]{background:#f8f8f8;padding:%?36?% %?30?%}.reason_box[data-v-de3f47cc]{padding:%?8?% %?30?%;box-sizing:border-box}.reason_box.remarks_box[data-v-de3f47cc]{align-items:flex-start}.reason_box .tit[data-v-de3f47cc]{font-size:15px;font-weight:700;position:relative;z-index:10}.reason_box .tit[data-v-de3f47cc]::before{z-index:-1;display:block;content:"";width:72%;height:%?20?%;border-radius:%?20?%;background:#ffe610;position:absolute;left:50%;bottom:%?6?%;-webkit-transform:translate(-50%);transform:translate(-50%)}.reason_box .txt[data-v-de3f47cc]{width:calc(100% - %?150?%)}.reason_box .txt.img_box[data-v-de3f47cc]{display:grid;grid-template-columns:repeat(3,1fr);grid-gap:%?25?%}.reason_box .txt.img_box img[data-v-de3f47cc]{border-radius:%?15?%;width:%?162?%;height:%?162?%}.content[data-v-de3f47cc]{min-height:100vh;padding:0 %?0?% %?130?%}.banShow[data-v-de3f47cc]{background:#fff;border-radius:%?30?%;padding:%?0?% %?46?% %?30?%;text-align:center}.banShow .tit[data-v-de3f47cc]{font-weight:700;padding:%?40?% 0;font-size:17px}.banShow .prompt[data-v-de3f47cc]{margin:%?6?% auto;line-height:1.5;color:#999}.banShow .red[data-v-de3f47cc]{color:#fd2c28}.banShow .btn[data-v-de3f47cc]{background:#ffe610;width:50%;font-size:16px;font-weight:700;height:%?80?%;line-height:%?80?%;border-radius:%?80?%;margin:%?62?% auto %?5?%}.top_box[data-v-de3f47cc]{padding:%?30?% 0;margin:0 %?30?%;border-bottom:%?2?% solid #eee}.top_box uni-view[data-v-de3f47cc]{font-size:13px;white-space:nowrap}.top_box .order_num[data-v-de3f47cc]{justify-content:flex-start;flex:1}.top_box .order_num .num[data-v-de3f47cc]{font-weight:700}.top_box .order_num .copy_btn[data-v-de3f47cc]{margin-left:%?12?%;color:#2979ff}.top_box .status[data-v-de3f47cc]{font-size:12px;font-weight:700}.msg_box[data-v-de3f47cc]{padding:0 %?30?%}.msg_box .goods_msg[data-v-de3f47cc]{margin:%?35?% auto %?45?%;padding-bottom:%?4?%}.msg_box .goods_msg .img[data-v-de3f47cc]{width:%?120?%;height:%?120?%;border-radius:%?10?%;position:relative;top:%?4?%}.msg_box .goods_msg .txt[data-v-de3f47cc]{width:calc(100% - %?145?%)}.msg_box .goods_msg .txt .price_box .price[data-v-de3f47cc]{color:#fd2c28;font-weight:700;font-size:18px}.msg_box .goods_msg .txt .price_box .price .unit[data-v-de3f47cc]{font-size:13px}.msg_box .goods_msg .txt .name[data-v-de3f47cc]{margin:%?6?% auto %?2?%;font-weight:700}.msg_box .goods_msg .txt .intro[data-v-de3f47cc]{font-size:13px;color:#999}.msg_box .tips[data-v-de3f47cc]{margin:%?28?% auto}.msg_box .tips uni-view[data-v-de3f47cc]{color:#999;font-size:14.4px}.msg_box .tips .tit[data-v-de3f47cc]{color:#444}.msg_box .tips .remark[data-v-de3f47cc]{flex:1;text-align:right;margin-left:%?150?%}.msg_box .tips .copy_btn[data-v-de3f47cc]{margin-left:%?14?%;color:#2979ff}.msg_box .tips .real_money[data-v-de3f47cc]{color:#fd2c28;font-weight:700;font-size:15px}.msg_box .tips .real_money .unit[data-v-de3f47cc]{font-size:11px}.msg_box .service_member_card[data-v-de3f47cc]{position:relative;margin:20px auto}.msg_box .service_member_card uni-view[data-v-de3f47cc]{text-align:center;white-space:nowrap}.msg_box .service_member_card .tip_box[data-v-de3f47cc]{background:#a387f1;position:absolute;z-index:9;top:7px;right:7px;height:36px;line-height:28px;font-size:12px;color:#fff;border-radius:0 12px 0 0;width:calc(100% - 95px - 11px);padding:0 12px 0 23px}.msg_box .service_member_card .card_box[data-v-de3f47cc]{position:relative;z-index:10}.msg_box .service_member_card .card_box .card_title[data-v-de3f47cc]{position:relative;z-index:0;border-radius:12px 0 0 0;height:36px;background:#ffe610;justify-content:flex-start;position:relative;overflow:visible;width:95px;padding-top:6px;padding-left:14px}.msg_box .service_member_card .card_box .card_title img[data-v-de3f47cc]{width:20px;height:20px;margin-right:7px}.msg_box .service_member_card .card_box .card_title .title[data-v-de3f47cc]{font-weight:700;font-size:12.6px}.msg_box .service_member_card .card_box .card_title[data-v-de3f47cc]::before{content:"";display:block;height:inherit;width:28px;right:-28px;background:url(' +
          o +
          ");background-position:0 0;background-repeat:no-repeat;background-size:100% 100%;position:absolute;top:0;bottom:0}.msg_box .service_member_card .card_box .card_main[data-v-de3f47cc]{position:relative;z-index:1;border-radius:0 12px 12px 12px;background:#ffe610;padding:%?0?% 12px;margin-top:-2px}.msg_box .service_member_card .card_box .card_main .worker_list .worker[data-v-de3f47cc]{margin:18px auto}.msg_box .service_member_card .card_box .card_main .worker_list .worker .worker_msg[data-v-de3f47cc]{flex:1;justify-content:flex-start}.msg_box .service_member_card .card_box .card_main .worker_list .worker .worker_msg .head[data-v-de3f47cc]{width:52px;height:52px;border-radius:100%;margin-right:14px}.msg_box .service_member_card .card_box .card_main .worker_list .worker .worker_msg .nickname_box[data-v-de3f47cc]{flex:1}.msg_box .service_member_card .card_box .card_main .worker_list .worker .worker_msg .nickname_box uni-view[data-v-de3f47cc]{text-align:left}.msg_box .service_member_card .card_box .card_main .worker_list .worker .worker_msg .nickname_box .nickname[data-v-de3f47cc]{font-size:15px;font-weight:700;text-overflow:ellipsis}.msg_box .service_member_card .card_box .card_main .worker_list .worker .worker_msg .nickname_box .id[data-v-de3f47cc]{color:#666;margin-top:6px;font-size:13px}.msg_box .service_member_card .card_box .card_main .worker_list .worker .choose_btn[data-v-de3f47cc]{width:60px;height:29px;line-height:29px;border-radius:29px;margin-left:45px;background:#a387f1;color:#fff;font-weight:700;font-size:13px}.cash_box[data-v-de3f47cc]{background:#fff;position:fixed;left:0;right:0;bottom:0;max-width:480px;width:100%;margin:0 auto;box-shadow:0 0 %?10?% #ddd;padding:%?25?%;z-index:99}.cash_box .total_box uni-view[data-v-de3f47cc],\r\n.cash_box .total_box uni-text[data-v-de3f47cc]{white-space:nowrap}.cash_box .total_box .tit[data-v-de3f47cc]{font-size:12.4px;color:#666}.cash_box .total_box .price[data-v-de3f47cc]{color:#fd2c28;font-weight:700;font-size:17px}.cash_box .total_box .price .unit[data-v-de3f47cc]{font-size:12px}.cash_box .btn_box[data-v-de3f47cc]{justify-content:flex-end}.cash_box .btn_box uni-view[data-v-de3f47cc]{background:#ffe610;height:%?66?%;line-height:%?66?%;border-radius:%?66?%;font-weight:700;margin-left:%?25?%;padding:0 %?24?%;box-sizing:border-box}.cash_box .btn_box uni-view[data-v-de3f47cc]:first-child{margin-left:0}.cash_box .btn_box uni-view.cancle[data-v-de3f47cc]{background:#eee;color:#666}.red-tips[data-v-de3f47cc]{color:red!important;font-weight:700;text-align:center}.raffle_info[data-v-de3f47cc]{margin:%?35?% auto %?45?%;padding-bottom:%?4?%}.raffle_info .img[data-v-de3f47cc]{width:%?120?%;height:%?120?%;border-radius:%?10?%;position:relative;top:%?4?%}.raffle_info .txt[data-v-de3f47cc]{width:calc(100% - %?145?%)}.raffle_info .txt .price_box .price[data-v-de3f47cc]{color:#fd2c28;font-weight:700;font-size:18px}.raffle_info .txt .price_box .price .unit[data-v-de3f47cc]{font-size:13px}.raffle_info .txt .name[data-v-de3f47cc]{margin:%?6?% auto %?2?%;font-weight:700}.raffle_info .txt .intro[data-v-de3f47cc]{font-size:13px;color:#999}.prize_list_box[data-v-de3f47cc]{background:#fffbe6;border-radius:%?16?%;padding:%?24?%;margin-bottom:%?24?%;border:%?2?% solid #ffe066}.prize_list_box .prize_list_title[data-v-de3f47cc]{font-size:16px;font-weight:700;color:#d4a800;margin-bottom:%?16?%}.prize_list_box .prize_list[data-v-de3f47cc]{display:flex;flex-direction:column;gap:%?12?%}.prize_list_box .prize_item[data-v-de3f47cc]{background:#fff;border-radius:%?12?%;padding:%?12?%;align-items:center}.prize_list_box .prize_item .prize_img[data-v-de3f47cc]{width:%?80?%;height:%?80?%;border-radius:%?8?%;margin-right:%?16?%}.prize_list_box .prize_item .prize_txt[data-v-de3f47cc]{flex:1;display:flex;align-items:center;gap:%?8?%}.prize_list_box .prize_item .prize_txt .prize_label[data-v-de3f47cc]{background:linear-gradient(135deg,#ff6a00,#ff8c00);color:#fff;font-size:10px;padding:%?2?% %?8?%;border-radius:%?4?%;font-weight:700}.prize_list_box .prize_item .prize_txt .prize_name[data-v-de3f47cc]{font-size:14px;color:#333}.prize_list_box .prize_item .prize_count[data-v-de3f47cc]{font-size:14px;color:#999;font-weight:700}.prize_list_box .show_more[data-v-de3f47cc]{text-align:center;color:#ff6a00;font-size:14px;margin-top:%?12?%;padding-top:%?12?%;border-top:%?1?% dashed #ffe066}",
        "",
      ]),
        (i.exports = e);
    },
    "26c4": function (i, e, t) {
      "use strict";
      var a = t("5132"),
        n = t.n(a);
      n.a;
    },
    "385b": function (i, e, t) {
      i.exports = t.p + "static/service_member_second.png";
    },
    "3a07": function (i, e, t) {
      var a = t("c86c");
      (e = a(!1)),
        e.push([
          i.i,
          '@charset "UTF-8";\r\n/**\r\n * 这里是uni-app内置的常用样式变量\r\n *\r\n * uni-app 官方扩展插件及插件市场（https://ext.dcloud.net.cn）上很多三方插件均使用了这些样式变量\r\n * 如果你是插件开发者，建议你使用scss预处理，并在插件代码中直接使用这些变量（无需 import 这个文件），方便用户通过搭积木的方式开发整体风格一致的App\r\n *\r\n */\r\n/**\r\n * 如果你是App开发者（插件使用者），你可以通过修改这些变量来定制自己的插件主题，实现自定义主题功能\r\n *\r\n * 如果你的项目同样使用了scss预处理，你也可以直接在你的 scss 代码中使用如下变量，同时无需 import 这个文件\r\n */\r\n/* 颜色变量 */\r\n/* 行为相关颜色 */\r\n/* 文字基本颜色 */\r\n/* 背景颜色 */\r\n/* 边框颜色 */\r\n/* 尺寸变量 */\r\n/* 文字尺寸 */\r\n/* 图片尺寸 */\r\n/* Border Radius */\r\n/* 水平间距 */\r\n/* 垂直间距 */\r\n/* 透明度 */\r\n/* 文章场景相关 */uni-view[data-v-c2d489ac], uni-scroll-view[data-v-c2d489ac], uni-swiper-item[data-v-c2d489ac]{display:flex;flex-direction:column;flex-shrink:0;flex-grow:0;flex-basis:auto;align-items:stretch;align-content:flex-start}.uv-divider[data-v-c2d489ac]{display:flex;flex-direction:row;flex-direction:row;align-items:center;margin:15px 0}.uv-divider__text[data-v-c2d489ac]{margin:0 15px}.uv-divider__dot[data-v-c2d489ac]{font-size:12px;margin:0 12px;color:#c0c4cc}',
          "",
        ]),
        (i.exports = e);
    },
    4589: function (i, e, t) {
      "use strict";
      t.r(e);
      var a = t("bc7d"),
        n = t("4ab8");
      for (var s in n)
        ["default"].indexOf(s) < 0 &&
          (function (i) {
            t.d(e, i, function () {
              return n[i];
            });
          })(s);
      t("26c4");
      var o = t("828b"),
        r = Object(o["a"])(
          n["default"],
          a["b"],
          a["c"],
          !1,
          null,
          "c2d489ac",
          null,
          !1,
          a["a"],
          void 0,
        );
      e["default"] = r.exports;
    },
    "4ab8": function (i, e, t) {
      "use strict";
      t.r(e);
      var a = t("6811"),
        n = t.n(a);
      for (var s in a)
        ["default"].indexOf(s) < 0 &&
          (function (i) {
            t.d(e, i, function () {
              return a[i];
            });
          })(s);
      e["default"] = n.a;
    },
    5132: function (i, e, t) {
      var a = t("3a07");
      a.__esModule && (a = a.default),
        "string" === typeof a && (a = [[i.i, a, ""]]),
        a.locals && (i.exports = a.locals);
      var n = t("967d").default;
      n("71a84af6", a, !0, { sourceMap: !1, shadowMode: !1 });
    },
    "660b": function (i, e, t) {
      "use strict";
      t.r(e);
      var a = t("c52f"),
        n = t("e189");
      for (var s in n)
        ["default"].indexOf(s) < 0 &&
          (function (i) {
            t.d(e, i, function () {
              return n[i];
            });
          })(s);
      t("9a984");
      var o = t("828b"),
        r = Object(o["a"])(
          n["default"],
          a["b"],
          a["c"],
          !1,
          null,
          "de3f47cc",
          null,
          !1,
          a["a"],
          void 0,
        );
      e["default"] = r.exports;
    },
    6811: function (i, e, t) {
      "use strict";
      t("6a54");
      var a = t("f5bd").default;
      Object.defineProperty(e, "__esModule", { value: !0 }),
        (e.default = void 0);
      var n = a(t("4d8f0")),
        s = a(t("9463")),
        o = a(t("caf4")),
        r = {
          name: "uv-divider",
          mixins: [n.default, s.default, o.default],
          emits: ["click"],
          computed: {
            textStyle: function () {
              var i = {};
              return (
                (i.fontSize = this.$uv.addUnit(this.textSize)),
                (i.color = this.textColor),
                i
              );
            },
            leftLineStyle: function () {
              var i = {};
              return (
                "left" === this.textPosition
                  ? (i.width = "80rpx")
                  : (i.flex = 1),
                i
              );
            },
            rightLineStyle: function () {
              var i = {};
              return (
                "right" === this.textPosition
                  ? (i.width = "80rpx")
                  : (i.flex = 1),
                i
              );
            },
          },
          methods: {
            click: function () {
              this.$emit("click");
            },
          },
        };
      e.default = r;
    },
    "7ffd": function (i, e, t) {
      i.exports = t.p + "static/loading.gif";
    },
    "9a984": function (i, e, t) {
      "use strict";
      var a = t("c9ec"),
        n = t.n(a);
      n.a;
    },
    a5ed5: function (i, e, t) {
      "use strict";
      t("6a54"),
        Object.defineProperty(e, "__esModule", { value: !0 }),
        (e.goRaffle = function (i) {
          return (0, a.send)(
            "/wechat/Raffle/getRaffleStyle",
            { label: "raffle", raffle_id: i },
            !1,
          )
            .then(function (e) {
              1 == e.status && e.data && 2 == e.data.style
                ? uni.navigateTo({
                    url: "/pages_sub1/active/lucky_draw?raffle_id=" + i,
                  })
                : uni.navigateTo({
                    url: "/pages/active/turntable?raffle_id=" + i,
                  });
            })
            .catch(function () {
              uni.navigateTo({ url: "/pages/active/turntable?raffle_id=" + i });
            });
        });
      var a = t("e74a");
    },
    bc7d: function (i, e, t) {
      "use strict";
      t.d(e, "b", function () {
        return n;
      }),
        t.d(e, "c", function () {
          return s;
        }),
        t.d(e, "a", function () {
          return a;
        });
      var a = { uvLine: t("73b2").default },
        n = function () {
          var i = this,
            e = i.$createElement,
            t = i._self._c || e;
          return t(
            "v-uni-view",
            {
              staticClass: "uv-divider",
              style: [i.$uv.addStyle(i.customStyle)],
              on: {
                click: function (e) {
                  (arguments[0] = e = i.$handleEvent(e)),
                    i.click.apply(void 0, arguments);
                },
              },
            },
            [
              t("uv-line", {
                attrs: {
                  color: i.lineColor,
                  customStyle: i.leftLineStyle,
                  hairline: i.hairline,
                  dashed: i.dashed,
                },
              }),
              i.dot
                ? t("v-uni-text", { staticClass: "uv-divider__dot" }, [
                    i._v("●"),
                  ])
                : i.text
                  ? t(
                      "v-uni-text",
                      { staticClass: "uv-divider__text", style: [i.textStyle] },
                      [i._v(i._s(i.text))],
                    )
                  : i._e(),
              t("uv-line", {
                attrs: {
                  color: i.lineColor,
                  customStyle: i.rightLineStyle,
                  hairline: i.hairline,
                  dashed: i.dashed,
                },
              }),
            ],
            1,
          );
        },
        s = [];
    },
    c52f: function (i, e, t) {
      "use strict";
      t.d(e, "b", function () {
        return n;
      }),
        t.d(e, "c", function () {
          return s;
        }),
        t.d(e, "a", function () {
          return a;
        });
      var a = {
          uvDivider: t("4589").default,
          uvPopup: t("ce8a").default,
          uvIcon: t("1a07").default,
        },
        n = function () {
          var i = this,
            e = i.$createElement,
            a = i._self._c || e;
          return a(
            "v-uni-view",
            { staticClass: "content" },
            [
              a(
                "v-uni-view",
                { staticClass: "status_box" },
                [
                  a(
                    "v-uni-view",
                    { staticClass: "status flex_box" },
                    [
                      1 == i.info.status
                        ? a("img", {
                            staticClass: "icon_loading",
                            attrs: { src: t("7ffd") },
                          })
                        : i._e(),
                      a("v-uni-view", { staticClass: "tit" }, [
                        i._v(i._s(i.info.status_text)),
                      ]),
                    ],
                    1,
                  ),
                  a("v-uni-view", { staticClass: "intro" }, [
                    i._v(i._s(i.info.status_tips)),
                  ]),
                  i.info.status >= 3 && i.info.status <= 5
                    ? a(
                        "v-uni-view",
                        { staticClass: "seller_msg_box flex_box" },
                        [
                          a("img", {
                            staticClass: "head",
                            attrs: { src: i.info.seller.avatar },
                          }),
                          a(
                            "v-uni-view",
                            { staticClass: "txt" },
                            [
                              a(
                                "v-uni-view",
                                { staticClass: "nickname uv-line-1" },
                                [i._v(i._s(i.info.seller.nickname))],
                              ),
                              a("v-uni-view", { staticClass: "tips" }, [
                                i._v("证明文字：" + i._s(i.info.service_txt)),
                              ]),
                              a(
                                "v-uni-view",
                                { staticClass: "img_box" },
                                i._l(i.info.service_imgs, function (e, t) {
                                  return a("img", {
                                    key: t,
                                    attrs: { text: e, src: e },
                                    on: {
                                      click: function (t) {
                                        (arguments[0] = t = i.$handleEvent(t)),
                                          i.previewImage(
                                            e,
                                            i.info.service_imgs,
                                          );
                                      },
                                    },
                                  });
                                }),
                                0,
                              ),
                              a("v-uni-view", { staticClass: "tips" }, [
                                i._v(
                                  "接单时间：" +
                                    i._s(
                                      i.info.start_time
                                        ? i.info.start_time
                                        : "",
                                    ),
                                ),
                              ]),
                              a("v-uni-view", { staticClass: "tips" }, [
                                i._v(
                                  "服务时间：" +
                                    i._s(
                                      i.info.service_time
                                        ? i.info.service_time
                                        : "",
                                    ),
                                ),
                              ]),
                              a("v-uni-view", { staticClass: "tips" }, [
                                i._v(
                                  "完成时间：" +
                                    i._s(
                                      i.info.end_time ? i.info.end_time : "",
                                    ),
                                ),
                              ]),
                            ],
                            1,
                          ),
                        ],
                        1,
                      )
                    : i._e(),
                  1 == i.info.is_accept && 1 == i.info.status
                    ? a("v-uni-view", { staticClass: "intro red-tips" }, [
                        i._v("打手已确认,请等待您指定的打手接单!"),
                      ])
                    : i._e(),
                  2 == i.info.status
                    ? a("v-uni-view", { staticClass: "intro red-tips" }, [
                        i._v("打手已接单,请尽快上线同意好友哦!"),
                      ])
                    : i._e(),
                  8 == i.info.status
                    ? a(
                        "v-uni-view",
                        { staticClass: "seller_msg_box flex_box" },
                        [
                          a("img", {
                            staticClass: "head",
                            attrs: { src: i.info.seller.avatar },
                          }),
                          a(
                            "v-uni-view",
                            { staticClass: "txt" },
                            [
                              a(
                                "v-uni-view",
                                { staticClass: "nickname uv-line-1" },
                                [i._v(i._s(i.info.seller.nickname))],
                              ),
                              a(
                                "v-uni-view",
                                { staticClass: "img_box" },
                                i._l(i.info.problem_imgs, function (e, t) {
                                  return a("img", {
                                    key: t,
                                    attrs: { text: e, src: e },
                                    on: {
                                      click: function (t) {
                                        (arguments[0] = t = i.$handleEvent(t)),
                                          i.previewImage(
                                            e,
                                            i.info.problem_imgs,
                                          );
                                      },
                                    },
                                  });
                                }),
                                0,
                              ),
                              a("v-uni-view", { staticClass: "tips" }, [
                                i._v("描述：" + i._s(i.info.problem_des)),
                              ]),
                              a("v-uni-view", { staticClass: "tips" }, [
                                i._v("时间：" + i._s(i.info.problem_time)),
                              ]),
                            ],
                            1,
                          ),
                        ],
                        1,
                      )
                    : i._e(),
                ],
                1,
              ),
              a(
                "v-uni-view",
                { staticClass: "top_box flex_box" },
                [
                  a(
                    "v-uni-view",
                    {
                      staticClass: "order_num flex_box",
                      on: {
                        click: function (e) {
                          (arguments[0] = e = i.$handleEvent(e)),
                            i.copyOrderNum(i.info.order_no);
                        },
                      },
                    },
                    [
                      a("v-uni-view", {}, [i._v("订单编号：")]),
                      a("v-uni-view", { staticClass: "num" }, [
                        i._v(i._s(i.info.order_no)),
                      ]),
                      a("v-uni-view", { staticClass: "copy_btn" }, [
                        i._v("复制"),
                      ]),
                    ],
                    1,
                  ),
                  a("v-uni-view", { staticClass: "status" }, [
                    i._v(i._s(i.info.status_text)),
                  ]),
                ],
                1,
              ),
              a(
                "v-uni-view",
                { staticClass: "msg_box" },
                [
                  0 != i.info.raffle_order &&
                  i.info.prizes &&
                  0 != i.info.prizes.length
                    ? i._e()
                    : a(
                        "v-uni-view",
                        {
                          staticClass: "goods_msg flex_box",
                          on: {
                            click: function (e) {
                              (arguments[0] = e = i.$handleEvent(e)),
                                i.jump(
                                  "/pages/index/goods?id=" + i.info.goods_id,
                                );
                            },
                          },
                        },
                        [
                          i.info.goods_thumb
                            ? a("img", {
                                staticClass: "img",
                                attrs: { src: i.info.goods_thumb },
                              })
                            : a("img", {
                                staticClass: "img",
                                attrs: {
                                  src: i.info.goods ? i.info.goods.thumb : "",
                                },
                              }),
                          a(
                            "v-uni-view",
                            { staticClass: "txt" },
                            [
                              a(
                                "v-uni-view",
                                { staticClass: "price_box flex_box" },
                                [
                                  a(
                                    "v-uni-view",
                                    { staticClass: "price" },
                                    [
                                      a("v-uni-text", { staticClass: "unit" }, [
                                        i._v("￥"),
                                      ]),
                                      a("v-uni-text", [
                                        i._v(i._s(i.info.price)),
                                      ]),
                                    ],
                                    1,
                                  ),
                                  a("v-uni-view", { staticClass: "num" }, [
                                    i._v("x " + i._s(i.info.num)),
                                  ]),
                                ],
                                1,
                              ),
                              a(
                                "v-uni-view",
                                { staticClass: "name uv-line-2" },
                                [i._v(i._s(i.info.goods_name))],
                              ),
                              a(
                                "v-uni-view",
                                { staticClass: "intro uv-line-2" },
                                [i._v(i._s(i.info.goods_intro))],
                              ),
                            ],
                            1,
                          ),
                        ],
                        1,
                      ),
                  i.info.raffle_order > 0 &&
                  i.info.prizes &&
                  i.info.prizes.length > 0
                    ? a(
                        "v-uni-view",
                        { staticClass: "raffle_info flex_box" },
                        [
                          i.info.raffle_thumb
                            ? a("img", {
                                staticClass: "img",
                                attrs: { src: i.info.raffle_thumb },
                              })
                            : i._e(),
                          a(
                            "v-uni-view",
                            { staticClass: "txt" },
                            [
                              a(
                                "v-uni-view",
                                { staticClass: "price_box flex_box" },
                                [
                                  a(
                                    "v-uni-view",
                                    { staticClass: "price" },
                                    [
                                      a("v-uni-text", { staticClass: "unit" }, [
                                        i._v("￥"),
                                      ]),
                                      a("v-uni-text", [
                                        i._v(i._s(i.info.price)),
                                      ]),
                                    ],
                                    1,
                                  ),
                                  a("v-uni-view", { staticClass: "num" }, [
                                    i._v("x " + i._s(i.info.num)),
                                  ]),
                                ],
                                1,
                              ),
                              a(
                                "v-uni-view",
                                { staticClass: "name uv-line-2" },
                                [i._v(i._s(i.info.raffle_title))],
                              ),
                              a(
                                "v-uni-view",
                                { staticClass: "intro uv-line-2" },
                                [i._v(i._s(i.info.raffle_intro))],
                              ),
                            ],
                            1,
                          ),
                        ],
                        1,
                      )
                    : i._e(),
                  i.info.raffle_order > 0 &&
                  i.info.prizes &&
                  i.info.prizes.length > 0
                    ? a(
                        "v-uni-view",
                        { staticClass: "prize_list_box" },
                        [
                          a("v-uni-view", { staticClass: "prize_list_title" }, [
                            i._v("抽中奖品"),
                          ]),
                          a(
                            "v-uni-view",
                            { staticClass: "prize_list" },
                            i._l(
                              i.showAllPrizes
                                ? i.info.prizes
                                : i.info.prizes.slice(0, 3),
                              function (e, t) {
                                return a(
                                  "v-uni-view",
                                  {
                                    key: t,
                                    staticClass: "prize_item flex_box",
                                    on: {
                                      click: function (t) {
                                        (arguments[0] = t = i.$handleEvent(t)),
                                          i.jump(
                                            "/pages/index/goods?id=" +
                                              e.goods_id,
                                          );
                                      },
                                    },
                                  },
                                  [
                                    a("img", {
                                      staticClass: "prize_img",
                                      attrs: { src: e.goods_thumb },
                                    }),
                                    a(
                                      "v-uni-view",
                                      { staticClass: "prize_txt" },
                                      [
                                        a(
                                          "v-uni-view",
                                          { staticClass: "prize_label" },
                                          [i._v("奖品")],
                                        ),
                                        a(
                                          "v-uni-view",
                                          {
                                            staticClass: "prize_name uv-line-1",
                                          },
                                          [i._v(i._s(e.goods_title))],
                                        ),
                                      ],
                                      1,
                                    ),
                                    e.count > 1
                                      ? a(
                                          "v-uni-view",
                                          { staticClass: "prize_count" },
                                          [i._v("x" + i._s(e.count))],
                                        )
                                      : i._e(),
                                  ],
                                  1,
                                );
                              },
                            ),
                            1,
                          ),
                          i.info.prizes.length > 3
                            ? a(
                                "v-uni-view",
                                {
                                  staticClass: "show_more",
                                  on: {
                                    click: function (e) {
                                      (arguments[0] = e = i.$handleEvent(e)),
                                        (i.showAllPrizes = !i.showAllPrizes);
                                    },
                                  },
                                },
                                [
                                  i._v(
                                    " " +
                                      i._s(
                                        i.showAllPrizes
                                          ? "收起"
                                          : "展开全部(" +
                                              i.info.prizes.length +
                                              "个)",
                                      ) +
                                      " ",
                                  ),
                                ],
                              )
                            : i._e(),
                        ],
                        1,
                      )
                    : i._e(),
                ],
                1,
              ),
              i.info.order_service && i.info.order_service.length > 0
                ? a("v-uni-view", { staticClass: "line_box" })
                : i._e(),
              i.info.order_service && i.info.order_service.length > 0
                ? a(
                    "v-uni-view",
                    { staticClass: "order_service_box" },
                    [
                      a("v-uni-view", { staticClass: "order_service_title" }, [
                        i._v("增值服务"),
                      ]),
                      i._l(
                        i.showAllServices
                          ? i.info.order_service
                          : i.info.order_service.slice(0, 3),
                        function (e) {
                          return a(
                            "v-uni-view",
                            {
                              key: e.id,
                              staticClass: "order_service_item flex_box",
                            },
                            [
                              e.image
                                ? a("img", {
                                    staticClass: "os_img",
                                    attrs: { src: e.image, mode: "aspectFill" },
                                    on: {
                                      click: function (t) {
                                        (arguments[0] = t = i.$handleEvent(t)),
                                          i.previewImage(
                                            e.image,
                                            i.info.order_service
                                              .filter(function (i) {
                                                return i.image;
                                              })
                                              .map(function (i) {
                                                return i.image;
                                              }),
                                          );
                                      },
                                    },
                                  })
                                : i._e(),
                              a(
                                "v-uni-view",
                                { staticClass: "os_info" },
                                [
                                  a(
                                    "v-uni-view",
                                    { staticClass: "os_name uv-line-1" },
                                    [i._v(i._s(e.name))],
                                  ),
                                  e.intro
                                    ? a(
                                        "v-uni-view",
                                        { staticClass: "os_intro uv-line-2" },
                                        [i._v(i._s(e.intro))],
                                      )
                                    : i._e(),
                                ],
                                1,
                              ),
                              a(
                                "v-uni-view",
                                { staticClass: "os_right" },
                                [
                                  a("v-uni-view", { staticClass: "os_num" }, [
                                    i._v("x" + i._s(e.num)),
                                  ]),
                                  a("v-uni-view", { staticClass: "os_price" }, [
                                    i._v("￥" + i._s(e.money)),
                                  ]),
                                ],
                                1,
                              ),
                            ],
                            1,
                          );
                        },
                      ),
                      i.info.order_service.length > 3
                        ? a(
                            "v-uni-view",
                            {
                              staticClass: "show_more",
                              on: {
                                click: function (e) {
                                  (arguments[0] = e = i.$handleEvent(e)),
                                    (i.showAllServices = !i.showAllServices);
                                },
                              },
                            },
                            [
                              i._v(
                                " " +
                                  i._s(
                                    i.showAllServices
                                      ? "收起"
                                      : "展开全部(" +
                                          i.info.order_service.length +
                                          "个)",
                                  ) +
                                  " ",
                              ),
                            ],
                          )
                        : i._e(),
                    ],
                    2,
                  )
                : i._e(),
              a("v-uni-view", { staticClass: "line_box" }),
              a(
                "v-uni-view",
                { staticClass: "msg_box" },
                [
                  i.info.raffle_order > 0
                    ? a(
                        "v-uni-view",
                        { staticClass: "tips flex_box" },
                        [
                          a("v-uni-view", { staticClass: "tit" }, [
                            i._v("订单类型"),
                          ]),
                          a("v-uni-view", { staticClass: "raffle_order" }, [
                            i._v("抽奖商品"),
                          ]),
                        ],
                        1,
                      )
                    : i._e(),
                  a(
                    "v-uni-view",
                    { staticClass: "tips flex_box" },
                    [
                      a("v-uni-view", { staticClass: "tit" }, [i._v("大区")]),
                      a("v-uni-view", [i._v(i._s(i.info.game_area_text))]),
                    ],
                    1,
                  ),
                  i.info.num_id
                    ? a(
                        "v-uni-view",
                        {
                          staticClass: "tips flex_box",
                          on: {
                            click: function (e) {
                              (arguments[0] = e = i.$handleEvent(e)),
                                i.copyOrderNum(i.info.num_id);
                            },
                          },
                        },
                        [
                          a("v-uni-view", { staticClass: "tit" }, [
                            i._v("数字编号"),
                          ]),
                          a(
                            "v-uni-view",
                            [
                              i._v(" " + i._s(i.info.num_id) + " "),
                              a("v-uni-text", { staticClass: "copy_btn" }, [
                                i._v("复制"),
                              ]),
                            ],
                            1,
                          ),
                        ],
                        1,
                      )
                    : i._e(),
                  "" != i.info.text_id
                    ? a(
                        "v-uni-view",
                        {
                          staticClass: "tips flex_box",
                          on: {
                            click: function (e) {
                              (arguments[0] = e = i.$handleEvent(e)),
                                i.copyOrderNum(i.info.text_id);
                            },
                          },
                        },
                        [
                          a("v-uni-view", { staticClass: "tit" }, [
                            i._v("文字ID"),
                          ]),
                          a(
                            "v-uni-view",
                            [
                              i._v(" " + i._s(i.info.text_id) + " "),
                              a("v-uni-text", { staticClass: "copy_btn" }, [
                                i._v("复制"),
                              ]),
                            ],
                            1,
                          ),
                        ],
                        1,
                      )
                    : i._e(),
                  null != i.info.seller
                    ? a(
                        "v-uni-view",
                        { staticClass: "tips flex_box" },
                        [
                          a("v-uni-view", { staticClass: "tit" }, [
                            i._v("打手昵称"),
                          ]),
                          a("v-uni-view", [i._v(i._s(i.info.seller.nickname))]),
                        ],
                        1,
                      )
                    : i._e(),
                  null != i.info.seller && null != i.info.seller.mobile
                    ? a(
                        "v-uni-view",
                        {
                          staticClass: "tips flex_box",
                          on: {
                            click: function (e) {
                              (arguments[0] = e = i.$handleEvent(e)),
                                i.callPhone(i.info.seller.mobile);
                            },
                          },
                        },
                        [
                          a("v-uni-view", { staticClass: "tit" }, [
                            i._v("手机号"),
                          ]),
                          a(
                            "v-uni-view",
                            [
                              i._v(" " + i._s(i.info.seller.mobile) + " "),
                              a("v-uni-text", { staticClass: "copy_btn" }, [
                                i._v("拨打电话"),
                              ]),
                            ],
                            1,
                          ),
                        ],
                        1,
                      )
                    : i._e(),
                  a(
                    "v-uni-view",
                    { staticClass: "tips flex_box" },
                    [
                      a("v-uni-view", { staticClass: "tit" }, [
                        i._v("支付方式"),
                      ]),
                      a("v-uni-view", [i._v(i._s(i.info.pay_type_text))]),
                    ],
                    1,
                  ),
                  a(
                    "v-uni-view",
                    { staticClass: "tips flex_box" },
                    [
                      a("v-uni-view", { staticClass: "tit" }, [
                        i._v("订单备注"),
                      ]),
                      a("v-uni-view", { staticClass: "remark uv-line-3" }, [
                        i._v(i._s(i.info.remark ? i.info.remark : "无")),
                      ]),
                    ],
                    1,
                  ),
                  a(
                    "v-uni-view",
                    { staticClass: "tips flex_box" },
                    [
                      a("v-uni-view", { staticClass: "tit" }, [
                        i._v("下单时间"),
                      ]),
                      a("v-uni-view", [
                        i._v(i._s(i.info.add_time ? i.info.add_time : "-")),
                      ]),
                    ],
                    1,
                  ),
                  a(
                    "v-uni-view",
                    { staticClass: "tips flex_box" },
                    [
                      a("v-uni-view", { staticClass: "tit" }, [
                        i._v("付款时间"),
                      ]),
                      a("v-uni-view", [
                        i._v(i._s(i.info.pay_time ? i.info.pay_time : "-")),
                      ]),
                    ],
                    1,
                  ),
                  a(
                    "v-uni-view",
                    { staticClass: "tips flex_box" },
                    [
                      a("v-uni-view", { staticClass: "tit" }, [
                        i._v("接单时间"),
                      ]),
                      a("v-uni-view", [
                        i._v(i._s(i.info.start_time ? i.info.start_time : "-")),
                      ]),
                    ],
                    1,
                  ),
                  a(
                    "v-uni-view",
                    { staticClass: "tips flex_box" },
                    [
                      a("v-uni-view", { staticClass: "tit" }, [
                        i._v("完成时间"),
                      ]),
                      a("v-uni-view", [
                        i._v(i._s(i.info.end_time ? i.info.end_time : "-")),
                      ]),
                    ],
                    1,
                  ),
                  i.info.cancel_time
                    ? a(
                        "v-uni-view",
                        { staticClass: "tips flex_box" },
                        [
                          a("v-uni-view", { staticClass: "tit" }, [
                            i._v("取消时间"),
                          ]),
                          a("v-uni-view", [
                            i._v(
                              i._s(
                                i.info.cancel_time ? i.info.cancel_time : "-",
                              ),
                            ),
                          ]),
                        ],
                        1,
                      )
                    : i._e(),
                  i.info.cancel_time && "" != i.info.cancel_reason
                    ? a(
                        "v-uni-view",
                        { staticClass: "tips flex_box" },
                        [
                          a("v-uni-view", { staticClass: "tit" }, [
                            i._v("取消原因"),
                          ]),
                          a("v-uni-view", [
                            i._v(
                              i._s(
                                i.info.cancel_reason
                                  ? i.info.cancel_reason
                                  : "-",
                              ),
                            ),
                          ]),
                        ],
                        1,
                      )
                    : i._e(),
                  i.member.length
                    ? a(
                        "v-uni-view",
                        { staticClass: "service_member_card" },
                        [
                          a("v-uni-view", { staticClass: "tip_box" }),
                          a(
                            "v-uni-view",
                            { staticClass: "card_box" },
                            [
                              a(
                                "v-uni-view",
                                { staticClass: "card_title flex_box" },
                                [
                                  a("img", {
                                    attrs: { src: t("385b"), alt: "" },
                                  }),
                                  a("v-uni-view", { staticClass: "title" }, [
                                    i._v("服务成员"),
                                  ]),
                                ],
                                1,
                              ),
                              a(
                                "v-uni-view",
                                { staticClass: "card_main" },
                                [
                                  a(
                                    "v-uni-view",
                                    { staticClass: "worker_list" },
                                    i._l(i.member, function (e, t) {
                                      return a(
                                        "v-uni-view",
                                        {
                                          key: t,
                                          staticClass: "worker flex_box",
                                          attrs: { text: e },
                                        },
                                        [
                                          1 == e.status
                                            ? a(
                                                "v-uni-view",
                                                {
                                                  staticClass:
                                                    "worker_msg flex_box",
                                                },
                                                [
                                                  a("img", {
                                                    staticClass: "head",
                                                    attrs: { src: e.avatar },
                                                  }),
                                                  a(
                                                    "v-uni-view",
                                                    {
                                                      staticClass:
                                                        "nickname_box",
                                                    },
                                                    [
                                                      a(
                                                        "v-uni-view",
                                                        {
                                                          staticClass:
                                                            "nickname",
                                                        },
                                                        [
                                                          i._v(
                                                            i._s(e.nickname),
                                                          ),
                                                        ],
                                                      ),
                                                      a(
                                                        "v-uni-view",
                                                        { staticClass: "id" },
                                                        [
                                                          i._v(
                                                            "ID: " +
                                                              i._s(
                                                                e.share_code,
                                                              ),
                                                          ),
                                                        ],
                                                      ),
                                                    ],
                                                    1,
                                                  ),
                                                ],
                                                1,
                                              )
                                            : i._e(),
                                          1 != i.kefu.show_contact_button ||
                                          1 != e.type ||
                                          [0, 1, 4, 6, 7].includes(
                                            i.info.status,
                                          )
                                            ? i._e()
                                            : a(
                                                "v-uni-view",
                                                {
                                                  staticClass: "choose_btn",
                                                  on: {
                                                    click: function (t) {
                                                      (arguments[0] = t =
                                                        i.$handleEvent(t)),
                                                        i.matchSeller1(
                                                          i.info.id,
                                                          e.id,
                                                        );
                                                    },
                                                  },
                                                },
                                                [i._v("聊天")],
                                              ),
                                        ],
                                        1,
                                      );
                                    }),
                                    1,
                                  ),
                                ],
                                1,
                              ),
                            ],
                            1,
                          ),
                        ],
                        1,
                      )
                    : i._e(),
                ],
                1,
              ),
              2 == i.info.status && 3 == i.info.status
                ? a("uv-divider", {
                    staticClass: "block_title",
                    attrs: { text: "打手已确认接单", textSize: "13" },
                  })
                : i._e(),
              2 == i.info.status && 3 == i.info.status
                ? a(
                    "v-uni-view",
                    { staticClass: "reason_box flex_box" },
                    [
                      a("v-uni-view", { staticClass: "tit" }, [
                        i._v("温馨提示:"),
                      ]),
                      a("v-uni-view", { staticClass: "txt" }, [
                        i._v("打手已上线, 请及时上号等待通过好友申请"),
                      ]),
                    ],
                    1,
                  )
                : i._e(),
              a(
                "v-uni-view",
                { staticClass: "cash_box flex_box" },
                [
                  a(
                    "v-uni-view",
                    { staticClass: "total_box flex_box" },
                    [
                      a("v-uni-view", { staticClass: "tit" }, [i._v("合计:")]),
                      a(
                        "v-uni-view",
                        { staticClass: "price" },
                        [
                          a("v-uni-text", { staticClass: "unit" }, [
                            i._v("￥"),
                          ]),
                          a("v-uni-text", [i._v(i._s(i.info.money))]),
                        ],
                        1,
                      ),
                    ],
                    1,
                  ),
                  a(
                    "v-uni-view",
                    { staticClass: "btn_box flex_box" },
                    [
                      3 == i.info.status
                        ? a(
                            "v-uni-view",
                            {
                              on: {
                                click: function (e) {
                                  (arguments[0] = e = i.$handleEvent(e)),
                                    i.endOrder.apply(void 0, arguments);
                                },
                              },
                            },
                            [i._v("确认结单")],
                          )
                        : i._e(),
                      1 == i.info.status && 0 == i.info.raffle_order
                        ? a(
                            "v-uni-view",
                            {
                              on: {
                                click: function (e) {
                                  (arguments[0] = e = i.$handleEvent(e)),
                                    i.cancleOrder.apply(void 0, arguments);
                                },
                              },
                            },
                            [i._v("取消订单")],
                          )
                        : i._e(),
                      0 == i.info.status
                        ? a(
                            "v-uni-view",
                            {
                              on: {
                                click: function (e) {
                                  (arguments[0] = e = i.$handleEvent(e)),
                                    i.jump(
                                      "/pages/pay/index?type=5&id=" + i.info.id,
                                    );
                                },
                              },
                            },
                            [i._v("去付款")],
                          )
                        : i._e(),
                      4 == i.info.status && 0 == i.info.comment
                        ? a(
                            "v-uni-view",
                            {
                              on: {
                                click: function (e) {
                                  (arguments[0] = e = i.$handleEvent(e)),
                                    i.jump(
                                      "/pages_sub1/order/comment?id=" +
                                        i.info.id,
                                    );
                                },
                              },
                            },
                            [i._v(" 发表评价")],
                          )
                        : i._e(),
                      1 == i.info.service_status
                        ? a(
                            "v-uni-view",
                            {
                              on: {
                                click: function (e) {
                                  (arguments[0] = e = i.$handleEvent(e)),
                                    i.jump(
                                      "/pages_sub1/order/service?id=" +
                                        i.info.id,
                                    );
                                },
                              },
                            },
                            [
                              i._v(
                                " " +
                                  i._s(
                                    0 == i.info.after_sale
                                      ? "申请售后"
                                      : "售后详情",
                                  ) +
                                  " ",
                              ),
                            ],
                          )
                        : i._e(),
                      4 == i.info.status
                        ? a(
                            "v-uni-view",
                            {
                              on: {
                                click: function (e) {
                                  (arguments[0] = e = i.$handleEvent(e)),
                                    i.openAgainShow.apply(void 0, arguments);
                                },
                              },
                            },
                            [i._v("续单")],
                          )
                        : i._e(),
                    ],
                    1,
                  ),
                ],
                1,
              ),
              a(
                "uv-popup",
                { ref: "banShow", attrs: { mode: "center", bgColor: "none" } },
                [
                  a(
                    "v-uni-view",
                    { staticClass: "banShow" },
                    [
                      a("v-uni-view", { staticClass: "tit" }, [
                        i._v("温馨提示"),
                      ]),
                      a("v-uni-view", { staticClass: "prompt red" }, [
                        i._v(
                          "当前订单还有" +
                            i._s(i.info.seconds) +
                            "分钟才可以取消",
                        ),
                      ]),
                      a("v-uni-view", { staticClass: "prompt" }, [
                        i._v("请耐心等待打手接单哦！如有问题请联系客服"),
                      ]),
                      a(
                        "v-uni-view",
                        {
                          staticClass: "btn",
                          on: {
                            click: function (e) {
                              (arguments[0] = e = i.$handleEvent(e)),
                                i.closeBanShow.apply(void 0, arguments);
                            },
                          },
                        },
                        [i._v("确定")],
                      ),
                    ],
                    1,
                  ),
                ],
                1,
              ),
              a(
                "uv-popup",
                {
                  ref: "againShow",
                  attrs: { mode: "center", bgColor: "none" },
                },
                [
                  a(
                    "v-uni-view",
                    { staticClass: "againShow" },
                    [
                      a("v-uni-view", { staticClass: "title" }, [
                        i._v("再次购买 - 选择打手安排方式"),
                      ]),
                      a(
                        "v-uni-view",
                        { staticClass: "type_list" },
                        i._l(i.againTypeShowList, function (e, t) {
                          return a(
                            "v-uni-view",
                            {
                              key: t,
                              class: { col: !0, cur: i.againType == e.name },
                              attrs: { label: e.label, name: e.name },
                              on: {
                                click: function (t) {
                                  (arguments[0] = t = i.$handleEvent(t)),
                                    i.selectAgainType(e);
                                },
                              },
                            },
                            [
                              a("v-uni-view", { staticClass: "tit" }, [
                                i._v(i._s(e.label)),
                              ]),
                              a(
                                "v-uni-view",
                                { staticClass: "circle" },
                                [
                                  i.againType == e.name
                                    ? a("uv-icon", {
                                        attrs: {
                                          name: "checkbox-mark",
                                          color: "#2979ff",
                                          size: "16",
                                        },
                                      })
                                    : i._e(),
                                ],
                                1,
                              ),
                            ],
                            1,
                          );
                        }),
                        1,
                      ),
                      a(
                        "v-uni-view",
                        { staticClass: "btn_box flex_box" },
                        [
                          a(
                            "v-uni-view",
                            {
                              staticClass: "cancle",
                              on: {
                                click: function (e) {
                                  (arguments[0] = e = i.$handleEvent(e)),
                                    i.closeAgainShow.apply(void 0, arguments);
                                },
                              },
                            },
                            [i._v("取消")],
                          ),
                          a(
                            "v-uni-view",
                            {
                              on: {
                                click: function (e) {
                                  (arguments[0] = e = i.$handleEvent(e)),
                                    i.subAgainOrder.apply(void 0, arguments);
                                },
                              },
                            },
                            [i._v("确认")],
                          ),
                        ],
                        1,
                      ),
                    ],
                    1,
                  ),
                ],
                1,
              ),
            ],
            1,
          );
        },
        s = [];
    },
    c9ec: function (i, e, t) {
      var a = t("1ca1");
      a.__esModule && (a = a.default),
        "string" === typeof a && (a = [[i.i, a, ""]]),
        a.locals && (i.exports = a.locals);
      var n = t("967d").default;
      n("087f1d9b", a, !0, { sourceMap: !1, shadowMode: !1 });
    },
    caf4: function (i, e, t) {
      "use strict";
      t("6a54");
      var a = t("f5bd").default;
      Object.defineProperty(e, "__esModule", { value: !0 }),
        (e.default = void 0),
        t("64aa");
      var n,
        s,
        o = a(t("9b1b")),
        r = {
          props: (0, o.default)(
            {
              dashed: { type: Boolean, default: !1 },
              hairline: { type: Boolean, default: !0 },
              dot: { type: Boolean, default: !1 },
              textPosition: { type: String, default: "center" },
              text: { type: [String, Number], default: "" },
              textSize: { type: [String, Number], default: 14 },
              textColor: { type: String, default: "#909399" },
              lineColor: { type: String, default: "#dcdfe6" },
            },
            null === (n = uni.$uv) ||
              void 0 === n ||
              null === (s = n.props) ||
              void 0 === s
              ? void 0
              : s.divider,
          ),
        };
      e.default = r;
    },
    e189: function (i, e, t) {
      "use strict";
      t.r(e);
      var a = t("f6a5"),
        n = t.n(a);
      for (var s in a)
        ["default"].indexOf(s) < 0 &&
          (function (i) {
            t.d(e, i, function () {
              return a[i];
            });
          })(s);
      e["default"] = n.a;
    },
    f6a5: function (i, e, t) {
      "use strict";
      t("6a54");
      var a = t("f5bd").default;
      Object.defineProperty(e, "__esModule", { value: !0 }),
        (e.default = void 0);
      var n = a(t("39d8"));
      t("8f71"), t("bf0f"), t("0c26");
      var s,
        o = t("e74a"),
        r = t("a5ed5"),
        c = {
          data: function () {
            return {
              id: 0,
              info: { seller: {}, prizes: [] },
              againTypeList: [
                { name: 1, label: "自动安排打手" },
                { name: 2, label: "继续安排当前订单打手" },
              ],
              againType: 1,
              intervalId: null,
              member: [],
              kefu: [],
              showAllPrizes: !1,
              showAllServices: !1,
            };
          },
          onLoad: function (i) {
            this.id = i.id;
            var e = this;
            clearInterval(this.intervalId),
              (this.intervalId = null),
              (this.intervalId = setInterval(function () {
                e.getOrderInfo(0);
              }, 6e3));
          },
          onShow: function () {
            this.getOrderInfo();
          },
          onUnload: function () {
            clearInterval(this.intervalId),
              (this.intervalId = null),
              console.log("清除定时器");
          },
          onPullDownRefresh: function () {
            var i = this;
            uni.showLoading({ title: "刷新中" }),
              setTimeout(function () {
                uni.hideLoading(),
                  i.getOrderInfo(),
                  uni.showToast({ title: "刷新成功", duration: 1e3 }),
                  uni.stopPullDownRefresh();
              }, 300);
          },
          mounted: function () {},
          computed: {
            againTypeShowList: function () {
              return this.info.raffle_order
                ? this.againTypeList.filter(function (i) {
                    return 1 == i.name;
                  })
                : this.againTypeList;
            },
          },
          methods:
            ((s = {
              subAgainOrder: function () {
                var i = this;
                return (
                  !!this.info.goods_id &&
                  (this.againType
                    ? this.info.raffle_order
                      ? this.info.raffle_id
                        ? (uni.navigateTo({
                            url: "/pages/pay/raffle?id=" + this.info.raffle_id,
                          }),
                          void this.closeAgainShow())
                        : uni.$uv.toast("转盘信息错误")
                      : this.info.seller_id
                        ? void (1 == this.againType
                            ? (uni.navigateTo({
                                url:
                                  "/pages/pay/submit?id=" + this.info.goods_id,
                              }),
                              this.closeAgainShow())
                            : (0, o.send)(
                                "/wechat/Seller/getSellerOnlineStatus",
                                { id: this.info.seller_id },
                                !1,
                              ).then(function (e) {
                                e.status, e.msg, e.data;
                                uni.navigateTo({
                                  url:
                                    "/pages/pay/submit?id=" +
                                    i.info.goods_id +
                                    "&&seller_id=" +
                                    i.info.seller_id,
                                }),
                                  i.closeAgainShow();
                              }))
                        : uni.$uv.toast("打手信息错误")
                    : uni.$uv.toast("请选择打手安排方式"))
                );
              },
              selectAgainType: function (i) {
                this.againType = i.name;
              },
              openAgainShow: function () {
                this.info.raffle_order &&
                1 == this.info.order_type &&
                this.info.raffle_id
                  ? (0, r.goRaffle)(this.info.raffle_id)
                  : this.$refs.againShow.open();
              },
              closeAgainShow: function () {
                this.$refs.againShow.close();
              },
              previewImage: function (i, e) {
                uni.previewImage({ current: i, urls: e });
              },
              copyOrderNum: function (i) {
                uni.setClipboardData({
                  data: i.trim(),
                  success: function () {
                    uni.$uv.toast("复制成功");
                  },
                  fail: function () {
                    uni.$uv.toast("复制失败");
                  },
                });
              },
              getOrderInfo: function () {
                var i = this,
                  e =
                    arguments.length > 0 && void 0 !== arguments[0]
                      ? arguments[0]
                      : 1;
                1 == e && uni.showLoading({ title: "加载中.." }),
                  (0, o.send)(
                    "/wechat/Order/getOrderInfo",
                    { id: this.id },
                    !1,
                  ).then(function (e) {
                    uni.hideLoading();
                    var t = e.status,
                      a = e.msg,
                      n = e.data;
                    if (1 != t) return uni.$uv.toast(a);
                    (i.info = n),
                      (i.member = n.member.member || []),
                      (i.kefu = n.kefu),
                      1 == i.info.ios_vitural_pay_alert &&
                        i.showIosVituralAlert(i.info.ios_vitural_pay_tips);
                  });
              },
              jump: function (i) {
                clearInterval(this.intervalId),
                  (this.intervalId = null),
                  uni.navigateTo({ url: i });
              },
              cancleOrder: function () {
                var i = this;
                this.info.seconds > 0
                  ? this.$refs.banShow.open()
                  : uni.showModal({
                      title: "请输入取消原因",
                      content: "",
                      editable: !0,
                      success: function (e) {
                        if ((console.log(e), e.confirm)) {
                          if ("" == e.content)
                            return uni.$uv.toast("取消原因不能为空");
                          i.subCancel(e.content);
                        }
                      },
                    });
              },
              closeBanShow: function () {
                this.$refs.banShow.close();
              },
              subCancel: function (i) {
                var e = this;
                uni.showLoading({ title: "加载中.." }),
                  (0, o.send)(
                    "/wechat/Order/userCancleOrder",
                    { id: this.id, cancel_reason: i },
                    !1,
                  ).then(function (i) {
                    uni.hideLoading();
                    var t = i.status,
                      a = i.msg;
                    i.data;
                    if ((2 == t && e.showIosVituralAlert(a), 1 != t))
                      return uni.$uv.toast(a);
                    uni.$uv.toast(a), e.getOrderInfo();
                  });
              },
              showIosVituralAlert: function (i) {
                var e = this;
                uni.showModal({
                  title: "温馨提示",
                  content: i,
                  showCancel: !1,
                  confirmText: "不再提示",
                  success: function (i) {
                    i.confirm &&
                      (0, o.send)(
                        "/wechat/Order/changeIosVituralPayAlert",
                        { id: e.id },
                        !1,
                      ).then(function (i) {
                        uni.hideLoading();
                        var e = i.status,
                          t = i.msg;
                        i.data;
                        if (1 != e) return uni.$uv.toast(t);
                      });
                  },
                });
              },
              endOrder: function () {
                var i = this;
                uni.showModal({
                  title: "温馨提示",
                  content: "请确认打手已经服务完成!!",
                  success: function (e) {
                    e.confirm &&
                      (uni.showLoading({ title: "加载中.." }),
                      (0, o.send)(
                        "/wechat/Order/endOrder",
                        { id: i.id },
                        !1,
                      ).then(function (e) {
                        uni.hideLoading();
                        var t = e.status,
                          a = e.msg;
                        e.data;
                        if (1 != t) return uni.$uv.toast(a);
                        uni.$uv.toast(a),
                          setTimeout(function () {
                            i.getOrderInfo();
                          }, 1500);
                      }));
                  },
                });
              },
              callPhone: function (i) {
                uni.makePhoneCall({
                  phoneNumber: i,
                  success: function () {
                    console.log("拨打电话成功");
                  },
                  fail: function (i) {
                    console.error("拨打电话失败", i);
                  },
                });
              },
            }),
            (0, n.default)(s, "previewImage", function (i, e) {
              uni.previewImage({ current: i, urls: e });
            }),
            (0, n.default)(s, "matchSeller1", function () {
              uni.$uv.throttle(this.matchSeller1Handle, 1500);
            }),
            (0, n.default)(s, "matchSeller1Handle", function () {
              var i = this;
              uni.showLoading({ title: "加载中.." }),
                (0, o.send)(
                  "/wechat/Chat/matchSeller1",
                  { order_id: this.id },
                  !1,
                ).then(function (e) {
                  uni.hideLoading();
                  var t = e.status,
                    a = e.msg,
                    n = e.data;
                  if (1 != t) return uni.$uv.toast(a);
                  i.jump("/pages_sub1/chat/info?id=" + n.chat_id);
                });
            }),
            s),
        };
      e.default = c;
    },
  },
]);
//# sourceMappingURL=pages_sub1-order-info.128e7b64.js.map
