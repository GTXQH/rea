(window["webpackJsonp"] = window["webpackJsonp"] || []).push([
  ["pages_sub1-seller-notice"],
  {
    "2e78": function (t, i, e) {
      "use strict";
      e.r(i);
      var n = e("f877"),
        a = e("6ae6");
      for (var s in a)
        ["default"].indexOf(s) < 0 &&
          (function (t) {
            e.d(i, t, function () {
              return a[t];
            });
          })(s);
      e("644a");
      var o = e("828b"),
        c = Object(o["a"])(
          a["default"],
          n["b"],
          n["c"],
          !1,
          null,
          "532db61c",
          null,
          !1,
          n["a"],
          void 0,
        );
      i["default"] = c.exports;
    },
    "3be2": function (t, i, e) {
      "use strict";
      e("6a54"),
        Object.defineProperty(i, "__esModule", { value: !0 }),
        (i.default = void 0),
        e("c223");
      var n = e("e74a"),
        a = {
          data: function () {
            return {
              currentTab: 0,
              list: [],
              page: 1,
              limit: 20,
              noMore: !1,
              isAnimating: !1,
            };
          },
          onLoad: function () {
            this.getList();
          },
          onShow: function () {
            this.getList();
          },
          onPullDownRefresh: function () {
            uni.showLoading({ title: "刷新中" }),
              (this.page = 1),
              (this.noMore = !1),
              this.getList(),
              setTimeout(function () {
                uni.hideLoading(), uni.stopPullDownRefresh();
              }, 500);
          },
          onReachBottom: function () {
            this.noMore || (this.page++, this.loadMore());
          },
          methods: {
            switchTab: function (t) {
              var i = this;
              this.currentTab !== t &&
                ((this.isAnimating = !0),
                (this.currentTab = t),
                (this.page = 1),
                (this.noMore = !1),
                (this.list = []),
                setTimeout(function () {
                  i.getList();
                }, 150));
            },
            getList: function () {
              var t = this;
              uni.showLoading({ title: "加载中.." }),
                (0, n.send)(
                  "/wechat/SellerNotice/getNoticeList",
                  { type: this.currentTab, page: 1, limit: this.limit },
                  !1,
                ).then(function (i) {
                  uni.hideLoading();
                  var e = i.status,
                    n = i.msg,
                    a = i.data;
                  if (1 != e) return (t.isAnimating = !1), uni.$uv.toast(n);
                  (t.list = a.list || []),
                    t.list.length < t.limit && (t.noMore = !0),
                    (t.isAnimating = !1);
                });
            },
            loadMore: function () {
              var t = this;
              (0, n.send)(
                "/wechat/SellerNotice/getNoticeList",
                { type: this.currentTab, page: this.page, limit: this.limit },
                !1,
              ).then(function (i) {
                var e = i.status,
                  n = i.msg,
                  a = i.data;
                if (1 != e) return uni.$uv.toast(n);
                var s = a.list || [];
                s.length > 0 && (t.list = t.list.concat(s)),
                  s.length < t.limit && (t.noMore = !0);
              });
            },
            goDetail: function (t) {
              uni.navigateTo({
                url: "/pages_sub1/seller/notice_detail?id=" + t.id,
              });
            },
          },
        };
      i.default = a;
    },
    "644a": function (t, i, e) {
      "use strict";
      var n = e("b36c"),
        a = e.n(n);
      a.a;
    },
    "6ae6": function (t, i, e) {
      "use strict";
      e.r(i);
      var n = e("3be2"),
        a = e.n(n);
      for (var s in n)
        ["default"].indexOf(s) < 0 &&
          (function (t) {
            e.d(i, t, function () {
              return n[t];
            });
          })(s);
      i["default"] = a.a;
    },
    "731d": function (t, i, e) {
      var n = e("c86c");
      (i = n(!1)),
        i.push([
          t.i,
          '@charset "UTF-8";\r\n/**\r\n * 这里是uni-app内置的常用样式变量\r\n *\r\n * uni-app 官方扩展插件及插件市场（https://ext.dcloud.net.cn）上很多三方插件均使用了这些样式变量\r\n * 如果你是插件开发者，建议你使用scss预处理，并在插件代码中直接使用这些变量（无需 import 这个文件），方便用户通过搭积木的方式开发整体风格一致的App\r\n *\r\n */\r\n/**\r\n * 如果你是App开发者（插件使用者），你可以通过修改这些变量来定制自己的插件主题，实现自定义主题功能\r\n *\r\n * 如果你的项目同样使用了scss预处理，你也可以直接在你的 scss 代码中使用如下变量，同时无需 import 这个文件\r\n */\r\n/* 颜色变量 */\r\n/* 行为相关颜色 */\r\n/* 文字基本颜色 */\r\n/* 背景颜色 */\r\n/* 边框颜色 */\r\n/* 尺寸变量 */\r\n/* 文字尺寸 */\r\n/* 图片尺寸 */\r\n/* Border Radius */\r\n/* 水平间距 */\r\n/* 垂直间距 */\r\n/* 透明度 */\r\n/* 文章场景相关 */.content[data-v-532db61c]{min-height:100vh;background:#f5f5f5}.tab_bar[data-v-532db61c]{display:flex;background:#fff;position:-webkit-sticky;position:sticky;top:0;z-index:10}.tab_bar .tab_item[data-v-532db61c]{flex:1;text-align:center;padding:%?30?% 0;font-size:%?30?%;color:#666;position:relative}.tab_bar .tab_item.active[data-v-532db61c]{color:#000;font-weight:700}.tab_bar .tab_item.active[data-v-532db61c]::after{content:"";position:absolute;bottom:0;left:50%;-webkit-transform:translateX(-50%);transform:translateX(-50%);width:%?60?%;height:%?6?%;background:#ffe610;border-radius:%?3?%}.notice_list[data-v-532db61c]{padding:%?20?%;transition:opacity .25s ease}.notice_list.animating[data-v-532db61c]{opacity:.3}.notice_item[data-v-532db61c]{display:flex;align-items:center;background:#fff;border-radius:%?16?%;padding:%?30?% %?24?%;margin-bottom:%?20?%}.notice_item .item_left[data-v-532db61c]{width:%?20?%;margin-right:%?20?%}.notice_item .item_left .dot[data-v-532db61c]{width:%?16?%;height:%?16?%;background:#fd2c28;border-radius:50%}.notice_item .item_center[data-v-532db61c]{flex:1;overflow:hidden}.notice_item .item_center .title[data-v-532db61c]{display:flex;align-items:center;margin-bottom:%?12?%}.notice_item .item_center .title .title_text[data-v-532db61c]{flex:1;font-size:%?30?%;font-weight:700;color:#333}.notice_item .item_center .title .force_tag[data-v-532db61c]{flex-shrink:0;background:#fd2c28;color:#fff;font-size:%?20?%;padding:%?4?% %?12?%;border-radius:%?6?%;margin-left:%?16?%}.notice_item .item_center .time[data-v-532db61c]{font-size:%?24?%;color:#999}.notice_item .item_right .arrow[data-v-532db61c]{font-size:%?40?%;color:#ccc}.empty_box[data-v-532db61c]{padding-top:%?200?%;text-align:center;transition:opacity .25s ease}.empty_box.animating[data-v-532db61c]{opacity:.3}.empty_box .empty_text[data-v-532db61c]{font-size:%?28?%;color:#999}',
          "",
        ]),
        (t.exports = i);
    },
    b36c: function (t, i, e) {
      var n = e("731d");
      n.__esModule && (n = n.default),
        "string" === typeof n && (n = [[t.i, n, ""]]),
        n.locals && (t.exports = n.locals);
      var a = e("967d").default;
      a("1af098d2", n, !0, { sourceMap: !1, shadowMode: !1 });
    },
    f877: function (t, i, e) {
      "use strict";
      e.d(i, "b", function () {
        return n;
      }),
        e.d(i, "c", function () {
          return a;
        }),
        e.d(i, "a", function () {});
      var n = function () {
          var t = this,
            i = t.$createElement,
            e = t._self._c || i;
          return e(
            "v-uni-view",
            { staticClass: "content" },
            [
              e(
                "v-uni-view",
                { staticClass: "tab_bar" },
                [
                  e(
                    "v-uni-view",
                    {
                      staticClass: "tab_item",
                      class: { active: 0 == t.currentTab },
                      on: {
                        click: function (i) {
                          (arguments[0] = i = t.$handleEvent(i)),
                            t.switchTab(0);
                        },
                      },
                    },
                    [t._v(" 全部 ")],
                  ),
                  e(
                    "v-uni-view",
                    {
                      staticClass: "tab_item",
                      class: { active: 1 == t.currentTab },
                      on: {
                        click: function (i) {
                          (arguments[0] = i = t.$handleEvent(i)),
                            t.switchTab(1);
                        },
                      },
                    },
                    [t._v(" 未读 ")],
                  ),
                  e(
                    "v-uni-view",
                    {
                      staticClass: "tab_item",
                      class: { active: 2 == t.currentTab },
                      on: {
                        click: function (i) {
                          (arguments[0] = i = t.$handleEvent(i)),
                            t.switchTab(2);
                        },
                      },
                    },
                    [t._v(" 已读 ")],
                  ),
                ],
                1,
              ),
              t.list.length > 0
                ? e(
                    "v-uni-view",
                    {
                      staticClass: "notice_list",
                      class: { animating: t.isAnimating },
                    },
                    t._l(t.list, function (i, n) {
                      return e(
                        "v-uni-view",
                        {
                          key: n,
                          staticClass: "notice_item",
                          on: {
                            click: function (e) {
                              (arguments[0] = e = t.$handleEvent(e)),
                                t.goDetail(i);
                            },
                          },
                        },
                        [
                          e(
                            "v-uni-view",
                            { staticClass: "item_left" },
                            [
                              0 == i.is_read
                                ? e("v-uni-view", { staticClass: "dot" })
                                : t._e(),
                            ],
                            1,
                          ),
                          e(
                            "v-uni-view",
                            { staticClass: "item_center" },
                            [
                              e(
                                "v-uni-view",
                                { staticClass: "title" },
                                [
                                  e(
                                    "v-uni-text",
                                    { staticClass: "title_text uv-line-1" },
                                    [t._v(t._s(i.title))],
                                  ),
                                  2 == i.type
                                    ? e(
                                        "v-uni-view",
                                        { staticClass: "force_tag" },
                                        [t._v("强制")],
                                      )
                                    : t._e(),
                                ],
                                1,
                              ),
                              e("v-uni-view", { staticClass: "time" }, [
                                t._v(t._s(i.create_time)),
                              ]),
                            ],
                            1,
                          ),
                          e(
                            "v-uni-view",
                            { staticClass: "item_right" },
                            [
                              e("v-uni-text", { staticClass: "arrow" }, [
                                t._v("›"),
                              ]),
                            ],
                            1,
                          ),
                        ],
                        1,
                      );
                    }),
                    1,
                  )
                : e(
                    "v-uni-view",
                    {
                      staticClass: "empty_box",
                      class: { animating: t.isAnimating },
                    },
                    [
                      e("v-uni-view", { staticClass: "empty_text" }, [
                        t._v("暂无通知"),
                      ]),
                    ],
                    1,
                  ),
            ],
            1,
          );
        },
        a = [];
    },
  },
]);
//# sourceMappingURL=pages_sub1-seller-notice.83940c0e.js.map
