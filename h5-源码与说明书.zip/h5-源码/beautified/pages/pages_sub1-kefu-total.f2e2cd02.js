(window["webpackJsonp"] = window["webpackJsonp"] || []).push([
  ["pages_sub1-kefu-total"],
  {
    "0c48": function (t, i, n) {
      "use strict";
      n.r(i);
      var a = n("b209"),
        e = n("6d30");
      for (var s in e)
        ["default"].indexOf(s) < 0 &&
          (function (t) {
            n.d(i, t, function () {
              return e[t];
            });
          })(s);
      n("5a7e");
      var o = n("828b"),
        r = Object(o["a"])(
          e["default"],
          a["b"],
          a["c"],
          !1,
          null,
          "24785b28",
          null,
          !1,
          a["a"],
          void 0,
        );
      i["default"] = r.exports;
    },
    5928: function (t, i, n) {
      "use strict";
      n("6a54");
      var a = n("f5bd").default;
      Object.defineProperty(i, "__esModule", { value: !0 }),
        (i.default = void 0),
        n("aa9c");
      var e = a(n("b7c7")),
        s = n("e74a"),
        o = {
          data: function () {
            return {
              info: [],
              list: [],
              keyword: "",
              type: 1,
              page: 1,
              no_more: 0,
              status: "loading",
              selected: 6,
            };
          },
          computed: {},
          onLoad: function () {
            this.getKefuDateInfo();
          },
          onPullDownRefresh: function () {
            var t = this;
            uni.showLoading({ title: "刷新中" }),
              setTimeout(function () {
                uni.hideLoading(),
                  (t.page = 1),
                  (t.no_more = 0),
                  (t.status = "loading"),
                  t.getKefuDateInfo(),
                  uni.showToast({ title: "刷新成功", duration: 1e3 }),
                  uni.stopPullDownRefresh();
              }, 300);
          },
          onReachBottom: function (t) {
            this.loadMoreFun();
          },
          methods: {
            workOn: function () {
              this.onStatus = 1;
            },
            workOff: function () {
              this.offStatus = 1;
            },
            jump: function (t) {
              uni.navigateTo({ url: t });
            },
            getKefuDateInfo: function () {
              var t = this;
              uni.showLoading({ title: "加载中.." }),
                (0, s.send)(
                  "/wechat/KefuDate/getKefuDateInfo",
                  { page: 1 },
                  !1,
                ).then(function (i) {
                  uni.hideLoading();
                  var n = i.status,
                    a = i.msg,
                    e = i.data;
                  if (1 != n) return uni.$uv.toast(a);
                  (t.info = e.info),
                    (t.list = e.list.list),
                    1 == e.list.no_more &&
                      ((t.status = "nomore"), (t.no_more = e.list.no_more));
                });
            },
            getKefuDateLog: function () {
              var t = this;
              uni.showLoading({ title: "加载中.." }),
                (0, s.send)(
                  "/wechat/KefuDate/getKefuDateLog",
                  { page: this.page },
                  !1,
                  1,
                ).then(function (i) {
                  uni.hideLoading();
                  var n,
                    a = i.status,
                    s = i.msg,
                    o = i.data;
                  if (1 != a) return uni.$uv.toast(s);
                  t.page > 1
                    ? (n = t.list).push.apply(n, (0, e.default)(o.list))
                    : (t.list = o.list);
                  1 == o.no_more &&
                    ((t.status = "nomore"), (t.no_more = o.no_more));
                });
            },
            loadMoreFun: function () {
              0 == this.no_more && (this.page++, this.getKefuDateLog()),
                console.log("到底了");
            },
          },
        };
      i.default = o;
    },
    "5a7e": function (t, i, n) {
      "use strict";
      var a = n("a870"),
        e = n.n(a);
      e.a;
    },
    "6d30": function (t, i, n) {
      "use strict";
      n.r(i);
      var a = n("5928"),
        e = n.n(a);
      for (var s in a)
        ["default"].indexOf(s) < 0 &&
          (function (t) {
            n.d(i, t, function () {
              return a[t];
            });
          })(s);
      i["default"] = e.a;
    },
    a870: function (t, i, n) {
      var a = n("d1db");
      a.__esModule && (a = a.default),
        "string" === typeof a && (a = [[t.i, a, ""]]),
        a.locals && (t.exports = a.locals);
      var e = n("967d").default;
      e("56cf98c9", a, !0, { sourceMap: !1, shadowMode: !1 });
    },
    b209: function (t, i, n) {
      "use strict";
      n.d(i, "b", function () {
        return e;
      }),
        n.d(i, "c", function () {
          return s;
        }),
        n.d(i, "a", function () {
          return a;
        });
      var a = { uvLoadMore: n("bd68").default, uvEmpty: n("caef").default },
        e = function () {
          var t = this,
            i = t.$createElement,
            n = t._self._c || i;
          return n(
            "v-uni-view",
            { staticClass: "content" },
            [
              n(
                "v-uni-view",
                { staticClass: "total_box" },
                [
                  n("v-uni-view", { staticClass: "money" }, [
                    t._v(t._s(t.info.total)),
                  ]),
                  n("v-uni-view", { staticClass: "total" }, [t._v("总单量")]),
                ],
                1,
              ),
              n(
                "v-uni-view",
                { staticClass: "grid_box" },
                [
                  n(
                    "v-uni-view",
                    { staticClass: "grid" },
                    [
                      n("v-uni-view", { staticClass: "order" }, [
                        t._v("今日单量"),
                      ]),
                      n("v-uni-view", { staticClass: "num" }, [
                        t._v(t._s(t.info.day)),
                      ]),
                    ],
                    1,
                  ),
                  n(
                    "v-uni-view",
                    { staticClass: "grid" },
                    [
                      n("v-uni-view", { staticClass: "order" }, [
                        t._v("本周单量"),
                      ]),
                      n("v-uni-view", { staticClass: "num" }, [
                        t._v(t._s(t.info.week)),
                      ]),
                    ],
                    1,
                  ),
                  n(
                    "v-uni-view",
                    { staticClass: "grid" },
                    [
                      n("v-uni-view", { staticClass: "order" }, [
                        t._v("上周单量"),
                      ]),
                      n("v-uni-view", { staticClass: "num" }, [
                        t._v(t._s(t.info.last_week)),
                      ]),
                    ],
                    1,
                  ),
                  n(
                    "v-uni-view",
                    { staticClass: "grid" },
                    [
                      n("v-uni-view", { staticClass: "order" }, [
                        t._v("本月单量"),
                      ]),
                      n("v-uni-view", { staticClass: "num" }, [
                        t._v(t._s(t.info.month)),
                      ]),
                    ],
                    1,
                  ),
                  n(
                    "v-uni-view",
                    { staticClass: "grid" },
                    [
                      n("v-uni-view", { staticClass: "order" }, [
                        t._v("本年单量"),
                      ]),
                      n("v-uni-view", { staticClass: "num" }, [
                        t._v(t._s(t.info.year)),
                      ]),
                    ],
                    1,
                  ),
                ],
                1,
              ),
              t.list.length > 0
                ? n(
                    "v-uni-view",
                    { staticClass: "list_box" },
                    [
                      t._l(t.list, function (i, a) {
                        return n(
                          "v-uni-view",
                          { key: a, staticClass: "item", attrs: { text: i } },
                          [
                            n(
                              "v-uni-view",
                              { staticClass: "reward_box" },
                              [
                                n("v-uni-view", { staticClass: "reward" }, [
                                  t._v("打卡记录"),
                                ]),
                                n("v-uni-view", { staticClass: "time" }, [
                                  t._v(t._s(i.time_log)),
                                ]),
                              ],
                              1,
                            ),
                            n("v-uni-view", { staticClass: "commission" }, [
                              t._v("+" + t._s(i.order_num)),
                            ]),
                          ],
                          1,
                        );
                      }),
                      t.page > 0
                        ? n("uv-load-more", { attrs: { status: t.status } })
                        : t._e(),
                    ],
                    2,
                  )
                : n("uv-empty", {
                    attrs: {
                      mode: "data",
                      text: "暂无打卡记录",
                      icon: "/static/imgs/no-data.png",
                    },
                  }),
              n("kefu-bar", { attrs: { selected: t.selected } }),
            ],
            1,
          );
        },
        s = [];
    },
    d1db: function (t, i, n) {
      var a = n("c86c");
      (i = a(!1)),
        i.push([
          t.i,
          '@charset "UTF-8";\r\n/**\r\n * 这里是uni-app内置的常用样式变量\r\n *\r\n * uni-app 官方扩展插件及插件市场（https://ext.dcloud.net.cn）上很多三方插件均使用了这些样式变量\r\n * 如果你是插件开发者，建议你使用scss预处理，并在插件代码中直接使用这些变量（无需 import 这个文件），方便用户通过搭积木的方式开发整体风格一致的App\r\n *\r\n */\r\n/**\r\n * 如果你是App开发者（插件使用者），你可以通过修改这些变量来定制自己的插件主题，实现自定义主题功能\r\n *\r\n * 如果你的项目同样使用了scss预处理，你也可以直接在你的 scss 代码中使用如下变量，同时无需 import 这个文件\r\n */\r\n/* 颜色变量 */\r\n/* 行为相关颜色 */\r\n/* 文字基本颜色 */\r\n/* 背景颜色 */\r\n/* 边框颜色 */\r\n/* 尺寸变量 */\r\n/* 文字尺寸 */\r\n/* 图片尺寸 */\r\n/* Border Radius */\r\n/* 水平间距 */\r\n/* 垂直间距 */\r\n/* 透明度 */\r\n/* 文章场景相关 */.total_box[data-v-24785b28]{padding:%?65?% %?20?% %?160?%;text-align:center;background-color:#ffd701}.total_box .money[data-v-24785b28]{font-size:27px;font-weight:700}.total_box .total[data-v-24785b28]{font-size:12px;margin-top:%?6?%}.grid_box[data-v-24785b28]{box-shadow:0 %?2?% %?8?% rgba(0,0,0,.2);border-radius:%?30?%;margin:%?-104?% %?30?% %?40?%;background-color:#fff;display:grid;grid-template-columns:repeat(3,1fr);grid-gap:%?45?% %?20?%;padding:%?45?% %?0?%}.grid_box .grid[data-v-24785b28]{text-align:center}.grid_box .grid .order[data-v-24785b28]{color:#999;font-size:12px;margin-bottom:%?6?%}.grid_box .grid .num[data-v-24785b28]{font-size:18px;font-weight:700}.list_box[data-v-24785b28]{box-shadow:0 %?2?% %?8?% rgba(0,0,0,.2);border-radius:%?30?%;margin:%?40?% %?30?%;padding:0 %?30?%}.list_box .item[data-v-24785b28]{display:flex;align-items:center;justify-content:space-between;margin:%?34?% auto}.list_box .item .reward_box .reward[data-v-24785b28]{font-size:13px;margin-bottom:%?8?%}.list_box .item .reward_box .time[data-v-24785b28]{font-size:12px;color:#999}.list_box .item .commission[data-v-24785b28]{font-size:16px;font-weight:700}.no_more[data-v-24785b28]{margin:%?34?% auto}',
          "",
        ]),
        (t.exports = i);
    },
  },
]);
//# sourceMappingURL=pages_sub1-kefu-total.f2e2cd02.js.map
