(window["webpackJsonp"] = window["webpackJsonp"] || []).push([
  ["pages_sub1-seller-hall"],
  {
    "05c2": function (t, e, i) {
      "use strict";
      i("6a54");
      var n = i("f5bd").default;
      Object.defineProperty(e, "__esModule", { value: !0 }),
        (e.default = void 0),
        i("473f"),
        i("bf0f"),
        i("f7a5"),
        i("5c47"),
        i("0506"),
        i("c223"),
        i("18f7"),
        i("de6c"),
        i("fd3c");
      var a = n(i("5de6")),
        s = n(i("9b1b")),
        r = n(i("2634")),
        o = n(i("2fdc")),
        c = n(i("4d8f0")),
        l = n(i("9463")),
        u = n(i("b92c")),
        d = n(i("7689")),
        v = {
          name: "uv-tabs",
          emits: ["click", "change"],
          mixins: [c.default, l.default, d.default],
          data: function () {
            return {
              firstTime: !0,
              scrollLeft: 0,
              scrollViewWidth: 0,
              lineOffsetLeft: 0,
              tabsRect: { left: 0 },
              innerCurrent: 0,
              moving: !1,
            };
          },
          watch: {
            current: {
              immediate: !0,
              handler: function (t, e) {
                var i = this;
                t !== this.innerCurrent &&
                  ((this.innerCurrent = t),
                  this.$nextTick(function () {
                    i.resize();
                  }));
              },
            },
            list: function () {
              var t = this;
              this.$nextTick(function () {
                t.resize();
              });
            },
          },
          computed: {
            textStyle: function () {
              var t = this;
              return function (e) {
                var i = {},
                  n =
                    e == t.innerCurrent
                      ? t.$uv.addStyle(t.activeStyle)
                      : t.$uv.addStyle(t.inactiveStyle);
                return (
                  t.list[e].disabled && (i.color = "#c8c9cc"),
                  t.$uv.deepMerge(n, i)
                );
              };
            },
            propsBadge: function () {
              return u.default;
            },
          },
          mounted: function () {
            var t = this;
            return (0, o.default)(
              (0, r.default)().mark(function e() {
                return (0, r.default)().wrap(function (e) {
                  while (1)
                    switch ((e.prev = e.next)) {
                      case 0:
                        t.init();
                      case 1:
                      case "end":
                        return e.stop();
                    }
                }, e);
              }),
            )();
          },
          methods: {
            setLineLeft: function () {
              var t = this,
                e = this.list[this.innerCurrent];
              if (e) {
                var i = this.list.slice(0, this.innerCurrent).reduce(function (
                    t,
                    e,
                  ) {
                    return t + e.rect.width;
                  }, 0),
                  n = this.$uv.getPx(this.lineWidth);
                this.$uv.test.number(this.lineWidth) &&
                  this.$uv.unit &&
                  (n = this.$uv.getPx(
                    "".concat(this.lineWidth).concat(this.$uv.unit),
                  )),
                  (this.lineOffsetLeft = i + (e.rect.width - n) / 2),
                  this.firstTime &&
                    setTimeout(function () {
                      t.firstTime = !1;
                    }, 20);
              }
            },
            animation: function (t) {},
            clickHandler: function (t, e) {
              var i = this;
              this.$emit(
                "click",
                (0, s.default)((0, s.default)({}, t), {}, { index: e }),
              ),
                t.disabled ||
                  (this.innerCurrent != e &&
                    this.$emit(
                      "change",
                      (0, s.default)((0, s.default)({}, t), {}, { index: e }),
                    ),
                  (this.innerCurrent = e),
                  this.$nextTick(function () {
                    i.resize();
                  }));
            },
            init: function () {
              var t = this;
              this.$uv.sleep().then(function () {
                t.resize();
              });
            },
            setScrollLeft: function () {
              var t = this.list[this.innerCurrent],
                e = this.list.slice(0, this.innerCurrent).reduce(function (
                  t,
                  e,
                ) {
                  return t + e.rect.width;
                }, 0),
                i = this.$uv.sys().windowWidth,
                n =
                  e -
                  (this.tabsRect.width - t.rect.width) / 2 -
                  (i - this.tabsRect.right) / 2 +
                  this.tabsRect.left / 2;
              (n = Math.min(n, this.scrollViewWidth - this.tabsRect.width)),
                (this.scrollLeft = Math.max(0, n));
            },
            resize: function () {
              var t = this;
              0 !== this.list.length &&
                Promise.all([this.getTabsRect(), this.getAllItemRect()]).then(
                  function (e) {
                    var i = (0, a.default)(e, 2),
                      n = i[0],
                      s = i[1],
                      r = void 0 === s ? [] : s;
                    (t.tabsRect = n),
                      (t.scrollViewWidth = 0),
                      r.map(function (e, i) {
                        (t.scrollViewWidth += e.width), (t.list[i].rect = e);
                      }),
                      t.setLineLeft(),
                      t.setScrollLeft();
                  },
                );
            },
            getTabsRect: function () {
              var t = this;
              return new Promise(function (e) {
                t.queryRect("uv-tabs__wrapper__scroll-view").then(function (t) {
                  return e(t);
                });
              });
            },
            getAllItemRect: function () {
              var t = this;
              return new Promise(function (e) {
                var i = t.list.map(function (e, i) {
                  return t.queryRect(
                    "uv-tabs__wrapper__nav__item-".concat(i),
                    !0,
                  );
                });
                Promise.all(i).then(function (t) {
                  return e(t);
                });
              });
            },
            queryRect: function (t, e) {
              var i = this;
              return new Promise(function (e) {
                i.$uvGetRect(".".concat(t)).then(function (t) {
                  e(t);
                });
              });
            },
          },
        };
      e.default = v;
    },
    2304: function (t, e, i) {
      "use strict";
      i.d(e, "b", function () {
        return a;
      }),
        i.d(e, "c", function () {
          return s;
        }),
        i.d(e, "a", function () {
          return n;
        });
      var n = {
          uvTabs: i("2b48").default,
          uvEmpty: i("caef").default,
          uvLoadMore: i("bd68").default,
          uvIcon: i("1a07").default,
        },
        a = function () {
          var t = this,
            e = t.$createElement,
            i = t._self._c || e;
          return i(
            "v-uni-view",
            { class: { content: !0, more_cat_content: t.moreCat } },
            [
              t.moreCat
                ? i("v-uni-view", {
                    staticClass: "more_cat_mark",
                    on: {
                      click: function (e) {
                        (arguments[0] = e = t.$handleEvent(e)),
                          (t.moreCat = !1);
                      },
                    },
                  })
                : t._e(),
              t.moreCat && t.tabs.length > 0
                ? i(
                    "v-uni-view",
                    {
                      staticClass: "more_cat_box",
                      style: "top:" + t.standHeight + "px;",
                    },
                    t._l(t.tabs, function (e, n) {
                      return i(
                        "v-uni-view",
                        {
                          key: n,
                          class: { item: !0, cur: t.current == n },
                          attrs: { text: e },
                          on: {
                            click: function (i) {
                              (arguments[0] = i = t.$handleEvent(i)),
                                t.selectMoreCat(e);
                            },
                          },
                        },
                        [t._v(t._s(e.name))],
                      );
                    }),
                    1,
                  )
                : t._e(),
              i(
                "v-uni-view",
                {
                  ref: "standHeight",
                  staticClass: "sticky_tabs_box",
                  attrs: { id: "standHeight" },
                },
                [
                  i("uv-tabs", {
                    attrs: {
                      current: t.game_current,
                      list: t.gameTabs,
                      lineColor: "#000",
                      activeStyle: {
                        color: "#000",
                        fontWeight: "bold",
                        transform: "scale(1.02)",
                      },
                      scrollable: !1,
                    },
                    on: {
                      change: function (e) {
                        (arguments[0] = e = t.$handleEvent(e)),
                          t.changeGames.apply(void 0, arguments);
                      },
                    },
                  }),
                  i(
                    "v-uni-view",
                    { staticClass: "area_tabs" },
                    [
                      i("uv-tabs", {
                        attrs: {
                          current: t.current,
                          list: t.area_list,
                          lineColor: "#ffe610",
                          activeStyle: {
                            color: "#000",
                            fontWeight: "bold",
                            transform: "scale(1.02)",
                          },
                          scrollable: !0,
                          itemStyle: { height: "30px" },
                        },
                        on: {
                          change: function (e) {
                            (arguments[0] = e = t.$handleEvent(e)),
                              t.changeTabs.apply(void 0, arguments);
                          },
                        },
                      }),
                    ],
                    1,
                  ),
                ],
                1,
              ),
              t.list.length > 0
                ? i(
                    "v-uni-view",
                    { staticClass: "order_list" },
                    t._l(t.list, function (e, n) {
                      return i(
                        "v-uni-view",
                        { key: n, staticClass: "col", attrs: { text: e } },
                        [
                          i(
                            "v-uni-view",
                            { staticClass: "top_box flex_box" },
                            [
                              i(
                                "v-uni-view",
                                {
                                  staticClass: "order_num flex_box",
                                  on: {
                                    click: function (i) {
                                      (arguments[0] = i = t.$handleEvent(i)),
                                        t.copyOrderNum(e.order_no);
                                    },
                                  },
                                },
                                [
                                  i("v-uni-view", {}, [t._v("订单编号：")]),
                                  i("v-uni-view", { staticClass: "num" }, [
                                    t._v(t._s(e.order_no)),
                                  ]),
                                  i("v-uni-view", { staticClass: "copy_btn" }, [
                                    t._v("复制"),
                                  ]),
                                ],
                                1,
                              ),
                              i("v-uni-view", { staticClass: "status" }, [
                                t._v(t._s(e.status_text)),
                              ]),
                            ],
                            1,
                          ),
                          i(
                            "v-uni-view",
                            {
                              staticClass: "msg_box",
                              on: {
                                click: function (i) {
                                  (arguments[0] = i = t.$handleEvent(i)),
                                    t.jump(
                                      "/pages_sub1/seller/hall_info?id=" + e.id,
                                    );
                                },
                              },
                            },
                            [
                              0 == t.show_goods_des
                                ? i(
                                    "v-uni-view",
                                    { staticClass: "goods_msg flex_box" },
                                    [
                                      i("img", {
                                        staticClass: "img",
                                        attrs: {
                                          src: e.cat3
                                            ? e.cat3.thumb
                                            : e.goods_thumb,
                                        },
                                      }),
                                      i(
                                        "v-uni-view",
                                        { staticClass: "txt" },
                                        [
                                          i(
                                            "v-uni-view",
                                            {
                                              staticClass: "price_box flex_box",
                                            },
                                            [
                                              i("v-uni-view", {
                                                staticClass: "price",
                                              }),
                                            ],
                                            1,
                                          ),
                                          i(
                                            "v-uni-view",
                                            { staticClass: "num" },
                                            [t._v("x " + t._s(e.num))],
                                          ),
                                          i(
                                            "v-uni-view",
                                            { staticClass: "name uv-line-2" },
                                            [
                                              t._v(
                                                t._s(
                                                  e.cat3
                                                    ? e.cat3.name
                                                    : e.raffle_title
                                                      ? e.raffle_title
                                                      : e.goods_name,
                                                ),
                                              ),
                                            ],
                                          ),
                                        ],
                                        1,
                                      ),
                                      e.is_zhiding
                                        ? i(
                                            "v-uni-view",
                                            { staticClass: "zhiding" },
                                            [t._v("指定单")],
                                          )
                                        : t._e(),
                                    ],
                                    1,
                                  )
                                : 0 != e.raffle_order && e.has_prizes
                                  ? i(
                                      "v-uni-view",
                                      { staticClass: "goods_msg flex_box" },
                                      [
                                        i("img", {
                                          staticClass: "img",
                                          attrs: {
                                            src: e.raffle_thumb
                                              ? e.raffle_thumb
                                              : e.goods_thumb,
                                          },
                                        }),
                                        i(
                                          "v-uni-view",
                                          { staticClass: "txt" },
                                          [
                                            i(
                                              "v-uni-view",
                                              {
                                                staticClass:
                                                  "price_box flex_box",
                                              },
                                              [
                                                i(
                                                  "v-uni-view",
                                                  { staticClass: "price" },
                                                  [
                                                    i(
                                                      "v-uni-text",
                                                      { staticClass: "unit" },
                                                      [t._v("￥")],
                                                    ),
                                                    i("v-uni-text", [
                                                      t._v(t._s(e.price)),
                                                    ]),
                                                  ],
                                                  1,
                                                ),
                                                i(
                                                  "v-uni-view",
                                                  { staticClass: "num" },
                                                  [t._v("x " + t._s(e.num))],
                                                ),
                                              ],
                                              1,
                                            ),
                                            i(
                                              "v-uni-view",
                                              { staticClass: "name uv-line-2" },
                                              [t._v(t._s(e.raffle_title))],
                                            ),
                                            i(
                                              "v-uni-view",
                                              {
                                                staticClass: "intro uv-line-2",
                                              },
                                              [t._v(t._s(e.raffle_intro))],
                                            ),
                                          ],
                                          1,
                                        ),
                                        e.is_zhiding
                                          ? i(
                                              "v-uni-view",
                                              { staticClass: "zhiding" },
                                              [t._v("指定单")],
                                            )
                                          : t._e(),
                                      ],
                                      1,
                                    )
                                  : i(
                                      "v-uni-view",
                                      { staticClass: "goods_msg flex_box" },
                                      [
                                        i("img", {
                                          staticClass: "img",
                                          attrs: { src: e.goods_thumb },
                                        }),
                                        i(
                                          "v-uni-view",
                                          { staticClass: "txt" },
                                          [
                                            i(
                                              "v-uni-view",
                                              {
                                                staticClass:
                                                  "price_box flex_box",
                                              },
                                              [
                                                i(
                                                  "v-uni-view",
                                                  { staticClass: "price" },
                                                  [
                                                    i(
                                                      "v-uni-text",
                                                      { staticClass: "unit" },
                                                      [t._v("￥")],
                                                    ),
                                                    i("v-uni-text", [
                                                      t._v(t._s(e.price)),
                                                    ]),
                                                  ],
                                                  1,
                                                ),
                                                i(
                                                  "v-uni-view",
                                                  { staticClass: "num" },
                                                  [t._v("x " + t._s(e.num))],
                                                ),
                                              ],
                                              1,
                                            ),
                                            i(
                                              "v-uni-view",
                                              { staticClass: "name uv-line-2" },
                                              [t._v(t._s(e.goods_name))],
                                            ),
                                            i(
                                              "v-uni-view",
                                              {
                                                staticClass: "intro uv-line-2",
                                              },
                                              [t._v(t._s(e.goods_intro))],
                                            ),
                                          ],
                                          1,
                                        ),
                                        e.is_zhiding
                                          ? i(
                                              "v-uni-view",
                                              { staticClass: "zhiding" },
                                              [t._v("指定单")],
                                            )
                                          : t._e(),
                                      ],
                                      1,
                                    ),
                              i(
                                "v-uni-view",
                                { staticClass: "tips flex_box" },
                                [
                                  i("v-uni-view", { staticClass: "tit" }, [
                                    t._v("大区"),
                                  ]),
                                  i("v-uni-view", [
                                    t._v(t._s(e.game_area_text)),
                                  ]),
                                ],
                                1,
                              ),
                              i(
                                "v-uni-view",
                                { staticClass: "tips flex_box" },
                                [
                                  i("v-uni-view", { staticClass: "tit" }, [
                                    t._v("订单备注"),
                                  ]),
                                  i(
                                    "v-uni-view",
                                    { staticClass: "remark uv-line-1" },
                                    [t._v(t._s(e.remark ? e.remark : "无"))],
                                  ),
                                ],
                                1,
                              ),
                              i(
                                "v-uni-view",
                                { staticClass: "tips flex_box" },
                                [
                                  i("v-uni-view", { staticClass: "tit" }, [
                                    t._v("下单时间"),
                                  ]),
                                  i("v-uni-view", [t._v(t._s(e.time))]),
                                ],
                                1,
                              ),
                              1 == t.show_goods_des
                                ? i(
                                    "v-uni-view",
                                    { staticClass: "tips flex_box" },
                                    [
                                      i("v-uni-view", { staticClass: "tit" }, [
                                        t._v("到手"),
                                      ]),
                                      i(
                                        "v-uni-view",
                                        { staticClass: "real_money" },
                                        [
                                          i(
                                            "v-uni-text",
                                            { staticClass: "unit" },
                                            [t._v("￥")],
                                          ),
                                          t._v(
                                            " " + t._s(e.seller_money) + " ",
                                          ),
                                        ],
                                        1,
                                      ),
                                    ],
                                    1,
                                  )
                                : t._e(),
                            ],
                            1,
                          ),
                          i(
                            "v-uni-view",
                            { staticClass: "btn_box flex_box" },
                            [
                              1 == e.status &&
                              e.seller_id > 0 &&
                              0 == e.is_accept
                                ? i(
                                    "v-uni-view",
                                    {
                                      staticStyle: {
                                        "background-color": "#3c9cff",
                                        color: "#fff",
                                        padding: "0 40rpx",
                                      },
                                      on: {
                                        click: function (i) {
                                          (arguments[0] = i =
                                            t.$handleEvent(i)),
                                            t.confirmOrder(1, e.id);
                                        },
                                      },
                                    },
                                    [t._v(" 接受 ")],
                                  )
                                : t._e(),
                              1 == e.status &&
                              e.seller_id > 0 &&
                              0 == e.is_accept
                                ? i(
                                    "v-uni-view",
                                    {
                                      staticStyle: {
                                        "background-color": "#fd2c28",
                                        color: "#fff",
                                        padding: "0 40rpx",
                                      },
                                      on: {
                                        click: function (i) {
                                          (arguments[0] = i =
                                            t.$handleEvent(i)),
                                            t.confirmOrder(2, e.id);
                                        },
                                      },
                                    },
                                    [t._v(" 拒绝 ")],
                                  )
                                : t._e(),
                              i(
                                "v-uni-view",
                                {
                                  on: {
                                    click: function (i) {
                                      (arguments[0] = i = t.$handleEvent(i)),
                                        t.jump(
                                          "/pages_sub1/seller/hall_info?id=" +
                                            e.id,
                                        );
                                    },
                                  },
                                },
                                [t._v("查看详情")],
                              ),
                            ],
                            1,
                          ),
                        ],
                        1,
                      );
                    }),
                    1,
                  )
                : i("uv-empty", {
                    attrs: {
                      mode: "data",
                      text: "暂无数据",
                      icon: "/static/imgs/no-data.png",
                    },
                  }),
              t.page > 1
                ? i("uv-load-more", { attrs: { status: t.loadTips } })
                : t._e(),
              i(
                "v-uni-view",
                {
                  staticClass: "stop_refresh flex_box",
                  on: {
                    click: function (e) {
                      (arguments[0] = e = t.$handleEvent(e)),
                        t.toggleStopRefresh.apply(void 0, arguments);
                    },
                  },
                },
                [
                  t.stopRefresh
                    ? i("uv-icon", {
                        attrs: {
                          name: "play-right-fill",
                          color: "#000",
                          size: "22",
                        },
                      })
                    : i("uv-icon", {
                        attrs: { name: "pause", color: "#000", size: "22" },
                      }),
                ],
                1,
              ),
            ],
            1,
          );
        },
        s = [];
    },
    "28f5": function (t, e, i) {
      "use strict";
      i.d(e, "b", function () {
        return a;
      }),
        i.d(e, "c", function () {
          return s;
        }),
        i.d(e, "a", function () {
          return n;
        });
      var n = { uvBadge: i("0261").default },
        a = function () {
          var t = this,
            e = t.$createElement,
            i = t._self._c || e;
          return i(
            "v-uni-view",
            { staticClass: "uv-tabs", style: [t.$uv.addStyle(t.customStyle)] },
            [
              i(
                "v-uni-view",
                { staticClass: "uv-tabs__wrapper" },
                [
                  t._t("left"),
                  i(
                    "v-uni-view",
                    { staticClass: "uv-tabs__wrapper__scroll-view-wrapper" },
                    [
                      i(
                        "v-uni-scroll-view",
                        {
                          ref: "uv-tabs__wrapper__scroll-view",
                          staticClass: "uv-tabs__wrapper__scroll-view",
                          attrs: {
                            "scroll-x": t.scrollable,
                            "scroll-left": t.scrollLeft,
                            "scroll-with-animation": !0,
                            "show-scrollbar": !1,
                          },
                        },
                        [
                          i(
                            "v-uni-view",
                            {
                              ref: "uv-tabs__wrapper__nav",
                              staticClass: "uv-tabs__wrapper__nav",
                              style: { flex: t.scrollable ? "" : 1 },
                            },
                            [
                              t._l(t.list, function (e, n) {
                                return i(
                                  "v-uni-view",
                                  {
                                    key: n,
                                    ref: "uv-tabs__wrapper__nav__item-" + n,
                                    refInFor: !0,
                                    staticClass: "uv-tabs__wrapper__nav__item",
                                    class: [
                                      "uv-tabs__wrapper__nav__item-" + n,
                                      e.disabled &&
                                        "uv-tabs__wrapper__nav__item--disabled",
                                    ],
                                    style: [
                                      { flex: t.scrollable ? "" : 1 },
                                      t.$uv.addStyle(t.itemStyle),
                                    ],
                                    on: {
                                      click: function (i) {
                                        (arguments[0] = i = t.$handleEvent(i)),
                                          t.clickHandler(e, n);
                                      },
                                    },
                                  },
                                  [
                                    i(
                                      "v-uni-text",
                                      {
                                        staticClass:
                                          "uv-tabs__wrapper__nav__item__text",
                                        class: [
                                          e.disabled &&
                                            "uv-tabs__wrapper__nav__item__text--disabled",
                                        ],
                                        style: [t.textStyle(n)],
                                      },
                                      [t._v(t._s(e[t.keyName]))],
                                    ),
                                    i("uv-badge", {
                                      attrs: {
                                        show: !(
                                          !e.badge ||
                                          !(
                                            e.badge.show ||
                                            e.badge.isDot ||
                                            e.badge.value
                                          )
                                        ),
                                        isDot:
                                          (e.badge && e.badge.isDot) ||
                                          t.propsBadge.isDot,
                                        value:
                                          (e.badge && e.badge.value) ||
                                          t.propsBadge.value,
                                        max:
                                          (e.badge && e.badge.max) ||
                                          t.propsBadge.max,
                                        type:
                                          (e.badge && e.badge.type) ||
                                          t.propsBadge.type,
                                        showZero:
                                          (e.badge && e.badge.showZero) ||
                                          t.propsBadge.showZero,
                                        bgColor:
                                          (e.badge && e.badge.bgColor) ||
                                          t.propsBadge.bgColor,
                                        color:
                                          (e.badge && e.badge.color) ||
                                          t.propsBadge.color,
                                        shape:
                                          (e.badge && e.badge.shape) ||
                                          t.propsBadge.shape,
                                        numberType:
                                          (e.badge && e.badge.numberType) ||
                                          t.propsBadge.numberType,
                                        inverted:
                                          (e.badge && e.badge.inverted) ||
                                          t.propsBadge.inverted,
                                        customStyle: "margin-left: 4px;",
                                      },
                                    }),
                                  ],
                                  1,
                                );
                              }),
                              i("v-uni-view", {
                                ref: "uv-tabs__wrapper__nav__line",
                                staticClass: "uv-tabs__wrapper__nav__line",
                                style: [
                                  {
                                    width: t.$uv.addUnit(t.lineWidth),
                                    transform:
                                      "translate(" + t.lineOffsetLeft + "px)",
                                    transitionDuration:
                                      (t.firstTime ? 0 : t.duration) + "ms",
                                    height: t.firstTime
                                      ? 0
                                      : t.$uv.addUnit(t.lineHeight),
                                    background: t.lineColor,
                                    backgroundSize: t.lineBgSize,
                                  },
                                ],
                              }),
                            ],
                            2,
                          ),
                        ],
                        1,
                      ),
                    ],
                    1,
                  ),
                  t._t("right"),
                ],
                2,
              ),
            ],
            1,
          );
        },
        s = [];
    },
    "2b48": function (t, e, i) {
      "use strict";
      i.r(e);
      var n = i("28f5"),
        a = i("39c1");
      for (var s in a)
        ["default"].indexOf(s) < 0 &&
          (function (t) {
            i.d(e, t, function () {
              return a[t];
            });
          })(s);
      i("45c0");
      var r = i("828b"),
        o = Object(r["a"])(
          a["default"],
          n["b"],
          n["c"],
          !1,
          null,
          "6f5b1fc6",
          null,
          !1,
          n["a"],
          void 0,
        );
      e["default"] = o.exports;
    },
    3105: function (t, e, i) {
      var n = i("c86c");
      (e = n(!1)),
        e.push([
          t.i,
          '@charset "UTF-8";\r\n/**\r\n * 这里是uni-app内置的常用样式变量\r\n *\r\n * uni-app 官方扩展插件及插件市场（https://ext.dcloud.net.cn）上很多三方插件均使用了这些样式变量\r\n * 如果你是插件开发者，建议你使用scss预处理，并在插件代码中直接使用这些变量（无需 import 这个文件），方便用户通过搭积木的方式开发整体风格一致的App\r\n *\r\n */\r\n/**\r\n * 如果你是App开发者（插件使用者），你可以通过修改这些变量来定制自己的插件主题，实现自定义主题功能\r\n *\r\n * 如果你的项目同样使用了scss预处理，你也可以直接在你的 scss 代码中使用如下变量，同时无需 import 这个文件\r\n */\r\n/* 颜色变量 */\r\n/* 行为相关颜色 */\r\n/* 文字基本颜色 */\r\n/* 背景颜色 */\r\n/* 边框颜色 */\r\n/* 尺寸变量 */\r\n/* 文字尺寸 */\r\n/* 图片尺寸 */\r\n/* Border Radius */\r\n/* 水平间距 */\r\n/* 垂直间距 */\r\n/* 透明度 */\r\n/* 文章场景相关 */uni-view[data-v-6f5b1fc6], uni-scroll-view[data-v-6f5b1fc6], uni-swiper-item[data-v-6f5b1fc6]{display:flex;flex-direction:column;flex-shrink:0;flex-grow:0;flex-basis:auto;align-items:stretch;align-content:flex-start}.uv-tabs__wrapper[data-v-6f5b1fc6]{display:flex;flex-direction:row;align-items:center}.uv-tabs__wrapper__scroll-view-wrapper[data-v-6f5b1fc6]{flex:1;overflow:auto hidden}.uv-tabs__wrapper__scroll-view[data-v-6f5b1fc6]{display:flex;flex-direction:row;flex:1}.uv-tabs__wrapper__nav[data-v-6f5b1fc6]{display:flex;flex-direction:row;position:relative}.uv-tabs__wrapper__nav__item[data-v-6f5b1fc6]{padding:0 11px;display:flex;flex-direction:row;align-items:center;justify-content:center}.uv-tabs__wrapper__nav__item--disabled[data-v-6f5b1fc6]{cursor:not-allowed}.uv-tabs__wrapper__nav__item__text[data-v-6f5b1fc6]{font-size:15px;color:#606266}.uv-tabs__wrapper__nav__item__text--disabled[data-v-6f5b1fc6]{color:#c8c9cc!important}.uv-tabs__wrapper__nav__line[data-v-6f5b1fc6]{height:3px;background:#3c9cff;width:30px;position:absolute;bottom:2px;border-radius:100px;transition-property:-webkit-transform;transition-property:transform;transition-property:transform,-webkit-transform;transition-duration:.3s}',
          "",
        ]),
        (t.exports = e);
    },
    "39c1": function (t, e, i) {
      "use strict";
      i.r(e);
      var n = i("05c2"),
        a = i.n(n);
      for (var s in n)
        ["default"].indexOf(s) < 0 &&
          (function (t) {
            i.d(e, t, function () {
              return n[t];
            });
          })(s);
      e["default"] = a.a;
    },
    "45c0": function (t, e, i) {
      "use strict";
      var n = i("62a9"),
        a = i.n(n);
      a.a;
    },
    "47e0": function (t, e, i) {
      "use strict";
      i.r(e);
      var n = i("2304"),
        a = i("8da9");
      for (var s in a)
        ["default"].indexOf(s) < 0 &&
          (function (t) {
            i.d(e, t, function () {
              return a[t];
            });
          })(s);
      i("d316");
      var r = i("828b"),
        o = Object(r["a"])(
          a["default"],
          n["b"],
          n["c"],
          !1,
          null,
          "707c93c6",
          null,
          !1,
          n["a"],
          void 0,
        );
      e["default"] = o.exports;
    },
    "62a9": function (t, e, i) {
      var n = i("3105");
      n.__esModule && (n = n.default),
        "string" === typeof n && (n = [[t.i, n, ""]]),
        n.locals && (t.exports = n.locals);
      var a = i("967d").default;
      a("0bdeecc7", n, !0, { sourceMap: !1, shadowMode: !1 });
    },
    7689: function (t, e, i) {
      "use strict";
      i("6a54");
      var n = i("f5bd").default;
      Object.defineProperty(e, "__esModule", { value: !0 }),
        (e.default = void 0),
        i("64aa");
      var a,
        s,
        r = n(i("9b1b")),
        o = {
          props: (0, r.default)(
            {
              duration: { type: Number, default: 300 },
              list: {
                type: Array,
                default: function () {
                  return [];
                },
              },
              lineColor: { type: String, default: "#3c9cff" },
              activeStyle: {
                type: [String, Object],
                default: function () {
                  return { color: "#303133" };
                },
              },
              inactiveStyle: {
                type: [String, Object],
                default: function () {
                  return { color: "#606266" };
                },
              },
              lineWidth: { type: [String, Number], default: 20 },
              lineHeight: { type: [String, Number], default: 3 },
              lineBgSize: { type: String, default: "cover" },
              itemStyle: {
                type: [String, Object],
                default: function () {
                  return { height: "44px" };
                },
              },
              scrollable: { type: Boolean, default: !0 },
              current: { type: [Number, String], default: 0 },
              keyName: { type: String, default: "name" },
            },
            null === (a = uni.$uv) ||
              void 0 === a ||
              null === (s = a.props) ||
              void 0 === s
              ? void 0
              : s.tabs,
          ),
        };
      e.default = o;
    },
    "8da9": function (t, e, i) {
      "use strict";
      i.r(e);
      var n = i("9cb8"),
        a = i.n(n);
      for (var s in n)
        ["default"].indexOf(s) < 0 &&
          (function (t) {
            i.d(e, t, function () {
              return n[t];
            });
          })(s);
      e["default"] = a.a;
    },
    "96d2": function (t, e, i) {
      var n = i("c86c");
      (e = n(!1)),
        e.push([
          t.i,
          '@charset "UTF-8";\r\n/**\r\n * 这里是uni-app内置的常用样式变量\r\n *\r\n * uni-app 官方扩展插件及插件市场（https://ext.dcloud.net.cn）上很多三方插件均使用了这些样式变量\r\n * 如果你是插件开发者，建议你使用scss预处理，并在插件代码中直接使用这些变量（无需 import 这个文件），方便用户通过搭积木的方式开发整体风格一致的App\r\n *\r\n */\r\n/**\r\n * 如果你是App开发者（插件使用者），你可以通过修改这些变量来定制自己的插件主题，实现自定义主题功能\r\n *\r\n * 如果你的项目同样使用了scss预处理，你也可以直接在你的 scss 代码中使用如下变量，同时无需 import 这个文件\r\n */\r\n/* 颜色变量 */\r\n/* 行为相关颜色 */\r\n/* 文字基本颜色 */\r\n/* 背景颜色 */\r\n/* 边框颜色 */\r\n/* 尺寸变量 */\r\n/* 文字尺寸 */\r\n/* 图片尺寸 */\r\n/* Border Radius */\r\n/* 水平间距 */\r\n/* 垂直间距 */\r\n/* 透明度 */\r\n/* 文章场景相关 */.area_tabs[data-v-707c93c6]{padding:%?12?% 0;background:#f7f8fa;box-shadow:0 0 %?10?% %?2?% #eee inset}.area_tabs[data-v-707c93c6] .uv-tabs__wrapper__nav__item{position:relative;z-index:2}.area_tabs[data-v-707c93c6] .uv-tabs__wrapper__nav__line{width:%?94?%!important;height:%?20?%!important;z-index:1;bottom:%?8?%!important;margin-left:%?-27?%!important}.stop_refresh[data-v-707c93c6]{z-index:9;position:fixed;right:%?30?%;bottom:14%;flex-direction:column;width:%?94?%;height:%?94?%;border-radius:%?94?%;justify-content:center;background:#ffe610;border:%?4?% solid #000}.stop_refresh[data-v-707c93c6] .uv-icon .uvicon-play-right-fill{position:relative;left:%?4?%}.stop_refresh[data-v-707c93c6] .uv-icon span{font-weight:700}.content[data-v-707c93c6]{padding-top:%?175?%}.sticky_tabs_box[data-v-707c93c6]{z-index:1009;padding-bottom:%?0?%}.sticky_tabs_box[data-v-707c93c6] .uv-tabs__wrapper__nav__item{min-width:20%;padding:0}.more_cat_content[data-v-707c93c6]{height:100vh}.more_cat_mark[data-v-707c93c6]{position:fixed;left:0;right:0;top:0;bottom:0;background:rgba(0,0,0,.5);z-index:1002}.more_cat_box[data-v-707c93c6]{z-index:1008;max-width:480px;margin:0 auto;position:fixed;left:0;right:0;top:%?95?%;background:#fff;display:grid;grid-template-columns:repeat(4,1fr);grid-gap:%?20?%;border-radius:0 0 %?20?% %?20?%;padding:%?40?% %?30?% %?34?%}.more_cat_box .item[data-v-707c93c6]{background:#eee;text-align:center;height:%?68?%;line-height:%?68?%;border-radius:%?10?%;padding:0 %?10?%}.more_cat_box .item.cur[data-v-707c93c6]{background:#ffe610;font-weight:700}.order_list[data-v-707c93c6]{margin-top:%?4?%}.order_list .col[data-v-707c93c6]{background:#fff;border-radius:%?25?%;box-shadow:0 %?2?% %?8?% #ddd;padding:0 %?30?%;margin:%?30?% %?30?% %?40?%}.order_list .col .top_box[data-v-707c93c6]{border-bottom:%?2?% solid #ddd}.order_list .col .top_box uni-view[data-v-707c93c6]{font-size:13px;white-space:nowrap}.order_list .col .top_box .order_num[data-v-707c93c6]{padding:%?22?% 0;justify-content:flex-start;flex:1}.order_list .col .top_box .order_num .num[data-v-707c93c6]{font-weight:700}.order_list .col .top_box .order_num .copy_btn[data-v-707c93c6]{margin-left:%?12?%;color:#2979ff}.order_list .col .top_box .status[data-v-707c93c6]{font-size:12px;font-weight:700}.order_list .col .msg_box[data-v-707c93c6]{padding:0 0 %?10?%}.order_list .col .msg_box .goods_msg[data-v-707c93c6]{margin:%?26?% auto %?24?%;padding-bottom:%?4?%;position:relative;padding-right:%?114?%}.order_list .col .msg_box .goods_msg .zhiding[data-v-707c93c6]{position:absolute;top:0;right:0;padding:0 %?14?%;height:%?40?%;line-height:%?40?%;border-radius:%?40?%;background:#fff1d4;color:#fd6400;font-size:12px;font-weight:700;white-space:nowrap}.order_list .col .msg_box .goods_msg .img[data-v-707c93c6]{width:%?114?%;height:%?114?%;border-radius:%?10?%;position:relative;top:%?4?%}.order_list .col .msg_box .goods_msg .txt[data-v-707c93c6]{width:calc(100% - %?138?%)}.order_list .col .msg_box .goods_msg .txt .price_box .price[data-v-707c93c6]{color:#fd2c28;font-weight:700;font-size:18px}.order_list .col .msg_box .goods_msg .txt .price_box .price .unit[data-v-707c93c6]{font-size:12.4px}.order_list .col .msg_box .goods_msg .txt .name[data-v-707c93c6]{font-size:13px;margin:%?6?% auto %?4?%;font-weight:700}.order_list .col .msg_box .goods_msg .txt .intro[data-v-707c93c6]{font-size:12px;color:#999}.order_list .col .msg_box .tips[data-v-707c93c6]{margin:%?10?% auto}.order_list .col .msg_box .tips uni-view[data-v-707c93c6]{font-size:12.6px;color:#999}.order_list .col .msg_box .tips .tit[data-v-707c93c6]{color:#444}.order_list .col .msg_box .tips .remark[data-v-707c93c6]{flex:1;text-align:right;margin-left:%?150?%}.order_list .col .msg_box .tips .real_money[data-v-707c93c6]{color:#fd2c28;font-weight:700;font-size:15px}.order_list .col .msg_box .tips .real_money .unit[data-v-707c93c6]{font-size:11px}.order_list .col .btn_box[data-v-707c93c6]{padding:%?20?% 0;border-top:%?2?% solid #ddd;justify-content:flex-end}.order_list .col .btn_box uni-view[data-v-707c93c6]{background:#ffe610;height:%?66?%;line-height:%?66?%;border-radius:%?66?%;font-weight:700;margin-left:%?25?%;padding:0 %?24?%;box-sizing:border-box}.order_list .col .btn_box uni-view[data-v-707c93c6]:first-child{margin-left:0}.order_list .col .btn_box uni-view.cancle[data-v-707c93c6]{background:#eee;color:#666}',
          "",
        ]),
        (t.exports = e);
    },
    "9cb8": function (t, e, i) {
      "use strict";
      i("6a54");
      var n = i("f5bd").default;
      Object.defineProperty(e, "__esModule", { value: !0 }),
        (e.default = void 0);
      var a = n(i("b7c7"));
      i("5c47"), i("aa9c"), i("bd06"), i("0c26");
      var s = i("e74a"),
        r = {
          data: function () {
            return {
              gameTabs: [],
              area_list: [],
              list: [],
              game_current: 0,
              current: 0,
              area: -1,
              page: 1,
              no_more: 0,
              loadTips: "loading",
              moreCat: !1,
              standHeight: 40,
              stopRefresh: !0,
              intervalId: null,
              show_goods_des: 0,
              cat1_id: 0,
              index: 0,
              loading_list: 0,
              seller_accept: 0,
            };
          },
          onLoad: function (t) {
            (this.current = t.current ? t.current : 0),
              (this.index = t.index ? t.index : 0),
              (this.cat1_id = uni.getStorageSync("select_cat1_id")),
              this.getHallCatInfo();
          },
          onShow: function () {
            this.toggleStopRefresh(), this.listJieliu();
          },
          onPullDownRefresh: function () {
            var t = this;
            uni.showLoading({ title: "刷新中" }),
              setTimeout(function () {
                uni.hideLoading(),
                  t.resetData(),
                  t.listJieliu(),
                  uni.showToast({ title: "刷新成功", duration: 1e3 }),
                  uni.stopPullDownRefresh();
              }, 300);
          },
          onReachBottom: function (t) {
            this.loadMoreFun();
          },
          mounted: function () {
            this.getHeight();
          },
          onUnload: function () {
            clearInterval(this.intervalId),
              (this.intervalId = null),
              console.log("清除定时器");
          },
          methods: {
            catJieliu: function () {
              uni.$uv.debounce(this.getHallCatInfo, 100);
            },
            getHallCatInfo: function () {
              var t = this;
              (0, s.send)(
                "/wechat/Order/getHallCatInfo",
                { cat1_id: this.cat1_id, index: this.index, page: this.page },
                !1,
              ).then(function (e) {
                var i = e.status,
                  n = e.msg,
                  a = e.data;
                if (1 != i) return uni.$uv.toast(n);
                (t.show_goods_des = a.show_goods_des),
                  (t.gameTabs = a.cat1),
                  (t.game_current = t.findIndexById(t.gameTabs, t.cat1_id)),
                  (t.area_list = a.area_list),
                  (t.seller_accept = a.seller_accept);
                var s = t;
                return 0 == t.seller_accept
                  ? uni.showModal({
                      title: "温馨提示",
                      content: "请先缴费开通接单权限",
                      success: function (t) {
                        t.confirm && s.jump("/pages_sub1/seller/seller_pay");
                      },
                    })
                  : void 0;
              });
            },
            toggleStopRefresh: function () {
              clearInterval(this.intervalId), (this.intervalId = null);
              var t = this;
              if (((this.stopRefresh = !this.stopRefresh), this.stopRefresh))
                return uni.$uv.toast("已暂停自动刷新");
              uni.$uv.toast("已启动自动刷新"),
                (this.intervalId = setInterval(function () {
                  t.resetData(), t.listJieliu(0);
                }, 7e3));
            },
            getHeight: function () {
              var t = this;
              this.$nextTick(function () {
                var e = uni.createSelectorQuery().in(t);
                e.select("#standHeight")
                  .boundingClientRect(function (e) {
                    console.log("定位" + e.height), (t.standHeight = e.height);
                  })
                  .exec();
              });
            },
            toggleMoreCat: function () {
              this.tabs.length > 0
                ? (this.moreCat = !this.moreCat)
                : console.log("没有更多分类");
            },
            selectMoreCat: function (t) {
              if (this.current == t.index) return console.log("重复点击"), !1;
              this.changeTabs(t), (this.moreCat = !1);
            },
            listJieliu: function () {
              var t =
                arguments.length > 0 && void 0 !== arguments[0]
                  ? arguments[0]
                  : 1;
              (this.loading_list = t), uni.$uv.debounce(this.getHallList, 100);
            },
            getHallList: function () {
              var t = this;
              1 == this.loading_list && uni.showLoading({ title: "加载中.." }),
                (0, s.send)(
                  "/wechat/Order/getHallList",
                  {
                    label: "order",
                    cat1_id: this.cat1_id,
                    index: this.index,
                    page: this.page,
                  },
                  !1,
                ).then(function (e) {
                  uni.hideLoading();
                  var i,
                    n = e.status,
                    s = e.msg,
                    r = e.data;
                  if (401 == n)
                    return (
                      clearInterval(t.intervalId),
                      (t.intervalId = null),
                      uni.switchTab({ url: "/pages/index/index" }),
                      uni.$uv.toast(s)
                    );
                  if (1 != n) return uni.$uv.toast(s);
                  ((t.current = r.current),
                  0 == t.current && (t.index = 0),
                  t.page > 1)
                    ? (i = t.list).push.apply(i, (0, a.default)(r.list))
                    : (t.list = r.list);
                  1 == r.no_more &&
                    ((t.loadTips = "nomore"), (t.no_more = r.no_more));
                });
            },
            findIndexById: function (t, e) {
              return t.findIndex(function (t) {
                return t.id === e;
              });
            },
            copyOrderNum: function (t) {
              uni.setClipboardData({
                data: t.trim(),
                success: function () {
                  return uni.$uv.toast("复制成功");
                },
                fail: function () {},
              });
            },
            changeTabs: function (t) {
              (this.current = t.index),
                (this.index = t.label),
                (this.page = 1),
                (this.list = []),
                (this.no_more = 0),
                console.log(t.index + t.name),
                this.listJieliu();
            },
            loadMoreFun: function () {
              0 == this.no_more && (this.page++, this.listJieliu()),
                console.log("到底了");
            },
            jump: function (t) {
              clearInterval(this.intervalId),
                (this.intervalId = null),
                (this.stopRefresh = !0),
                uni.navigateTo({ url: t });
            },
            resetData: function () {
              (this.page = 1), (this.no_more = 0), (this.loadTips = "loading");
            },
            changeGames: function (t) {
              (this.cat1_id = t.id),
                (this.page = 1),
                (this.list = []),
                (this.no_more = 0),
                uni.$uv.debounce(this.changeTabsJieliu, 100);
            },
            changeTabsJieliu: function () {
              this.getHallList(), this.getHallCatInfo();
            },
            confirmOrder: function (t, e) {
              var i = this,
                n = "";
              1 == t && (n = "确认要接受么? 接受之后系统将不自动随机派单"),
                2 == t && (n = "确认要拒绝么? 拒绝之后系统将随机派给其它打手"),
                uni.showModal({
                  title: "温馨提示",
                  content: n,
                  success: function (n) {
                    n.confirm &&
                      (uni.showLoading({ title: "加载中.." }),
                      (0, s.send)(
                        "/wechat/Order/confirmOrder",
                        { id: e, type: t },
                        !1,
                      ).then(function (t) {
                        uni.hideLoading();
                        var e = t.status,
                          n = t.msg;
                        t.data;
                        if (1 != e) return uni.$uv.toast(n);
                        uni.$uv.toast(n),
                          setTimeout(function () {
                            i.listJieliu();
                          }, 1500);
                      }));
                  },
                });
            },
          },
        };
      e.default = r;
    },
    d0b4: function (t, e, i) {
      var n = i("96d2");
      n.__esModule && (n = n.default),
        "string" === typeof n && (n = [[t.i, n, ""]]),
        n.locals && (t.exports = n.locals);
      var a = i("967d").default;
      a("dc46b2c6", n, !0, { sourceMap: !1, shadowMode: !1 });
    },
    d316: function (t, e, i) {
      "use strict";
      var n = i("d0b4"),
        a = i.n(n);
      a.a;
    },
  },
]);
//# sourceMappingURL=pages_sub1-seller-hall.7d87d2ce.js.map
