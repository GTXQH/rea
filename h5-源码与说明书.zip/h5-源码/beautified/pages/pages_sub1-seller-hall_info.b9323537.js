(window["webpackJsonp"] = window["webpackJsonp"] || []).push([
  ["pages_sub1-seller-hall_info"],
  {
    1225: function (t, e, i) {
      var o = i("c86c");
      (e = o(!1)),
        e.push([
          t.i,
          'a + a[data-v-0bff2c70]{margin-left:10px}\r\n/* 弹窗开始  */.lang-dialog__wrapper[data-v-0bff2c70]{position:fixed;top:0;right:0;bottom:0;left:0;overflow:hidden;width:100%;height:100%;background:rgba(0,0,0,.5);text-align:left;z-index:88888888}.lang-dialog[data-v-0bff2c70]{position:relative;margin:0 auto 50px;border-radius:2px;box-shadow:0 1px 3px rgba(0,0,0,.3);box-sizing:border-box;background:#fff;width:50%;margin-top:calc(50vh - 185px);width:360px}.lang-dialog__header[data-v-0bff2c70]{padding:20px 10px 10px}.lang-dialog__title[data-v-0bff2c70]{line-height:20px;font-size:18px;color:#525252}.lang-dialog-header-btn[data-v-0bff2c70]{position:absolute;top:20px;right:20px;padding:0;background:0 0;border:none;outline:0;cursor:pointer;font-size:16px}.lang-icon-close[data-v-0bff2c70]{color:rgba(0,0,0,.68);font-size:20px}.lang-icon-close[data-v-0bff2c70]:before{content:"×"}.lang-icon-close[data-v-0bff2c70]:hover{color:rgba(0,0,0,.88)}.lang-dialog__body[data-v-0bff2c70]{color:#828282;font-size:14px;word-break:break-all;padding:0 10px;height:320px}.loading-transparent-mask[data-v-0bff2c70]{position:absolute;top:0;left:0;width:100%;height:100%;background:transparent;z-index:999}\r\n/* 弹窗结束  */\r\n/* loading start */.loading-body[data-v-0bff2c70]{position:absolute;top:0;left:0;width:100%;height:100%;background:hsla(0,0%,100%,.6);z-index:999}.loading[data-v-0bff2c70]{position:relative;display:inline-block;width:30px;height:30px;border-radius:50%;border-top:2px solid transparent;border-bottom:2px solid transparent;border-left:2px solid #409eff;border-right:2px solid #409eff;-webkit-animation:loading-data-v-0bff2c70 1s infinite linear;animation:loading-data-v-0bff2c70 1s infinite linear}@-webkit-keyframes loading-data-v-0bff2c70{to{-webkit-transform:rotate(1turn);transform:rotate(1turn)}}@keyframes loading-data-v-0bff2c70{to{-webkit-transform:rotate(1turn);transform:rotate(1turn)}}.slider-loading[data-v-0bff2c70]{position:absolute;top:calc(50% - 15px);left:calc(50% - 15px);z-index:999}\r\n/* loading end */.tips[data-v-0bff2c70]{color:#525252;line-height:36px;font-size:18px}.slider-body[data-v-0bff2c70]{position:relative;width:100%;height:245px}.slider-bg[data-v-0bff2c70]{position:absolute;top:0;left:0;background-position:0 0;background-size:340px 251px;background-repeat:no-repeat;width:340px;height:191px;overflow:hidden}.slider-draw[data-v-0bff2c70]{position:absolute;left:27px;width:50px;height:50px;background:#fff;background-position:-5px -196px;background-size:340px 251px;background-repeat:no-repeat;z-index:1;cursor:pointer;opacity:1;box-shadow:0 0 10px 2px #000}.slider-progress[data-v-0bff2c70]{position:absolute;width:100%;background-image:url("data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAqoAAAJsCAYAAAA1NIHDAAAACXBIWXMAAAsTAAALEwEAmpwYAAAE7mlUWHRYTUw6Y29tLmFkb2JlLnhtcAAAAAAAPD94cGFja2V0IGJlZ2luPSLvu78iIGlkPSJXNU0wTXBDZWhpSHpyZVN6TlRjemtjOWQiPz4gPHg6eG1wbWV0YSB4bWxuczp4PSJhZG9iZTpuczptZXRhLyIgeDp4bXB0az0iQWRvYmUgWE1QIENvcmUgNy4xLWMwMDAgNzkuOWNjYzRkZSwgMjAyMi8wMy8xNC0xMToyNjoxOSAgICAgICAgIj4gPHJkZjpSREYgeG1sbnM6cmRmPSJodHRwOi8vd3d3LnczLm9yZy8xOTk5LzAyLzIyLXJkZi1zeW50YXgtbnMjIj4gPHJkZjpEZXNjcmlwdGlvbiByZGY6YWJvdXQ9IiIgeG1sbnM6eG1wPSJodHRwOi8vbnMuYWRvYmUuY29tL3hhcC8xLjAvIiB4bWxuczpkYz0iaHR0cDovL3B1cmwub3JnL2RjL2VsZW1lbnRzLzEuMS8iIHhtbG5zOnBob3Rvc2hvcD0iaHR0cDovL25zLmFkb2JlLmNvbS9waG90b3Nob3AvMS4wLyIgeG1sbnM6eG1wTU09Imh0dHA6Ly9ucy5hZG9iZS5jb20veGFwLzEuMC9tbS8iIHhtbG5zOnN0RXZ0PSJodHRwOi8vbnMuYWRvYmUuY29tL3hhcC8xLjAvc1R5cGUvUmVzb3VyY2VFdmVudCMiIHhtcDpDcmVhdG9yVG9vbD0iQWRvYmUgUGhvdG9zaG9wIDIzLjMgKFdpbmRvd3MpIiB4bXA6Q3JlYXRlRGF0ZT0iMjAyMi0xMi0wNlQxNzoyOToxNSswODowMCIgeG1wOk1vZGlmeURhdGU9IjIwMjItMTItMDZUMTc6MzI6MDIrMDg6MDAiIHhtcDpNZXRhZGF0YURhdGU9IjIwMjItMTItMDZUMTc6MzI6MDIrMDg6MDAiIGRjOmZvcm1hdD0iaW1hZ2UvcG5nIiBwaG90b3Nob3A6Q29sb3JNb2RlPSIzIiB4bXBNTTpJbnN0YW5jZUlEPSJ4bXAuaWlkOmJhYmMyMDIzLTdkNDgtZTg0Zi05ZTFlLTNkZDQ2YTFiMWNkZCIgeG1wTU06RG9jdW1lbnRJRD0ieG1wLmRpZDpiYWJjMjAyMy03ZDQ4LWU4NGYtOWUxZS0zZGQ0NmExYjFjZGQiIHhtcE1NOk9yaWdpbmFsRG9jdW1lbnRJRD0ieG1wLmRpZDpiYWJjMjAyMy03ZDQ4LWU4NGYtOWUxZS0zZGQ0NmExYjFjZGQiPiA8eG1wTU06SGlzdG9yeT4gPHJkZjpTZXE+IDxyZGY6bGkgc3RFdnQ6YWN0aW9uPSJjcmVhdGVkIiBzdEV2dDppbnN0YW5jZUlEPSJ4bXAuaWlkOmJhYmMyMDIzLTdkNDgtZTg0Zi05ZTFlLTNkZDQ2YTFiMWNkZCIgc3RFdnQ6d2hlbj0iMjAyMi0xMi0wNlQxNzoyOToxNSswODowMCIgc3RFdnQ6c29mdHdhcmVBZ2VudD0iQWRvYmUgUGhvdG9zaG9wIDIzLjMgKFdpbmRvd3MpIi8+IDwvcmRmOlNlcT4gPC94bXBNTTpIaXN0b3J5PiA8L3JkZjpEZXNjcmlwdGlvbj4gPC9yZGY6UkRGPiA8L3g6eG1wbWV0YT4gPD94cGFja2V0IGVuZD0iciI/PmbOvQUAABmXSURBVHic7d1rrKVXfd/x33qefebqwdgJl0ZpwdzKtZiYijQSzBhQFUUggsmxkrYUqZHavKERSGmlqtV42qpSG5W+SFW1jXpRkhdoTnAohCpVQOMhTYsru5AmQLhpEEJCwRCwPTOec/Zl9cUZD/axPZ7Lsfd/cz4faTQ6R/vZe82MNPqe9ay1ntZ7PxQAAChmWPYAAADgyQhVAABKEqoAAJQkVAEAKEmoAgBQklAFAKAkoQoAQElCFQCAkoQqAAAlCVUAAEoSqgAAlCRUAQAoSagCAFCSUAUAoCShCgBASUIVAICShCoAACUJVQAAShKqAACUJFQBAChJqAIAUJJQBQCgJKEKAEBJQhUAgJKEKgAAJQlVAABKEqoAAJQkVAEAKEmoAgBQklAFAKAkoQoAQElCFQCAkoQqAAAlCVUAAEoSqgAAlCRUAQAoSagCAFCSUAUAoCShCgBASUIVAICShCoAACUJVQAAShKqAACUJFQBAChJqAIAUJJQBQCgJKEKAEBJQhUAgJKEKgAAJQlVAABKEqoAAJQkVAEAKEmoAgBQklAFAKAkoQoAQElCFQCAkoQqAAAlCVUAAEoSqgAAlCRUAQAoSagCAFCSUAUAoCShCgBASUIVAICShCoAACUJVQAAShKqAACUJFQBAChJqAIAUJJQBQCgJKEKAEBJQhUAgJKEKgAAJQlVAABKEqoAAJQkVAEAKEmoAgBQklAFAKAkoQoAQElCFQCAkoQqAAAlCVUAAEoSqgAAlCRUAQAoSagCAFCSUAUAoCShCgBASUIVAICShCoAACUJVQAAShKqAACUJFQBAChJqAIAUJJQBQCgJKEKAEBJQhUAgJKEKgAAJQlVAABKEqoAAJQkVAEAKEmoAgBQklAFAKAkoQoAQElCFQCAkoQqAAAlCVUAAEoSqgAAlCRUAQAoSagCAFCSUAUAoCShCgBASUIVAICShCoAACUJVQAAShKqAACUJFQBAChJqAIAUJJQBQCgJKEKAEBJQhUAgJKEKgAAJQlVAABKEqoAAJQkVAEAKEmoAgBQklAFAKAkoQoAQElCFQCAkoQqAAAlCVUAAEoSqgAAlCRUAQAoSagCAFCSUAUAoCShCgBASUIVAICShCoAACUJVQAAShKqAACUJFQBAChJqAIAUJJQBQCgJKEKAEBJQhUAgJKEKgAAJQlVAABKEqoAAJQkVAEAKEmoAgBQklAFAKAkoQoAQElCFQCAkoQqAAAlCVUAAEoSqgAAlCRUAQAoSagCAFCSUAUAoCShCgBASUIVAICShCoAACUJVQAAShKqAACUJFQBAChJqAIAUJJQBQCgJKEKAEBJQhUAgJKEKgAAJQlVAABKEqoAAJQkVAEAKEmoAgBQklAFAKAkoQoAQElCFQCAkoQqAAAlCVUAAEoSqgAAlCRUAQAoSagCAFCSUAUAoCShCgBASUIVAICShCoAACUJVQAAShKqAACUJFQBAChJqAIAUJJQBQCgJKEKAEBJQhUAgJKEKgAAJQlVAABKEqoAAJQkVAEAKEmoAgBQklAFAKAkoQoAQElCFQCAkoQqAAAlCVUAAEoSqgAAlCRUAQAoSagCAFCSUAUAoCShCgBASUIVAICShCoAACUJVQAAShKqAACUJFQBAChJqAIAUJJQBQCgJKEKAEBJQhUAgJKEKgAAJQlVAABKEqoAAJQkVAEAKEmoAgBQklAFAKAkoQoAQElCFQCAkoQqAAAlCVUAAEoSqgAAlCRUAQAoSagCAFCSUAUAoCShCgBASUIVAICShCoAACUJVQAAShKqAACUJFQBAChJqAIAUJJQBQCgJKEKAEBJQhUAgJKEKgAAJQlVAABKEqoAAJQkVAEAKEmoAgBQklAFAKAkoQoAQElCFQCAkoQqAAAlCVUAAEoSqgAAlCRUAQAoSagCAFCSUAUAoCShCgBASUIVAICShCoAACUJVQAAShKqAACUJFQBAChJqAIAUJJQBQCgJKEKAEBJQhUAgJKEKgAAJQlVAABKEqoAAJQkVAEAKEmoAgBQklAFAKAkoQoAQElCFQCAkoQqAAAlCVUAAEoSqgAAlCRUAQAoSagCAFCSUAUAoCShCgBASUIVAICShCoAACUJVQAAShKqAACUJFQBAChJqAIAUJJQBQCgJKEKAEBJQhUAgJKEKgAAJQlVAABKEqoAAJQkVAEAKEmoAgBQklAFAKAkoQoAQElCFQCAkoQqAAAlCVUAAEoSqgAAlCRUAQAoSagCAFCSUAUAoCShCgBASUIVAICShCoAACUJVQAAShKqAACUJFQBAChJqAIAUJJQBQCgJKEKAEBJQhUAgJKEKgAAJQlVAABKEqoAAJQkVAEAKEmoAgBQklAFAKAkoQoAQElCFQCAkoQqAAAlCVUAAEoSqgAAlCRUAQAoSagCAFCSUAUAoCShCgBASUIVAICShCoAACUJVQAAShKqAACUJFQBAChJqAIAUJJQBQCgJKEKAEBJQhUAgJKEKgAAJQlVAABKEqoAAJQkVAEAKEmoAgBQklAFAKAkoQoAQElCFQCAkoQqAAAlCVUAAEoSqgAAlCRUAQAoSagCAFCSUAUAoCShCgBASUIVAICShCoAACUJVQAAShKqAACUJFQBAChJqAIAUJJQBQCgJKEKAEBJQhUAgJKEKgAAJQlVAABKEqoAAJQkVAEAKEmoAgBQklAFAKAkoQoAQElCFQCAkoQqAAAlCVUAAEoSqgAAlCRUAQAoSagCAFCSUAUAoCShCgBASUIVAICShCoAACUJVQAAShKqAACUJFQBAChJqAIAUJJQBQCgJKEKAEBJQhUAgJKEKgAAJQlVAABKEqoAAJQkVAEAKEmoAgBQklAFAKAkoQoAQElCFQCAkoQqAAAlCVUAAEoSqgAAlCRUAQAoSagCAFCSUAUAoCShCgBASUIVAICShCoAACUJVQAAShKqAACUJFQBAChJqAIAUJJQBQCgJKEKAEBJQhUAgJKEKgAAJQlVAABKEqoAAJQkVAEAKEmoAgBQklAFAKAkoQoAQElCFQCAkoQqAAAlCVUAAEoSqgAAlCRUAQAoSagCAFDS5GovuPfee889EwMBAGB1velNbzq82+/Zeu+Hnu5F4hQAgCu1W9F62VAVqAAAXKvrDdanXKMqUgEAuB7X25NPGqoiFQCA3XA9XfmEUBWpAADspmvty8eFqkgFAOCZcC2deSlURSoAAM+kq+1NB/4DAFDSkJhNBQDg2XE13WlGFQCAkoQqAAAltc985jN92YMAAGBvuZKnVplRBQCgJKEKAEBJQhUAgJKEKgAAJQlVAABKEqoAAJQ0XMnRAAAAsFuutD/NqAIAUJJQBQCgpCG58ulXAAC4HlfTnWZUAQAo6VKomlUFAOCZdLW9+bgZVbEKAMAz4Vo68wm3/sUqAAC76Vr78knXqIpVAAB2w/V05VNuphKrAABcj+vtydZ7P/R0L7r33nvPXc+HAACwd+zWhOcVhepjiVYAAHZ6Ju7GX3WoAgDAs8GB/wAAlCRUAQAoSagCAFCSUAUAoCShCgBASUIVAICShCoAACUJVQAAShKqAACUJFQBAChJqAIAUJJQBQCgJKEKAEBJQhUAgJKEKgAAJQlVAABKEqoAAJQkVAEAKEmoAgBQklAFAKAkoQoAQElCFQCAkibLHgAr4/yyBwAXHVr2AAB4dphRBQCgJKEKAEBJQhUAgJKEKgAAJQlVAABKEqoAAJQkVAEAKEmoAgBQklAFAKAkoQoAQElCFQCAkoQqAAAlCVUAAEqatNbO7/q7rvcxSbLR5pe+93f7Wr77jVdkmLw+87NvzrD/L2Wx+YK0yW3p0560tuvjWAm9p6219Nm30obPpi+mGQ9/NLML38ik3Z+Nlz74mNe2HL1nzOlj86T13R1FP7Sb7wcAcL12Nw7XT47ZWF9ciqj1P7k5i8nbk+Ed6fmJZHhJJgcOJhcbq8+T+YVdH8bq6UmbJOP+7S/bkMzOJ33xrYz7/jAZ/mcy/71svORLly45emqym8F6BaG6+z/QwLXxQxXAHrE7hbh+csyrP99z4sQiSXLnN96S+fznksXfzOTgzWlDMt9MFlvJYrbY/tjWk97SmuUHSZLe09si6S1JT2tjhrVkPLgdrtOzs/T56WTy63n4od/N7996LsnFYL19dv2fLlRZGUIVYI+4zlB99Fb0xVC642tvz9D+Ydrk7RnWktm5ZDGbp7We3oe01q7/M/eS3tOzSGvbU66Tg9n+e33kK0n/tTz40H/eDtbesr4xZOPO+dO/51N9klBlZQhVgD3i2qNx/eR4KYze/advzbjvH6VN3nZx9m+RpKdl2LtrT3fddrRmkYwHxkwOJrMLX04W/za//ZJfS3Jds6tClRUiVAH2iGuLyNvuW8v9b5zmXf/nL2bfX/iV9On7Mx5Ith66GKht3N1h8ji9L5Let4P1cDI9eyp985/l7ledSvqQ43fl0jKMK35LocrKEKoAe8RVhmpvyV0tObHIHV+8PW3ff8q+596SCw8I1GXofZGWRSZHJllMkz7/YD7y0n+TJDneh5xoVxyrQpUVIlQB9oirCNXHROp7vvaBtPFDSU/mF2Zpw+SZGyJPq/d50pIDPzJmdu7DmX3/V/I7r/9m1vv4uCPCLvsWQpWVIVQB9ogr3HF/cbNOTizynq/+Rvbf9KHMN+eZby5EagGtjWkZc+E704wHfj7Dcz6dd37ulmy0eY6e8u8DAKykKwjVx+wov+Mrv5m1G9+bRx7YSuujo6WKaW0tm9+bZly7Jftu/FTe+blbcvr2mVgFAFbR04Tmjkjd99y/la0/n6Zln1OmimptLbOzM7EKAKy6y9TmYzdOPSZSk7VnbXRchz7L5IZJ5tMz2Xrwbfn4rWcut8HKGlVWiDWqAHvEU4TqxYP8n/9Az+LW/5K1m94rUlfRo7G6dSb97Ntz9+vOJGnJE2NVqLJChCrAHvHkt/5vu3/74PjZa/9+9j/vvdn8862I1BXUJpmenWbt8C3Jwf+a9Y0ht90/XnxMKwBAaU8M1fU+bh/m/0dvztqRX82F70zTukhdVY9usNr3nDdn+rpfzf1vnOboPc67BQDK2zGzdnzI+mta8voXpq99Omm3ZL7Z7e5feT1tmGc80DI99wv5nVdu7Dxj1a1/Vohb/wB7xOMD9Oix7R3+s/k/ztqNL8l8cyZSfyi0LOZD+mLMMH4o7ztzIK9OtwQAAKjsBxG6fnLM6dvnueNLb8nkyC9m87uztOaW/w+L1obMH5llcsOP58EL/yIn2sISAACgsp2zpT29n0gb19IXZtt++IyZnltk3P9LedcXX5zTx+ZJN2MOAJS0HSnrfczGnfO864vHMjl8NNOH52ltJWbbWksmY8tkbBmHq2vrZV27PK0ls0Umhw5myD9IWs/Re4QqAFDSdmGtnxzz6vWe//elT2XtyLGVCdWWZNqTzf6D7x0aruyhWcu6dul6TyY9rV3IML42Gy/6epLWew48zYU2U1GFzVQAe8Qk6ye3Z1PffeYnMzl0LNOzKxGprSV92vPjL1jLX/vLB5Mk01nPJ/7vuUyn/bLRuKxra2gtmc2zdtOhbH3//Un7YI6eGpNjyx4YAMDjTPLt511Mq833ZbgxaY/0y19Swzi0zC4scvQ1h/Jbv/zCS9+/+X1fzfc2F2mTlv4Uf5JlXVtHGzI735O8Oz/9mbvye296eNkjAgDYacjp22dZ/5Ob09rfyOx8kl5+NvWSlmxOe2bz7V/ffXh+5ZG4rGtrGLLYmmffc1+cgzf/9aSt1ugBgD1heyNN3/+2rB05kj6bbd8aXh02U12PRU9bvCfH7fwHAOrZDpT5/GfSxlWtLa5JHzO70NJzLJ/9w8PLHg0AwE5Dfvq/70/yVzPfjDM195LWspguMjlwc4Yfff2yRwMAsNOQgy9+eYbxJVls9jzxAQD8MOu9Z5jsyzC8ddlDAQDYacgwvi7jwYNZLBYrcLYSu633pC/etOxhAADsNGTR35Islj0OlqH1IfPNpLVblz0UAICdhqS9yB3/vaq19FkyTH5s2SMBANhpSMvz02eJ+/57VEsWU+eoAgDlDBkmt2V+IWmmVfeu1To7FwDYG4bt2TSdAgBALYPZNAAAKnK7HwCAkobtgzQBAKCWIcNaS7QqAAC1DFnMvpU2iZlVAAAqGdL7fRkPJL15PNWeZT8dAFDPkLS5R6juZS3pfWvZowAA2GlIhk+kjcseB8vQM8/kQJL8r2UPBQBgpyFDvprFdCvNeap705Ck/+myRwEAsNOQ73zzvswvPJBhzVFVe05L+nyRlv+x7JEAAOw05Nix80m7b/sWcJsve0A8W3rPOI5ZXHgoF2afWfZoAAB2GnKiLZL+aQ+p2mN6W2TYn/T+xzn3mu8sezgAADtdrNP20UzPzpI2rtrh/70ns3nPbN4zX1zd2Jd1bQmt94z7kwwfyek2W/ZwAAB2GrJ+cszrXvH1zDc/ncmhlr5Ct/97sn+tZTJu//qRI2OueEvYsq4tofdkMmTr4YcyLj627NEAADyZSb79vJaNNs+7vvzvMkzemrYaU6rzRU8OtJz+/Pnc+a+/lSSZznrOXujJ0C67LWxZ19bR5lk7PMnW9z+Zj7zqTI6emix7RAAAO7Wkt+SulvW/fSTz+ecy7HtRFhd60uovWm1Jpj3ZfEwdHhqu7EFLy7q2gp55JgfHLLbeno+87FNZPzn2k+v7n+aq88/K2ODpHVr2AAB4dgxJ6zl6bMjGSx9MFv8qk4MtWZHHqfakrbVMnjNm8pwx45HxymNxWdcuW+/zrN0wZnb+nkcjNRt3rs5yDwBgz9ieNT19bJ7jx4c8fOE3svXg1zPsG5O+ErFqM9XVaklf9Cz6ie2v15c7HACAp/Dorv+ee44N+f1bz23Pqh5uSVYiVLkKvc+zdmTM7Nzp/LdX3bM9m7pCm+cAgD3l8Tes1/uYm+4f8t0bP5nx0FsyfXie1sYljY1d1XsyWaQNW5luviEfe+WXk1xa5tF7f7p1f9aoUoU1qgB7xI4NUxvJf3zjNH3rnySLedq4yKodrMqT622WfUfGzDf/fT72qi/l6D3jyqxFBgD2pCduATp6apLTt8/y7i98IAde8KFceGCa1taWMDZ2TZ9l7cZJpmf/IONnb8+3n9dy+tg8aZd+CDGjygoxowqwRzzJXvXecvSeMc9/oGf+hg9n33N+LpvfE6urqi8WGQ8m6Q9k8fBP5e7XncljbvlfeplQZXUIVYA94ikOVepDkp53/vHzs++G/51x3y2ZnZ0lzcHwK2XRk7VFJgfGXPj+ej722t++NGO+g1BlhQhVgD3iKQ71b4scT8vH/8qfZeuht2U+PZPJDZOkeyb8yng0UveP2XrwvZeLVACAii5/TP163z6+6J2fuyX7bvxUxjUzqyvhsZF67r356Ct/K7fdt5b73zh9qivMqLJCzKgC7BGXf0zqRpvn6KlJPn7rmWw9+IOZ1d6fMnhYsr5YXG2kAgBUdPlQTZLTt8+eEKv7b1oTqxX1WcYDQyYHRCoAsPKePlSTJ8bq7JFT2X/TWpJF+mo8avWHW+/pfZq1Gydp4zczfegXRCoAsOouv0Z1p+N9yImLxxrd8dUPZZh8IK0l80dmScakXd37cf16n2cYxqzdmMweOZXN7/9iPn7rmavdOGWNKivEGlWAPeLqw/L48SFfeE3Lxp3zvPtLP5/J4X+aYXx5ZmeTPhesz5be50la9h0ZMt88n8XiP+Tul30wSa5ld79QZYUIVYA94tqD8tEYesfHDmXfq/95huHvZXLoUKYPJX0xS29D2hUuLeAK9Z6eRZKWtRuG9EXSZ59Kf+SX85HXfD7pQ47flZw4cdXLMYQqK0SoAuwR1zfzuX5yzMad8yTJHV99eca192cx/ztZO3w4s/PJfHN+8VMGs6zXqvf0tkjrPW2cZHJDspgmffbJLPq/zN0v/WSSa5pFffynCFVWhlAF2CN2IR57y3qGbLTtKP3Zr70ik7VfSmbvyOTwy9MXyfyRi3HV59tP7+zC9XJ6XyStJ71lmAwZDyTj/mTze+czrP1uhuHXc/JF24F6/Pj2rPU1zKI+/iOFKitDqALsEbsXi8ePD/nCXe1SsL7jvkM5+KM/k/n0jqTfntZemMmhbIfr5sWHXGnVJ2rJ5OD2732eLGbfTdofpY0fz2L6idz9sq9sv663rG8Ml2a0r5NQZYUIVYA9YvdL8Xgfck+GnG4/uA39rjPPzTD/iQzjT2bIT2W+9Ya0yY+lT7uZ1cdqSe9bmew7nfnsa2nzU1l77ul8+IV/dukl631MNrJbgfooocoKEaoAe0S7gkCBRKhSh/+zAPYIu/IBAChJqAIAUJJQBQCgJKEKAEBJQhUAgJKEKgAAJQlVAABKEqoAAJQkVAEAKEmoAgBQklAFAKAkoQoAQElCFQCAkoQqAAAlCVUAAEoSqgAAlCRUAQAoSagCAFCSUAUAoCShCgBASUIVAICShCoAACUJVQAAShKqAACUJFQBAChJqAIAUJJQBQCgJKEKAEBJQhUAgJKEKgAAJQlVAABKEqoAAJQkVAEAKEmoAgBQklAFAKAkoQoAQElCFQCAkoQqAAAlCVUAAEoSqgAAlCRUAQAoSagCAFCSUAUAoCShCgBASUIVAICShCoAACUJVQAAShKqAACUJFQBAChJqAIAUJJQBQCgJKEKAEBJQhUAgJKEKgAAJQlVAABKEqoAAJQkVAEAKEmoAgBQklAFAKCk/w+WTfr+O6j6dgAAAABJRU5ErkJggg==");background-position:0 -213.512px;background-size:345.06px 313.69px;width:340px;height:16px;left:0;top:210px;z-index:1;opacity:1}.slider-success[data-v-0bff2c70]{position:absolute;top:0;left:0;width:100%;height:100%;z-index:4;background:hsla(0,0%,100%,.8)}.slider-success .slider-success-icon[data-v-0bff2c70]{width:64px;height:64px;margin:15% auto 0}.slider-success .slider-success-icon uni-image[data-v-0bff2c70]{width:100%;height:100%}.slider-success .slider-success-text[data-v-0bff2c70]{color:#1bc300;text-align:center;margin-top:16px;font-size:18px}.slider-btn[data-v-0bff2c70]{position:absolute;left:20px;top:200px;z-index:2;width:65px;height:35px;line-height:35px;background-color:#0057d4;box-shadow:rgba(0,87,212,.5) 0 0 5.05952px .505952px;position:absolute;text-align:center;border-radius:999px;font-size:0;cursor:pointer;opacity:1;z-index:1;-moz-user-select:none;\r\n  /* 禁止双击节点被选中 */-o-user-select:none;-khtml-user-select:none;-webkit-user-select:none;-ms-user-select:none;user-select:none;-moz-user-drag:none;\r\n  /* 禁止被拖动 */-webkit-user-drag:none\r\n  /* 禁止被拖动 */}.slider-btn i[data-v-0bff2c70]{display:inline-block;width:0;vertical-align:middle}.slider-btn uni-image[data-v-0bff2c70]{width:18px;height:13px;-moz-user-select:none;\r\n  /* 禁止双击节点被选中 */-o-user-select:none;-khtml-user-select:none;-webkit-user-select:none;-ms-user-select:none;user-select:none;-moz-user-drag:none;\r\n  /* 禁止被拖动 */-webkit-user-drag:none;\r\n  /* 禁止被拖动 */pointer-events:none;display:inline-block;vertical-align:middle}uni-view[data-v-0bff2c70]{overflow:visible!important}.slider-refresh[data-v-0bff2c70]{\r\n\t/* background-color: #1bc300; */position:absolute;cursor:pointer;left:0;top:0;z-index:2;font-size:30px;height:30px;line-height:30px}[data-v-0bff2c70] .slider-tools-btn{\r\n\t/* background-color: #409eff; */position:relative;width:25px!important;height:25px!important}\r\n/* tips */.lang-tips a[data-v-0bff2c70]{\r\n\t/* background-color: #ff0; */text-decoration:none;color:#409eff}.lang-tips-item[data-v-0bff2c70]{position:fixed;font-size:14px;color:#525252;max-width:340px;margin-top:40px;margin-left:0;background:#fff;padding:7px 10px;border-radius:4px;margin-left:-8px}.lang-tips-left[data-v-0bff2c70]{margin-top:-10px;margin-left:-140px}.lang-tips-left[data-v-0bff2c70]:after{content:"";position:absolute;border-top:10px solid transparent;border-bottom:10px solid transparent;border-left:10px solid #000;border-right:10px solid transparent;right:-18px;top:12px}.lang-tips-bottom[data-v-0bff2c70]{margin-top:50px}.lang-tips-bottom[data-v-0bff2c70]:after{content:"";position:absolute;border-top:10px solid transparent;border-bottom:10px solid #fff;border-left:10px solid transparent;border-right:10px solid transparent;\r\n  /* right: calc(50% - 10px); */left:10px;top:-20px}\r\n/* tips */.slider-tools-btn uni-image[data-v-0bff2c70]{\r\n\t/* background-color: #ff0; */width:100%!important;height:100%!important}.slider-shock[data-v-0bff2c70]{-webkit-animation-delay:0s;animation-delay:0s;-webkit-animation-name:shock-data-v-0bff2c70;animation-name:shock-data-v-0bff2c70;-webkit-animation-duration:.1s;animation-duration:.1s;-webkit-animation-iteration-count:5;animation-iteration-count:5;-webkit-animation-direction:normal;animation-direction:normal;-webkit-animation-timing-function:linear;animation-timing-function:linear}@-webkit-keyframes shock-data-v-0bff2c70{0%{margin-left:2px}100%{margin-left:-2px}}@keyframes shock-data-v-0bff2c70{0%{margin-left:2px}100%{margin-left:-2px}}',
          "",
        ]),
        (t.exports = e);
    },
    "19e0": function (t, e, i) {
      var o = i("1225");
      o.__esModule && (o = o.default),
        "string" === typeof o && (o = [[t.i, o, ""]]),
        o.locals && (t.exports = o.locals);
      var s = i("967d").default;
      s("757b2111", o, !0, { sourceMap: !1, shadowMode: !1 });
    },
    "26c4": function (t, e, i) {
      "use strict";
      var o = i("5132"),
        s = i.n(o);
      s.a;
    },
    3268: function (t, e, i) {
      "use strict";
      i.r(e);
      var o = i("9ed2"),
        s = i("e05d");
      for (var n in s)
        ["default"].indexOf(n) < 0 &&
          (function (t) {
            i.d(e, t, function () {
              return s[t];
            });
          })(n);
      i("bc2f");
      var a = i("828b"),
        r = Object(a["a"])(
          s["default"],
          o["b"],
          o["c"],
          !1,
          null,
          "0bff2c70",
          null,
          !1,
          o["a"],
          void 0,
        );
      e["default"] = r.exports;
    },
    3744: function (t, e, i) {
      t.exports = i.p + "static/vip.png";
    },
    "3a07": function (t, e, i) {
      var o = i("c86c");
      (e = o(!1)),
        e.push([
          t.i,
          '@charset "UTF-8";\r\n/**\r\n * 这里是uni-app内置的常用样式变量\r\n *\r\n * uni-app 官方扩展插件及插件市场（https://ext.dcloud.net.cn）上很多三方插件均使用了这些样式变量\r\n * 如果你是插件开发者，建议你使用scss预处理，并在插件代码中直接使用这些变量（无需 import 这个文件），方便用户通过搭积木的方式开发整体风格一致的App\r\n *\r\n */\r\n/**\r\n * 如果你是App开发者（插件使用者），你可以通过修改这些变量来定制自己的插件主题，实现自定义主题功能\r\n *\r\n * 如果你的项目同样使用了scss预处理，你也可以直接在你的 scss 代码中使用如下变量，同时无需 import 这个文件\r\n */\r\n/* 颜色变量 */\r\n/* 行为相关颜色 */\r\n/* 文字基本颜色 */\r\n/* 背景颜色 */\r\n/* 边框颜色 */\r\n/* 尺寸变量 */\r\n/* 文字尺寸 */\r\n/* 图片尺寸 */\r\n/* Border Radius */\r\n/* 水平间距 */\r\n/* 垂直间距 */\r\n/* 透明度 */\r\n/* 文章场景相关 */uni-view[data-v-c2d489ac], uni-scroll-view[data-v-c2d489ac], uni-swiper-item[data-v-c2d489ac]{display:flex;flex-direction:column;flex-shrink:0;flex-grow:0;flex-basis:auto;align-items:stretch;align-content:flex-start}.uv-divider[data-v-c2d489ac]{display:flex;flex-direction:row;flex-direction:row;align-items:center;margin:15px 0}.uv-divider__text[data-v-c2d489ac]{margin:0 15px}.uv-divider__dot[data-v-c2d489ac]{font-size:12px;margin:0 12px;color:#c0c4cc}',
          "",
        ]),
        (t.exports = e);
    },
    4589: function (t, e, i) {
      "use strict";
      i.r(e);
      var o = i("bc7d"),
        s = i("4ab8");
      for (var n in s)
        ["default"].indexOf(n) < 0 &&
          (function (t) {
            i.d(e, t, function () {
              return s[t];
            });
          })(n);
      i("26c4");
      var a = i("828b"),
        r = Object(a["a"])(
          s["default"],
          o["b"],
          o["c"],
          !1,
          null,
          "c2d489ac",
          null,
          !1,
          o["a"],
          void 0,
        );
      e["default"] = r.exports;
    },
    "4ab8": function (t, e, i) {
      "use strict";
      i.r(e);
      var o = i("6811"),
        s = i.n(o);
      for (var n in o)
        ["default"].indexOf(n) < 0 &&
          (function (t) {
            i.d(e, t, function () {
              return o[t];
            });
          })(n);
      e["default"] = s.a;
    },
    5132: function (t, e, i) {
      var o = i("3a07");
      o.__esModule && (o = o.default),
        "string" === typeof o && (o = [[t.i, o, ""]]),
        o.locals && (t.exports = o.locals);
      var s = i("967d").default;
      s("71a84af6", o, !0, { sourceMap: !1, shadowMode: !1 });
    },
    "5c0b": function (t, e, i) {
      "use strict";
      var o = i("84c3"),
        s = i.n(o);
      s.a;
    },
    6811: function (t, e, i) {
      "use strict";
      i("6a54");
      var o = i("f5bd").default;
      Object.defineProperty(e, "__esModule", { value: !0 }),
        (e.default = void 0);
      var s = o(i("4d8f0")),
        n = o(i("9463")),
        a = o(i("caf4")),
        r = {
          name: "uv-divider",
          mixins: [s.default, n.default, a.default],
          emits: ["click"],
          computed: {
            textStyle: function () {
              var t = {};
              return (
                (t.fontSize = this.$uv.addUnit(this.textSize)),
                (t.color = this.textColor),
                t
              );
            },
            leftLineStyle: function () {
              var t = {};
              return (
                "left" === this.textPosition
                  ? (t.width = "80rpx")
                  : (t.flex = 1),
                t
              );
            },
            rightLineStyle: function () {
              var t = {};
              return (
                "right" === this.textPosition
                  ? (t.width = "80rpx")
                  : (t.flex = 1),
                t
              );
            },
          },
          methods: {
            click: function () {
              this.$emit("click");
            },
          },
        };
      e.default = r;
    },
    7402: function (t, e, i) {
      var o = i("c86c");
      (e = o(!1)),
        e.push([
          t.i,
          '@charset "UTF-8";\r\n/**\r\n * 这里是uni-app内置的常用样式变量\r\n *\r\n * uni-app 官方扩展插件及插件市场（https://ext.dcloud.net.cn）上很多三方插件均使用了这些样式变量\r\n * 如果你是插件开发者，建议你使用scss预处理，并在插件代码中直接使用这些变量（无需 import 这个文件），方便用户通过搭积木的方式开发整体风格一致的App\r\n *\r\n */\r\n/**\r\n * 如果你是App开发者（插件使用者），你可以通过修改这些变量来定制自己的插件主题，实现自定义主题功能\r\n *\r\n * 如果你的项目同样使用了scss预处理，你也可以直接在你的 scss 代码中使用如下变量，同时无需 import 这个文件\r\n */\r\n/* 颜色变量 */\r\n/* 行为相关颜色 */\r\n/* 文字基本颜色 */\r\n/* 背景颜色 */\r\n/* 边框颜色 */\r\n/* 尺寸变量 */\r\n/* 文字尺寸 */\r\n/* 图片尺寸 */\r\n/* Border Radius */\r\n/* 水平间距 */\r\n/* 垂直间距 */\r\n/* 透明度 */\r\n/* 文章场景相关 */\r\n/* 增值服务明细 */.order_service_box[data-v-57ecf9c1]{padding:0 %?30?% %?30?%}.order_service_box .show_more[data-v-57ecf9c1]{text-align:center;color:#ff6a00;font-size:14px;margin-top:%?12?%;padding-top:%?12?%;border-top:%?1?% dashed #eee}.order_service_box .order_service_title[data-v-57ecf9c1]{font-size:15px;color:#333;font-weight:700;margin:%?30?% auto %?10?%}.order_service_box .order_service_item[data-v-57ecf9c1]{padding:%?20?% 0;border-bottom:%?2?% solid #f2f2f2}.order_service_box .order_service_item[data-v-57ecf9c1]:last-child{border-bottom:none}.order_service_box .order_service_item .os_img[data-v-57ecf9c1]{width:%?80?%;height:%?80?%;border-radius:%?8?%;margin-right:%?16?%;flex-shrink:0}.order_service_box .order_service_item .os_info[data-v-57ecf9c1]{flex:1;min-width:0;margin-right:%?16?%}.order_service_box .order_service_item .os_info .os_name[data-v-57ecf9c1]{font-size:13.5px;color:#333}.order_service_box .order_service_item .os_info .os_intro[data-v-57ecf9c1]{font-size:12.4px;color:#999;margin-top:%?6?%}.order_service_box .order_service_item .os_right[data-v-57ecf9c1]{display:flex;flex-direction:column;align-items:flex-end;flex-shrink:0}.order_service_box .order_service_item .os_right .os_num[data-v-57ecf9c1]{font-size:12.4px;color:#999;margin-bottom:%?4?%}.order_service_box .order_service_item .os_right .os_price[data-v-57ecf9c1]{color:#fd2c28;font-weight:700;font-size:14.4px}.user_msg_flex[data-v-57ecf9c1]{justify-content:center;border-bottom:%?14?% solid #f8f8f8;padding:12px 4px}.user_msg_flex .head_msg_box[data-v-57ecf9c1]{margin-right:10px;display:flex;flex-direction:column;justify-content:space-between;max-width:calc(100% - 255px)}.user_msg_flex .head_msg_box .head_frame_box[data-v-57ecf9c1]{display:flex;align-items:center;justify-content:center;position:relative;width:80px;height:80px}.user_msg_flex .head_msg_box .head_frame_box .head_frame[data-v-57ecf9c1]{position:absolute;z-index:10;pointer-events:none}.user_msg_flex .head_msg_box .head_frame_box .head[data-v-57ecf9c1]{position:absolute;z-index:9;width:60px;height:60px;border-radius:100%}.user_msg_flex .head_msg_box .id[data-v-57ecf9c1]{color:#555;font-size:12px;text-align:center;margin-top:1px}.user_msg_flex .name_rights[data-v-57ecf9c1]{width:245px}.user_msg_flex .name_rights .name_box[data-v-57ecf9c1]{display:flex;align-items:center;justify-content:flex-start;margin-top:2px}.user_msg_flex .name_rights .name_box .nickname[data-v-57ecf9c1]{font-size:15px;font-weight:700;max-width:calc(100% - 80px);text-overflow:ellipsis;white-space:nowrap}.user_msg_flex .name_rights .name_box .level[data-v-57ecf9c1]{width:47px;height:14px;object-fit:contain;margin:0 6px 0 7px}.user_msg_flex .name_rights .name_box .vip[data-v-57ecf9c1]{width:20px;height:18px;object-fit:contain;-webkit-filter:grayscale(100%);filter:grayscale(100%)}.user_msg_flex .name_rights .name_box.is_vip .nickname[data-v-57ecf9c1]{color:red}.user_msg_flex .name_rights .name_box.is_vip .vip[data-v-57ecf9c1]{-webkit-filter:grayscale(0);filter:grayscale(0)}.user_msg_flex .name_rights .rights_grid[data-v-57ecf9c1]{margin-top:11px;display:grid;grid-template-columns:repeat(3,1fr);grid-gap:4px}.user_msg_flex .name_rights .rights_grid .rights[data-v-57ecf9c1]{width:79px;height:23px;line-height:23px;border-radius:23px;background:#e30000;color:#fff;font-size:11px;text-align:center;white-space:nowrap}.seller_msg_box[data-v-57ecf9c1]{margin:%?30?% auto 0;align-items:flex-start}.seller_msg_box .head[data-v-57ecf9c1]{width:%?72?%;height:%?72?%;border-radius:100%}.seller_msg_box .txt[data-v-57ecf9c1]{width:calc(100% - %?97?%)}.seller_msg_box .txt .nickname[data-v-57ecf9c1]{height:%?72?%;line-height:%?72?%;font-size:15px}.seller_msg_box .txt .img_box[data-v-57ecf9c1]{margin:%?4?% auto %?20?%;display:grid;grid-template-columns:repeat(3,1fr);grid-gap:%?30?%}.seller_msg_box .txt .img_box img[data-v-57ecf9c1]{width:%?170?%;height:%?170?%}.seller_msg_box .txt .tips[data-v-57ecf9c1]{color:#999;margin:%?6?% auto}.status_box[data-v-57ecf9c1]{padding:%?20?% %?30?% %?30?%;border-bottom:%?14?% solid #f8f8f8}.status_box .status[data-v-57ecf9c1]{justify-content:flex-start}.status_box .status .icon_loading[data-v-57ecf9c1]{display:inline-block;margin:0 %?14?% 0 0;width:%?38?%;height:%?38?%}.status_box .status .tit[data-v-57ecf9c1]{font-weight:700;font-size:16px}.status_box .intro[data-v-57ecf9c1]{color:#999;margin-top:%?10?%}.line_box[data-v-57ecf9c1]{background:#f8f8f8;width:100%;height:%?14?%;margin:0 auto}.block_title[data-v-57ecf9c1]{background:#f8f8f8;padding:%?36?% %?30?%}.reason_box[data-v-57ecf9c1]{padding:%?8?% %?30?%;box-sizing:border-box}.reason_box.remarks_box[data-v-57ecf9c1]{align-items:flex-start}.reason_box .tit[data-v-57ecf9c1]{font-size:15px;font-weight:700;position:relative;z-index:10}.reason_box .tit[data-v-57ecf9c1]::before{z-index:-1;display:block;content:"";width:72%;height:%?20?%;border-radius:%?20?%;background:#ffe610;position:absolute;left:50%;bottom:%?6?%;-webkit-transform:translate(-50%);transform:translate(-50%)}.reason_box .txt[data-v-57ecf9c1]{width:calc(100% - %?150?%)}.reason_box .txt.img_box[data-v-57ecf9c1]{display:grid;grid-template-columns:repeat(3,1fr);grid-gap:%?25?%}.reason_box .txt.img_box img[data-v-57ecf9c1]{border-radius:%?15?%;width:%?162?%;height:%?162?%}.content[data-v-57ecf9c1]{min-height:100vh;padding:0 %?0?% %?130?%}.banShow[data-v-57ecf9c1]{background:#fff;border-radius:%?30?%;padding:%?0?% %?46?% %?30?%;text-align:center}.banShow .tit[data-v-57ecf9c1]{font-weight:700;padding:%?40?% 0;font-size:17px}.banShow .prompt[data-v-57ecf9c1]{margin:%?6?% auto;line-height:1.5;color:#999}.banShow .red[data-v-57ecf9c1]{color:#fd2c28}.banShow .btn[data-v-57ecf9c1]{background:#ffe610;width:50%;font-size:16px;font-weight:700;height:%?80?%;line-height:%?80?%;border-radius:%?80?%;margin:%?62?% auto %?5?%}.top_box[data-v-57ecf9c1]{padding:%?30?% 0;margin:0 %?30?%;border-bottom:%?2?% solid #eee}.top_box uni-view[data-v-57ecf9c1]{font-size:13px;white-space:nowrap}.top_box .order_num[data-v-57ecf9c1]{justify-content:flex-start;flex:1}.top_box .order_num .num[data-v-57ecf9c1]{font-weight:700}.top_box .order_num .copy_btn[data-v-57ecf9c1]{margin-left:%?12?%;color:#2979ff}.top_box .status[data-v-57ecf9c1]{font-size:12px;font-weight:700}.msg_box[data-v-57ecf9c1]{padding:0 %?30?%}.msg_box .goods_msg[data-v-57ecf9c1]{margin:%?35?% auto %?45?%;padding-bottom:%?4?%;position:relative;padding-right:%?114?%}.msg_box .goods_msg .zhiding[data-v-57ecf9c1]{position:absolute;top:0;right:0;padding:0 %?14?%;height:%?40?%;line-height:%?40?%;border-radius:%?40?%;background:#fff1d4;color:#fd6400;font-size:12px;font-weight:700;white-space:nowrap}.msg_box .goods_msg .img[data-v-57ecf9c1]{width:%?120?%;height:%?120?%;border-radius:%?10?%;position:relative;top:%?4?%}.msg_box .goods_msg .txt[data-v-57ecf9c1]{width:calc(100% - %?145?%)}.msg_box .goods_msg .txt .price_box .price[data-v-57ecf9c1]{color:#fd2c28;font-weight:700;font-size:18px}.msg_box .goods_msg .txt .price_box .price .unit[data-v-57ecf9c1]{font-size:13px}.msg_box .goods_msg .txt .name[data-v-57ecf9c1]{margin:%?6?% auto %?2?%;font-weight:700}.msg_box .goods_msg .txt .intro[data-v-57ecf9c1]{font-size:13px;color:#999}.msg_box .tips[data-v-57ecf9c1]{margin:%?28?% auto}.msg_box .tips uni-view[data-v-57ecf9c1]{color:#999;font-size:14.4px}.msg_box .tips .tit[data-v-57ecf9c1]{color:#444}.msg_box .tips .remark[data-v-57ecf9c1]{flex:1;text-align:right;margin-left:%?150?%}.msg_box .tips .copy_btn[data-v-57ecf9c1]{margin-left:%?14?%;color:#2979ff}.msg_box .tips .real_money[data-v-57ecf9c1]{color:#fd2c28;font-weight:700;font-size:15px}.msg_box .tips .real_money .unit[data-v-57ecf9c1]{font-size:11px}.prize_list_box[data-v-57ecf9c1]{background:#fffbe6;border-radius:%?16?%;padding:%?24?%;margin-bottom:%?24?%;border:%?2?% solid #ffe066}.prize_list_box .prize_list_title[data-v-57ecf9c1]{font-size:16px;font-weight:700;color:#d4a800;margin-bottom:%?16?%}.prize_list_box .prize_list[data-v-57ecf9c1]{display:flex;flex-direction:column;gap:%?12?%}.prize_list_box .prize_item[data-v-57ecf9c1]{background:#fff;border-radius:%?12?%;padding:%?12?%;align-items:center}.prize_list_box .prize_item .prize_img[data-v-57ecf9c1]{width:%?80?%;height:%?80?%;border-radius:%?8?%;margin-right:%?16?%}.prize_list_box .prize_item .prize_txt[data-v-57ecf9c1]{flex:1;display:flex;align-items:center;gap:%?8?%}.prize_list_box .prize_item .prize_txt .prize_label[data-v-57ecf9c1]{background:linear-gradient(135deg,#ff6a00,#ff8c00);color:#fff;font-size:10px;padding:%?2?% %?8?%;border-radius:%?4?%;font-weight:700}.prize_list_box .prize_item .prize_txt .prize_name[data-v-57ecf9c1]{font-size:14px;color:#333}.prize_list_box .prize_item .prize_count[data-v-57ecf9c1]{font-size:14px;color:#999;font-weight:700}.prize_list_box .show_more[data-v-57ecf9c1]{text-align:center;color:#ff6a00;font-size:14px;margin-top:%?12?%;padding-top:%?12?%;border-top:%?1?% dashed #ffe066}.cash_box[data-v-57ecf9c1]{background:#fff;position:fixed;left:0;right:0;bottom:0;max-width:480px;width:100%;margin:0 auto;box-shadow:0 0 %?10?% #ddd;padding:%?25?%;z-index:99}.cash_box .total_box uni-view[data-v-57ecf9c1],\r\n.cash_box .total_box uni-text[data-v-57ecf9c1]{white-space:nowrap}.cash_box .total_box .tit[data-v-57ecf9c1]{font-size:12.4px;color:#666}.cash_box .total_box .price[data-v-57ecf9c1]{color:#fd2c28;font-weight:700;font-size:17px}.cash_box .total_box .price .unit[data-v-57ecf9c1]{font-size:12px}.cash_box .btn_box[data-v-57ecf9c1]{justify-content:flex-end}.cash_box .btn_box uni-view[data-v-57ecf9c1]{background:#ffe610;height:%?72?%;line-height:%?72?%;border-radius:%?72?%;font-weight:700;margin-left:%?25?%;padding:0 %?40?%;box-sizing:border-box;font-size:16px}.cash_box .btn_box uni-view[data-v-57ecf9c1]:first-child{margin-left:0}.cash_box .btn_box uni-view.cancle[data-v-57ecf9c1]{background:#eee;color:#666}\r\n/* 随机数抢单等待层 */.rob_mask[data-v-57ecf9c1]{position:fixed;left:0;top:0;right:0;bottom:0;background:rgba(0,0,0,.55);z-index:9999;display:flex;align-items:center;justify-content:center}.rob_box[data-v-57ecf9c1]{width:%?560?%;background:#fff;border-radius:%?20?%;padding:%?50?% %?40?%;display:flex;flex-direction:column;align-items:center}.rob_title[data-v-57ecf9c1]{font-size:%?36?%;font-weight:700;color:#333}.rob_desc[data-v-57ecf9c1]{font-size:%?28?%;color:#fd2c28;margin-top:%?20?%;text-align:center}.rob_count[data-v-57ecf9c1]{font-size:%?26?%;color:#999;margin-top:%?16?%;height:%?36?%}.rob_remain[data-v-57ecf9c1]{font-size:%?40?%;font-weight:700;color:#ffe610;margin-top:%?20?%}.rob_loading[data-v-57ecf9c1]{width:%?60?%;height:%?60?%;margin-top:%?20?%}',
          "",
        ]),
        (t.exports = e);
    },
    "76bd": function (t, e, i) {
      "use strict";
      i.d(e, "b", function () {
        return s;
      }),
        i.d(e, "c", function () {
          return n;
        }),
        i.d(e, "a", function () {
          return o;
        });
      var o = { uvDivider: i("4589").default, uvPopup: i("ce8a").default },
        s = function () {
          var t = this,
            e = t.$createElement,
            o = t._self._c || e;
          return o(
            "v-uni-view",
            { staticClass: "content" },
            [
              o(
                "v-uni-view",
                { staticClass: "status_box" },
                [
                  o(
                    "v-uni-view",
                    { staticClass: "status flex_box" },
                    [
                      1 == t.info.status
                        ? o("img", {
                            staticClass: "icon_loading",
                            attrs: { src: i("7ffd") },
                          })
                        : t._e(),
                      o("v-uni-view", { staticClass: "tit" }, [
                        t._v(t._s(t.info.status_text)),
                      ]),
                    ],
                    1,
                  ),
                  o("v-uni-view", { staticClass: "intro" }, [
                    t._v(t._s(t.info.status_tips)),
                  ]),
                ],
                1,
              ),
              1 == t.info.show_hall_user_rights
                ? o(
                    "v-uni-view",
                    { staticClass: "user_msg_flex flex_box" },
                    [
                      o(
                        "v-uni-view",
                        { staticClass: "head_msg_box" },
                        [
                          o(
                            "v-uni-view",
                            { staticClass: "head_frame_box" },
                            [
                              t.user.avatar_frame
                                ? o("img", {
                                    staticClass: "head_frame",
                                    attrs: { src: t.user.avatar_frame },
                                  })
                                : t._e(),
                              o("v-uni-view", { staticClass: "head" }, [
                                o("img", { attrs: { src: t.user.avatar } }),
                              ]),
                            ],
                            1,
                          ),
                          o("v-uni-view", { staticClass: "id" }, [
                            t._v("ID: " + t._s(t.user.share_code)),
                          ]),
                        ],
                        1,
                      ),
                      o(
                        "v-uni-view",
                        { staticClass: "name_rights" },
                        [
                          o(
                            "v-uni-view",
                            {
                              class: {
                                name_box: !0,
                                is_vip:
                                  1 == t.user.user_vip && 1 == t.vip_status,
                              },
                            },
                            [
                              o("v-uni-view", { staticClass: "nickname" }, [
                                t._v(t._s(t.user.nickname)),
                              ]),
                              o("img", {
                                staticClass: "level",
                                attrs: { src: t.user_level.icon },
                              }),
                              o("img", {
                                staticClass: "vip",
                                attrs: { src: i("3744") },
                              }),
                            ],
                            1,
                          ),
                          o(
                            "v-uni-view",
                            { staticClass: "rights_grid" },
                            t._l(t.user_level.icon_list, function (e, i) {
                              return o(
                                "v-uni-view",
                                {
                                  key: i,
                                  staticClass: "rights",
                                  attrs: { text: e },
                                },
                                [t._v(t._s(e))],
                              );
                            }),
                            1,
                          ),
                        ],
                        1,
                      ),
                    ],
                    1,
                  )
                : t._e(),
              o(
                "v-uni-view",
                { staticClass: "top_box flex_box" },
                [
                  o(
                    "v-uni-view",
                    {
                      staticClass: "order_num flex_box",
                      on: {
                        click: function (e) {
                          (arguments[0] = e = t.$handleEvent(e)),
                            t.copyOrderNum(t.info.order_no);
                        },
                      },
                    },
                    [
                      o("v-uni-view", {}, [t._v("订单编号：")]),
                      o("v-uni-view", { staticClass: "num" }, [
                        t._v(t._s(t.info.order_no)),
                      ]),
                      o("v-uni-view", { staticClass: "copy_btn" }, [
                        t._v("复制"),
                      ]),
                    ],
                    1,
                  ),
                  o("v-uni-view", { staticClass: "status" }, [
                    t._v(t._s(t.info.status_text)),
                  ]),
                ],
                1,
              ),
              o(
                "v-uni-view",
                { staticClass: "msg_box" },
                [
                  0 == t.info.show_goods_des
                    ? o(
                        "v-uni-view",
                        { staticClass: "goods_msg flex_box" },
                        [
                          o("img", {
                            staticClass: "img",
                            attrs: {
                              src: t.info.cat3
                                ? t.info.cat3.thumb
                                : t.info.goods_thumb,
                            },
                          }),
                          o(
                            "v-uni-view",
                            { staticClass: "txt" },
                            [
                              o(
                                "v-uni-view",
                                { staticClass: "price_box flex_box" },
                                [o("v-uni-view", { staticClass: "price" })],
                                1,
                              ),
                              o("v-uni-view", { staticClass: "num" }, [
                                t._v("x " + t._s(t.info.num)),
                              ]),
                              o(
                                "v-uni-view",
                                { staticClass: "name uv-line-2" },
                                [
                                  t._v(
                                    t._s(
                                      t.info.cat3
                                        ? t.info.cat3.name
                                        : t.info.raffle_title
                                          ? t.info.raffle_title
                                          : t.info.goods_name,
                                    ),
                                  ),
                                ],
                              ),
                            ],
                            1,
                          ),
                          t.info.is_zhiding
                            ? o("v-uni-view", { staticClass: "zhiding" }, [
                                t._v("指定单"),
                              ])
                            : t._e(),
                        ],
                        1,
                      )
                    : 0 != t.info.raffle_order &&
                        t.info.prizes &&
                        0 != t.info.prizes.length
                      ? o(
                          "v-uni-view",
                          { staticClass: "goods_msg flex_box" },
                          [
                            o("img", {
                              staticClass: "img",
                              attrs: {
                                src: t.info.raffle_thumb
                                  ? t.info.raffle_thumb
                                  : t.info.goods_thumb,
                              },
                            }),
                            o(
                              "v-uni-view",
                              { staticClass: "txt" },
                              [
                                o(
                                  "v-uni-view",
                                  { staticClass: "price_box flex_box" },
                                  [
                                    o(
                                      "v-uni-view",
                                      { staticClass: "price" },
                                      [
                                        o(
                                          "v-uni-text",
                                          { staticClass: "unit" },
                                          [t._v("￥")],
                                        ),
                                        o("v-uni-text", [
                                          t._v(t._s(t.info.price)),
                                        ]),
                                      ],
                                      1,
                                    ),
                                    o("v-uni-view", { staticClass: "num" }, [
                                      t._v("x " + t._s(t.info.num)),
                                    ]),
                                  ],
                                  1,
                                ),
                                o(
                                  "v-uni-view",
                                  { staticClass: "name uv-line-2" },
                                  [t._v(t._s(t.info.raffle_title))],
                                ),
                                o(
                                  "v-uni-view",
                                  { staticClass: "intro uv-line-2" },
                                  [t._v(t._s(t.info.raffle_intro))],
                                ),
                              ],
                              1,
                            ),
                            t.info.is_zhiding
                              ? o("v-uni-view", { staticClass: "zhiding" }, [
                                  t._v("指定单"),
                                ])
                              : t._e(),
                          ],
                          1,
                        )
                      : o(
                          "v-uni-view",
                          { staticClass: "goods_msg flex_box" },
                          [
                            o("img", {
                              staticClass: "img",
                              attrs: { src: t.info.goods_thumb },
                            }),
                            o(
                              "v-uni-view",
                              { staticClass: "txt" },
                              [
                                o(
                                  "v-uni-view",
                                  { staticClass: "price_box flex_box" },
                                  [
                                    o(
                                      "v-uni-view",
                                      { staticClass: "price" },
                                      [
                                        o(
                                          "v-uni-text",
                                          { staticClass: "unit" },
                                          [t._v("￥")],
                                        ),
                                        o("v-uni-text", [
                                          t._v(t._s(t.info.price)),
                                        ]),
                                      ],
                                      1,
                                    ),
                                    o("v-uni-view", { staticClass: "num" }, [
                                      t._v("x " + t._s(t.info.num)),
                                    ]),
                                  ],
                                  1,
                                ),
                                o(
                                  "v-uni-view",
                                  { staticClass: "name uv-line-2" },
                                  [t._v(t._s(t.info.goods_name))],
                                ),
                                o(
                                  "v-uni-view",
                                  { staticClass: "intro uv-line-2" },
                                  [t._v(t._s(t.info.goods_intro))],
                                ),
                              ],
                              1,
                            ),
                            t.info.is_zhiding
                              ? o("v-uni-view", { staticClass: "zhiding" }, [
                                  t._v("指定单"),
                                ])
                              : t._e(),
                          ],
                          1,
                        ),
                  1 == t.info.show_goods_des &&
                  t.info.raffle_order > 0 &&
                  t.info.prizes &&
                  t.info.prizes.length > 0
                    ? o(
                        "v-uni-view",
                        { staticClass: "prize_list_box" },
                        [
                          o("v-uni-view", { staticClass: "prize_list_title" }, [
                            t._v("抽中奖品"),
                          ]),
                          o(
                            "v-uni-view",
                            { staticClass: "prize_list" },
                            t._l(
                              t.showAllPrizes
                                ? t.info.prizes
                                : t.info.prizes.slice(0, 3),
                              function (e, i) {
                                return o(
                                  "v-uni-view",
                                  {
                                    key: i,
                                    staticClass: "prize_item flex_box",
                                  },
                                  [
                                    o("img", {
                                      staticClass: "prize_img",
                                      attrs: { src: e.goods_thumb },
                                    }),
                                    o(
                                      "v-uni-view",
                                      { staticClass: "prize_txt" },
                                      [
                                        o(
                                          "v-uni-view",
                                          { staticClass: "prize_label" },
                                          [t._v("奖品")],
                                        ),
                                        o(
                                          "v-uni-view",
                                          {
                                            staticClass: "prize_name uv-line-1",
                                          },
                                          [t._v(t._s(e.goods_title))],
                                        ),
                                      ],
                                      1,
                                    ),
                                    e.count > 1
                                      ? o(
                                          "v-uni-view",
                                          { staticClass: "prize_count" },
                                          [t._v("x" + t._s(e.count))],
                                        )
                                      : t._e(),
                                  ],
                                  1,
                                );
                              },
                            ),
                            1,
                          ),
                          t.info.prizes.length > 3
                            ? o(
                                "v-uni-view",
                                {
                                  staticClass: "show_more",
                                  on: {
                                    click: function (e) {
                                      (arguments[0] = e = t.$handleEvent(e)),
                                        (t.showAllPrizes = !t.showAllPrizes);
                                    },
                                  },
                                },
                                [
                                  t._v(
                                    " " +
                                      t._s(
                                        t.showAllPrizes
                                          ? "收起"
                                          : "展开全部(" +
                                              t.info.prizes.length +
                                              "个)",
                                      ) +
                                      " ",
                                  ),
                                ],
                              )
                            : t._e(),
                        ],
                        1,
                      )
                    : t._e(),
                ],
                1,
              ),
              t.info.order_service && t.info.order_service.length > 0
                ? o("v-uni-view", { staticClass: "line_box" })
                : t._e(),
              t.info.order_service && t.info.order_service.length > 0
                ? o(
                    "v-uni-view",
                    { staticClass: "order_service_box" },
                    [
                      o("v-uni-view", { staticClass: "order_service_title" }, [
                        t._v("增值服务"),
                      ]),
                      t._l(
                        t.showAllServices
                          ? t.info.order_service
                          : t.info.order_service.slice(0, 3),
                        function (e) {
                          return o(
                            "v-uni-view",
                            {
                              key: e.id,
                              staticClass: "order_service_item flex_box",
                            },
                            [
                              e.image
                                ? o("img", {
                                    staticClass: "os_img",
                                    attrs: { src: e.image, mode: "aspectFill" },
                                    on: {
                                      click: function (i) {
                                        (arguments[0] = i = t.$handleEvent(i)),
                                          t.previewImage(
                                            e.image,
                                            t.info.order_service
                                              .filter(function (t) {
                                                return t.image;
                                              })
                                              .map(function (t) {
                                                return t.image;
                                              }),
                                          );
                                      },
                                    },
                                  })
                                : t._e(),
                              o(
                                "v-uni-view",
                                { staticClass: "os_info" },
                                [
                                  o(
                                    "v-uni-view",
                                    { staticClass: "os_name uv-line-1" },
                                    [t._v(t._s(e.name))],
                                  ),
                                  e.intro
                                    ? o(
                                        "v-uni-view",
                                        { staticClass: "os_intro uv-line-2" },
                                        [t._v(t._s(e.intro))],
                                      )
                                    : t._e(),
                                ],
                                1,
                              ),
                              o(
                                "v-uni-view",
                                { staticClass: "os_right" },
                                [
                                  o("v-uni-view", { staticClass: "os_num" }, [
                                    t._v("x" + t._s(e.num)),
                                  ]),
                                  o("v-uni-view", { staticClass: "os_price" }, [
                                    t._v("￥" + t._s(e.money)),
                                  ]),
                                ],
                                1,
                              ),
                            ],
                            1,
                          );
                        },
                      ),
                      t.info.order_service.length > 3
                        ? o(
                            "v-uni-view",
                            {
                              staticClass: "show_more",
                              on: {
                                click: function (e) {
                                  (arguments[0] = e = t.$handleEvent(e)),
                                    (t.showAllServices = !t.showAllServices);
                                },
                              },
                            },
                            [
                              t._v(
                                " " +
                                  t._s(
                                    t.showAllServices
                                      ? "收起"
                                      : "展开全部(" +
                                          t.info.order_service.length +
                                          "个)",
                                  ) +
                                  " ",
                              ),
                            ],
                          )
                        : t._e(),
                    ],
                    2,
                  )
                : t._e(),
              o("v-uni-view", { staticClass: "line_box" }),
              o(
                "v-uni-view",
                { staticClass: "msg_box" },
                [
                  o(
                    "v-uni-view",
                    { staticClass: "tips flex_box" },
                    [
                      o("v-uni-view", { staticClass: "tit" }, [t._v("大区")]),
                      o("v-uni-view", [t._v(t._s(t.info.game_area_text))]),
                    ],
                    1,
                  ),
                  null != t.info.seller
                    ? o(
                        "v-uni-view",
                        {
                          staticClass: "tips flex_box",
                          on: {
                            click: function (e) {
                              (arguments[0] = e = t.$handleEvent(e)),
                                t.callPhone(t.info.seller.mobile);
                            },
                          },
                        },
                        [
                          o("v-uni-view", { staticClass: "tit" }, [
                            t._v("手机号"),
                          ]),
                          o(
                            "v-uni-view",
                            [
                              t._v(" " + t._s(t.info.seller.mobile) + " "),
                              o("v-uni-text", { staticClass: "copy_btn" }, [
                                t._v("拨打电话"),
                              ]),
                            ],
                            1,
                          ),
                        ],
                        1,
                      )
                    : t._e(),
                  1 == t.info.show_goods_des
                    ? o(
                        "v-uni-view",
                        { staticClass: "tips flex_box" },
                        [
                          o("v-uni-view", { staticClass: "tit" }, [
                            t._v("服务费"),
                          ]),
                          o("v-uni-view", [t._v(t._s(t.info.service_fee))]),
                        ],
                        1,
                      )
                    : t._e(),
                  o(
                    "v-uni-view",
                    { staticClass: "tips flex_box" },
                    [
                      o("v-uni-view", { staticClass: "tit" }, [
                        t._v("支付方式"),
                      ]),
                      o("v-uni-view", [t._v(t._s(t.info.pay_type_text))]),
                    ],
                    1,
                  ),
                  o(
                    "v-uni-view",
                    { staticClass: "tips flex_box" },
                    [
                      o("v-uni-view", { staticClass: "tit" }, [
                        t._v("订单备注"),
                      ]),
                      o("v-uni-view", { staticClass: "remark uv-line-3" }, [
                        t._v(t._s(t.info.remark ? t.info.remark : "无")),
                      ]),
                    ],
                    1,
                  ),
                  o(
                    "v-uni-view",
                    { staticClass: "tips flex_box" },
                    [
                      o("v-uni-view", { staticClass: "tit" }, [
                        t._v("下单时间"),
                      ]),
                      o("v-uni-view", [t._v(t._s(t.info.add_time))]),
                    ],
                    1,
                  ),
                  o(
                    "v-uni-view",
                    { staticClass: "tips flex_box" },
                    [
                      o("v-uni-view", { staticClass: "tit" }, [
                        t._v("付款时间"),
                      ]),
                      o("v-uni-view", [
                        t._v(t._s(t.info.pay_time ? t.info.pay_time : "-")),
                      ]),
                    ],
                    1,
                  ),
                  o(
                    "v-uni-view",
                    { staticClass: "tips flex_box" },
                    [
                      o("v-uni-view", { staticClass: "tit" }, [
                        t._v("完成时间"),
                      ]),
                      o("v-uni-view", [
                        t._v(t._s(t.info.end_time ? t.info.end_time : "-")),
                      ]),
                    ],
                    1,
                  ),
                  o(
                    "v-uni-view",
                    { staticClass: "tips flex_box" },
                    [
                      o("v-uni-view", { staticClass: "tit" }, [
                        t._v("接受状态"),
                      ]),
                      o("v-uni-view", [
                        t._v(
                          t._s(
                            1 == t.info.is_accept
                              ? "已接受"
                              : 2 == t.info.is_accept
                                ? "已拒绝"
                                : "-",
                          ),
                        ),
                      ]),
                    ],
                    1,
                  ),
                ],
                1,
              ),
              t.info.start_imgs
                ? o("uv-divider", {
                    staticClass: "block_title",
                    attrs: { text: "订单已发货", textSize: "13" },
                  })
                : t._e(),
              t.info.start_imgs
                ? o(
                    "v-uni-view",
                    { staticClass: "reason_box flex_box" },
                    [
                      o("v-uni-view", { staticClass: "tit" }, [
                        t._v("发货证明"),
                      ]),
                      o(
                        "v-uni-view",
                        { staticClass: "txt img_box" },
                        t._l(t.info.start_imgs, function (e, i) {
                          return o("img", {
                            key: i,
                            attrs: { text: e, src: e },
                            on: {
                              click: function (i) {
                                (arguments[0] = i = t.$handleEvent(i)),
                                  t.previewImage(e, t.info.start_imgs);
                              },
                            },
                          });
                        }),
                        0,
                      ),
                    ],
                    1,
                  )
                : t._e(),
              1 == t.info.status && 1 == t.info.confirm
                ? o("uv-divider", {
                    staticClass: "block_title",
                    attrs: { text: "打手已确认接单", textSize: "13" },
                  })
                : t._e(),
              1 == t.info.status && 1 == t.info.confirm
                ? o(
                    "v-uni-view",
                    { staticClass: "reason_box flex_box" },
                    [
                      o("v-uni-view", { staticClass: "tit" }, [
                        t._v("温馨提示:"),
                      ]),
                      o("v-uni-view", { staticClass: "txt" }, [
                        t._v("打手已上线, 请及时上号等待通过好友申请"),
                      ]),
                    ],
                    1,
                  )
                : t._e(),
              o(
                "v-uni-view",
                { staticClass: "cash_box flex_box" },
                [
                  0 == t.info.show_goods_des
                    ? o(
                        "v-uni-view",
                        { staticClass: "total_box flex_box" },
                        [o("v-uni-view", { staticClass: "price" })],
                        1,
                      )
                    : o(
                        "v-uni-view",
                        { staticClass: "total_box flex_box" },
                        [
                          o("v-uni-view", { staticClass: "tit" }, [
                            t._v("到手:"),
                          ]),
                          o(
                            "v-uni-view",
                            { staticClass: "price" },
                            [
                              o("v-uni-text", { staticClass: "unit" }, [
                                t._v("￥"),
                              ]),
                              o("v-uni-text", [
                                t._v(t._s(t.info.seller_money)),
                              ]),
                            ],
                            1,
                          ),
                        ],
                        1,
                      ),
                  o(
                    "v-uni-view",
                    { staticClass: "btn_box flex_box" },
                    [
                      1 == t.info.status &&
                      t.info.seller_id > 0 &&
                      0 == t.info.is_accept
                        ? o(
                            "v-uni-view",
                            {
                              staticStyle: {
                                "background-color": "#3c9cff",
                                color: "#fff",
                              },
                              on: {
                                click: function (e) {
                                  (arguments[0] = e = t.$handleEvent(e)),
                                    t.confirmOrder(1);
                                },
                              },
                            },
                            [t._v("接受")],
                          )
                        : t._e(),
                      1 == t.info.status &&
                      t.info.seller_id > 0 &&
                      0 == t.info.is_accept
                        ? o(
                            "v-uni-view",
                            {
                              staticStyle: {
                                "background-color": "#fd2c28",
                                color: "#fff",
                              },
                              on: {
                                click: function (e) {
                                  (arguments[0] = e = t.$handleEvent(e)),
                                    t.confirmOrder(2);
                                },
                              },
                            },
                            [t._v("拒绝")],
                          )
                        : t._e(),
                      1 == t.info.status
                        ? o(
                            "v-uni-view",
                            {
                              on: {
                                click: function (e) {
                                  (arguments[0] = e = t.$handleEvent(e)),
                                    t.openSlider.apply(void 0, arguments);
                                },
                              },
                            },
                            [t._v("接单")],
                          )
                        : 6 == t.info.status
                          ? o("v-uni-view", [t._v("订单已退款")])
                          : 7 == t.info.status
                            ? o("v-uni-view", [t._v("订单已取消")])
                            : o(
                                "v-uni-view",
                                [
                                  t.info.seller_id == t.info.my_user_id
                                    ? o("v-uni-view", [t._v("已接单")])
                                    : o("v-uni-view", [
                                        t._v("已经被别人抢走了"),
                                      ]),
                                ],
                                1,
                              ),
                    ],
                    1,
                  ),
                ],
                1,
              ),
              o(
                "uv-popup",
                { ref: "banShow", attrs: { mode: "center", bgColor: "none" } },
                [
                  o(
                    "v-uni-view",
                    { staticClass: "banShow" },
                    [
                      o("v-uni-view", { staticClass: "tit" }, [
                        t._v("温馨提示"),
                      ]),
                      o("v-uni-view", { staticClass: "prompt red" }, [
                        t._v(
                          "当前订单还有" +
                            t._s(t.info.seconds) +
                            "分钟才可以取消",
                        ),
                      ]),
                      o("v-uni-view", { staticClass: "prompt" }, [
                        t._v(
                          "如需提醒打手发货, 您可以直接拨打打手电话联系对方尽快发货哦",
                        ),
                      ]),
                      o(
                        "v-uni-view",
                        {
                          staticClass: "btn",
                          on: {
                            click: function (e) {
                              (arguments[0] = e = t.$handleEvent(e)),
                                t.closeBanShow.apply(void 0, arguments);
                            },
                          },
                        },
                        [t._v("确定")],
                      ),
                    ],
                    1,
                  ),
                ],
                1,
              ),
              o(
                "slider-captcha",
                {
                  attrs: { options: t.options, loading: t.loading },
                  on: {
                    check: function (e) {
                      (arguments[0] = e = t.$handleEvent(e)),
                        t.checkSlider.apply(void 0, arguments);
                    },
                    close: function (e) {
                      (arguments[0] = e = t.$handleEvent(e)),
                        t.closeSlider.apply(void 0, arguments);
                    },
                    refresh: function (e) {
                      (arguments[0] = e = t.$handleEvent(e)),
                        t.getSliderOptions.apply(void 0, arguments);
                    },
                    error: function (e) {
                      (arguments[0] = e = t.$handleEvent(e)),
                        t.getSliderOptions.apply(void 0, arguments);
                    },
                  },
                  scopedSlots: t._u([
                    {
                      key: "title",
                      fn: function () {
                        return [t._v("安全验证")];
                      },
                      proxy: !0,
                    },
                    {
                      key: "successText",
                      fn: function () {
                        return [t._v("验证成功-接单中..")];
                      },
                      proxy: !0,
                    },
                    {
                      key: "errorText",
                      fn: function () {
                        return [t._v("验证失败,请重新验证!")];
                      },
                      proxy: !0,
                    },
                    {
                      key: "tips",
                      fn: function () {
                        return [t._v("拖动下方滑块完成拼图")];
                      },
                      proxy: !0,
                    },
                    {
                      key: "question",
                      fn: function () {
                        return [
                          t._v("拖动滑块，把小图拼到对应位置，完成验证~"),
                        ];
                      },
                      proxy: !0,
                    },
                  ]),
                  model: {
                    value: t.visible,
                    callback: function (e) {
                      t.visible = e;
                    },
                    expression: "visible",
                  },
                },
                [
                  o(
                    "v-uni-view",
                    { staticClass: "tips_box" },
                    [
                      o(
                        "v-uni-view",
                        { attrs: { slot: "title" }, slot: "title" },
                        [t._v("安全验证")],
                      ),
                      o(
                        "v-uni-view",
                        { attrs: { slot: "successText" }, slot: "successText" },
                        [t._v("验证成功-接单中..")],
                      ),
                      o(
                        "v-uni-view",
                        { attrs: { slot: "errorText" }, slot: "errorText" },
                        [t._v("验证失败,请重新验证!")],
                      ),
                      o(
                        "v-uni-view",
                        { attrs: { slot: "tips" }, slot: "tips" },
                        [t._v("拖动下方滑块完成拼图")],
                      ),
                      o(
                        "v-uni-view",
                        { attrs: { slot: "question" }, slot: "question" },
                        [t._v("拖动滑块，把小图拼到对应位置，完成验证~")],
                      ),
                    ],
                    1,
                  ),
                ],
                1,
              ),
              t.robWaiting
                ? o(
                    "v-uni-view",
                    { staticClass: "rob_mask" },
                    [
                      o(
                        "v-uni-view",
                        { staticClass: "rob_box" },
                        [
                          o("v-uni-view", { staticClass: "rob_title" }, [
                            t._v("抢单分配中"),
                          ]),
                          o("v-uni-view", { staticClass: "rob_desc" }, [
                            t._v(
                              t._s(
                                "win" == t.robResult
                                  ? "恭喜抢单成功"
                                  : "lose" == t.robResult
                                    ? "很遗憾未抢到"
                                    : "",
                              ),
                            ),
                          ]),
                          t.robResult
                            ? o("v-uni-view", { staticClass: "rob_count" })
                            : o("v-uni-view", { staticClass: "rob_count" }, [
                                t._v("当前参与：" + t._s(t.robCount) + " 人"),
                              ]),
                          t.robResult
                            ? t._e()
                            : o("v-uni-view", { staticClass: "rob_remain" }, [
                                t._v(t._s(t.robRemain) + "s"),
                              ]),
                          t.robResult
                            ? t._e()
                            : o("v-uni-image", {
                                staticClass: "rob_loading",
                                attrs: {
                                  src: "/static/loading.gif",
                                  mode: "aspectFit",
                                },
                              }),
                        ],
                        1,
                      ),
                    ],
                    1,
                  )
                : t._e(),
            ],
            1,
          );
        },
        n = [];
    },
    "792d": function (t, e, i) {
      "use strict";
      i("6a54");
      var o = i("f5bd").default;
      Object.defineProperty(e, "__esModule", { value: !0 }),
        (e.default = void 0),
        i("0c26");
      var s = i("e74a"),
        n = o(i("3268")),
        a = {
          components: { SliderCaptcha: n.default },
          data: function () {
            return {
              id: 0,
              info: { seller: {}, show_hall_user_rights: 0 },
              showAllPrizes: !1,
              showAllServices: !1,
              visible: !1,
              loading: !1,
              options: {},
              user_level: [],
              user: [],
              vip_status: 0,
              robWaiting: !1,
              robRemain: 0,
              robCount: 0,
              robResult: "",
              robTimer: null,
            };
          },
          onLoad: function (t) {
            this.id = t.id;
          },
          onShow: function () {
            this.getHallInfo();
          },
          onHide: function () {
            this.stopRobWaiting();
          },
          onUnload: function () {
            this.stopRobWaiting();
          },
          onPullDownRefresh: function () {
            var t = this;
            uni.showLoading({ title: "刷新中" }),
              setTimeout(function () {
                uni.hideLoading(),
                  t.getHallInfo(),
                  uni.showToast({ title: "刷新成功", duration: 1e3 }),
                  uni.stopPullDownRefresh();
              }, 300);
          },
          methods: {
            previewImage: function (t, e) {
              uni.previewImage({ current: t, urls: e });
            },
            copyOrderNum: function (t) {
              uni.setClipboardData({
                data: t.trim(),
                success: function () {
                  uni.$uv.toast("复制成功");
                },
                fail: function () {
                  uni.$uv.toast("复制失败");
                },
              });
            },
            getHallInfo: function () {
              var t = this;
              uni.showLoading({ title: "加载中.." }),
                (0, s.send)(
                  "/wechat/Order/getHallInfo",
                  { id: this.id },
                  !1,
                ).then(function (e) {
                  uni.hideLoading();
                  var i = e.status,
                    o = e.msg,
                    s = e.data;
                  if (1 != i) return uni.$uv.toast(o);
                  (t.info = s),
                    (t.showAllPrizes = !1),
                    (t.user_level = s.user_level),
                    (t.user = s.user),
                    (t.vip_status = s.vip_status);
                });
            },
            jump: function (t) {
              uni.navigateTo({ url: t });
            },
            cancleOrder: function () {
              var t = this;
              this.info.seconds > 0
                ? this.$refs.banShow.open()
                : uni.showModal({
                    title: "请输入取消原因",
                    content: "",
                    editable: !0,
                    success: function (e) {
                      if ((console.log(e), e.confirm)) {
                        if ("" == e.content)
                          return uni.$uv.toast("取消原因不能为空");
                        t.subCancel(e.content);
                      }
                    },
                  });
            },
            closeBanShow: function () {
              this.$refs.banShow.close();
            },
            subCancel: function (t) {
              var e = this;
              uni.showLoading({ title: "加载中.." }),
                (0, s.send)(
                  "/wechat/Order/userCancleOrder",
                  { id: this.id, cancel_reason: t },
                  !1,
                ).then(function (t) {
                  uni.hideLoading();
                  var i = t.status,
                    o = t.msg;
                  t.data;
                  if (1 != i) return uni.$uv.toast(o);
                  uni.$uv.toast(o), e.getHallInfo();
                });
            },
            callPhone: function (t) {
              uni.makePhoneCall({
                phoneNumber: t,
                success: function () {
                  console.log("拨打电话成功");
                },
                fail: function (t) {
                  console.error("拨打电话失败", t);
                },
              });
            },
            confirmOrder: function (t) {
              var e = this,
                i = "";
              1 == t && (i = "确认要接受么? 接受之后系统将不自动随机派单"),
                2 == t && (i = "确认要拒绝么? 拒绝之后系统将随机派给其它打手"),
                uni.showModal({
                  title: "温馨提示",
                  content: i,
                  success: function (i) {
                    i.confirm &&
                      (uni.showLoading({ title: "加载中.." }),
                      (0, s.send)(
                        "/wechat/Order/confirmOrder",
                        { id: e.id, type: t },
                        !1,
                      ).then(function (i) {
                        uni.hideLoading();
                        var o = i.status,
                          s = i.msg;
                        i.data;
                        return 402 == o
                          ? uni.showToast({
                              title: s,
                              icon: "error",
                              duration: 2e3,
                            })
                          : 1 != o
                            ? uni.$uv.toast(s)
                            : (uni.$uv.toast(s),
                              setTimeout(function () {
                                e.getHallInfo();
                              }, 1500),
                              void (
                                1 != t &&
                                2 == t &&
                                setTimeout(function () {
                                  uni.navigateBack({ delta: 1 });
                                }, 2e3)
                              ));
                      }));
                  },
                });
            },
            openSlider: function () {
              var t = this;
              1 == t.info.order_captcha
                ? ((t.visible = !0), t.getSliderOptions())
                : uni.showModal({
                    title: "温馨提示",
                    content: "确认要接单么 ?",
                    success: function (e) {
                      e.confirm &&
                        (uni.showLoading({ title: "接单中.." }),
                        t.startOrder());
                    },
                  });
            },
            closeSlider: function () {},
            getSliderOptions: function () {
              var t = this;
              (this.loading = !0),
                (0, s.send)(
                  "/wechat/OrderCaptcha/getSliderOptions",
                  { label: "" },
                  !1,
                ).then(function (e) {
                  var i = e.data,
                    o = i.img,
                    s = i.key,
                    n = i.y;
                  (t.options = { sliderImg: o, sliderKey: s, sliderY: n }),
                    (t.loading = !1);
                });
            },
            checkSlider: function (t, e, i, o) {
              var n = this,
                a = this;
              (this.loading = !0),
                (0, s.send)(
                  "/wechat/OrderCaptcha/checkSlider",
                  { id: this.id, sliderKey: t, sliderX: e },
                  !1,
                ).then(function (t) {
                  n.loading = !1;
                  var e = t.status;
                  t.msg, t.data;
                  1 == e
                    ? (i(),
                      setTimeout(function () {
                        (a.visible = !1),
                          uni.showLoading({ title: "接单中.." }),
                          setTimeout(function () {
                            a.startOrder();
                          }, 300);
                      }, 300))
                    : o();
                });
            },
            startOrder: function () {
              var t = this;
              (0, s.send)("/wechat/Order/startOrder", { id: t.id }, !1).then(
                function (e) {
                  uni.hideLoading();
                  var i = e.status,
                    o = e.msg,
                    s = e.data;
                  return 40019 == i
                    ? uni.showModal({
                        title: "温馨提示",
                        content: o,
                        success: function (e) {
                          e.confirm && t.jump("/pages_sub1/seller/seller_pay");
                        },
                      })
                    : 40020 == i
                      ? uni.showModal({
                          title: "温馨提示",
                          content: o,
                          success: function (e) {
                            e.confirm && t.jump("/pages/pay/deposit");
                          },
                        })
                      : 40021 == i
                        ? uni.showToast({
                            title: o,
                            icon: "error",
                            duration: 2e3,
                          })
                        : 1 != i
                          ? uni.$uv.toast(o)
                          : void (s && "waiting" == s.rob_status
                              ? t.startRobWaiting(s)
                              : (uni.$uv.toast(o),
                                setTimeout(function () {
                                  t.getHallInfo(),
                                    uni.redirectTo({
                                      url: "/pages_sub1/order/seller?current=1",
                                    });
                                }, 1500)));
                },
              );
            },
            startRobWaiting: function (t) {
              (this.robWaiting = !0),
                (this.robResult = ""),
                (this.robRemain = t.remain || 3),
                (this.robCount = t.count || 1),
                this.pollRobResult();
            },
            pollRobResult: function () {
              var t = this;
              this.robTimer && clearTimeout(this.robTimer),
                (this.robTimer = setTimeout(function () {
                  (0, s.send)("/wechat/Order/getRobResult", { id: t.id }, !1)
                    .then(function (e) {
                      var i = e.status,
                        o = e.msg,
                        s = e.data;
                      if (1 != i)
                        return (
                          (t.robResult = "lose"),
                          (t.robWaiting = !1),
                          uni.$uv.toast(o || "抢单失败")
                        );
                      "waiting" == s.rob_status
                        ? ((t.robRemain = s.remain),
                          (t.robCount = s.count),
                          t.pollRobResult())
                        : "win" == s.rob_status
                          ? ((t.robResult = "win"),
                            (t.robWaiting = !1),
                            uni.$uv.toast("抢单成功"),
                            setTimeout(function () {
                              t.getHallInfo(),
                                uni.redirectTo({
                                  url: "/pages_sub1/order/seller?current=1",
                                });
                            }, 1200))
                          : ((t.robResult = "lose"),
                            (t.robWaiting = !1),
                            uni.$uv.toast(s.msg || "抢单失败, 被别人抢走了"),
                            setTimeout(function () {
                              t.getHallInfo();
                            }, 1200));
                    })
                    .catch(function () {
                      t.pollRobResult();
                    });
                }, 800));
            },
            stopRobWaiting: function () {
              this.robTimer &&
                (clearTimeout(this.robTimer), (this.robTimer = null)),
                (this.robWaiting = !1);
            },
          },
        };
      e.default = a;
    },
    "7ffd": function (t, e, i) {
      t.exports = i.p + "static/loading.gif";
    },
    "84c3": function (t, e, i) {
      var o = i("7402");
      o.__esModule && (o = o.default),
        "string" === typeof o && (o = [[t.i, o, ""]]),
        o.locals && (t.exports = o.locals);
      var s = i("967d").default;
      s("e9663fac", o, !0, { sourceMap: !1, shadowMode: !1 });
    },
    "9ed2": function (t, e, i) {
      "use strict";
      i.d(e, "b", function () {
        return o;
      }),
        i.d(e, "c", function () {
          return s;
        }),
        i.d(e, "a", function () {});
      var o = function () {
          var t = this,
            e = t.$createElement,
            i = t._self._c || e;
          return t.dialogVisible
            ? i(
                "v-uni-view",
                {
                  staticClass: "lang-dialog__wrapper",
                  on: {
                    touchmove: function (e) {
                      e.stopPropagation(),
                        e.preventDefault(),
                        (arguments[0] = e = t.$handleEvent(e)),
                        t.moveHandle.apply(void 0, arguments);
                    },
                  },
                },
                [
                  i(
                    "v-uni-view",
                    { staticClass: "lang-dialog" },
                    [
                      i(
                        "v-uni-view",
                        { staticClass: "lang-dialog__header" },
                        [
                          i(
                            "v-uni-view",
                            { staticClass: "lang-dialog__title" },
                            [t._t("title", [t._v(t._s(t.title))])],
                            2,
                          ),
                          i(
                            "v-uni-view",
                            {
                              staticClass: "lang-dialog-header-btn",
                              attrs: { type: "button" },
                              on: {
                                click: function (e) {
                                  (arguments[0] = e = t.$handleEvent(e)),
                                    t.close.apply(void 0, arguments);
                                },
                              },
                            },
                            [i("i", { staticClass: "lang-icon-close" })],
                          ),
                        ],
                        1,
                      ),
                      i(
                        "v-uni-view",
                        { staticClass: "lang-dialog__body" },
                        [
                          i(
                            "v-uni-view",
                            {
                              directives: [
                                {
                                  name: "show",
                                  rawName: "v-show",
                                  value: t.failed,
                                  expression: "failed",
                                },
                              ],
                              staticClass: "tips",
                            },
                            [t._t("errorText", [t._v(t._s(t.errorText))])],
                            2,
                          ),
                          i(
                            "v-uni-view",
                            {
                              directives: [
                                {
                                  name: "show",
                                  rawName: "v-show",
                                  value: !t.failed,
                                  expression: "!failed",
                                },
                              ],
                              staticClass: "tips",
                            },
                            [t._t("tips", [t._v(t._s(t.tips))])],
                            2,
                          ),
                          i(
                            "v-uni-view",
                            {
                              staticClass: "slider-body",
                              class: { "slider-shock": t.shock },
                            },
                            [
                              i("v-uni-view", {
                                directives: [
                                  {
                                    name: "show",
                                    rawName: "v-show",
                                    value: t.mask,
                                    expression: "mask",
                                  },
                                ],
                                staticClass: "loading-transparent-mask",
                              }),
                              t.loading
                                ? i(
                                    "v-uni-view",
                                    { staticClass: "loading-body" },
                                    [
                                      i("v-uni-view", {
                                        staticClass: "loading slider-loading",
                                      }),
                                    ],
                                    1,
                                  )
                                : t._e(),
                              i("v-uni-view", {
                                directives: [
                                  {
                                    name: "show",
                                    rawName: "v-show",
                                    value: t.sliderImg,
                                    expression: "sliderImg",
                                  },
                                ],
                                staticClass: "slider-bg slider-img",
                                style: {
                                  "background-image":
                                    "url(" + t.sliderImg + ")",
                                },
                              }),
                              i("v-uni-view", {
                                directives: [
                                  {
                                    name: "show",
                                    rawName: "v-show",
                                    value: t.sliderImg,
                                    expression: "sliderImg",
                                  },
                                ],
                                staticClass:
                                  "slider-draw slider-move-draw slider-img",
                                style: {
                                  "background-image":
                                    "url(" + t.sliderImg + ")",
                                  top: t.sliderY + "px",
                                  left: t.sliderMoveDrawLeft,
                                },
                                on: {
                                  touchstart: function (e) {
                                    e.stopPropagation(),
                                      (arguments[0] = e = t.$handleEvent(e)),
                                      t.sliderTouchStart.apply(
                                        void 0,
                                        arguments,
                                      );
                                  },
                                  touchmove: function (e) {
                                    if (
                                      !e.type.indexOf("key") &&
                                      t._k(
                                        e.keyCode,
                                        "catch",
                                        void 0,
                                        e.key,
                                        void 0,
                                      )
                                    )
                                      return null;
                                    (arguments[0] = e = t.$handleEvent(e)),
                                      t.sliderTouchMove.apply(
                                        void 0,
                                        arguments,
                                      );
                                  },
                                  touchend: function (e) {
                                    e.stopPropagation(),
                                      (arguments[0] = e = t.$handleEvent(e)),
                                      t.sliderEnd.apply(void 0, arguments);
                                  },
                                  mousedown: function (e) {
                                    (arguments[0] = e = t.$handleEvent(e)),
                                      t.sliderStart.apply(void 0, arguments);
                                  },
                                },
                              }),
                              i("v-uni-view", {
                                staticClass: "slider-progress",
                              }),
                              i(
                                "v-uni-view",
                                {
                                  directives: [
                                    {
                                      name: "show",
                                      rawName: "v-show",
                                      value: t.success,
                                      expression: "success",
                                    },
                                  ],
                                  staticClass: "slider-success",
                                },
                                [
                                  i(
                                    "v-uni-view",
                                    { staticClass: "slider-success-icon" },
                                    [
                                      i("v-uni-image", {
                                        attrs: {
                                          src: "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAGAAAABgCAMAAADVRocKAAAAzFBMVEUAAAAs0AAu1AAs0AAr0AAq1QAs0AAt0AAs0AAs0AAr0AAq0wAs0AAq0QAs0AAs0AAs0AAs0AAr0AAs0AAr0AAs0AAr0QAs0QAs0AApygAs0AAs0AAs0AAs0AAs0QAr0QAt0gAs0AAt0QAtzwAq0QArzwAs0AAqzQAs0QAs0AAs0AAs0AD////l+d/8/vty4FVG1iCI5W/X989G1h881BNy31My0gd34Vr5/vjt++qk65Gd6omO5naB42Za2jdL1ybR9cjA8bNp3kpZ2jY9PuX7AAAAK3RSTlMA/APuFwfUZln0OxLIVEbr49vZzsKxmW1MDvmsqIxpXiGejlA3NGgk1pyDVbbBQAAAArxJREFUaN7Nmody2kAURZ9QQRIyTTTRDDauV3GsFNzjlP//p8CQjAZLwLY3w/mAc9EWZvftIzGS8HIyitp2AAR2OxpNLsOETFHzex5K8Hp+Td/u9DsWdmJ1+o6OvTLoWjiA1R1UFPVutQ0h2lVX5ddXmxCmWZX+ijCGFHEot3BuIM1cYkmd21DAPhcd/TMociY0E7MIysQzgdltQIPGxSH/yRBaBPX9/lMLmgz9vX4Y4HTP+FgwgHWyy78IYIThYsf6bMAQjasyvxvDGLFLRW5gkHnJBMMohYl2bBjFdmibMQwz3vbXYZz61j+0B+N4FcqpgoFq7nebYKDpFj6A6xMqLbDQ+j8LAzAxoA1dMNH9t4kt6PL+/Ov5DwpYm+3chy7fH9M0vctQoE9rOtr+u3TN3Ts+0ln7a5a+f8NrcYzWx0nflD99QQF/FdAz5U8fUKC3CvCgw+fc/2WJAh5RYsr/6R4lJHTB6kdIPqsfU7pl9WNCY1Y/RhSx+hFRCzv4/fPx6Xmp6UeLbJTzsFnb3/T8sClAKcunNE9Q9yMglPMjTfMEdT+wOyBP0PFjzxDlCRr+YN8k5wnKfti7l2lWSFDwo0URhBIU/YhoDLEENT9GdAvBhIL/KwSYkA/RBBU/pnQB4QQFP0JKIJzwJu9HQuQJJ6Tyfk/g2JJp+NETOXhl6n74QkfHTNlv1cQOv5miHx3R43um5kdf+AKSKfktR/wKlSn40ZW5BL49rvealB8DqWvs/evLwxIytCrMF/FL9lICdzGEvZzDXZBiLqmN2IuC7GXNAnMYZM5cWvZcKuGKqTiesxjCCMGC94FiWGd+YvG5H4m4n7nYH+oOMouhTDwjAVz1x1L3OJ57VzhjSDN2SIa6Bym8+rE1Daxwp6JtD1P3OBs3+FtP8uaZa5RwnTfP6JOE0+32n6lo+89fOWa8/GcTqREAAAAASUVORK5CYII=",
                                          alt: "",
                                        },
                                      }),
                                    ],
                                    1,
                                  ),
                                  i(
                                    "v-uni-view",
                                    { staticClass: "slider-success-text" },
                                    [
                                      t._t("successText", [
                                        t._v(t._s(t.successText)),
                                      ]),
                                    ],
                                    2,
                                  ),
                                ],
                                1,
                              ),
                              i(
                                "v-uni-view",
                                {
                                  staticClass: "slider-btn slider-move-btn",
                                  class: { "slider-shock": t.shock },
                                  style: { left: t.sliderMoveLeft },
                                  on: {
                                    touchstart: function (e) {
                                      e.stopPropagation(),
                                        (arguments[0] = e = t.$handleEvent(e)),
                                        t.sliderTouchStart.apply(
                                          void 0,
                                          arguments,
                                        );
                                    },
                                    touchmove: [
                                      function (e) {
                                        e.stopPropagation(),
                                          (arguments[0] = e =
                                            t.$handleEvent(e)),
                                          t.sliderTouchMove.apply(
                                            void 0,
                                            arguments,
                                          );
                                      },
                                      function (e) {
                                        e.stopPropagation(),
                                          e.preventDefault(),
                                          (arguments[0] = e =
                                            t.$handleEvent(e)),
                                          t.moveHandle.apply(void 0, arguments);
                                      },
                                    ],
                                    touchend: function (e) {
                                      e.stopPropagation(),
                                        (arguments[0] = e = t.$handleEvent(e)),
                                        t.sliderEnd.apply(void 0, arguments);
                                    },
                                    mousedown: function (e) {
                                      (arguments[0] = e = t.$handleEvent(e)),
                                        t.sliderStart.apply(void 0, arguments);
                                    },
                                  },
                                },
                                [
                                  i("i", [t._v(" ")]),
                                  i("v-uni-image", {
                                    attrs: {
                                      src: "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAACgAAAAcAgMAAABuexVFAAAACVBMVEUAAADCwsL9/f1P0DqbAAAAAXRSTlMAQObYZgAAAB1JREFUGNNjCGVgYGANABKhyMwoEHMBkIgaZWIwAdyJJQnaJRg5AAAAAElFTkSuQmCC",
                                      alt: "",
                                    },
                                  }),
                                  i("i", [t._v(" ")]),
                                ],
                                1,
                              ),
                            ],
                            1,
                          ),
                          i(
                            "v-uni-view",
                            { staticStyle: { position: "relative" } },
                            [
                              i(
                                "v-uni-view",
                                {
                                  staticClass: "slider-refresh",
                                  staticStyle: { "font-size": "29px" },
                                  on: {
                                    click: function (e) {
                                      e.stopPropagation(),
                                        (arguments[0] = e = t.$handleEvent(e));
                                    },
                                    mouseenter: function (e) {
                                      (arguments[0] = e = t.$handleEvent(e)),
                                        (t.questionMessage = !0);
                                    },
                                    mouseleave: function (e) {
                                      (arguments[0] = e = t.$handleEvent(e)),
                                        (t.questionMessage = !1);
                                    },
                                  },
                                },
                                [
                                  i(
                                    "v-uni-view",
                                    {
                                      staticClass: "slider-tools-btn lang-tips",
                                    },
                                    [
                                      i(
                                        "v-uni-view",
                                        {
                                          directives: [
                                            {
                                              name: "show",
                                              rawName: "v-show",
                                              value: t.questionMessage,
                                              expression: "questionMessage",
                                            },
                                          ],
                                          staticClass:
                                            "lang-tips-item lang-tips-bottom",
                                        },
                                        [
                                          t._t("question", [
                                            t.question
                                              ? i("v-uni-view", [
                                                  t._v(t._s(t.question)),
                                                ])
                                              : i("v-uni-view", [
                                                  t._v(
                                                    " 拖动滑块完成拼图，欢迎提建议！ ",
                                                  ),
                                                  i(
                                                    "a",
                                                    {
                                                      attrs: {
                                                        href: "https://gitee.com/langlanglang/poster",
                                                        target: "_blank",
                                                      },
                                                    },
                                                    [t._v("gitee")],
                                                  ),
                                                  i(
                                                    "a",
                                                    {
                                                      attrs: {
                                                        href: "https://github.com/kkokk/poster",
                                                        target: "_blank",
                                                      },
                                                    },
                                                    [t._v("github")],
                                                  ),
                                                ]),
                                          ]),
                                        ],
                                        2,
                                      ),
                                      i("v-uni-image", {
                                        attrs: {
                                          src: "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAADAAAAAwCAYAAABXAvmHAAAACXBIWXMAABYlAAAWJQFJUiTwAAAAAXNSR0IArs4c6QAAAARnQU1BAACxjwv8YQUAAAVgSURBVHgBzVrZUdxMEG7EcjzuH8EvIvA6Ai8ZmAhgqziLByACRASGB4qzChwBZOAlgl1HYDmDfaIoTn/ferQlNSNpRpJd/qrG8s7ZPdPT1zAlDeDq6qr98PDweWpqqoPyP6o6KG1TEsRoi19fX7/jO8D3bmtrK5aamJKKINHPz887b29vXRapADAyxNjDOsx4M5AQjkV3JbvDtQBmrl9eXg58GfFi4OLiYr9pwjWCIIjW1tYOXPs7MXBychJOT0/f4Lg7eX3Q1seH8t0Hk8P5+flRr9cbsY2ndn9/H7ZarRBtvCefULoFS/KuLLqcRikDl5eXyzjaQ7Hv+ggLHYHYw4RYV3BT8Olix/fxDW1zo/Q2NjZui+YpZMCITJQz+QEmP5QGAGZW8hgpE6lcBvKIh6gczc3NRb47XgZzIhEIXtZtRUxYGTg7O/uMz42laa+pXc8D1qaS+KLrcQdXVldXv+r6dwxwJ8DxQLIyT1lfwqXqy1/A8fFxBxf+m4WGj/pit/RgEK8HCvT+4vb29lAcQa3z9PQU4vInWiv2YZ5rYSOXDC0J2tSE+H5M982cQI7cO4tNiZEbQXXe+hgrmzhhbo6PRDNgROdHujOt4/r6ek8cYI6dOxSWdKVPtIR5nU709PT0EP13UlWj2dnZhUSJBKmGSC/E3RIHkHkjs6FD9xCa7Nv5+XnHoa9Q48lvtZ2AjuNu8iNICLCor8j1qG33houC0GsUGqJYtbVRfyMOMDt9oNbbobiO/2/qumpcDLn/Kg6gERK187QVGP/f5uZmD2UJ/1+g7KqhIWR82WUNcwetpzBmgBypMZE4ApohQwTvDYje1f148ciY6rsijqDLotb9xG9gLGBHdb4TR1gcvKO8vtio65KxuaC/pcZ2KUY8ga5q6Hv65BnZL9IuljZnt5x3gZ5uuo5RYMAwMF0JBpx3n1CTFqpGc9ppePlTDEfV2h2cavBBVQ7EA1C1Pco2C92Nor5QtZn7gjHO1t3Q1ldVYQuThOkaMPRTPGDEbbesH3a/q608L7x4gIES6EuP/0BfKEx3mpmZiaUhkGjOT01lCfxjH2VBMMp7fHxMV7UD3akpPx86/gsNHMpVTtYi8g3gLbS9Z6BB5IoVjZqroSwDGchwlZjoPwGqaBOsR1IBNtp4B8jApAG6tS2e6s0FhvC+1ABjDFUV8wQyqow3W/4AmojmtMbE7zjAP1ptLso/CuaUVNX3QBsTbdiqwsdCuyJx4FJrDALo1tt0ZeIkSU34WGgX0A3R6ph2pEXdiuion240vnYkNeBqoT3QVb+HXGOclcBu3UF0Jh1MfBBJDSRvBphrVJYedIHJ3KUxdq/Hhsz42pmIx2QEKoHEw+QPaIXx8wZz/agjlraoL3FDxgxQjHTEA+xXXZQ7rxYMwdCKVICJ1zO7TycwcUMmroTtFLDovlQA7lOT1jwStfvpbMmEgZxT2K0iSkxgSXYzOLf3PYBy2dHZEpPYiidr6UEgmAGNjpG93QAePRgZM893MF/P0yTKdHDFbMlCusI5uQtiFl2zaXXBOAI03IhDcvedO80O6LinqpmIGtTRTK4wYmNLlPVsp5j7wIFdiCy6t/JrYhmM6uV67zZJJ3Qz9EgB8piQ36nCqKmghLuOE47EkmYpIp4ofeQzrzVXYs/hxChRlYdqh/dmyvwe5r0umsf5mdXIZZg7EbxP45IM+ScFTA6kn1kZKKGtQ5+LHm/R6z5f8DHXUiPPrIqRPJFqCmNb5BNyev+pQdFrYg1Ufm+u/MceqYdqeq4dqQAG+UxlViE8QWUG0kiYMXlWRnS0wmGqCx87SCAN4U9GgQykmshB/QKLND1fMNqj0gAAAABJRU5ErkJggg==",
                                          alt: "",
                                        },
                                      }),
                                    ],
                                    1,
                                  ),
                                ],
                                1,
                              ),
                              i(
                                "v-uni-view",
                                {
                                  staticClass: "slider-refresh",
                                  staticStyle: { left: "35px" },
                                  on: {
                                    click: function (e) {
                                      e.stopPropagation(),
                                        (arguments[0] = e = t.$handleEvent(e)),
                                        t.refresh.apply(void 0, arguments);
                                    },
                                    mouseenter: function (e) {
                                      (arguments[0] = e = t.$handleEvent(e)),
                                        (t.refreshMessage = !0);
                                    },
                                    mouseleave: function (e) {
                                      (arguments[0] = e = t.$handleEvent(e)),
                                        (t.refreshMessage = !1);
                                    },
                                  },
                                },
                                [
                                  i(
                                    "v-uni-view",
                                    {
                                      staticClass: "slider-tools-btn lang-tips",
                                      staticStyle: {
                                        width: "24px",
                                        height: "24px",
                                        "margin-top": "-2px",
                                      },
                                    },
                                    [
                                      i(
                                        "v-uni-view",
                                        {
                                          directives: [
                                            {
                                              name: "show",
                                              rawName: "v-show",
                                              value: t.refreshMessage,
                                              expression: "refreshMessage",
                                            },
                                          ],
                                          staticClass:
                                            "lang-tips-item lang-tips-bottom",
                                        },
                                        [t._v(" 刷新")],
                                      ),
                                      i("v-uni-image", {
                                        attrs: {
                                          src: "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAADAAAAAwCAYAAABXAvmHAAAACXBIWXMAABYlAAAWJQFJUiTwAAAAAXNSR0IArs4c6QAAAARnQU1BAACxjwv8YQUAAAPZSURBVHgB7VpLTuNAEC2b8NlNboDnBJgbJCdgOAFkAQixGDgB9gkIC4T4SIETTOYEhBOQOcF4buAVQojPvGfZGbv9iWMbE0vzpMam3e7Uq66u7q6yJhXh/PzcwKWjaZqJsop7E6XtF8JlwTPn7e3tF64jXMf7+/uOlIAmJTAYDNovLy/f39/fOyxSACSCd29A5r4ImUIEfG1buq5vyD8NlwbI3Ly+vtp5iFAGtpuJQKBxaOtQKhRcgQvF9Hd2duy0BldXV8eQQwMBKzeBs7Mzs9Vq/cCtkdYGpkBzuIcAY9r3ysqK2+v1aPse+cfHRwN9GL65rUHjnYyf5FzpqqNB4VFvodi5CVxeXtLOLUnWuoNn/eXl5dtA2LwIJj4IH0uyYthfb29vbxgWnve5CYRfUgVHsdD5rVQAkNnOIHKEZ1/CcgQE9KxO04SHxk+XlpbWqxKegDD0RF2UpD5PUpQoLUkBzSbhJRd1R/wx+QD49r6N0XD80ZiKxBGgbdKulWoXM7/7UcKHQdOAonp52sYI0FuA/Z1S7Ql/cHAwlpoAb7Wap12MAP28xCeSXafwGY4jhggBmo76IicsJmtfasIswhPqCFjK/w78uyU1YVbhiYkXovZh+1vKc2vWxako+PvcHuDWzvnKiH+0UAeW4rocmM5XmXNMTChJ+9IAeASwaPHwYYQfYKX9KQ2ARwB7cDNcyV1lXbZfFh4B/2AyAba5jdA+4RGAwJFtMvfy0hB4BGAyplLvSEMQeKHICJSNFNQJXRqO/wQ+GwGBiM/3D9uNQEDAUeoNaQg8AoxVRip13ZSGIFgHIgsXFrYNaQiClXgYruTCxrOxNAAeAX/hckL17efn521pACZuVA0oNcWMJgQQiI0c3BmAvbi4+CZzjgkB7v8Twnon8z4XpkUlDMyFXCG+z0KEACczo75Km8Pr6+stmVPEwus0GWj9QaKrMZNz3d3d3VoPOkyq+IvqKG2LH9vMcS4gPrMp0f1RG5P6zj/81wKOOuKjDyAwQPmN/VknqV3ibtSPg6qm5JGAZzqUDwZD+wg03CjVnaS2mRmahGBXgD7CLnbVkQvffAe4jblvmPB6kglPTTFlkHCkohRTjuznUVqAOVeSzzebk5THDopVJFGdQ/BIki8JudOsfvCXiQ8jtTNk3WG797gdLSwsuIuLi044zfr09MTkiclVHte1rOw++hqjr81pSpk5U59hUlWBhO28OYmynxpUucBxK3PKPdkszqHUxx6hRDXTUoXWCMZhcRkWSZQTpQiEEf7cBtc1FAP3RqiJC2EpIF3hH54Coe1hWVf8FxUNF4vY5AiIAAAAAElFTkSuQmCC",
                                          alt: "",
                                        },
                                      }),
                                    ],
                                    1,
                                  ),
                                ],
                                1,
                              ),
                            ],
                            1,
                          ),
                        ],
                        1,
                      ),
                    ],
                    1,
                  ),
                ],
                1,
              )
            : t._e();
        },
        s = [];
    },
    a335: function (t, e, i) {
      "use strict";
      i("6a54"),
        Object.defineProperty(e, "__esModule", { value: !0 }),
        (e.default = void 0);
      var o = {
        name: "SliderCaptcha",
        props: {
          value: { type: Boolean, defalut: !1 },
          modelValue: { type: Boolean, defalut: !1 },
          loading: { type: Boolean, defalut: !1 },
          title: { type: String, default: "滑块安全验证" },
          tips: { type: String, default: "拖动下方滑块完成拼图" },
          successText: { type: String, default: "验证成功" },
          errorText: { type: String, default: "是不是太难了，咱换一个" },
          question: { type: String, default: "" },
          options: {
            type: Object,
            default: function () {
              return { sliderImg: "", sliderKey: "", sliderY: "" };
            },
          },
        },
        watch: {
          value: {
            handler: function (t) {
              this.init(t);
            },
            immediate: !0,
          },
          modelValue: {
            handler: function (t) {
              this.init(t);
            },
            immediate: !0,
          },
          options: {
            handler: function (t) {
              this.clear(),
                (this.sliderImg = t.sliderImg),
                (this.sliderKey = t.sliderKey),
                (this.sliderY = t.sliderY);
            },
            deep: !0,
            immediate: !0,
          },
        },
        data: function () {
          return {
            dialogVisible: !1,
            mask: !1,
            success: !1,
            failed: !1,
            sliderImg: "",
            sliderKey: "",
            sliderX: 27,
            sliderY: "",
            sliderMoveDrawLeft: "27px",
            sliderMoveLeft: "20px",
            shock: !1,
            tipEvents: {},
            sliderMoveX: 0,
            questionMessage: !1,
            refreshMessage: !1,
          };
        },
        methods: {
          init: function (t) {
            (this.dialogVisible = t), t && this.clear();
          },
          clear: function () {
            (this.mask = !1),
              (this.success = !1),
              (this.failed = !1),
              (this.sliderImg = ""),
              (this.sliderKey = ""),
              (this.sliderX = 27),
              (this.sliderMoveDrawLeft = "27px"),
              (this.sliderMoveLeft = "20px"),
              (this.sliderY = "");
          },
          check: function (t, e) {
            this.$emit("check", t, e, this.done, this.error);
          },
          done: function () {
            this.success = !0;
          },
          error: function () {
            var t = this;
            (this.failed = !0),
              (this.mask = !0),
              (this.shock = !0),
              setTimeout(function () {
                (t.shock = !1), t.$emit("error");
              }, 1e3);
          },
          close: function () {
            (this.dialogVisible = !1),
              this.$emit("input", this.dialogVisible),
              this.$emit("update:modelValue", this.dialogVisible),
              this.$emit("close");
          },
          refresh: function () {
            this.$emit("refresh");
          },
          sliderTouchStart: function (t) {
            var e = t.target;
            this.sliderMoveX = t.touches[0].clientX - e.offsetLeft;
          },
          sliderTouchMove: function (t) {
            var e = t.touches[0].clientX - this.sliderMoveX;
            e >= 20 &&
              e <= 280 &&
              ((this.sliderMoveDrawLeft = 5 + e + "px"),
              (this.sliderMoveLeft = e + "px"),
              (this.sliderX = 5 + e));
          },
          sliderEnd: function () {
            this.check(this.sliderKey, this.sliderX);
          },
          sliderStart: function (t) {
            var e = this,
              i = this,
              o = t.target;
            (i.sliderMoveX = t.clientX - o.offsetLeft),
              (document.onmousemove = function (t) {
                var e = t.clientX - i.sliderMoveX;
                e >= 20 &&
                  e <= 280 &&
                  ((i.sliderMoveDrawLeft = 5 + e + "px"),
                  (i.sliderMoveLeft = e + "px"),
                  (i.sliderX = 5 + e));
              }),
              (document.onmouseup = function () {
                (document.onmousemove = null),
                  (document.onmouseup = null),
                  e.check(e.sliderKey, e.sliderX);
              });
          },
          moveHandle: function () {},
        },
      };
      e.default = o;
    },
    bb3b: function (t, e, i) {
      "use strict";
      i.r(e);
      var o = i("792d"),
        s = i.n(o);
      for (var n in o)
        ["default"].indexOf(n) < 0 &&
          (function (t) {
            i.d(e, t, function () {
              return o[t];
            });
          })(n);
      e["default"] = s.a;
    },
    bc2f: function (t, e, i) {
      "use strict";
      var o = i("19e0"),
        s = i.n(o);
      s.a;
    },
    bc7d: function (t, e, i) {
      "use strict";
      i.d(e, "b", function () {
        return s;
      }),
        i.d(e, "c", function () {
          return n;
        }),
        i.d(e, "a", function () {
          return o;
        });
      var o = { uvLine: i("73b2").default },
        s = function () {
          var t = this,
            e = t.$createElement,
            i = t._self._c || e;
          return i(
            "v-uni-view",
            {
              staticClass: "uv-divider",
              style: [t.$uv.addStyle(t.customStyle)],
              on: {
                click: function (e) {
                  (arguments[0] = e = t.$handleEvent(e)),
                    t.click.apply(void 0, arguments);
                },
              },
            },
            [
              i("uv-line", {
                attrs: {
                  color: t.lineColor,
                  customStyle: t.leftLineStyle,
                  hairline: t.hairline,
                  dashed: t.dashed,
                },
              }),
              t.dot
                ? i("v-uni-text", { staticClass: "uv-divider__dot" }, [
                    t._v("●"),
                  ])
                : t.text
                  ? i(
                      "v-uni-text",
                      { staticClass: "uv-divider__text", style: [t.textStyle] },
                      [t._v(t._s(t.text))],
                    )
                  : t._e(),
              i("uv-line", {
                attrs: {
                  color: t.lineColor,
                  customStyle: t.rightLineStyle,
                  hairline: t.hairline,
                  dashed: t.dashed,
                },
              }),
            ],
            1,
          );
        },
        n = [];
    },
    bf85: function (t, e, i) {
      "use strict";
      i.r(e);
      var o = i("76bd"),
        s = i("bb3b");
      for (var n in s)
        ["default"].indexOf(n) < 0 &&
          (function (t) {
            i.d(e, t, function () {
              return s[t];
            });
          })(n);
      i("5c0b");
      var a = i("828b"),
        r = Object(a["a"])(
          s["default"],
          o["b"],
          o["c"],
          !1,
          null,
          "57ecf9c1",
          null,
          !1,
          o["a"],
          void 0,
        );
      e["default"] = r.exports;
    },
    caf4: function (t, e, i) {
      "use strict";
      i("6a54");
      var o = i("f5bd").default;
      Object.defineProperty(e, "__esModule", { value: !0 }),
        (e.default = void 0),
        i("64aa");
      var s,
        n,
        a = o(i("9b1b")),
        r = {
          props: (0, a.default)(
            {
              dashed: { type: Boolean, default: !1 },
              hairline: { type: Boolean, default: !0 },
              dot: { type: Boolean, default: !1 },
              textPosition: { type: String, default: "center" },
              text: { type: [String, Number], default: "" },
              textSize: { type: [String, Number], default: 14 },
              textColor: { type: String, default: "#909399" },
              lineColor: { type: String, default: "#dcdfe6" },
            },
            null === (s = uni.$uv) ||
              void 0 === s ||
              null === (n = s.props) ||
              void 0 === n
              ? void 0
              : n.divider,
          ),
        };
      e.default = r;
    },
    e05d: function (t, e, i) {
      "use strict";
      i.r(e);
      var o = i("a335"),
        s = i.n(o);
      for (var n in o)
        ["default"].indexOf(n) < 0 &&
          (function (t) {
            i.d(e, t, function () {
              return o[t];
            });
          })(n);
      e["default"] = s.a;
    },
  },
]);
//# sourceMappingURL=pages_sub1-seller-hall_info.b9323537.js.map
