(window["webpackJsonp"] = window["webpackJsonp"] || []).push([
  ["pages_sub1-chat-index"],
  {
    "05c2": function (t, e, i) {
      "use strict";
      i("6a54");
      var a = i("f5bd").default;
      Object.defineProperty(e, "__esModule", { value: !0 }),
        (e.default = void 0),
        i("473f"),
        i("bf0f"),
        i("f7a5"),
        i("5c47"),
        i("0506"),
        i("c223"),
        i("18f7"),
        i("de6c"),
        i("fd3c");
      var n = a(i("5de6")),
        o = a(i("9b1b")),
        s = a(i("2634")),
        r = a(i("2fdc")),
        c = a(i("4d8f0")),
        d = a(i("9463")),
        l = a(i("b92c")),
        u = a(i("7689")),
        h = {
          name: "uv-tabs",
          emits: ["click", "change"],
          mixins: [c.default, d.default, u.default],
          data: function () {
            return {
              firstTime: !0,
              scrollLeft: 0,
              scrollViewWidth: 0,
              lineOffsetLeft: 0,
              tabsRect: { left: 0 },
              innerCurrent: 0,
              moving: !1,
            };
          },
          watch: {
            current: {
              immediate: !0,
              handler: function (t, e) {
                var i = this;
                t !== this.innerCurrent &&
                  ((this.innerCurrent = t),
                  this.$nextTick(function () {
                    i.resize();
                  }));
              },
            },
            list: function () {
              var t = this;
              this.$nextTick(function () {
                t.resize();
              });
            },
          },
          computed: {
            textStyle: function () {
              var t = this;
              return function (e) {
                var i = {},
                  a =
                    e == t.innerCurrent
                      ? t.$uv.addStyle(t.activeStyle)
                      : t.$uv.addStyle(t.inactiveStyle);
                return (
                  t.list[e].disabled && (i.color = "#c8c9cc"),
                  t.$uv.deepMerge(a, i)
                );
              };
            },
            propsBadge: function () {
              return l.default;
            },
          },
          mounted: function () {
            var t = this;
            return (0, r.default)(
              (0, s.default)().mark(function e() {
                return (0, s.default)().wrap(function (e) {
                  while (1)
                    switch ((e.prev = e.next)) {
                      case 0:
                        t.init();
                      case 1:
                      case "end":
                        return e.stop();
                    }
                }, e);
              }),
            )();
          },
          methods: {
            setLineLeft: function () {
              var t = this,
                e = this.list[this.innerCurrent];
              if (e) {
                var i = this.list.slice(0, this.innerCurrent).reduce(function (
                    t,
                    e,
                  ) {
                    return t + e.rect.width;
                  }, 0),
                  a = this.$uv.getPx(this.lineWidth);
                this.$uv.test.number(this.lineWidth) &&
                  this.$uv.unit &&
                  (a = this.$uv.getPx(
                    "".concat(this.lineWidth).concat(this.$uv.unit),
                  )),
                  (this.lineOffsetLeft = i + (e.rect.width - a) / 2),
                  this.firstTime &&
                    setTimeout(function () {
                      t.firstTime = !1;
                    }, 20);
              }
            },
            animation: function (t) {},
            clickHandler: function (t, e) {
              var i = this;
              this.$emit(
                "click",
                (0, o.default)((0, o.default)({}, t), {}, { index: e }),
              ),
                t.disabled ||
                  (this.innerCurrent != e &&
                    this.$emit(
                      "change",
                      (0, o.default)((0, o.default)({}, t), {}, { index: e }),
                    ),
                  (this.innerCurrent = e),
                  this.$nextTick(function () {
                    i.resize();
                  }));
            },
            init: function () {
              var t = this;
              this.$uv.sleep().then(function () {
                t.resize();
              });
            },
            setScrollLeft: function () {
              var t = this.list[this.innerCurrent],
                e = this.list.slice(0, this.innerCurrent).reduce(function (
                  t,
                  e,
                ) {
                  return t + e.rect.width;
                }, 0),
                i = this.$uv.sys().windowWidth,
                a =
                  e -
                  (this.tabsRect.width - t.rect.width) / 2 -
                  (i - this.tabsRect.right) / 2 +
                  this.tabsRect.left / 2;
              (a = Math.min(a, this.scrollViewWidth - this.tabsRect.width)),
                (this.scrollLeft = Math.max(0, a));
            },
            resize: function () {
              var t = this;
              0 !== this.list.length &&
                Promise.all([this.getTabsRect(), this.getAllItemRect()]).then(
                  function (e) {
                    var i = (0, n.default)(e, 2),
                      a = i[0],
                      o = i[1],
                      s = void 0 === o ? [] : o;
                    (t.tabsRect = a),
                      (t.scrollViewWidth = 0),
                      s.map(function (e, i) {
                        (t.scrollViewWidth += e.width), (t.list[i].rect = e);
                      }),
                      t.setLineLeft(),
                      t.setScrollLeft();
                  },
                );
            },
            getTabsRect: function () {
              var t = this;
              return new Promise(function (e) {
                t.queryRect("uv-tabs__wrapper__scroll-view").then(function (t) {
                  return e(t);
                });
              });
            },
            getAllItemRect: function () {
              var t = this;
              return new Promise(function (e) {
                var i = t.list.map(function (e, i) {
                  return t.queryRect(
                    "uv-tabs__wrapper__nav__item-".concat(i),
                    !0,
                  );
                });
                Promise.all(i).then(function (t) {
                  return e(t);
                });
              });
            },
            queryRect: function (t, e) {
              var i = this;
              return new Promise(function (e) {
                i.$uvGetRect(".".concat(t)).then(function (t) {
                  e(t);
                });
              });
            },
          },
        };
      e.default = h;
    },
    "0fba": function (t, e, i) {
      "use strict";
      i.r(e);
      var a = i("e0db"),
        n = i("babb");
      for (var o in n)
        ["default"].indexOf(o) < 0 &&
          (function (t) {
            i.d(e, t, function () {
              return n[t];
            });
          })(o);
      i("1c80");
      var s = i("828b"),
        r = Object(s["a"])(
          n["default"],
          a["b"],
          a["c"],
          !1,
          null,
          "b5ca7150",
          null,
          !1,
          a["a"],
          void 0,
        );
      e["default"] = r.exports;
    },
    "1c80": function (t, e, i) {
      "use strict";
      var a = i("67a0"),
        n = i.n(a);
      n.a;
    },
    "28f5": function (t, e, i) {
      "use strict";
      i.d(e, "b", function () {
        return n;
      }),
        i.d(e, "c", function () {
          return o;
        }),
        i.d(e, "a", function () {
          return a;
        });
      var a = { uvBadge: i("0261").default },
        n = function () {
          var t = this,
            e = t.$createElement,
            i = t._self._c || e;
          return i(
            "v-uni-view",
            { staticClass: "uv-tabs", style: [t.$uv.addStyle(t.customStyle)] },
            [
              i(
                "v-uni-view",
                { staticClass: "uv-tabs__wrapper" },
                [
                  t._t("left"),
                  i(
                    "v-uni-view",
                    { staticClass: "uv-tabs__wrapper__scroll-view-wrapper" },
                    [
                      i(
                        "v-uni-scroll-view",
                        {
                          ref: "uv-tabs__wrapper__scroll-view",
                          staticClass: "uv-tabs__wrapper__scroll-view",
                          attrs: {
                            "scroll-x": t.scrollable,
                            "scroll-left": t.scrollLeft,
                            "scroll-with-animation": !0,
                            "show-scrollbar": !1,
                          },
                        },
                        [
                          i(
                            "v-uni-view",
                            {
                              ref: "uv-tabs__wrapper__nav",
                              staticClass: "uv-tabs__wrapper__nav",
                              style: { flex: t.scrollable ? "" : 1 },
                            },
                            [
                              t._l(t.list, function (e, a) {
                                return i(
                                  "v-uni-view",
                                  {
                                    key: a,
                                    ref: "uv-tabs__wrapper__nav__item-" + a,
                                    refInFor: !0,
                                    staticClass: "uv-tabs__wrapper__nav__item",
                                    class: [
                                      "uv-tabs__wrapper__nav__item-" + a,
                                      e.disabled &&
                                        "uv-tabs__wrapper__nav__item--disabled",
                                    ],
                                    style: [
                                      { flex: t.scrollable ? "" : 1 },
                                      t.$uv.addStyle(t.itemStyle),
                                    ],
                                    on: {
                                      click: function (i) {
                                        (arguments[0] = i = t.$handleEvent(i)),
                                          t.clickHandler(e, a);
                                      },
                                    },
                                  },
                                  [
                                    i(
                                      "v-uni-text",
                                      {
                                        staticClass:
                                          "uv-tabs__wrapper__nav__item__text",
                                        class: [
                                          e.disabled &&
                                            "uv-tabs__wrapper__nav__item__text--disabled",
                                        ],
                                        style: [t.textStyle(a)],
                                      },
                                      [t._v(t._s(e[t.keyName]))],
                                    ),
                                    i("uv-badge", {
                                      attrs: {
                                        show: !(
                                          !e.badge ||
                                          !(
                                            e.badge.show ||
                                            e.badge.isDot ||
                                            e.badge.value
                                          )
                                        ),
                                        isDot:
                                          (e.badge && e.badge.isDot) ||
                                          t.propsBadge.isDot,
                                        value:
                                          (e.badge && e.badge.value) ||
                                          t.propsBadge.value,
                                        max:
                                          (e.badge && e.badge.max) ||
                                          t.propsBadge.max,
                                        type:
                                          (e.badge && e.badge.type) ||
                                          t.propsBadge.type,
                                        showZero:
                                          (e.badge && e.badge.showZero) ||
                                          t.propsBadge.showZero,
                                        bgColor:
                                          (e.badge && e.badge.bgColor) ||
                                          t.propsBadge.bgColor,
                                        color:
                                          (e.badge && e.badge.color) ||
                                          t.propsBadge.color,
                                        shape:
                                          (e.badge && e.badge.shape) ||
                                          t.propsBadge.shape,
                                        numberType:
                                          (e.badge && e.badge.numberType) ||
                                          t.propsBadge.numberType,
                                        inverted:
                                          (e.badge && e.badge.inverted) ||
                                          t.propsBadge.inverted,
                                        customStyle: "margin-left: 4px;",
                                      },
                                    }),
                                  ],
                                  1,
                                );
                              }),
                              i("v-uni-view", {
                                ref: "uv-tabs__wrapper__nav__line",
                                staticClass: "uv-tabs__wrapper__nav__line",
                                style: [
                                  {
                                    width: t.$uv.addUnit(t.lineWidth),
                                    transform:
                                      "translate(" + t.lineOffsetLeft + "px)",
                                    transitionDuration:
                                      (t.firstTime ? 0 : t.duration) + "ms",
                                    height: t.firstTime
                                      ? 0
                                      : t.$uv.addUnit(t.lineHeight),
                                    background: t.lineColor,
                                    backgroundSize: t.lineBgSize,
                                  },
                                ],
                              }),
                            ],
                            2,
                          ),
                        ],
                        1,
                      ),
                    ],
                    1,
                  ),
                  t._t("right"),
                ],
                2,
              ),
            ],
            1,
          );
        },
        o = [];
    },
    "2b48": function (t, e, i) {
      "use strict";
      i.r(e);
      var a = i("28f5"),
        n = i("39c1");
      for (var o in n)
        ["default"].indexOf(o) < 0 &&
          (function (t) {
            i.d(e, t, function () {
              return n[t];
            });
          })(o);
      i("45c0");
      var s = i("828b"),
        r = Object(s["a"])(
          n["default"],
          a["b"],
          a["c"],
          !1,
          null,
          "6f5b1fc6",
          null,
          !1,
          a["a"],
          void 0,
        );
      e["default"] = r.exports;
    },
    3105: function (t, e, i) {
      var a = i("c86c");
      (e = a(!1)),
        e.push([
          t.i,
          '@charset "UTF-8";\r\n/**\r\n * 这里是uni-app内置的常用样式变量\r\n *\r\n * uni-app 官方扩展插件及插件市场（https://ext.dcloud.net.cn）上很多三方插件均使用了这些样式变量\r\n * 如果你是插件开发者，建议你使用scss预处理，并在插件代码中直接使用这些变量（无需 import 这个文件），方便用户通过搭积木的方式开发整体风格一致的App\r\n *\r\n */\r\n/**\r\n * 如果你是App开发者（插件使用者），你可以通过修改这些变量来定制自己的插件主题，实现自定义主题功能\r\n *\r\n * 如果你的项目同样使用了scss预处理，你也可以直接在你的 scss 代码中使用如下变量，同时无需 import 这个文件\r\n */\r\n/* 颜色变量 */\r\n/* 行为相关颜色 */\r\n/* 文字基本颜色 */\r\n/* 背景颜色 */\r\n/* 边框颜色 */\r\n/* 尺寸变量 */\r\n/* 文字尺寸 */\r\n/* 图片尺寸 */\r\n/* Border Radius */\r\n/* 水平间距 */\r\n/* 垂直间距 */\r\n/* 透明度 */\r\n/* 文章场景相关 */uni-view[data-v-6f5b1fc6], uni-scroll-view[data-v-6f5b1fc6], uni-swiper-item[data-v-6f5b1fc6]{display:flex;flex-direction:column;flex-shrink:0;flex-grow:0;flex-basis:auto;align-items:stretch;align-content:flex-start}.uv-tabs__wrapper[data-v-6f5b1fc6]{display:flex;flex-direction:row;align-items:center}.uv-tabs__wrapper__scroll-view-wrapper[data-v-6f5b1fc6]{flex:1;overflow:auto hidden}.uv-tabs__wrapper__scroll-view[data-v-6f5b1fc6]{display:flex;flex-direction:row;flex:1}.uv-tabs__wrapper__nav[data-v-6f5b1fc6]{display:flex;flex-direction:row;position:relative}.uv-tabs__wrapper__nav__item[data-v-6f5b1fc6]{padding:0 11px;display:flex;flex-direction:row;align-items:center;justify-content:center}.uv-tabs__wrapper__nav__item--disabled[data-v-6f5b1fc6]{cursor:not-allowed}.uv-tabs__wrapper__nav__item__text[data-v-6f5b1fc6]{font-size:15px;color:#606266}.uv-tabs__wrapper__nav__item__text--disabled[data-v-6f5b1fc6]{color:#c8c9cc!important}.uv-tabs__wrapper__nav__line[data-v-6f5b1fc6]{height:3px;background:#3c9cff;width:30px;position:absolute;bottom:2px;border-radius:100px;transition-property:-webkit-transform;transition-property:transform;transition-property:transform,-webkit-transform;transition-duration:.3s}',
          "",
        ]),
        (t.exports = e);
    },
    "31a6": function (t, e, i) {
      "use strict";
      i.d(e, "b", function () {
        return a;
      }),
        i.d(e, "c", function () {
          return n;
        }),
        i.d(e, "a", function () {});
      var a = function () {
          var t = this,
            e = t.$createElement,
            i = t._self._c || e;
          return i(
            "v-uni-view",
            {
              staticClass: "uv-textarea",
              class: t.textareaClass,
              style: [t.textareaStyle],
            },
            [
              i("v-uni-textarea", {
                staticClass: "uv-textarea__field",
                style: [
                  { height: t.autoHeight ? "auto" : t.$uv.addUnit(t.height) },
                  t.$uv.addStyle(t.textStyle),
                ],
                attrs: {
                  value: t.innerValue,
                  placeholder: t.placeholder,
                  "placeholder-style": t.$uv.addStyle(
                    t.placeholderStyle,
                    "string",
                  ),
                  "placeholder-class": t.placeholderClass,
                  disabled: t.disabled,
                  focus: t.focus,
                  autoHeight: t.autoHeight,
                  fixed: t.fixed,
                  cursorSpacing: t.cursorSpacing,
                  cursor: t.cursor,
                  showConfirmBar: t.showConfirmBar,
                  selectionStart: t.selectionStart,
                  selectionEnd: t.selectionEnd,
                  adjustPosition: t.adjustPosition,
                  disableDefaultPadding: t.disableDefaultPadding,
                  holdKeyboard: t.holdKeyboard,
                  maxlength: t.maxlen,
                  confirmType: t.confirmType,
                  ignoreCompositionEvent: t.ignoreCompositionEvent,
                  "confirm-hold": t.confirmHold,
                },
                on: {
                  focus: function (e) {
                    (arguments[0] = e = t.$handleEvent(e)),
                      t.onFocus.apply(void 0, arguments);
                  },
                  blur: function (e) {
                    (arguments[0] = e = t.$handleEvent(e)),
                      t.onBlur.apply(void 0, arguments);
                  },
                  linechange: function (e) {
                    (arguments[0] = e = t.$handleEvent(e)),
                      t.onLinechange.apply(void 0, arguments);
                  },
                  input: function (e) {
                    (arguments[0] = e = t.$handleEvent(e)),
                      t.onInput.apply(void 0, arguments);
                  },
                  confirm: function (e) {
                    (arguments[0] = e = t.$handleEvent(e)),
                      t.onConfirm.apply(void 0, arguments);
                  },
                  keyboardheightchange: function (e) {
                    (arguments[0] = e = t.$handleEvent(e)),
                      t.onKeyboardheightchange.apply(void 0, arguments);
                  },
                },
              }),
              t.count && -1 != t.maxlen
                ? i(
                    "v-uni-text",
                    {
                      staticClass: "uv-textarea__count",
                      style: [
                        {
                          "background-color": t.disabled
                            ? "transparent"
                            : "#fff",
                        },
                        t.$uv.addStyle(t.countStyle),
                      ],
                    },
                    [t._v(t._s(t.getCount) + "/" + t._s(t.maxlen))],
                  )
                : t._e(),
            ],
            1,
          );
        },
        n = [];
    },
    3597: function (t, e) {
      t.exports =
        "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAADwAAAA8CAYAAAA6/NlyAAAACXBIWXMAAAsTAAALEwEAmpwYAAAFu2lUWHRYTUw6Y29tLmFkb2JlLnhtcAAAAAAAPD94cGFja2V0IGJlZ2luPSLvu78iIGlkPSJXNU0wTXBDZWhpSHpyZVN6TlRjemtjOWQiPz4gPHg6eG1wbWV0YSB4bWxuczp4PSJhZG9iZTpuczptZXRhLyIgeDp4bXB0az0iQWRvYmUgWE1QIENvcmUgOS4xLWMwMDEgNzkuMTQ2Mjg5OSwgMjAyMy8wNi8yNS0yMDowMTo1NSAgICAgICAgIj4gPHJkZjpSREYgeG1sbnM6cmRmPSJodHRwOi8vd3d3LnczLm9yZy8xOTk5LzAyLzIyLXJkZi1zeW50YXgtbnMjIj4gPHJkZjpEZXNjcmlwdGlvbiByZGY6YWJvdXQ9IiIgeG1sbnM6eG1wPSJodHRwOi8vbnMuYWRvYmUuY29tL3hhcC8xLjAvIiB4bWxuczpkYz0iaHR0cDovL3B1cmwub3JnL2RjL2VsZW1lbnRzLzEuMS8iIHhtbG5zOnBob3Rvc2hvcD0iaHR0cDovL25zLmFkb2JlLmNvbS9waG90b3Nob3AvMS4wLyIgeG1sbnM6eG1wTU09Imh0dHA6Ly9ucy5hZG9iZS5jb20veGFwLzEuMC9tbS8iIHhtbG5zOnN0RXZ0PSJodHRwOi8vbnMuYWRvYmUuY29tL3hhcC8xLjAvc1R5cGUvUmVzb3VyY2VFdmVudCMiIHhtcDpDcmVhdG9yVG9vbD0iQWRvYmUgUGhvdG9zaG9wIDI1LjAgKFdpbmRvd3MpIiB4bXA6Q3JlYXRlRGF0ZT0iMjAyNS0xMS0xN1QwNToyOTo0NSswODowMCIgeG1wOk1vZGlmeURhdGU9IjIwMjUtMTEtMTdUMDU6NDQ6MTcrMDg6MDAiIHhtcDpNZXRhZGF0YURhdGU9IjIwMjUtMTEtMTdUMDU6NDQ6MTcrMDg6MDAiIGRjOmZvcm1hdD0iaW1hZ2UvcG5nIiBwaG90b3Nob3A6Q29sb3JNb2RlPSIzIiB4bXBNTTpJbnN0YW5jZUlEPSJ4bXAuaWlkOmM0MWY3OGFiLWQzZTAtNjg0Ny1hYTNmLWMwZmIxMTUxMmFmMyIgeG1wTU06RG9jdW1lbnRJRD0ieG1wLmRpZDphYzAyYTBlZi0yYjViLTk1NGQtYWEzNy01MTlhNmYwMzY3YWEiIHhtcE1NOk9yaWdpbmFsRG9jdW1lbnRJRD0ieG1wLmRpZDphYzAyYTBlZi0yYjViLTk1NGQtYWEzNy01MTlhNmYwMzY3YWEiPiA8eG1wTU06SGlzdG9yeT4gPHJkZjpTZXE+IDxyZGY6bGkgc3RFdnQ6YWN0aW9uPSJjcmVhdGVkIiBzdEV2dDppbnN0YW5jZUlEPSJ4bXAuaWlkOmFjMDJhMGVmLTJiNWItOTU0ZC1hYTM3LTUxOWE2ZjAzNjdhYSIgc3RFdnQ6d2hlbj0iMjAyNS0xMS0xN1QwNToyOTo0NSswODowMCIgc3RFdnQ6c29mdHdhcmVBZ2VudD0iQWRvYmUgUGhvdG9zaG9wIDI1LjAgKFdpbmRvd3MpIi8+IDxyZGY6bGkgc3RFdnQ6YWN0aW9uPSJzYXZlZCIgc3RFdnQ6aW5zdGFuY2VJRD0ieG1wLmlpZDpjNDFmNzhhYi1kM2UwLTY4NDctYWEzZi1jMGZiMTE1MTJhZjMiIHN0RXZ0OndoZW49IjIwMjUtMTEtMTdUMDU6NDQ6MTcrMDg6MDAiIHN0RXZ0OnNvZnR3YXJlQWdlbnQ9IkFkb2JlIFBob3Rvc2hvcCAyNS4wIChXaW5kb3dzKSIgc3RFdnQ6Y2hhbmdlZD0iLyIvPiA8L3JkZjpTZXE+IDwveG1wTU06SGlzdG9yeT4gPC9yZGY6RGVzY3JpcHRpb24+IDwvcmRmOlJERj4gPC94OnhtcG1ldGE+IDw/eHBhY2tldCBlbmQ9InIiPz6cMH2QAAAGs0lEQVRoge3ba4ydRRkH8N/2xqW4NNLCWkwoEgKtYFRWChgkxICI0rSg0cZiUIn6oWoNKhoNauIN7xgbC16qfhAQEwiCSrWVAJYaltRIRMqtK9SCCr2AsNS2rB+eeT1zzp7Le86ewy61/2TyzsyZd+b5z/vMzDPPzOkbHR31/4QpEy3AC439hPd1TMsTg4OD3a6/r+Y5FQN4WUo/hsexN6VHa55dwdDQ0P/i05qU6wRThdZMwck4Da/HPEFydoP3nhDkN+P3uBN/wvMp7G3wXtvoBuEpqZ5ZWIozcQqOaKOO2SmciEUpb6sgfjuuxg7sER3QMcZDeAoOwnF4B96Oo2vK7Elht1DTPBCqnodpmJ6ec3FBCh/Bz1PYhBEdEu+U8Awcg0vxNszMftuF/6SwEXfgd3gaT6Xn06nsS1LoT8/TU1goiB+QwtGpreX4BS7HQ6mNttCXGx4lJ61+LMGnxNct8CyewS+xRqjjI+0KlDBXjP1zcJ7o0IOz3zfhy7hedGJTjGfSmiN6+pIsb0SMr2twnSA6XmxNdV2HU8VweaeYJ4ph9GMx5i/Hv8pW3A7hw7Ea52Z520QvX4F72qirHdyZwmoxlpfgpem3SzAf78E/y1RW1vAYwPdUyO4S6noZLtY7sjnuSW1dltrelfLPxUolV4UyhAfwdZyf0s9hLZalhl5orExtr02yEBPn15Qg3YpwP76Ad6X0iJiQlov1caJwe5JhTZIJLhSy9jd7sRXhJXhfiu/CLVghLKKJxmYhyy0q6n2xkLkhmhGeK3qxwBA+anKQLbBZyDSU5S0XstdFI8IzRO8VC/OT+CqGxythDzAsZHsypQeF7DPqFW5E+HhclKV/hhu7IV2PcKOQscBFgsMYNCK8VBgZxC5mVbck6yFWCVkJ2ZfWK1TP8DgCi7P0tbi3RWNzxPbv0LZELI/HhTXXzKK6V8i6IqUX49v4R16oHuFFKurwVKqkFd6A94p9by9wt1h3f9Ki3LVJjn7BYRG+nxeoR/gtWfwObCgh0PGqTc5uY4FYb1sR3oA/4M0p/VY1hOuN4QVZfG1Jgf6GB0uW7QQPCg9IGazL4q+s/bH2C89Q8TfBwyUb+Y3Yv55Wsny7WC+2nWUwnMUHxH66MEzGEJ6NQ7L0QyUbeULsZlaXLN9L5DLPFBPqliKjVqXn1KS39kioXqLW6XB4nqglPFKTPqjr4vQetVq7O0/UEt4iXDUFjvPiwzFZ/HmZOjO2N54VM+78lJ6v/Ew9T6zHneABYSUNd/h+jtxzugM78x/rrcMPqBCua4/WwQA+jzPaFK7A/bgJ3+nw/RzHZvEtaty59QjnS9FJYqZ7pkUjb8S7O5Eu4Sg8Oo73C8zC2Vl6jNFUz/C4VeVo4wTlvtpm/Lk92aqwUXzl8eIMvDbFR4Tjvgr1vvBtuEsclxwivAi/VTPb1WA9PqlandrBJuWNnGZYJgwNwtP5x9oC9QhvF3vLU1L6THEasK5O2Ry/TmGicLaQtcA1+HdtoUb74evF5EWMiw9qfPI3GXAkPo3DUvpuMQmOQSPCW1Tr/1n4ULek6wEuVNFIuFLFGVCFZk68H4mzWuIrv1986cmG8/ABFR/WGtzQqHAzwg/jEyqWyoCYmDo1LnqBs/BFFcfDTnxLE89IK7/0kGpVPgrfEOvuRON04a08Mcv7rhYHBGWOWm7Gx7L0IL6JD7cpYLcwXSw/V+DVWf5XxDFMUyOpDOHd+KE4siysoVfh48JTuKDBe73AQqFhn8NrsvwviQ6oO1HlKHtcukNMBI/is8Jn9HLR09NVjmN6hRPwJmG+zlM5P/o7rhIdX+q4tJ3z4T3CclkhvPzLhJ39ijbqaBcLRecuFu7jgey3dWKC2iA8LqXQyR2P+8U9i2UdvNsKB4oNSxFOFl6Yw2rKrRQqnJ8Tl0Knl1p2ti6COLe9VNwU2Ca+RBHfKzQkD69Tfcklv9exDb8Sk+itwjnfNrp9Ma3ASfiMIHCk6utLRXxU5SLb1BRm1qmr2CvfINy121UOwttGtwkfKmbQxcLdW+xcpqVwYIk6totxuVFsOe8SGrVTdNS40E3CK8TaPEe1q3e9EPzglF88dwuLKA+P4C9iLzsixmfHX7MeukX4PjGLzsryHhNG/CpxgaxPqG/xHBXjOA97dHDZrB10g/CpwnDvy/J+Ksy8v6qzJ51IdIPwAVn8NnG96WbhAe3aLdhuoVsqPYwfCK/jc5q7gyYU3SB8lVDf+0xiogXGQ3iNmJBuUllXJz3GQ/ic9HxREC3Qt/9/S/s49hPe1/Ff7sFv63FxSTgAAAAASUVORK5CYII=";
    },
    "39c1": function (t, e, i) {
      "use strict";
      i.r(e);
      var a = i("05c2"),
        n = i.n(a);
      for (var o in a)
        ["default"].indexOf(o) < 0 &&
          (function (t) {
            i.d(e, t, function () {
              return a[t];
            });
          })(o);
      e["default"] = n.a;
    },
    "3e65": function (t, e, i) {
      "use strict";
      i.r(e);
      var a = i("31a6"),
        n = i("96f8");
      for (var o in n)
        ["default"].indexOf(o) < 0 &&
          (function (t) {
            i.d(e, t, function () {
              return n[t];
            });
          })(o);
      i("b24f");
      var s = i("828b"),
        r = Object(s["a"])(
          n["default"],
          a["b"],
          a["c"],
          !1,
          null,
          "26fd47e8",
          null,
          !1,
          a["a"],
          void 0,
        );
      e["default"] = r.exports;
    },
    "45c0": function (t, e, i) {
      "use strict";
      var a = i("62a9"),
        n = i.n(a);
      n.a;
    },
    "4bc9": function (t, e, i) {
      var a = i("c86c");
      (e = a(!1)),
        e.push([
          t.i,
          '@charset "UTF-8";\r\n/**\r\n * 这里是uni-app内置的常用样式变量\r\n *\r\n * uni-app 官方扩展插件及插件市场（https://ext.dcloud.net.cn）上很多三方插件均使用了这些样式变量\r\n * 如果你是插件开发者，建议你使用scss预处理，并在插件代码中直接使用这些变量（无需 import 这个文件），方便用户通过搭积木的方式开发整体风格一致的App\r\n *\r\n */\r\n/**\r\n * 如果你是App开发者（插件使用者），你可以通过修改这些变量来定制自己的插件主题，实现自定义主题功能\r\n *\r\n * 如果你的项目同样使用了scss预处理，你也可以直接在你的 scss 代码中使用如下变量，同时无需 import 这个文件\r\n */\r\n/* 颜色变量 */\r\n/* 行为相关颜色 */\r\n/* 文字基本颜色 */\r\n/* 背景颜色 */\r\n/* 边框颜色 */\r\n/* 尺寸变量 */\r\n/* 文字尺寸 */\r\n/* 图片尺寸 */\r\n/* Border Radius */\r\n/* 水平间距 */\r\n/* 垂直间距 */\r\n/* 透明度 */\r\n/* 文章场景相关 */.uv-border[data-v-26fd47e8]{border-width:.5px!important;border-color:#dadbde!important;border-style:solid}.uv-border-bottom[data-v-26fd47e8]{border-bottom-width:.5px!important;border-color:#dadbde!important;border-bottom-style:solid}uni-view[data-v-26fd47e8], uni-scroll-view[data-v-26fd47e8], uni-swiper-item[data-v-26fd47e8]{display:flex;flex-direction:column;flex-shrink:0;flex-grow:0;flex-basis:auto;align-items:stretch;align-content:flex-start}.uv-textarea[data-v-26fd47e8]{border-radius:4px;background-color:#fff;position:relative;display:flex;flex-direction:row;flex:1;padding:9px}.uv-textarea--radius[data-v-26fd47e8]{border-radius:4px}.uv-textarea--no-radius[data-v-26fd47e8]{border-radius:0}.uv-textarea--disabled[data-v-26fd47e8]{background-color:#f5f7fa}.uv-textarea__field[data-v-26fd47e8]{flex:1;font-size:15px;color:#606266;width:100%}.uv-textarea__count[data-v-26fd47e8]{position:absolute;right:5px;bottom:2px;font-size:12px;color:#909193;background-color:#fff;padding:1px 4px}',
          "",
        ]),
        (t.exports = e);
    },
    5629: function (t, e, i) {
      "use strict";
      i("6a54");
      var a = i("f5bd").default;
      Object.defineProperty(e, "__esModule", { value: !0 }),
        (e.default = void 0);
      var n = a(i("2634")),
        o = a(i("2fdc"));
      i("bf0f"),
        i("2797"),
        i("18f7"),
        i("de6c"),
        i("dc89"),
        i("2425"),
        i("aa9c"),
        i("5c47"),
        i("a1c1"),
        i("aa77"),
        i("64aa"),
        i("4100"),
        i("bd06"),
        i("5ef2"),
        i("8f71"),
        i("dd2b"),
        i("fd3c");
      var s = i("e74a"),
        r = a(i("2609")),
        c = {
          data: function () {
            return {
              online_status: 1,
              platform: 1,
              gridShow: !1,
              emoShow: !1,
              current: 0,
              keyword: "",
              kefu_token: "",
              server_name: "",
              content: "",
              send_msg: "",
              audio_url: "",
              scrollTop: 0,
              kefu: [],
              user_list: [],
              chat: [],
              log: [],
              order: [],
              emoji: [],
              kefu_list: [],
              log_kefu_list: [],
              log_kefu_log: [],
              log_kefu_id: 0,
              online: 0,
              select_id: 0,
              chat_id: 0,
              imgList: [],
              blobUrls: [],
              show_pase: 0,
              tabs: [
                { name: "咨询中", id: 1 },
                { name: "全部", id: 0 },
              ],
              chat_status: 1,
              chat_current: 0,
            };
          },
          onLoad: function (t) {
            (this.kefu_token = t.kefu_token),
              (this.chat_id = t.chat_id),
              this.getPcKefuChatInfo(),
              uni.$on("websocket_message", this.handleWebsocketMessage);
          },
          onUnload: function () {
            uni.$off("websocket_message", this.handleWebsocketMessage);
          },
          onShow: function () {},
          beforeUnmount: function () {
            this.blobUrls.forEach(function (t) {
              return URL.revokeObjectURL(t);
            });
          },
          methods: {
            getPcKefuChatInfo: function () {
              var t = this;
              uni.showLoading({ title: "加载中.." }),
                (0, s.send)(
                  "/wechat/ChatPc/getPcKefuChatInfo",
                  { kefu_token: this.kefu_token, keyword: this.keyword },
                  !1,
                ).then(function (e) {
                  uni.hideLoading();
                  var i = e.status,
                    a = e.msg,
                    n = e.data;
                  if (1 != i) return uni.$uv.toast(a);
                  if (
                    ((t.kefu = n.kefu),
                    (t.user_list = n.user_list),
                    (t.server_name = n.server_name),
                    (t.emoji = n.emoji),
                    (t.audio_url = n.audio_url),
                    (t.online = t.kefu.online),
                    t.initUpload(n.up_config),
                    t.chat_id)
                  ) {
                    var o = t.findIndexById(t.user_list, t.chat_id);
                    t.selectChat(t.chat_id, o);
                  }
                });
            },
            handleWebsocketMessage: function (t) {
              "sync_msg" == t.label &&
                (t.chat_id == this.select_id &&
                  (1 == t.type && (t.content = this.handleMessageText(t)),
                  this.log.push(t)),
                this.scrollToBottom(),
                (this.user_list = this.incrementKefuNewById(
                  1,
                  this.user_list,
                  t,
                )),
                this.playLocalAudio()),
                "sync_kefu_msg" == t.label &&
                  (t.chat_id == this.select_id &&
                    (1 == t.type && (t.content = this.handleMessageText(t)),
                    this.log.push(t)),
                  this.scrollToBottom(),
                  (this.user_list = this.incrementKefuNewById(
                    2,
                    this.user_list,
                    t,
                  ))),
                "up_online" == t.label && (this.kefu.online = t.online);
            },
            hideGrid: function () {
              (this.emoShow = !1), (this.gridShow = !1);
            },
            toggleGrid: function () {
              (this.gridShow = !this.gridShow), (this.emoShow = !1);
            },
            emoGrid: function () {
              (this.emoShow = !this.emoShow), (this.gridShow = !1);
            },
            close: function () {
              this.$refs.chatHistoryPop.close(), this.$refs.transFerPop.close();
            },
            jump: function (t) {
              uni.navigateTo({ url: t });
            },
            jumpTab: function (t) {
              uni.setStorageSync("cat1_id", this.cat1_id),
                uni.switchTab({ url: t });
            },
            previewImage: function (t) {
              uni.previewImage({ current: t, urls: [t] });
            },
            selectChat: function (t, e) {
              var i = this;
              this.handlePaste(), this.focusPasteZone();
              var a = this;
              (this.chat = []),
                (this.log = []),
                (this.order = []),
                (this.select_id = t),
                (0, s.send)(
                  "/wechat/ChatPc/pcKefuSelectChat",
                  { kefu_token: this.kefu_token, id: this.select_id },
                  !1,
                ).then(function (t) {
                  uni.hideLoading();
                  var n = t.status,
                    o = t.msg,
                    s = t.data;
                  if (1 != n) return uni.$uv.toast(o);
                  (i.chat = s.chat),
                    (i.log = s.log.log),
                    (i.order = s.order),
                    (i.user = s.user),
                    (i.user_list[e].kefu_new = 0),
                    i.log.forEach(function (t, e) {
                      1 == t.type && (t.content = a.handleMessageText(t));
                    }),
                    i.scrollToBottom();
                });
            },
            handleScroll: function (t) {},
            scrollToBottom: function () {
              var t = this;
              (this.scrollTop = 0),
                this.$nextTick(function () {
                  t.scrollTop = 999999;
                });
            },
            sendMsgHandle: function () {
              1 != this.show_pase ? this.sendMsg(1) : this.sendPaseImages();
            },
            sendMsg: function (t) {
              var e = this;
              if ((1 == t && (this.send_msg = this.content), !this.send_msg))
                return uni.showToast({
                  title: "请输入有效的内容",
                  icon: "none",
                });
              this.hideGrid(),
                uni.showLoading({ title: "正在发送" }),
                setTimeout(function () {
                  uni.hideLoading(),
                    (0, s.send)(
                      "/wechat/ChatPc/pcSendKefuMsg",
                      {
                        kefu_token: e.kefu_token,
                        chat_id: e.chat.id,
                        content: e.send_msg,
                        type: t,
                      },
                      !1,
                    ).then(function (t) {
                      var i = t.status,
                        a = t.msg;
                      t.data;
                      if (1 != i) return uni.$uv.toast(a);
                      (e.content = ""), (e.send_msg = "");
                    });
                }, 300);
            },
            selEmoji: function (t) {
              (this.content += t), console.log(this.content), this.hideGrid();
            },
            handleMessageText: function (t) {
              var e = {};
              this.emoji.forEach(function (t) {
                e[t.name] = t.path;
              });
              var i = t.content.replace(/\[([^\s\]]+?)\]/g, function (t, i) {
                var a = "[".concat(i, "]");
                return e[a]
                  ? '<img class="emoji-img" style="display:inline-block;width:22px;height:22px;margin-left:3px;position: relative;top: 3px;" alt="' +
                      i +
                      '" title="' +
                      i +
                      '" src="' +
                      e[a] +
                      '">'
                  : t;
              });
              return i;
            },
            initUpload: function (t) {
              this.uploader = new r.default({
                domain: t.domain,
                tokenUrl: t.token_url,
                quality: 0.6,
                prefix: t.prefix,
              });
            },
            selectImg: function () {
              var t = this;
              return (0, o.default)(
                (0, n.default)().mark(function e() {
                  var i;
                  return (0, n.default)().wrap(
                    function (e) {
                      while (1)
                        switch ((e.prev = e.next)) {
                          case 0:
                            return (
                              (e.prev = 0),
                              (e.next = 3),
                              t.uploader.chooseAndUpload()
                            );
                          case 3:
                            (i = e.sent),
                              console.log(i),
                              (t.send_msg = i.data.url),
                              t.sendMsg(2),
                              (e.next = 13);
                            break;
                          case 9:
                            (e.prev = 9),
                              (e.t0 = e["catch"](0)),
                              uni.showToast({
                                title:
                                  "发送失败: " + (e.t0.message || "未知错误"),
                                icon: "none",
                              }),
                              console.error("发送失败:", e.t0);
                          case 13:
                          case "end":
                            return e.stop();
                        }
                    },
                    e,
                    null,
                    [[0, 9]],
                  );
                }),
              )();
            },
            playLocalAudio: function () {
              var t = uni.createInnerAudioContext();
              (t.src = this.audio_url),
                t.play(),
                t.onError(function (t) {
                  console.error("音频播放失败：", t);
                });
            },
            lookOrder: function (t) {
              var e = this;
              (0, s.send)(
                "/wechat/ChatPc/lookOrder",
                { kefu_token: this.kefu_token, order_id: t },
                !1,
              ).then(function (t) {
                t.status, t.msg;
                var i = t.data;
                e.order = i;
              });
            },
            getOnlineKefuList: function () {
              var t = this;
              this.$refs.transferPop.open();
              (0, s.send)(
                "/wechat/ChatPc/getPcOnlineKefuList",
                { kefu_token: this.kefu_token },
                !1,
              ).then(function (e) {
                var i = e.status,
                  a = e.msg,
                  n = e.data;
                if (1 != i) return uni.$uv.toast(a);
                t.kefu_list = n;
              });
            },
            pcTransToTa: function (t) {
              var e = this;
              return (
                this.$refs.transferPop.close(),
                uni.showModal({
                  title: "温馨提示",
                  content: "确定要转给" + t.nickname + "么?",
                  confirmColor: "#36c337",
                  cancelText: "取消",
                  success: function (i) {
                    i.confirm &&
                      (0, s.send)(
                        "/wechat/ChatPc/pcTransToTa",
                        {
                          kefu_token: e.kefu_token,
                          trans_kefu_id: t.id,
                          chat_id: e.chat.id,
                        },
                        !1,
                      ).then(function (t) {
                        var i = t.status,
                          a = t.msg,
                          n = t.data;
                        return 1 != i
                          ? uni.$uv.toast(a)
                          : (e.log.push(n),
                            e.scrollToBottom(),
                            (e.user.disabled = 1),
                            (e.keyword = ""),
                            e.selectUser(),
                            uni.$uv.toast("转接成功, 当前聊天已结束"));
                      });
                  },
                })
              );
            },
            changeTabs: function (t) {
              (this.current = t.index),
                (this.log_kefu_id = t.id),
                this.getPcKefuLogList();
            },
            getPcKefuLogList: function () {
              var t = this;
              this.$refs.chatHistoryPop.open();
              var e = this;
              (0, s.send)(
                "/wechat/ChatPc/getPcKefuLogList",
                {
                  kefu_token: this.kefu_token,
                  chat_id: this.chat.id,
                  log_kefu_id: this.log_kefu_id,
                },
                !1,
              ).then(function (i) {
                var a = i.status,
                  n = i.msg,
                  o = i.data;
                if (1 != a) return uni.$uv.toast(n);
                (t.log_kefu_list = o.kefu_list),
                  (t.log_kefu_log = o.log.log),
                  t.log_kefu_log.forEach(function (t, i) {
                    1 == t.type && (t.content = e.handleMessageText(t));
                  });
              });
            },
            changePcKefuStatus: function () {
              var t = this;
              (this.online = !this.online),
                (0, s.send)(
                  "/wechat/ChatPc/changePcKefuStatus",
                  { kefu_token: this.kefu_token, online: this.online },
                  !1,
                ).then(function (e) {
                  var i = e.status,
                    a = e.msg;
                  e.data;
                  return 1 != i
                    ? uni.$uv.toast(a)
                    : 1 == t.online
                      ? uni.showToast({
                          title: "已开始接待",
                          icon: "success",
                          duration: 2e3,
                        })
                      : uni.showModal({
                          title: "温馨提示",
                          showCancel: !1,
                          content: "已停止接待, 请尽快结束或转接咨询中的会话",
                          success: function (t) {},
                        });
                });
            },
            selectUser: function () {
              var t = this;
              (0, s.send)(
                "/wechat/ChatPc/selectUser",
                {
                  kefu_token: this.kefu_token,
                  keyword: this.keyword,
                  chat_status: this.chat_status,
                },
                !1,
              ).then(function (e) {
                var i = e.status,
                  a = e.msg,
                  n = e.data;
                if (1 != i) return uni.$uv.toast(a);
                t.user_list = n;
              });
            },
            incrementKefuNewById: function () {
              var t =
                  arguments.length > 0 && void 0 !== arguments[0]
                    ? arguments[0]
                    : 1,
                e = arguments.length > 1 ? arguments[1] : void 0,
                i = arguments.length > 2 ? arguments[2] : void 0,
                a = e.find(function (t) {
                  return t.id === i.chat_id;
                });
              return (
                a
                  ? ((a.kefu_new = 1 == t ? Number(a.kefu_new) + 1 : 0),
                    (a.content_text = i.content_text),
                    (a.last = i.time))
                  : ((this.keyword = ""), this.selectUser()),
                e.sort(function (t, e) {
                  return new Date(e.last) - new Date(t.last);
                }),
                e
              );
            },
            endChat: function () {
              var t = this;
              return uni.showModal({
                title: "温馨提示",
                content: "确定要结束当前聊天么?",
                confirmColor: "#36c337",
                cancelText: "取消",
                success: function (e) {
                  e.confirm && t.endChatHandle();
                },
              });
            },
            endChatHandle: function () {
              var t = this;
              (this.gridShow = !1),
                (0, s.send)(
                  "/wechat/ChatPc/endPcChat",
                  { kefu_token: this.kefu_token, chat_id: this.chat.id },
                  !1,
                ).then(function (e) {
                  var i = e.status,
                    a = e.msg,
                    n = e.data;
                  return (
                    1 != i ||
                      (t.log.push(n),
                      (t.user.disabled = 1),
                      t.scrollToBottom(),
                      (t.keyword = ""),
                      t.selectUser()),
                    uni.$uv.toast(a)
                  );
                });
            },
            findIndexById: function (t, e) {
              return t.findIndex(function (t) {
                return t.id === e;
              });
            },
            focusPasteZone: function () {
              var t;
              null === (t = this.$refs.pasteZone) || void 0 === t || t.focus(),
                console.log(11);
            },
            handlePaste: function () {
              var t = this;
              console.log(22),
                document.addEventListener("paste", function (e) {
                  var i = (e.clipboardData && e.clipboardData.items) || [],
                    a = null;
                  i[0] &&
                    -1 !== i[0].type.indexOf("image") &&
                    ((a = i[0].getAsFile()), a && t.addImage(a));
                });
            },
            addImage: function (t) {
              if (t.size > 10485760)
                uni.showToast({ title: "图片大小不能超过 10MB", icon: "none" });
              else {
                (this.blobUrls = []), (this.imgList = []);
                var e = URL.createObjectURL(t);
                this.blobUrls.push(e),
                  this.imgList.push({ url: e, file: t }),
                  (this.show_pase = 1);
              }
            },
            removeImage: function (t) {
              var e = this.imgList[t];
              e &&
                (URL.revokeObjectURL(e.url),
                (this.blobUrls = this.blobUrls.filter(function (t) {
                  return t !== e.url;
                })),
                this.imgList.splice(t, 1),
                (this.show_pase = 0));
            },
            previewPaseImage: function (t) {
              uni.previewImage({
                current: t,
                urls: this.imgList.map(function (t) {
                  return t.url;
                }),
              });
            },
            sendPaseImages: function () {
              var t = this;
              return (0, o.default)(
                (0, n.default)().mark(function e() {
                  var i, a;
                  return (0, n.default)().wrap(
                    function (e) {
                      while (1)
                        switch ((e.prev = e.next)) {
                          case 0:
                            if (((t.show_pase = 0), 0 !== t.imgList.length)) {
                              e.next = 4;
                              break;
                            }
                            return (
                              uni.showToast({
                                title: "请先粘贴图片",
                                icon: "none",
                              }),
                              e.abrupt("return")
                            );
                          case 4:
                            return (
                              (e.prev = 4),
                              (i = t.imgList.map(function (e) {
                                return t.uploader.uploadDirect(e.file);
                              })),
                              (e.next = 8),
                              Promise.all(i)
                            );
                          case 8:
                            (a = e.sent),
                              (t.send_msg = a[0].data.url),
                              t.sendMsg(2),
                              (t.imgList = []),
                              (e.next = 19);
                            break;
                          case 14:
                            (e.prev = 14),
                              (e.t0 = e["catch"](4)),
                              uni.hideLoading(),
                              uni.showToast({
                                title: "上传失败",
                                icon: "error",
                              }),
                              console.error("上传错误:", e.t0);
                          case 19:
                          case "end":
                            return e.stop();
                        }
                    },
                    e,
                    null,
                    [[4, 14]],
                  );
                }),
              )();
            },
            changeChatStatus: function (t) {
              (this.chat_status = t.id),
                (this.chat_current = t.index),
                this.selectUser();
            },
          },
        };
      e.default = c;
    },
    "56da": function (t, e, i) {
      "use strict";
      i("6a54");
      var a = i("f5bd").default;
      Object.defineProperty(e, "__esModule", { value: !0 }),
        (e.default = void 0),
        i("64aa");
      var n,
        o,
        s = a(i("9b1b")),
        r = {
          props: (0, s.default)(
            {
              value: { type: [String, Number], default: "" },
              modelValue: { type: [String, Number], default: "" },
              placeholder: { type: [String, Number], default: "" },
              placeholderClass: {
                type: String,
                default: "textarea-placeholder",
              },
              placeholderStyle: {
                type: [String, Object],
                default: "color: #c0c4cc",
              },
              height: { type: [String, Number], default: 70 },
              confirmType: { type: String, default: "return" },
              disabled: { type: Boolean, default: !1 },
              count: { type: Boolean, default: !1 },
              focus: { type: Boolean, default: !1 },
              autoHeight: { type: Boolean, default: !1 },
              fixed: { type: Boolean, default: !1 },
              cursorSpacing: { type: Number, default: 0 },
              cursor: { type: [String, Number], default: "" },
              showConfirmBar: { type: Boolean, default: !0 },
              selectionStart: { type: Number, default: -1 },
              selectionEnd: { type: Number, default: -1 },
              adjustPosition: { type: Boolean, default: !0 },
              disableDefaultPadding: { type: Boolean, default: !1 },
              holdKeyboard: { type: Boolean, default: !1 },
              maxlength: { type: [String, Number], default: 140 },
              border: { type: String, default: "surround" },
              formatter: { type: [Function, null], default: null },
              ignoreCompositionEvent: { type: Boolean, default: !0 },
              confirmHold: { type: Boolean, default: !1 },
              textStyle: { type: [Object, String], default: function () {} },
              countStyle: { type: [Object, String], default: function () {} },
            },
            null === (n = uni.$uv) ||
              void 0 === n ||
              null === (o = n.props) ||
              void 0 === o
              ? void 0
              : o.textarea,
          ),
        };
      e.default = r;
    },
    "62a9": function (t, e, i) {
      var a = i("3105");
      a.__esModule && (a = a.default),
        "string" === typeof a && (a = [[t.i, a, ""]]),
        a.locals && (t.exports = a.locals);
      var n = i("967d").default;
      n("0bdeecc7", a, !0, { sourceMap: !1, shadowMode: !1 });
    },
    "64d8": function (t, e, i) {
      var a = i("4bc9");
      a.__esModule && (a = a.default),
        "string" === typeof a && (a = [[t.i, a, ""]]),
        a.locals && (t.exports = a.locals);
      var n = i("967d").default;
      n("52a068ac", a, !0, { sourceMap: !1, shadowMode: !1 });
    },
    "67a0": function (t, e, i) {
      var a = i("f9d7");
      a.__esModule && (a = a.default),
        "string" === typeof a && (a = [[t.i, a, ""]]),
        a.locals && (t.exports = a.locals);
      var n = i("967d").default;
      n("28db80b0", a, !0, { sourceMap: !1, shadowMode: !1 });
    },
    "6c27": function (t, e, i) {
      "use strict";
      i("6a54");
      var a = i("f5bd").default;
      Object.defineProperty(e, "__esModule", { value: !0 }),
        (e.default = void 0),
        i("c223"),
        i("aa9c");
      var n = a(i("4d8f0")),
        o = a(i("9463")),
        s = a(i("56da")),
        r = {
          name: "uv-textarea",
          mixins: [n.default, o.default, s.default],
          data: function () {
            return {
              innerValue: "",
              focused: !1,
              innerFormatter: function (t) {
                return t;
              },
            };
          },
          created: function () {
            this.innerValue = this.value;
          },
          watch: {
            value: function (t) {
              this.innerValue = t;
            },
            modelValue: function (t) {
              this.innerValue = t;
            },
          },
          computed: {
            textareaClass: function () {
              var t = [],
                e = this.border,
                i = this.disabled;
              return (
                "surround" === e &&
                  (t = t.concat(["uv-border", "uv-textarea--radius"])),
                "bottom" === e &&
                  (t = t.concat([
                    "uv-border-bottom",
                    "uv-textarea--no-radius",
                  ])),
                i && t.push("uv-textarea--disabled"),
                t.join(" ")
              );
            },
            textareaStyle: function () {
              return this.$uv.deepMerge(
                {},
                this.$uv.addStyle(this.customStyle),
              );
            },
            maxlen: function () {
              return this.maxlength < 0
                ? this.maxlength < 0
                  ? -1
                  : 140
                : this.maxlength;
            },
            getCount: function () {
              try {
                return this.innerValue.length > this.maxlen
                  ? this.maxlen
                  : this.innerValue.length;
              } catch (t) {
                return 0;
              }
            },
          },
          methods: {
            setFormatter: function (t) {
              this.innerFormatter = t;
            },
            onFocus: function (t) {
              this.$emit("focus", t);
            },
            onBlur: function (t) {
              this.$emit("blur", t), this.$uv.formValidate(this, "blur");
            },
            onLinechange: function (t) {
              this.$emit("linechange", t);
            },
            onInput: function (t) {
              var e = this,
                i = t.detail || {},
                a = i.value,
                n = void 0 === a ? "" : a,
                o = this.formatter || this.innerFormatter,
                s = o(n);
              (this.innerValue = n),
                this.$nextTick(function () {
                  (e.innerValue = s), e.valueChange();
                });
            },
            valueChange: function () {
              var t = this,
                e = this.innerValue;
              this.$nextTick(function () {
                t.$emit("input", e),
                  t.$emit("update:modelValue", e),
                  t.$emit("change", e),
                  t.$uv.formValidate(t, "change");
              });
            },
            onConfirm: function (t) {
              this.$emit("confirm", t);
            },
            onKeyboardheightchange: function (t) {
              this.$emit("keyboardheightchange", t);
            },
          },
        };
      e.default = r;
    },
    7689: function (t, e, i) {
      "use strict";
      i("6a54");
      var a = i("f5bd").default;
      Object.defineProperty(e, "__esModule", { value: !0 }),
        (e.default = void 0),
        i("64aa");
      var n,
        o,
        s = a(i("9b1b")),
        r = {
          props: (0, s.default)(
            {
              duration: { type: Number, default: 300 },
              list: {
                type: Array,
                default: function () {
                  return [];
                },
              },
              lineColor: { type: String, default: "#3c9cff" },
              activeStyle: {
                type: [String, Object],
                default: function () {
                  return { color: "#303133" };
                },
              },
              inactiveStyle: {
                type: [String, Object],
                default: function () {
                  return { color: "#606266" };
                },
              },
              lineWidth: { type: [String, Number], default: 20 },
              lineHeight: { type: [String, Number], default: 3 },
              lineBgSize: { type: String, default: "cover" },
              itemStyle: {
                type: [String, Object],
                default: function () {
                  return { height: "44px" };
                },
              },
              scrollable: { type: Boolean, default: !0 },
              current: { type: [Number, String], default: 0 },
              keyName: { type: String, default: "name" },
            },
            null === (n = uni.$uv) ||
              void 0 === n ||
              null === (o = n.props) ||
              void 0 === o
              ? void 0
              : o.tabs,
          ),
        };
      e.default = r;
    },
    "96f8": function (t, e, i) {
      "use strict";
      i.r(e);
      var a = i("6c27"),
        n = i.n(a);
      for (var o in a)
        ["default"].indexOf(o) < 0 &&
          (function (t) {
            i.d(e, t, function () {
              return a[t];
            });
          })(o);
      e["default"] = n.a;
    },
    "9e9a": function (t, e) {
      t.exports =
        "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAADwAAAA8CAYAAAA6/NlyAAAACXBIWXMAAAsTAAALEwEAmpwYAAAGiGlUWHRYTUw6Y29tLmFkb2JlLnhtcAAAAAAAPD94cGFja2V0IGJlZ2luPSLvu78iIGlkPSJXNU0wTXBDZWhpSHpyZVN6TlRjemtjOWQiPz4gPHg6eG1wbWV0YSB4bWxuczp4PSJhZG9iZTpuczptZXRhLyIgeDp4bXB0az0iQWRvYmUgWE1QIENvcmUgOS4xLWMwMDEgNzkuMTQ2Mjg5OSwgMjAyMy8wNi8yNS0yMDowMTo1NSAgICAgICAgIj4gPHJkZjpSREYgeG1sbnM6cmRmPSJodHRwOi8vd3d3LnczLm9yZy8xOTk5LzAyLzIyLXJkZi1zeW50YXgtbnMjIj4gPHJkZjpEZXNjcmlwdGlvbiByZGY6YWJvdXQ9IiIgeG1sbnM6eG1wPSJodHRwOi8vbnMuYWRvYmUuY29tL3hhcC8xLjAvIiB4bWxuczpkYz0iaHR0cDovL3B1cmwub3JnL2RjL2VsZW1lbnRzLzEuMS8iIHhtbG5zOnBob3Rvc2hvcD0iaHR0cDovL25zLmFkb2JlLmNvbS9waG90b3Nob3AvMS4wLyIgeG1sbnM6eG1wTU09Imh0dHA6Ly9ucy5hZG9iZS5jb20veGFwLzEuMC9tbS8iIHhtbG5zOnN0RXZ0PSJodHRwOi8vbnMuYWRvYmUuY29tL3hhcC8xLjAvc1R5cGUvUmVzb3VyY2VFdmVudCMiIHhtcDpDcmVhdG9yVG9vbD0iQWRvYmUgUGhvdG9zaG9wIDI1LjAgKFdpbmRvd3MpIiB4bXA6Q3JlYXRlRGF0ZT0iMjAyNS0xMS0xN1QwNToyOToyOCswODowMCIgeG1wOk1vZGlmeURhdGU9IjIwMjUtMTEtMTdUMDU6NDM6MTQrMDg6MDAiIHhtcDpNZXRhZGF0YURhdGU9IjIwMjUtMTEtMTdUMDU6NDM6MTQrMDg6MDAiIGRjOmZvcm1hdD0iaW1hZ2UvcG5nIiBwaG90b3Nob3A6Q29sb3JNb2RlPSIzIiB4bXBNTTpJbnN0YW5jZUlEPSJ4bXAuaWlkOmVkNzkxMDY1LTMwYWYtMjQ0ZS1iNzU4LTViZTYxOTRkNjBmYyIgeG1wTU06RG9jdW1lbnRJRD0ieG1wLmRpZDpjZDU1NjFkYi05Mzc3LTJiNDEtYTI1OS1iMWRiMzczNWQwYmYiIHhtcE1NOk9yaWdpbmFsRG9jdW1lbnRJRD0ieG1wLmRpZDpjZDU1NjFkYi05Mzc3LTJiNDEtYTI1OS1iMWRiMzczNWQwYmYiPiA8eG1wTU06SGlzdG9yeT4gPHJkZjpTZXE+IDxyZGY6bGkgc3RFdnQ6YWN0aW9uPSJjcmVhdGVkIiBzdEV2dDppbnN0YW5jZUlEPSJ4bXAuaWlkOmNkNTU2MWRiLTkzNzctMmI0MS1hMjU5LWIxZGIzNzM1ZDBiZiIgc3RFdnQ6d2hlbj0iMjAyNS0xMS0xN1QwNToyOToyOCswODowMCIgc3RFdnQ6c29mdHdhcmVBZ2VudD0iQWRvYmUgUGhvdG9zaG9wIDI1LjAgKFdpbmRvd3MpIi8+IDxyZGY6bGkgc3RFdnQ6YWN0aW9uPSJzYXZlZCIgc3RFdnQ6aW5zdGFuY2VJRD0ieG1wLmlpZDo5OTkyNDJhZC1kODk2LTNjNDYtOTkzNi1lODRiODIwMjY0MDYiIHN0RXZ0OndoZW49IjIwMjUtMTEtMTdUMDU6NDM6MDcrMDg6MDAiIHN0RXZ0OnNvZnR3YXJlQWdlbnQ9IkFkb2JlIFBob3Rvc2hvcCAyNS4wIChXaW5kb3dzKSIgc3RFdnQ6Y2hhbmdlZD0iLyIvPiA8cmRmOmxpIHN0RXZ0OmFjdGlvbj0ic2F2ZWQiIHN0RXZ0Omluc3RhbmNlSUQ9InhtcC5paWQ6ZWQ3OTEwNjUtMzBhZi0yNDRlLWI3NTgtNWJlNjE5NGQ2MGZjIiBzdEV2dDp3aGVuPSIyMDI1LTExLTE3VDA1OjQzOjE0KzA4OjAwIiBzdEV2dDpzb2Z0d2FyZUFnZW50PSJBZG9iZSBQaG90b3Nob3AgMjUuMCAoV2luZG93cykiIHN0RXZ0OmNoYW5nZWQ9Ii8iLz4gPC9yZGY6U2VxPiA8L3htcE1NOkhpc3Rvcnk+IDwvcmRmOkRlc2NyaXB0aW9uPiA8L3JkZjpSREY+IDwveDp4bXBtZXRhPiA8P3hwYWNrZXQgZW5kPSJyIj8+ddwmQQAAB7xJREFUaIHt23uwVVUdB/DP9V5BAiJKkCsapCmhlYmYDU1SCjNpSlmG42RlRWVZzdTENGlPa3LGsT+sqUAso3xUlkozZvaauJVRkjoxhgRImnJhDLyCIBeE2x+/vTl773se+5x7EEG/M3vO2Wuvvc76rsfvtX6nY2BgwPMJh+zvDjzbeN4R7sreTJ8+vd3tj8cMnIKXoztzDcdmbMDG5HMN/oR70d+uTixfvnzv96469VrF63AmZuNUvLRO3VFiIIp4GL/E77FMDEhb0E7CZ2EezsBLhtjWJHwyuR7GdfgpVg+x3bYQPlcQnYkxdertwJOZ6xmMxGi8OPkcVuW9SfgaLhHEb8aqVjs7FMIn4ktiZkfXqLMCt+MmPNigvRF4Lc7H2zC18HwiviwG9yp8q5VOt0p4JhbhuCrP1or9dyvux1Ml23waf0uubwhhdwHeLlZAiom4AlNwabMdb0UtXYgfG0x2TdLR2fgM/qw82SKewB34GN6JX2BX5vkYfCT5jaObabhZwtdiYeFH+vFNIawux7om26yHbUJSfxDvTr6n6MIbhRo7qWyDzRC+CnPl9+sGMdJfxX+baKtZbMESfBQ/KTybhNvUF5h7UZbwp/GhQqMPYg5uwNaS7QwVa4WquqxQ3o0flWmgDOGzkh/IGhDrxGzfgz1lfqiN+B+uFNZbisPElrqy0cuNCB+Jr8gbEo8LybmiiU7uC6zCezL3o4TUnl/vpUaEP4wTVNTXdnxCLK39jW24SxglKUYKA6WaukR9wicJtTAyU/a55Ee2t9zN9mITvieEFsGnW5CuinqELxFCqiO5vwG3CLPwuYTN+D52JvcjhOaYUa1yLcKz8V4hDIjls1gYBM819AvrbHGmbDg+Xq1yLcLvwqGZ+x/iPpVRrIcuHCGkeium62GYgMObeOdJ0cfNyf2hOA/TihVrEX6LSmfTxsos5bliYHrF/lqC15frM5glLKdePII71ViaBezCA0k/U3Ql7eVQjfDpwnRMn/XgP8Kdq4cjxd55tcq+P1sYJ+NKdPpEfABp2GUE3oSLS7xLLO2/Zu47RSAih2qEZyWVU/QIX7YRuuUleorxypl9Y8VSzmIkjhI6thF2iNWxPrnvFF5dLuJSjfAc+b1XlvB21VfB08rt/X6D1d1A8m5ZNbgTd2fuDxGWYq4gi1HCz0zL/yXMyEbLGVbiL2LvpngES5PPRngIy7E7U7YOv1befN2R1E/RgZOzFYpSdILK/iN83DJkU1yGPwjpuFO4cw+UfHcTrhEzNF3M+DL5GWuEXfLhnw6FbVIk3C1PuFd+xBthD36TXK2gD79NrlawW/Q5xSDCxSVdnOHHNEd4f2NA+M6pu1qKcBa9nn33b6jYLSYqRXf2YTWhlZ3hrQ48wgMqsbQOBZVWJNybvJBiorxOPhDQKXQ3wWV99mGR8Hp5wkc58AgPU9maA/JC7KCb4U7R5xSlZjiLA22Gu+QJ02CGN4kgWTrLM/CyKvXqYayIlpRxGOq1MVVzLiLhWmZNyT34d7ZCNSJL5K2r01UCAY1woTAv7xcB+5Pr1q6OV+DzwvNZJjywshgm+ptij3Ax96Ia4bvkjY1mCM9QWVLniYjnKTVrD8YxIuo4X3hYk0T4tQyGibPpVyX3e/BPYR7vRTXCPfLeSTOE75ZX+nPEyeEXBZlaOEIcp9wkAocpNorVUgbD5YMFu+WPZlA9BNMnbOE0zDMp6cy3NY563Cxm5rM4Nik7Xpz2fUo4FisL7xwtBvWVhfLHcaNyx6Idwu+dmyl7RknChIs1RyWudbE4wStjeS1IPufLz+rhhQ7VQ68I11yjnC88Rpwbn5Dc7xaBvd8VK9aSvouFx5I67seKs6WxJTu8QIRrbtPcudNT+BXeL1zNMrkdnZiM92XK+vHdapXrRRUX4s0qaQgXCYHWo1yGTY/IxjlNpEWcq/Y+fkhoh9vxDxEWLouxYnDT5Jj+pK1bqlXuyGbiVUlbWiBGbkRyv0IcUK8pViyJkUI/jxP7blNybdWaGzpaqMKFmbI+vENEWpBPW2pkUFwrP9qvEZK05tlNA2wTEdB78HdxRtWnNbJdQs9nyW7H9TJki2hE+F6hUvoyZafiamEg7E8cL3/asEOkSXyh3ktlTMYFQmJmhc8coWomN9PDNqETbxBCNfv7m4U6rCvVm8kAKAqri/AdEUDvqPbSPsAEkV7RIwL/KR7FOUpER5txCs4xOGHlbJFqMFc+tWhfYLI4C75c/txrY1J2X5lGms3imSr025ZM2TRxlLpIZNWUNUPLYpxIZvm5MC6yeExYcKXyO2gtT+tSscQfzZR1iVm+VQi0KS20W8SLxNnQ9UKOZJ2QXcKSOh8/a6bRVjPxfiD059XyNvB4MSAXCANiqXDPVipnrIwSqm9Wck0z+FypT5C8Qt5RKYVGhkcjTBGKf57BkYYsVgudWyu5dIywtY9RCcAVsUUIq0UitbE02pkvvUr4vDeKWZ0nvKsijtO6sdKHP4pM2jtabGMv2pUvvRpfF+7hGSJlYqZY4q1gh0h8u1N4bj1t6CPanxG/NrkWCaP+NLxV5S8A41Ts8hRp4HyDGLilYibLHsI1hX3xF4AUT4jZyR5fdoqByP7nYaPmvKMhoeOF/y0d5HiB8MGO/wMhibLvJjQgsgAAAABJRU5ErkJggg==";
    },
    a112: function (t, e) {
      t.exports =
        "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAADwAAAA8CAYAAAA6/NlyAAAACXBIWXMAAAsTAAALEwEAmpwYAAAGiGlUWHRYTUw6Y29tLmFkb2JlLnhtcAAAAAAAPD94cGFja2V0IGJlZ2luPSLvu78iIGlkPSJXNU0wTXBDZWhpSHpyZVN6TlRjemtjOWQiPz4gPHg6eG1wbWV0YSB4bWxuczp4PSJhZG9iZTpuczptZXRhLyIgeDp4bXB0az0iQWRvYmUgWE1QIENvcmUgOS4xLWMwMDEgNzkuMTQ2Mjg5OSwgMjAyMy8wNi8yNS0yMDowMTo1NSAgICAgICAgIj4gPHJkZjpSREYgeG1sbnM6cmRmPSJodHRwOi8vd3d3LnczLm9yZy8xOTk5LzAyLzIyLXJkZi1zeW50YXgtbnMjIj4gPHJkZjpEZXNjcmlwdGlvbiByZGY6YWJvdXQ9IiIgeG1sbnM6eG1wPSJodHRwOi8vbnMuYWRvYmUuY29tL3hhcC8xLjAvIiB4bWxuczpkYz0iaHR0cDovL3B1cmwub3JnL2RjL2VsZW1lbnRzLzEuMS8iIHhtbG5zOnBob3Rvc2hvcD0iaHR0cDovL25zLmFkb2JlLmNvbS9waG90b3Nob3AvMS4wLyIgeG1sbnM6eG1wTU09Imh0dHA6Ly9ucy5hZG9iZS5jb20veGFwLzEuMC9tbS8iIHhtbG5zOnN0RXZ0PSJodHRwOi8vbnMuYWRvYmUuY29tL3hhcC8xLjAvc1R5cGUvUmVzb3VyY2VFdmVudCMiIHhtcDpDcmVhdG9yVG9vbD0iQWRvYmUgUGhvdG9zaG9wIDI1LjAgKFdpbmRvd3MpIiB4bXA6Q3JlYXRlRGF0ZT0iMjAyNS0xMS0xN1QwNToyOTo1MSswODowMCIgeG1wOk1vZGlmeURhdGU9IjIwMjUtMTEtMTdUMDU6NDI6MTQrMDg6MDAiIHhtcDpNZXRhZGF0YURhdGU9IjIwMjUtMTEtMTdUMDU6NDI6MTQrMDg6MDAiIGRjOmZvcm1hdD0iaW1hZ2UvcG5nIiBwaG90b3Nob3A6Q29sb3JNb2RlPSIzIiB4bXBNTTpJbnN0YW5jZUlEPSJ4bXAuaWlkOmEzOGJjNGMwLTFiYWItYTc0ZS1iNTE4LTk5NGU0OWVkNDc1YiIgeG1wTU06RG9jdW1lbnRJRD0ieG1wLmRpZDpmZDU4ZTg4NC03YmFmLTExNDAtOTQyOS02ZjAwOWI1MDUwZGQiIHhtcE1NOk9yaWdpbmFsRG9jdW1lbnRJRD0ieG1wLmRpZDpmZDU4ZTg4NC03YmFmLTExNDAtOTQyOS02ZjAwOWI1MDUwZGQiPiA8eG1wTU06SGlzdG9yeT4gPHJkZjpTZXE+IDxyZGY6bGkgc3RFdnQ6YWN0aW9uPSJjcmVhdGVkIiBzdEV2dDppbnN0YW5jZUlEPSJ4bXAuaWlkOmZkNThlODg0LTdiYWYtMTE0MC05NDI5LTZmMDA5YjUwNTBkZCIgc3RFdnQ6d2hlbj0iMjAyNS0xMS0xN1QwNToyOTo1MSswODowMCIgc3RFdnQ6c29mdHdhcmVBZ2VudD0iQWRvYmUgUGhvdG9zaG9wIDI1LjAgKFdpbmRvd3MpIi8+IDxyZGY6bGkgc3RFdnQ6YWN0aW9uPSJzYXZlZCIgc3RFdnQ6aW5zdGFuY2VJRD0ieG1wLmlpZDozOTdjOGMwZC03NGEyLWNlNDgtOGY2ZC0wOGEyYWFlMWZmZWMiIHN0RXZ0OndoZW49IjIwMjUtMTEtMTdUMDU6NDA6MzQrMDg6MDAiIHN0RXZ0OnNvZnR3YXJlQWdlbnQ9IkFkb2JlIFBob3Rvc2hvcCAyNS4wIChXaW5kb3dzKSIgc3RFdnQ6Y2hhbmdlZD0iLyIvPiA8cmRmOmxpIHN0RXZ0OmFjdGlvbj0ic2F2ZWQiIHN0RXZ0Omluc3RhbmNlSUQ9InhtcC5paWQ6YTM4YmM0YzAtMWJhYi1hNzRlLWI1MTgtOTk0ZTQ5ZWQ0NzViIiBzdEV2dDp3aGVuPSIyMDI1LTExLTE3VDA1OjQyOjE0KzA4OjAwIiBzdEV2dDpzb2Z0d2FyZUFnZW50PSJBZG9iZSBQaG90b3Nob3AgMjUuMCAoV2luZG93cykiIHN0RXZ0OmNoYW5nZWQ9Ii8iLz4gPC9yZGY6U2VxPiA8L3htcE1NOkhpc3Rvcnk+IDwvcmRmOkRlc2NyaXB0aW9uPiA8L3JkZjpSREY+IDwveDp4bXBtZXRhPiA8P3hwYWNrZXQgZW5kPSJyIj8+oIRRvAAABSZJREFUaIHt28lvHEUUx/HPjO1JIIYQYkjCDmLfl7CDxBLWQBAQEGE9IG5cOPA38EcgEAcQIIG4ICEhQIAACRSxKOybEHvYAyFA4tgcft2ZcRMv8YztsfFPstotd8/Ut+rVe69elWvDw8P+T6rPdAOmW/PAc13zwHNdva03K1euLH/twSXYDwcV992u7fgGX+E5DJZ/WL9+/Y6Hev/zGgtwH67GQjSmspUd1jb8hedxT/H7CFWBG7gLa7EcQ/gHsyFY17CnWOM16MPdKtBV4HNxJ1bgO3yM16Tnul0NnI5jZSpegevxcOtDVeCrcJT01hN4CR+ZHcB9eAMXy8jug3V4TMt8rgJfIPP2BzyJDWISs8Wkv8PvuAnLcEpx/aZ8qAp8ePHiRhnZP8wO2FK/S7s3CugS8UU7gKtxuL+4bsbfZhcsae/f+LO4r2NR6wNV4PJ++9S2a8rV2v4RjJ3MtGrFT1drZ4nHrqoEbRTXbdLDXTkdOgG8QkLAfpKl/YBv8b3Mp65Su8D7SoA/STz87vgS7+LF4rqlze/oqNoBXihBfh2OxlIx618l/i3HQ3hPFznBdoAPkJz1NMlhy7m8BIulQzbgcwlzXaF2vPTxOFFg65oeui4debCM/OJ2GthptQN8JPYa4zP6xJn1j/L3GVE7wIPGDz1liOoatQP8Hn6SNXNVw7Lo+Bqb2viOjqsd4A2yHPsJWwV8SEZ+E97E27IA6Rq146U34vHiM06WBKQPv+BDWV6+IRWTrlE7wNvxsiy9zsOZ2E2qJK/gHYHvqhSz3Uxrq6w/P5NSSk3TrLsyn+5ELj0k4LNCnQDutEpHOmwKLKSbgHtkMXIS9sYHEgkGx3ppV9UtwL2Sqt4hhcQFAnu/rLo6Bt0NwH04DrfjWllX1zAgmdpmrNch6JkGbuAYWWJejf0127QUF0oSswXv6wD0TO4eNmQ1tRZrZHXVOgB1KbVeLnXmQ3VgU2+mgBs4QtbT1+AwMe2qenCgdMh1muY+ac0EcEMA1wjskcbeoeyT8tENWC2mPmno6QYuCwOrxUEdKx55PC0Qx3azePHdJ9uA6QQuzfNKMc/jJPeeqBZKrew2nGXnU2BcTcZLtxbcJ5oN1TS3MNdKcjGZUVokC5VNmkvQna3HR9VkgJdJ6WYbfpYq5XjhYjkuw40ySovGfnxU1aSsdIkA/ykZ2YS1q8CHYJXMvS34FK9LZXK0de++uFRCy6kmD1uqLh1+lXT2g/hioi/vCvCB4inXyEGXbbK7cBCewSeyXdlqYgPSQetkd75TBb0eSVKuL77zEdkbHlcTBd5fHM1NkiyUnvUAqUMvwQtS0vleOmMpLireOQN76OxmW6+EtxvFvJ+SctO4L42nZRIvS9jdNBveIwnEQnFKK6QK8hvOKd45S2rTnd5ZrEnHl6npH2JpY6oKPCRzpEzhlspcWYcTjIQt1Sdm3S/OaUB6epVA723qwl9NfMKpuFXM+53K943w4lXgzbKT0C9men7xQWUYGW2UegX0dBnNLWJuA6b+UFt5XOkcGeW6Zsgb0jwNsKOhrfpU8yDIRbhF9o76jW+SdbGAY6SetcD0JTY16eiLi/tlxfVX8Sk7VG3Qi7KnOyDntc42MdhWNQR8utPWukzB1RK2BvGWlJNHPNSqp6UKOSxl10VmwTGGFtU1o8GPeFQlKaoCv4oHJKbVBXxolv0MFrDPyGbACFXn8FapIx3mf3K4lKSI9+JZc+T4cKtq8//VMsc1DzzXNQ881/UvuDYo4RBiHRwAAAAASUVORK5CYII=";
    },
    b24f: function (t, e, i) {
      "use strict";
      var a = i("64d8"),
        n = i.n(a);
      n.a;
    },
    babb: function (t, e, i) {
      "use strict";
      i.r(e);
      var a = i("5629"),
        n = i.n(a);
      for (var o in a)
        ["default"].indexOf(o) < 0 &&
          (function (t) {
            i.d(e, t, function () {
              return a[t];
            });
          })(o);
      e["default"] = n.a;
    },
    dfe7: function (t, e) {
      t.exports =
        "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAADwAAAA8CAYAAAA6/NlyAAAACXBIWXMAAAsTAAALEwEAmpwYAAAGiGlUWHRYTUw6Y29tLmFkb2JlLnhtcAAAAAAAPD94cGFja2V0IGJlZ2luPSLvu78iIGlkPSJXNU0wTXBDZWhpSHpyZVN6TlRjemtjOWQiPz4gPHg6eG1wbWV0YSB4bWxuczp4PSJhZG9iZTpuczptZXRhLyIgeDp4bXB0az0iQWRvYmUgWE1QIENvcmUgOS4xLWMwMDEgNzkuMTQ2Mjg5OSwgMjAyMy8wNi8yNS0yMDowMTo1NSAgICAgICAgIj4gPHJkZjpSREYgeG1sbnM6cmRmPSJodHRwOi8vd3d3LnczLm9yZy8xOTk5LzAyLzIyLXJkZi1zeW50YXgtbnMjIj4gPHJkZjpEZXNjcmlwdGlvbiByZGY6YWJvdXQ9IiIgeG1sbnM6eG1wPSJodHRwOi8vbnMuYWRvYmUuY29tL3hhcC8xLjAvIiB4bWxuczpkYz0iaHR0cDovL3B1cmwub3JnL2RjL2VsZW1lbnRzLzEuMS8iIHhtbG5zOnBob3Rvc2hvcD0iaHR0cDovL25zLmFkb2JlLmNvbS9waG90b3Nob3AvMS4wLyIgeG1sbnM6eG1wTU09Imh0dHA6Ly9ucy5hZG9iZS5jb20veGFwLzEuMC9tbS8iIHhtbG5zOnN0RXZ0PSJodHRwOi8vbnMuYWRvYmUuY29tL3hhcC8xLjAvc1R5cGUvUmVzb3VyY2VFdmVudCMiIHhtcDpDcmVhdG9yVG9vbD0iQWRvYmUgUGhvdG9zaG9wIDI1LjAgKFdpbmRvd3MpIiB4bXA6Q3JlYXRlRGF0ZT0iMjAyNS0xMS0xN1QwNTozMDoyMyswODowMCIgeG1wOk1vZGlmeURhdGU9IjIwMjUtMTEtMTdUMDY6MTI6NDMrMDg6MDAiIHhtcDpNZXRhZGF0YURhdGU9IjIwMjUtMTEtMTdUMDY6MTI6NDMrMDg6MDAiIGRjOmZvcm1hdD0iaW1hZ2UvcG5nIiBwaG90b3Nob3A6Q29sb3JNb2RlPSIzIiB4bXBNTTpJbnN0YW5jZUlEPSJ4bXAuaWlkOjcxMDdhYzMwLTcxZmYtZTg0Yi04Yzk3LWZjN2EyZGQ2OTZjMiIgeG1wTU06RG9jdW1lbnRJRD0ieG1wLmRpZDo4MDU5NmE5Yy0zOGUzLTgwNGQtYTc2Ni02ZDgyZjE4OTYwZWUiIHhtcE1NOk9yaWdpbmFsRG9jdW1lbnRJRD0ieG1wLmRpZDo4MDU5NmE5Yy0zOGUzLTgwNGQtYTc2Ni02ZDgyZjE4OTYwZWUiPiA8eG1wTU06SGlzdG9yeT4gPHJkZjpTZXE+IDxyZGY6bGkgc3RFdnQ6YWN0aW9uPSJjcmVhdGVkIiBzdEV2dDppbnN0YW5jZUlEPSJ4bXAuaWlkOjgwNTk2YTljLTM4ZTMtODA0ZC1hNzY2LTZkODJmMTg5NjBlZSIgc3RFdnQ6d2hlbj0iMjAyNS0xMS0xN1QwNTozMDoyMyswODowMCIgc3RFdnQ6c29mdHdhcmVBZ2VudD0iQWRvYmUgUGhvdG9zaG9wIDI1LjAgKFdpbmRvd3MpIi8+IDxyZGY6bGkgc3RFdnQ6YWN0aW9uPSJzYXZlZCIgc3RFdnQ6aW5zdGFuY2VJRD0ieG1wLmlpZDo4OWIzZWEyOS00OTc3LWIzNDgtOGE1Yy1jMWJiNTE3MDlkYTYiIHN0RXZ0OndoZW49IjIwMjUtMTEtMTdUMDU6NDM6NDUrMDg6MDAiIHN0RXZ0OnNvZnR3YXJlQWdlbnQ9IkFkb2JlIFBob3Rvc2hvcCAyNS4wIChXaW5kb3dzKSIgc3RFdnQ6Y2hhbmdlZD0iLyIvPiA8cmRmOmxpIHN0RXZ0OmFjdGlvbj0ic2F2ZWQiIHN0RXZ0Omluc3RhbmNlSUQ9InhtcC5paWQ6NzEwN2FjMzAtNzFmZi1lODRiLThjOTctZmM3YTJkZDY5NmMyIiBzdEV2dDp3aGVuPSIyMDI1LTExLTE3VDA2OjEyOjQzKzA4OjAwIiBzdEV2dDpzb2Z0d2FyZUFnZW50PSJBZG9iZSBQaG90b3Nob3AgMjUuMCAoV2luZG93cykiIHN0RXZ0OmNoYW5nZWQ9Ii8iLz4gPC9yZGY6U2VxPiA8L3htcE1NOkhpc3Rvcnk+IDwvcmRmOkRlc2NyaXB0aW9uPiA8L3JkZjpSREY+IDwveDp4bXBtZXRhPiA8P3hwYWNrZXQgZW5kPSJyIj8+HSnrSwAABFNJREFUaIHtmltoXEUYx3+x1qQhGFvrrQGbxFu1Pij9oFhRRLR4ebC+CKL2TVrxxQv6IFYfBSXog0jBy4saFbxfiIZqvNBS8V8FjRqL2GhE0oDa1NTaJDY+zFl6dvacs7s5Obuezf5gSOZ8M9+ef2Z25vtm0jI3N8di4rh6v0CtaQpudJqCG52m4EZn0Qk+vt4vUAlmtgS4HDgP+BXYAUxLOlqtr1wIBi4D3gXag/obwDNmths4UI3wvEzpKaA1VL8ReA3oAzaY2WmVOmrJQyxtZsuAl4GrgWWeeQx4B3gJ2CtpIslXLgQDmNkq4A5gHXBtRJNvgY9wI/+VpINRfuoi2MzagRM59p2shjW4KX0RYBH2PcAQsEPSB76xZoLN7ExgA7AeOBUntjWxUzJnAefG2I4APwBDku4KG2oi2Mw2AVtxL7iKdEKrYRrYKOmTwoPMtyUz2wo8CJwOLMn68zxOACbDDzIVbGabgceADs80BYwDiStqGdqALiBuSzoIvAIMhx9mNqXNrAPYDaz1TPdIejyF31bgbmAb0YveYdz+3CfpgG/MZITNrAW4n2KxU8AmSR/O02cncCtua/L/iNPA38CLwHZJw8SQ1ZTuALaE6jPAfSnEdgD9wHWeaQb3tRgEnpc0VM5XVoJ7cFtPgX2StqfwZ5SKHQW+APolvVmpo6wE93r1kZT+xoHPgdW46TsMvAAMSvq9GkdZCe7y6r+kcSZpxMzuBc7HBRWfSRqdj6+sBO/36ivSOpS0E9iZ1k9W6eEer74uo8+pmqwEjwE/huq9ZrYlrnEtyUSwpFlcmlZgKfBIkOLVlSwjrZXALuCc0ONDwNPAgKTBTD64DJlmS8E0fpLoxfEn4Gvgt6CMBz+jmMAthH8Cs8C/wSyqmszTQzN7DrgFl7mk5Q9gABdwvA5Mxp1sxFELwStwo3wpLkVcCOHgEvy3cSHlN5V2qtUBwHLgKuAa4Gzg5FBZ6jWfw8XI4XJSRLsC3wEPSHqrknep6ZmWmbUB3bhYuzsobV6zo8A/uDTvcPB7V1BOwYWXa7w+U8BNkgbKvUOeTi1X4pL9XuBm4AaK8+HvgduDiCyW3AgOY2Y9wCXAU0BnyPQ+bqT/iuubl5uHIiTtk9QPPOSZrsCtFbHkUnCIZ3Fn0AXagM1JHXItWNIh3J4c5oKkPrkWHOAvUquTGjeCYP9ybTSpcSMI7vHqfi5eRK4Fm9kZwJXe40TBefkPgBLMbC1wJ+7OuMBe4OOkfrkTHMTlG4HbgOtDphngYUlfJvUvEWxmXbik3V8M6snyUOnGBRf+atyHSxkTiRrhbbg73LjspB60e8W/hXwVeFTSdDlHRbG0mV0MfErpbd//lQncfdITkio6+/ZHeAS3j124sO+1oBRuHt7DjezPkiaTuxyjJFsys/W4ILwzqkOd2I8bzTGc2CO4s61ZSVWle7lMD9OQ68BjPjQFNzpNwY1OU3Cjs+gE/wcTRE+ZR98dWgAAAABJRU5ErkJggg==";
    },
    e0db: function (t, e, i) {
      "use strict";
      i.d(e, "b", function () {
        return n;
      }),
        i.d(e, "c", function () {
          return o;
        }),
        i.d(e, "a", function () {
          return a;
        });
      var a = {
          uvSearch: i("146d").default,
          uvTabs: i("2b48").default,
          uvEmpty: i("caef").default,
          uvParse: i("c96a").default,
          uvTextarea: i("3e65").default,
          uvPopup: i("ce8a").default,
        },
        n = function () {
          var t = this,
            e = t.$createElement,
            a = t._self._c || e;
          return a(
            "v-uni-view",
            { staticClass: "content" },
            [
              a(
                "v-uni-view",
                { staticClass: "top_bar flex_box" },
                [
                  a("uv-search", {
                    attrs: {
                      placeholder: "搜索用户名称",
                      showAction: !1,
                      height: "35",
                    },
                    on: {
                      change: function (e) {
                        (arguments[0] = e = t.$handleEvent(e)), t.selectUser();
                      },
                    },
                    model: {
                      value: t.keyword,
                      callback: function (e) {
                        t.keyword = e;
                      },
                      expression: "keyword",
                    },
                  }),
                  a(
                    "v-uni-view",
                    { staticClass: "kefu_msg flex_box" },
                    [
                      a("img", {
                        staticClass: "head",
                        attrs: { src: t.kefu.avatar },
                      }),
                      a("v-uni-view", { staticClass: "nickname" }, [
                        t._v(t._s(t.kefu.nickname)),
                      ]),
                      a(
                        "v-uni-view",
                        {
                          class: {
                            status: !0,
                            flex_box: !0,
                            offline: 1 != t.online,
                          },
                          on: {
                            click: function (e) {
                              (arguments[0] = e = t.$handleEvent(e)),
                                t.changePcKefuStatus();
                            },
                          },
                        },
                        [
                          a("v-uni-view", { staticClass: "circle" }),
                          a("v-uni-view", [
                            t._v(t._s(1 == t.online ? "在线" : "离线")),
                          ]),
                        ],
                        1,
                      ),
                    ],
                    1,
                  ),
                ],
                1,
              ),
              a(
                "v-uni-view",
                { staticClass: "main_box flex_box" },
                [
                  a(
                    "v-uni-view",
                    { staticClass: "list_box" },
                    [
                      a(
                        "v-uni-view",
                        { staticClass: "tabs_box" },
                        [
                          a("uv-tabs", {
                            attrs: {
                              list: t.tabs,
                              current: t.chat_current,
                              activeStyle: {
                                color: "#000",
                                fontWeight: "bold",
                                transform: "scale(1.02)",
                              },
                            },
                            on: {
                              change: function (e) {
                                (arguments[0] = e = t.$handleEvent(e)),
                                  t.changeChatStatus.apply(void 0, arguments);
                              },
                            },
                          }),
                        ],
                        1,
                      ),
                      t.user_list.length > 0
                        ? t._l(t.user_list, function (e, i) {
                            return a(
                              "v-uni-view",
                              {
                                key: i,
                                class: {
                                  col: !0,
                                  flex_box: !0,
                                  cur: e.id == t.select_id,
                                },
                                attrs: { text: e },
                                on: {
                                  click: function (a) {
                                    (arguments[0] = a = t.$handleEvent(a)),
                                      t.selectChat(e.id, i);
                                  },
                                },
                              },
                              [
                                a(
                                  "v-uni-view",
                                  { class: { head_box: !0, offline: !0 } },
                                  [
                                    a("img", {
                                      staticClass: "head",
                                      attrs: { src: e.avatar },
                                    }),
                                  ],
                                ),
                                a(
                                  "v-uni-view",
                                  { staticClass: "tit" },
                                  [
                                    a(
                                      "v-uni-view",
                                      { staticClass: "name_msg flex_box" },
                                      [
                                        a(
                                          "v-uni-view",
                                          {
                                            staticClass:
                                              "nickname_box flex_box",
                                          },
                                          [
                                            a(
                                              "v-uni-view",
                                              {
                                                staticClass:
                                                  "nickname uv-line-1",
                                              },
                                              [t._v(t._s(e.nickname))],
                                            ),
                                            1 == e.chat_type
                                              ? a(
                                                  "v-uni-view",
                                                  { staticClass: "from gzh" },
                                                  [t._v("用户")],
                                                )
                                              : t._e(),
                                            3 == e.chat_type
                                              ? a(
                                                  "v-uni-view",
                                                  { staticClass: "from xcx" },
                                                  [t._v("打手")],
                                                )
                                              : t._e(),
                                          ],
                                          1,
                                        ),
                                        a(
                                          "v-uni-view",
                                          { staticClass: "time" },
                                          [t._v(t._s(e.time_text))],
                                        ),
                                      ],
                                      1,
                                    ),
                                    a(
                                      "v-uni-view",
                                      { staticClass: "message_box flex_box" },
                                      [
                                        a(
                                          "v-uni-view",
                                          { staticClass: "message uv-line-1" },
                                          [
                                            t._v(
                                              t._s(
                                                e.content_text
                                                  ? e.content_text
                                                  : "-",
                                              ),
                                            ),
                                          ],
                                        ),
                                        e.kefu_new > 0
                                          ? a(
                                              "v-uni-view",
                                              { staticClass: "num" },
                                              [t._v(t._s(e.kefu_new))],
                                            )
                                          : t._e(),
                                      ],
                                      1,
                                    ),
                                  ],
                                  1,
                                ),
                              ],
                              1,
                            );
                          })
                        : a("uv-empty", {
                            attrs: {
                              mode: "data",
                              text: "暂无聊天对话",
                              icon: "/static/imgs/no-data.png",
                            },
                          }),
                    ],
                    2,
                  ),
                  t.chat.id
                    ? a(
                        "v-uni-view",
                        { staticClass: "chatting_box" },
                        [
                          a(
                            "v-uni-view",
                            { staticClass: "history_box" },
                            [
                              t.gridShow || t.emoShow
                                ? a("v-uni-view", {
                                    staticClass: "mark_box",
                                    on: {
                                      click: function (e) {
                                        (arguments[0] = e = t.$handleEvent(e)),
                                          t.hideGrid.apply(void 0, arguments);
                                      },
                                    },
                                  })
                                : t._e(),
                              t.log.length > 0
                                ? a(
                                    "v-uni-scroll-view",
                                    {
                                      staticStyle: {
                                        height: "calc(100% - 10px)",
                                      },
                                      attrs: {
                                        "scroll-y": !0,
                                        "scroll-top": t.scrollTop,
                                      },
                                      on: {
                                        scroll: function (e) {
                                          (arguments[0] = e =
                                            t.$handleEvent(e)),
                                            t.handleScroll.apply(
                                              void 0,
                                              arguments,
                                            );
                                        },
                                      },
                                    },
                                    [
                                      t._l(t.log, function (e, i) {
                                        return [
                                          -1 == e.type
                                            ? a(
                                                "v-uni-view",
                                                {
                                                  key: i + "_0",
                                                  staticClass: "time",
                                                },
                                                [t._v(t._s(e.display_time))],
                                              )
                                            : 4 == e.type
                                              ? a(
                                                  "v-uni-view",
                                                  { staticClass: "time" },
                                                  [t._v(t._s(e.content))],
                                                )
                                              : [
                                                  2 != e.from
                                                    ? a(
                                                        "v-uni-view",
                                                        {
                                                          staticClass:
                                                            "item user flex_box",
                                                        },
                                                        [
                                                          a("img", {
                                                            staticClass: "head",
                                                            attrs: {
                                                              src: e.avatar,
                                                            },
                                                          }),
                                                          1 == e.type
                                                            ? a(
                                                                "v-uni-view",
                                                                {
                                                                  staticClass:
                                                                    "txt",
                                                                },
                                                                [
                                                                  a(
                                                                    "uv-parse",
                                                                    {
                                                                      attrs: {
                                                                        content:
                                                                          e.content,
                                                                        "preview-img":
                                                                          !1,
                                                                        selectable:
                                                                          !0,
                                                                      },
                                                                    },
                                                                  ),
                                                                ],
                                                                1,
                                                              )
                                                            : t._e(),
                                                          2 == e.type
                                                            ? a(
                                                                "v-uni-view",
                                                                {
                                                                  staticClass:
                                                                    "txt",
                                                                },
                                                                [
                                                                  a("img", {
                                                                    attrs: {
                                                                      src: e.content,
                                                                    },
                                                                    on: {
                                                                      click:
                                                                        function (
                                                                          i,
                                                                        ) {
                                                                          (arguments[0] =
                                                                            i =
                                                                              t.$handleEvent(
                                                                                i,
                                                                              )),
                                                                            t.previewImage(
                                                                              e.content,
                                                                            );
                                                                        },
                                                                    },
                                                                  }),
                                                                ],
                                                              )
                                                            : t._e(),
                                                          3 == e.type
                                                            ? a(
                                                                "v-uni-view",
                                                                {
                                                                  staticClass:
                                                                    "txt",
                                                                },
                                                                [
                                                                  a(
                                                                    "v-uni-view",
                                                                    {
                                                                      staticClass:
                                                                        "order_card",
                                                                      on: {
                                                                        click:
                                                                          function (
                                                                            i,
                                                                          ) {
                                                                            (arguments[0] =
                                                                              i =
                                                                                t.$handleEvent(
                                                                                  i,
                                                                                )),
                                                                              t.lookOrder(
                                                                                e
                                                                                  .order
                                                                                  .id,
                                                                              );
                                                                          },
                                                                      },
                                                                    },
                                                                    [
                                                                      a(
                                                                        "v-uni-view",
                                                                        {
                                                                          staticClass:
                                                                            "goods_msg flex_box",
                                                                        },
                                                                        [
                                                                          a(
                                                                            "img",
                                                                            {
                                                                              staticClass:
                                                                                "img",
                                                                              attrs:
                                                                                {
                                                                                  src: e
                                                                                    .order
                                                                                    .goods_thumb,
                                                                                },
                                                                            },
                                                                          ),
                                                                          a(
                                                                            "v-uni-view",
                                                                            {
                                                                              staticClass:
                                                                                "tit",
                                                                            },
                                                                            [
                                                                              a(
                                                                                "v-uni-view",
                                                                                {
                                                                                  staticClass:
                                                                                    "name uv-line-1",
                                                                                },
                                                                                [
                                                                                  t._v(
                                                                                    " " +
                                                                                      t._s(
                                                                                        e
                                                                                          .order
                                                                                          .goods_name,
                                                                                      ) +
                                                                                      " ",
                                                                                  ),
                                                                                ],
                                                                              ),
                                                                              a(
                                                                                "v-uni-view",
                                                                                {
                                                                                  staticClass:
                                                                                    "status",
                                                                                },
                                                                                [
                                                                                  t._v(
                                                                                    t._s(
                                                                                      e
                                                                                        .order
                                                                                        .status_text,
                                                                                    ),
                                                                                  ),
                                                                                ],
                                                                              ),
                                                                            ],
                                                                            1,
                                                                          ),
                                                                        ],
                                                                        1,
                                                                      ),
                                                                      a(
                                                                        "v-uni-view",
                                                                        {
                                                                          staticClass:
                                                                            "num_msg",
                                                                        },
                                                                        [
                                                                          a(
                                                                            "v-uni-view",
                                                                            {
                                                                              staticClass:
                                                                                "order_num",
                                                                            },
                                                                            [
                                                                              t._v(
                                                                                "订单编号:" +
                                                                                  t._s(
                                                                                    e
                                                                                      .order
                                                                                      .order_no,
                                                                                  ),
                                                                              ),
                                                                            ],
                                                                          ),
                                                                        ],
                                                                        1,
                                                                      ),
                                                                    ],
                                                                    1,
                                                                  ),
                                                                ],
                                                                1,
                                                              )
                                                            : t._e(),
                                                        ],
                                                        1,
                                                      )
                                                    : t._e(),
                                                  2 == e.from
                                                    ? a(
                                                        "v-uni-view",
                                                        {
                                                          staticClass:
                                                            "item kefu flex_box",
                                                        },
                                                        [
                                                          1 == e.type
                                                            ? a(
                                                                "v-uni-view",
                                                                {
                                                                  staticClass:
                                                                    "txt",
                                                                },
                                                                [
                                                                  a(
                                                                    "uv-parse",
                                                                    {
                                                                      attrs: {
                                                                        content:
                                                                          e.content,
                                                                        "preview-img":
                                                                          !1,
                                                                        selectable:
                                                                          !0,
                                                                      },
                                                                    },
                                                                  ),
                                                                ],
                                                                1,
                                                              )
                                                            : t._e(),
                                                          2 == e.type
                                                            ? a(
                                                                "v-uni-view",
                                                                {
                                                                  staticClass:
                                                                    "txt",
                                                                },
                                                                [
                                                                  a("img", {
                                                                    attrs: {
                                                                      src: e.content,
                                                                    },
                                                                    on: {
                                                                      click:
                                                                        function (
                                                                          i,
                                                                        ) {
                                                                          (arguments[0] =
                                                                            i =
                                                                              t.$handleEvent(
                                                                                i,
                                                                              )),
                                                                            t.previewImage(
                                                                              e.content,
                                                                            );
                                                                        },
                                                                    },
                                                                  }),
                                                                ],
                                                              )
                                                            : t._e(),
                                                          a("img", {
                                                            staticClass: "head",
                                                            attrs: {
                                                              src: e.kefu_avatar,
                                                            },
                                                          }),
                                                        ],
                                                        1,
                                                      )
                                                    : t._e(),
                                                ],
                                        ];
                                      }),
                                    ],
                                    2,
                                  )
                                : t._e(),
                            ],
                            1,
                          ),
                          0 == t.user.disabled
                            ? a(
                                "v-uni-view",
                                { staticClass: "operate_box" },
                                [
                                  t.emoShow
                                    ? a(
                                        "v-uni-view",
                                        { staticClass: "project" },
                                        [
                                          a(
                                            "v-uni-view",
                                            { staticClass: "emo-grid" },
                                            t._l(t.emoji, function (e, i) {
                                              return a("img", {
                                                key: i,
                                                staticClass: "emo",
                                                attrs: { text: e, src: e.path },
                                                on: {
                                                  click: function (i) {
                                                    (arguments[0] = i =
                                                      t.$handleEvent(i)),
                                                      t.selEmoji(e.name);
                                                  },
                                                },
                                              });
                                            }),
                                            0,
                                          ),
                                        ],
                                        1,
                                      )
                                    : t._e(),
                                  a(
                                    "v-uni-view",
                                    { staticClass: "bar_box flex_box" },
                                    [
                                      a(
                                        "v-uni-view",
                                        { staticClass: "icon_box flex_box" },
                                        [
                                          a("img", {
                                            staticClass: "icon",
                                            attrs: { src: i("9e9a") },
                                            on: {
                                              click: function (e) {
                                                (arguments[0] = e =
                                                  t.$handleEvent(e)),
                                                  t.emoGrid();
                                              },
                                            },
                                          }),
                                          a("img", {
                                            staticClass: "icon",
                                            attrs: { src: i("a112") },
                                            on: {
                                              "": function (e) {
                                                arguments[0] = e =
                                                  t.$handleEvent(e);
                                              },
                                              click: function (e) {
                                                (arguments[0] = e =
                                                  t.$handleEvent(e)),
                                                  t.selectImg();
                                              },
                                            },
                                          }),
                                          a("img", {
                                            staticClass: "icon",
                                            attrs: { src: i("3597") },
                                            on: {
                                              click: function (e) {
                                                (arguments[0] = e =
                                                  t.$handleEvent(e)),
                                                  t.getPcKefuLogList();
                                              },
                                            },
                                          }),
                                        ],
                                      ),
                                      a(
                                        "v-uni-view",
                                        { staticClass: "flex_box" },
                                        [
                                          a(
                                            "v-uni-view",
                                            {
                                              staticClass: "end_btn",
                                              on: {
                                                click: function (e) {
                                                  (arguments[0] = e =
                                                    t.$handleEvent(e)),
                                                    t.endChat();
                                                },
                                              },
                                            },
                                            [t._v("结束接待")],
                                          ),
                                          a(
                                            "v-uni-view",
                                            {
                                              staticClass:
                                                "transfer_box flex_box",
                                              on: {
                                                click: function (e) {
                                                  (arguments[0] = e =
                                                    t.$handleEvent(e)),
                                                    t.getOnlineKefuList();
                                                },
                                              },
                                            },
                                            [
                                              a("img", {
                                                staticClass: "icon",
                                                attrs: { src: i("dfe7") },
                                              }),
                                              a("v-uni-view", [t._v("转接")]),
                                            ],
                                            1,
                                          ),
                                        ],
                                        1,
                                      ),
                                    ],
                                    1,
                                  ),
                                  a(
                                    "v-uni-view",
                                    { staticClass: "textarea_box" },
                                    [
                                      0 == t.show_pase
                                        ? a("uv-textarea", {
                                            attrs: {
                                              autoHeight: !0,
                                              placeholder: "请输入文字内容",
                                              maxlength: "-1",
                                              border: "none",
                                              focus: !0,
                                              count: !0,
                                              maxlength: 50,
                                            },
                                            model: {
                                              value: t.content,
                                              callback: function (e) {
                                                t.content = e;
                                              },
                                              expression: "content",
                                            },
                                          })
                                        : t._e(),
                                      a(
                                        "v-uni-view",
                                        { staticClass: "preview-container" },
                                        t._l(t.imgList, function (e, i) {
                                          return a(
                                            "v-uni-view",
                                            {
                                              key: i,
                                              staticClass: "preview-item",
                                            },
                                            [
                                              a("v-uni-image", {
                                                staticClass: "preview-img",
                                                attrs: {
                                                  src: e.url,
                                                  mode: "aspectFill",
                                                },
                                                on: {
                                                  click: function (e) {
                                                    (arguments[0] = e =
                                                      t.$handleEvent(e)),
                                                      t.previewPaseImage(i);
                                                  },
                                                },
                                              }),
                                              a(
                                                "v-uni-view",
                                                {
                                                  staticClass: "delete-btn",
                                                  on: {
                                                    click: function (e) {
                                                      e.stopPropagation(),
                                                        (arguments[0] = e =
                                                          t.$handleEvent(e)),
                                                        t.removeImage(i);
                                                    },
                                                  },
                                                },
                                                [t._v("×")],
                                              ),
                                            ],
                                            1,
                                          );
                                        }),
                                        1,
                                      ),
                                      a(
                                        "v-uni-view",
                                        {
                                          staticClass: "send_btn",
                                          on: {
                                            click: function (e) {
                                              (arguments[0] = e =
                                                t.$handleEvent(e)),
                                                t.sendMsgHandle();
                                            },
                                          },
                                        },
                                        [t._v("发送")],
                                      ),
                                    ],
                                    1,
                                  ),
                                ],
                                1,
                              )
                            : t._e(),
                        ],
                        1,
                      )
                    : t._e(),
                  t.chat.id
                    ? a(
                        "v-uni-view",
                        { staticClass: "user_box" },
                        [
                          a(
                            "v-uni-view",
                            { staticClass: "jichu flex_box" },
                            [
                              a("img", {
                                staticClass: "head",
                                attrs: { src: t.chat.avatar },
                              }),
                              a(
                                "v-uni-view",
                                { staticClass: "nickname uv-line-1" },
                                [t._v(t._s(t.chat.nickname))],
                              ),
                              1 == t.chat.chat_type
                                ? a("v-uni-view", { staticClass: "from gzh" }, [
                                    t._v("用户"),
                                  ])
                                : t._e(),
                              3 == t.chat.chat_type
                                ? a("v-uni-view", { staticClass: "from xcx" }, [
                                    t._v("打手"),
                                  ])
                                : t._e(),
                            ],
                            1,
                          ),
                          t.order
                            ? a(
                                "v-uni-view",
                                { staticClass: "tips_box" },
                                [
                                  a(
                                    "v-uni-view",
                                    {
                                      staticClass: "tips flex_box",
                                      on: {
                                        click: function (e) {
                                          (arguments[0] = e =
                                            t.$handleEvent(e)),
                                            t.scrollToBottom();
                                        },
                                      },
                                    },
                                    [
                                      a(
                                        "v-uni-view",
                                        { staticClass: "title" },
                                        [t._v("订单编号")],
                                      ),
                                      a(
                                        "v-uni-text",
                                        {
                                          staticClass: "txt",
                                          attrs: { selectable: "true" },
                                        },
                                        [t._v(t._s(t.order.order_no))],
                                      ),
                                    ],
                                    1,
                                  ),
                                  a(
                                    "v-uni-view",
                                    { staticClass: "tips flex_box" },
                                    [
                                      a(
                                        "v-uni-view",
                                        { staticClass: "title" },
                                        [t._v("订单状态")],
                                      ),
                                      a(
                                        "v-uni-text",
                                        {
                                          staticClass: "txt",
                                          attrs: { selectable: "true" },
                                        },
                                        [t._v(t._s(t.order.status_text))],
                                      ),
                                    ],
                                    1,
                                  ),
                                  a(
                                    "v-uni-view",
                                    { staticClass: "tips flex_box" },
                                    [
                                      a(
                                        "v-uni-view",
                                        { staticClass: "title" },
                                        [t._v("缩略图")],
                                      ),
                                      a("v-uni-view", { staticClass: "txt" }, [
                                        a("img", {
                                          staticClass: "thumb",
                                          attrs: { src: t.order.goods_thumb },
                                        }),
                                      ]),
                                    ],
                                    1,
                                  ),
                                  a(
                                    "v-uni-view",
                                    { staticClass: "tips flex_box" },
                                    [
                                      a(
                                        "v-uni-view",
                                        { staticClass: "title" },
                                        [t._v("商品名称")],
                                      ),
                                      a(
                                        "v-uni-text",
                                        {
                                          staticClass: "txt",
                                          attrs: { selectable: "true" },
                                        },
                                        [t._v(t._s(t.order.goods_name))],
                                      ),
                                    ],
                                    1,
                                  ),
                                  a(
                                    "v-uni-view",
                                    { staticClass: "tips flex_box" },
                                    [
                                      a(
                                        "v-uni-view",
                                        { staticClass: "title" },
                                        [t._v("商品介绍")],
                                      ),
                                      a(
                                        "v-uni-text",
                                        {
                                          staticClass: "txt",
                                          attrs: { selectable: "true" },
                                        },
                                        [t._v(t._s(t.order.goods_intro))],
                                      ),
                                    ],
                                    1,
                                  ),
                                  a(
                                    "v-uni-view",
                                    { staticClass: "tips flex_box" },
                                    [
                                      a(
                                        "v-uni-view",
                                        { staticClass: "title" },
                                        [t._v("售价")],
                                      ),
                                      a(
                                        "v-uni-text",
                                        {
                                          staticClass: "txt",
                                          attrs: { selectable: "true" },
                                        },
                                        [t._v(t._s(t.order.price))],
                                      ),
                                    ],
                                    1,
                                  ),
                                  a(
                                    "v-uni-view",
                                    { staticClass: "tips flex_box" },
                                    [
                                      a(
                                        "v-uni-view",
                                        { staticClass: "title" },
                                        [t._v("数量")],
                                      ),
                                      a(
                                        "v-uni-text",
                                        {
                                          staticClass: "txt",
                                          attrs: { selectable: "true" },
                                        },
                                        [t._v("￥" + t._s(t.order.num))],
                                      ),
                                    ],
                                    1,
                                  ),
                                  a(
                                    "v-uni-view",
                                    { staticClass: "tips flex_box" },
                                    [
                                      a(
                                        "v-uni-view",
                                        { staticClass: "title" },
                                        [t._v("实际付款")],
                                      ),
                                      a(
                                        "v-uni-text",
                                        {
                                          staticClass: "txt",
                                          attrs: { selectable: "true" },
                                        },
                                        [t._v("￥" + t._s(t.order.money))],
                                      ),
                                    ],
                                    1,
                                  ),
                                  a(
                                    "v-uni-view",
                                    { staticClass: "tips flex_box" },
                                    [
                                      a(
                                        "v-uni-view",
                                        { staticClass: "title" },
                                        [t._v("游戏ID")],
                                      ),
                                      a(
                                        "v-uni-text",
                                        {
                                          staticClass: "txt",
                                          attrs: { selectable: "true" },
                                        },
                                        [t._v(t._s(t.order.num_id))],
                                      ),
                                    ],
                                    1,
                                  ),
                                  a(
                                    "v-uni-view",
                                    { staticClass: "tips flex_box" },
                                    [
                                      a(
                                        "v-uni-view",
                                        { staticClass: "title" },
                                        [t._v("文字ID")],
                                      ),
                                      a(
                                        "v-uni-text",
                                        {
                                          staticClass: "txt",
                                          attrs: { selectable: "true" },
                                        },
                                        [t._v(t._s(t.order.text_id))],
                                      ),
                                    ],
                                    1,
                                  ),
                                ],
                                1,
                              )
                            : t._e(),
                        ],
                        1,
                      )
                    : t._e(),
                ],
                1,
              ),
              a(
                "uv-popup",
                {
                  ref: "chatHistoryPop",
                  attrs: { bgColor: "none" },
                  on: {
                    close: function (e) {
                      (arguments[0] = e = t.$handleEvent(e)),
                        t.close.apply(void 0, arguments);
                    },
                  },
                },
                [
                  a(
                    "v-uni-view",
                    { staticClass: "chat_history_pop" },
                    [
                      a(
                        "v-uni-view",
                        { staticClass: "tabs_box" },
                        [
                          a("uv-tabs", {
                            attrs: {
                              current: t.current,
                              list: t.log_kefu_list,
                              lineColor: "#000",
                              activeStyle: {
                                color: "#000",
                                fontWeight: "bold",
                                transform: "scale(1.02)",
                              },
                              scrollable: !0,
                            },
                            on: {
                              change: function (e) {
                                (arguments[0] = e = t.$handleEvent(e)),
                                  t.changeTabs.apply(void 0, arguments);
                              },
                            },
                          }),
                        ],
                        1,
                      ),
                      a(
                        "v-uni-view",
                        { staticClass: "history_box" },
                        [
                          t._l(t.log_kefu_log, function (e, i) {
                            return [
                              -1 == e.type
                                ? a(
                                    "v-uni-view",
                                    { key: i + "_0", staticClass: "time" },
                                    [t._v(t._s(e.display_time))],
                                  )
                                : 4 == e.type
                                  ? a("v-uni-view", { staticClass: "time" }, [
                                      t._v(t._s(e.content)),
                                    ])
                                  : [
                                      2 != e.from
                                        ? a(
                                            "v-uni-view",
                                            {
                                              staticClass: "item user flex_box",
                                            },
                                            [
                                              a("img", {
                                                staticClass: "head",
                                                attrs: { src: e.avatar },
                                              }),
                                              1 == e.type
                                                ? a(
                                                    "v-uni-view",
                                                    { staticClass: "txt" },
                                                    [
                                                      a("uv-parse", {
                                                        attrs: {
                                                          content: e.content,
                                                          selectable: !0,
                                                        },
                                                      }),
                                                    ],
                                                    1,
                                                  )
                                                : t._e(),
                                              2 == e.type
                                                ? a(
                                                    "v-uni-view",
                                                    { staticClass: "txt" },
                                                    [
                                                      a("img", {
                                                        attrs: {
                                                          src: e.content,
                                                        },
                                                        on: {
                                                          click: function (i) {
                                                            (arguments[0] = i =
                                                              t.$handleEvent(
                                                                i,
                                                              )),
                                                              t.previewImage(
                                                                e.content,
                                                              );
                                                          },
                                                        },
                                                      }),
                                                    ],
                                                  )
                                                : t._e(),
                                              3 == e.type
                                                ? a(
                                                    "v-uni-view",
                                                    { staticClass: "txt" },
                                                    [
                                                      a(
                                                        "v-uni-view",
                                                        {
                                                          staticClass:
                                                            "order_card",
                                                          on: {
                                                            click: function (
                                                              i,
                                                            ) {
                                                              (arguments[0] =
                                                                i =
                                                                  t.$handleEvent(
                                                                    i,
                                                                  )),
                                                                t.lookOrder(
                                                                  e.order.id,
                                                                );
                                                            },
                                                          },
                                                        },
                                                        [
                                                          a(
                                                            "v-uni-view",
                                                            {
                                                              staticClass:
                                                                "goods_msg flex_box",
                                                            },
                                                            [
                                                              a("img", {
                                                                staticClass:
                                                                  "img",
                                                                attrs: {
                                                                  src: e.order
                                                                    .goods_thumb,
                                                                },
                                                              }),
                                                              a(
                                                                "v-uni-view",
                                                                {
                                                                  staticClass:
                                                                    "tit",
                                                                },
                                                                [
                                                                  a(
                                                                    "v-uni-view",
                                                                    {
                                                                      staticClass:
                                                                        "name uv-line-1",
                                                                    },
                                                                    [
                                                                      t._v(
                                                                        " " +
                                                                          t._s(
                                                                            e
                                                                              .order
                                                                              .goods_name,
                                                                          ) +
                                                                          " ",
                                                                      ),
                                                                    ],
                                                                  ),
                                                                  a(
                                                                    "v-uni-view",
                                                                    {
                                                                      staticClass:
                                                                        "status",
                                                                    },
                                                                    [
                                                                      t._v(
                                                                        t._s(
                                                                          e
                                                                            .order
                                                                            .status_text,
                                                                        ),
                                                                      ),
                                                                    ],
                                                                  ),
                                                                ],
                                                                1,
                                                              ),
                                                            ],
                                                            1,
                                                          ),
                                                          a(
                                                            "v-uni-view",
                                                            {
                                                              staticClass:
                                                                "num_msg",
                                                            },
                                                            [
                                                              a(
                                                                "v-uni-view",
                                                                {
                                                                  staticClass:
                                                                    "order_num",
                                                                },
                                                                [
                                                                  t._v(
                                                                    "订单编号:" +
                                                                      t._s(
                                                                        e.order
                                                                          .order_no,
                                                                      ),
                                                                  ),
                                                                ],
                                                              ),
                                                            ],
                                                            1,
                                                          ),
                                                        ],
                                                        1,
                                                      ),
                                                    ],
                                                    1,
                                                  )
                                                : t._e(),
                                            ],
                                            1,
                                          )
                                        : t._e(),
                                      2 == e.from
                                        ? a(
                                            "v-uni-view",
                                            {
                                              staticClass: "item kefu flex_box",
                                            },
                                            [
                                              1 == e.type
                                                ? a(
                                                    "v-uni-view",
                                                    { staticClass: "txt" },
                                                    [
                                                      a("uv-parse", {
                                                        attrs: {
                                                          content: e.content,
                                                          selectable: !0,
                                                        },
                                                      }),
                                                    ],
                                                    1,
                                                  )
                                                : t._e(),
                                              2 == e.type
                                                ? a(
                                                    "v-uni-view",
                                                    { staticClass: "txt" },
                                                    [
                                                      a("img", {
                                                        attrs: {
                                                          src: e.content,
                                                        },
                                                        on: {
                                                          click: function (i) {
                                                            (arguments[0] = i =
                                                              t.$handleEvent(
                                                                i,
                                                              )),
                                                              t.previewImage(
                                                                e.content,
                                                              );
                                                          },
                                                        },
                                                      }),
                                                    ],
                                                  )
                                                : t._e(),
                                              a("img", {
                                                staticClass: "head",
                                                attrs: { src: e.kefu_avatar },
                                              }),
                                            ],
                                            1,
                                          )
                                        : t._e(),
                                    ],
                            ];
                          }),
                        ],
                        2,
                      ),
                    ],
                    1,
                  ),
                ],
                1,
              ),
              a(
                "uv-popup",
                {
                  ref: "transferPop",
                  attrs: { bgColor: "none" },
                  on: {
                    close: function (e) {
                      (arguments[0] = e = t.$handleEvent(e)),
                        t.close.apply(void 0, arguments);
                    },
                  },
                },
                [
                  a(
                    "v-uni-view",
                    { staticClass: "transfer_pop" },
                    [
                      t.kefu_list.length > 0
                        ? a(
                            "v-uni-view",
                            { staticClass: "list" },
                            t._l(t.kefu_list, function (e, i) {
                              return a(
                                "v-uni-view",
                                {
                                  key: i,
                                  staticClass: "col",
                                  attrs: { text: e },
                                },
                                [
                                  a("img", {
                                    staticClass: "head",
                                    attrs: { src: e.avatar, alt: "" },
                                  }),
                                  a(
                                    "v-uni-view",
                                    { staticClass: "nickname uv-line-1" },
                                    [t._v(t._s(e.nickname))],
                                  ),
                                  a(
                                    "v-uni-view",
                                    {
                                      staticClass: "btn",
                                      on: {
                                        click: function (i) {
                                          (arguments[0] = i =
                                            t.$handleEvent(i)),
                                            t.pcTransToTa(e);
                                        },
                                      },
                                    },
                                    [t._v("转给TA")],
                                  ),
                                ],
                                1,
                              );
                            }),
                            1,
                          )
                        : a("uv-empty", {
                            attrs: {
                              mode: "data",
                              text: "暂无其他在线客服",
                              icon: "/static/imgs/no-data.png",
                            },
                          }),
                    ],
                    1,
                  ),
                ],
                1,
              ),
            ],
            1,
          );
        },
        o = [];
    },
    f9d7: function (t, e, i) {
      var a = i("c86c");
      (e = a(!1)),
        e.push([
          t.i,
          '@charset "UTF-8";\r\n/**\r\n * 这里是uni-app内置的常用样式变量\r\n *\r\n * uni-app 官方扩展插件及插件市场（https://ext.dcloud.net.cn）上很多三方插件均使用了这些样式变量\r\n * 如果你是插件开发者，建议你使用scss预处理，并在插件代码中直接使用这些变量（无需 import 这个文件），方便用户通过搭积木的方式开发整体风格一致的App\r\n *\r\n */\r\n/**\r\n * 如果你是App开发者（插件使用者），你可以通过修改这些变量来定制自己的插件主题，实现自定义主题功能\r\n *\r\n * 如果你的项目同样使用了scss预处理，你也可以直接在你的 scss 代码中使用如下变量，同时无需 import 这个文件\r\n */\r\n/* 颜色变量 */\r\n/* 行为相关颜色 */\r\n/* 文字基本颜色 */\r\n/* 背景颜色 */\r\n/* 边框颜色 */\r\n/* 尺寸变量 */\r\n/* 文字尺寸 */\r\n/* 图片尺寸 */\r\n/* Border Radius */\r\n/* 水平间距 */\r\n/* 垂直间距 */\r\n/* 透明度 */\r\n/* 文章场景相关 */.content[data-v-b5ca7150]{max-width:100%}.top_bar[data-v-b5ca7150]{padding:10px 16px;background:#007aff;position:relative;z-index:10}.top_bar[data-v-b5ca7150] .uv-search{flex:none!important;width:370px!important}.top_bar[data-v-b5ca7150] .uv-search .uv-icon__icon{font-size:24px;line-height:24px}.top_bar .kefu_msg .head[data-v-b5ca7150]{width:40px;height:40px;border-radius:100%}.top_bar .kefu_msg .nickname[data-v-b5ca7150]{margin:0 12px;color:#fff;font-size:16px}.top_bar .kefu_msg .status[data-v-b5ca7150]{padding:0 14px;height:30px;line-height:30px;border-radius:30px;background:#fff;justify-content:center}.top_bar .kefu_msg .status .circle[data-v-b5ca7150]{width:6px;height:6px;border-radius:6px;background:#4cd964;margin-right:8px}.top_bar .kefu_msg .status.offline .circle[data-v-b5ca7150]{background:#c8c7cc}.main_box[data-v-b5ca7150]{height:calc(100vh - 78px);align-items:stretch}.main_box > uni-view[data-v-b5ca7150]{background:#fff;overflow-y:scroll}.main_box .list_box[data-v-b5ca7150]{width:380px;box-shadow:0 0 10px #eee;border-right:1px solid #eee;position:relative;z-index:10}.main_box .list_box .tabs_box[data-v-b5ca7150]{padding:0 3px 5px;border-bottom:1px solid #eee}.main_box .list_box .col[data-v-b5ca7150]{padding:12px}.main_box .list_box .col.cur[data-v-b5ca7150]{background:#f3f3f3!important;box-shadow:0 0 12px #dedede inset}.main_box .list_box .col[data-v-b5ca7150]:hover{background:#f5f5f5}.main_box .list_box .col .head_box[data-v-b5ca7150]{position:relative;margin-right:10px}.main_box .list_box .col .head_box .head[data-v-b5ca7150]{width:48px;height:48px;border-radius:100%}.main_box .list_box .col .head_box .circle[data-v-b5ca7150]{width:11px;height:11px;border-radius:100%;background:#4cd964;position:absolute;right:4px;bottom:2px}.main_box .list_box .col .head_box.offline .circle[data-v-b5ca7150]{background:#c8c7cc}.main_box .list_box .col .tit[data-v-b5ca7150]{flex:1}.main_box .list_box .col .tit .name_msg .nickname_box[data-v-b5ca7150]{max-width:calc(100% - 100px);justify-content:flex-start}.main_box .list_box .col .tit .name_msg .nickname_box .nickname[data-v-b5ca7150]{font-size:14px;font-weight:700;flex:1}.main_box .list_box .col .tit .name_msg .nickname_box .from[data-v-b5ca7150]{margin-left:10px;height:20px;line-height:20px;border-radius:3px;padding:0 5px;font-size:12px}.main_box .list_box .col .tit .name_msg .nickname_box .from.xcx[data-v-b5ca7150]{background:#e1eefd;color:#007aff}.main_box .list_box .col .tit .name_msg .nickname_box .from.h5[data-v-b5ca7150]{background:#fdf6e1;color:#f0ad4e}.main_box .list_box .col .tit .name_msg .nickname_box .from.gzh[data-v-b5ca7150]{background:#e7f8ec;color:#4cd964}.main_box .list_box .col .tit .name_msg .nickname_box .from.pc[data-v-b5ca7150]{background:#e7dffc;color:#4f30b3}.main_box .list_box .col .tit .name_msg .time[data-v-b5ca7150]{color:#999}.main_box .list_box .col .tit .message_box[data-v-b5ca7150]{margin:6px auto 4px}.main_box .list_box .col .tit .message_box .message[data-v-b5ca7150]{flex:1;color:#999;font-size:13px}.main_box .list_box .col .tit .message_box .num[data-v-b5ca7150]{text-align:center;margin-left:10px;min-width:20px;height:20px;line-height:20px;border-radius:20px;padding:0 6px;font-size:12px;background:red;color:#fff}.main_box .chatting_box[data-v-b5ca7150]{position:relative;z-index:9;flex:1}.main_box .chatting_box .history_box[data-v-b5ca7150]{padding:0 20px;height:calc(100% - 190px);overflow-y:scroll;position:relative;z-index:9}.main_box .chatting_box .history_box .mark_box[data-v-b5ca7150]{z-index:10;position:absolute;left:0;right:0;top:0;bottom:0}.main_box .chatting_box .history_box .time[data-v-b5ca7150]{margin-top:10px;text-align:center;color:#999}.main_box .chatting_box .history_box .item[data-v-b5ca7150]{align-items:flex-start;margin:23px auto 35px}.main_box .chatting_box .history_box .item.user[data-v-b5ca7150]{justify-content:flex-start}.main_box .chatting_box .history_box .item.user .head[data-v-b5ca7150]{margin-right:14px}.main_box .chatting_box .history_box .item.kefu[data-v-b5ca7150]{justify-content:flex-end}.main_box .chatting_box .history_box .item.kefu .head[data-v-b5ca7150]{margin-left:14px}.main_box .chatting_box .history_box .item .head[data-v-b5ca7150]{width:45px;height:45px;border-radius:100%}.main_box .chatting_box .history_box .item .txt[data-v-b5ca7150]{max-width:calc(50%);background:#f5f5f5;padding:12px 14px;border-radius:8px;line-height:1.5;\r\n  /* 换行属性 */word-wrap:break-word;word-break:break-word;white-space:pre-wrap;overflow-wrap:break-word}.main_box .chatting_box .history_box .item .txt[data-v-b5ca7150]  img{width:160px;height:160px}.main_box .chatting_box .history_box .item .txt .copy_btn[data-v-b5ca7150]{font-size:13px;color:#007aff;text-decoration:underline;text-align:right;margin-top:8px}.main_box .chatting_box .history_box .item .txt .pic_grid[data-v-b5ca7150]{display:grid;grid-template-columns:repeat(3,1fr);grid-gap:10px}.main_box .chatting_box .history_box .item .txt .pic_grid img[data-v-b5ca7150]{width:114px;height:114px;border-radius:4px}.main_box .chatting_box .history_box .item .txt .emoji[data-v-b5ca7150]{width:30px;height:30px}.main_box .chatting_box .history_box .item .txt .order_card .goods_msg[data-v-b5ca7150]{justify-content:flex-start;margin:2px 0}.main_box .chatting_box .history_box .item .txt .order_card .goods_msg .img[data-v-b5ca7150]{width:50px;height:50px;border-radius:5px;margin-right:12px}.main_box .chatting_box .history_box .item .txt .order_card .goods_msg .tit[data-v-b5ca7150]{flex:1}.main_box .chatting_box .history_box .item .txt .order_card .goods_msg .tit .name[data-v-b5ca7150]{font-size:14px;font-weight:700}.main_box .chatting_box .history_box .item .txt .order_card .goods_msg .tit .status[data-v-b5ca7150]{font-size:12px;margin-top:7px;color:#007aff}.main_box .chatting_box .history_box .item .txt .order_card .num_msg[data-v-b5ca7150]{border-top:1px solid #ddd;padding-top:10px;margin-top:14px}.main_box .chatting_box .history_box .item .txt .order_card .num_msg .order_num[data-v-b5ca7150]{font-size:13px;color:#555}.main_box .chatting_box .operate_box[data-v-b5ca7150]{height:190px;position:relative;z-index:10;overflow:visible;background:#fff}.main_box .chatting_box .operate_box .project[data-v-b5ca7150]{position:absolute;z-index:1;left:6px;top:-240px;overflow:visible}.main_box .chatting_box .operate_box .project[data-v-b5ca7150]:before{display:block;content:"";width:16px;height:16px;background:#f2f2f2;position:absolute;z-index:0;bottom:-7px;left:14px;border-radius:5px;-webkit-transform:rotate(45deg);transform:rotate(45deg)}.main_box .chatting_box .operate_box .project .emo-grid[data-v-b5ca7150]{position:relative;z-index:1;padding:12px;background:#f2f2f2;display:grid;grid-template-columns:repeat(10,1fr);grid-gap:12px;overflow-y:auto;height:222px;width:432px;border-radius:6px}.main_box .chatting_box .operate_box .project .emo-grid img[data-v-b5ca7150]{width:30px;height:30px;margin:0 auto}.main_box .chatting_box .operate_box .bar_box[data-v-b5ca7150]{position:relative;z-index:2;height:52px;padding:0 14px;box-shadow:0 0 10px #eee;border-top:1px solid #eee;border-bottom:1px solid #eee;background:#fff}.main_box .chatting_box .operate_box .bar_box .icon[data-v-b5ca7150]{width:27px;height:27px;margin-right:13px}.main_box .chatting_box .operate_box .bar_box .paste-tip[data-v-b5ca7150]{color:#999;font-size:13px}.main_box .chatting_box .operate_box .bar_box .end_btn[data-v-b5ca7150]{margin:0 12px;padding:0 10px;height:33px;line-height:33px;border-radius:3px;background:#dd524d;color:#fff;text-align:center}.main_box .chatting_box .operate_box .bar_box .transfer_box uni-view[data-v-b5ca7150]{font-size:15px}.main_box .chatting_box .operate_box .bar_box .transfer_box .icon[data-v-b5ca7150]{margin-right:10px}.main_box .chatting_box .operate_box .textarea_box[data-v-b5ca7150]{background:#fff;position:relative;z-index:1;height:calc(100% - 52px)}.main_box .chatting_box .operate_box .textarea_box[data-v-b5ca7150]  .uv-textarea{padding:14px!important;height:100%;overflow-y:scroll!important}.main_box .chatting_box .operate_box .textarea_box[data-v-b5ca7150]  .uv-textarea .uni-textarea-wrapper{height:100%!important}.main_box .chatting_box .operate_box .textarea_box .send_btn[data-v-b5ca7150]{position:absolute;right:5px;bottom:5px;width:60px;height:33px;line-height:33px;border-radius:3px;background:#007aff;color:#fff;text-align:center;font-size:14.4px}.main_box .user_box[data-v-b5ca7150]{position:relative;z-index:10;width:380px;box-shadow:0 0 10px #eee;border-left:1px solid #eee;padding:0 18px}.main_box .user_box > uni-view[data-v-b5ca7150]{border-bottom:1px solid #eee;padding:7px 0}.main_box .user_box > uni-view[data-v-b5ca7150]:last-child{border:none}.main_box .user_box .jichu[data-v-b5ca7150]{padding:22px 0;justify-content:flex-start}.main_box .user_box .jichu .head[data-v-b5ca7150]{width:48px;height:48px;border-radius:100%}.main_box .user_box .jichu .nickname[data-v-b5ca7150]{margin:0 10px;font-size:16px;font-weight:700;max-width:calc(100% - 114px);top:-1.6px;position:relative}.main_box .user_box .jichu .from[data-v-b5ca7150]{height:20px;line-height:20px;border-radius:3px;padding:0 5px;font-size:12px}.main_box .user_box .jichu .from.xcx[data-v-b5ca7150]{background:#e1eefd;color:#007aff}.main_box .user_box .jichu .from.h5[data-v-b5ca7150]{background:#fdf6e1;color:#f0ad4e}.main_box .user_box .jichu .from.gzh[data-v-b5ca7150]{background:#e7f8ec;color:#4cd964}.main_box .user_box .jichu .from.pc[data-v-b5ca7150]{background:#e7dffc;color:#4f30b3}.main_box .user_box .tips_box .tips[data-v-b5ca7150]{align-items:flex-start;margin:17px auto}.main_box .user_box .tips_box .tips .title[data-v-b5ca7150]{color:#aaa;width:64px;margin-right:14px}.main_box .user_box .tips_box .tips .txt[data-v-b5ca7150]{flex:1}.main_box .user_box .tips_box .tips .tag_box[data-v-b5ca7150]{display:block}.main_box .user_box .tips_box .tips .tag_box .tag[data-v-b5ca7150]{display:inline-block;margin:0 13px 8px 0;height:21px;line-height:21px;padding:0 8px;font-size:12px;background:#e8f4fe;color:#2a8fdd}.main_box .user_box .tips_box .tips .thumb[data-v-b5ca7150]{width:90px;height:90px;border-radius:5px}.main_box .user_box .tips_box .tips .copy_btn[data-v-b5ca7150]{margin-left:10px;color:#007aff}[data-v-b5ca7150] .uv-popup__content{left:14px!important;max-width:37%!important;height:80%!important}.chat_history_pop[data-v-b5ca7150]{height:100%;background:#fff;border-radius:10px;overflow-y:scroll;padding-top:50px}.chat_history_pop .tabs_box[data-v-b5ca7150]{border-radius:10px 10px 0 0;background:#fff;position:absolute;left:0;right:0;top:0;border-bottom:1px solid #eee;padding-bottom:5px;z-index:10}.chat_history_pop .history_box[data-v-b5ca7150]{padding:0 20px}.chat_history_pop .history_box .time[data-v-b5ca7150]{text-align:center;color:#999}.chat_history_pop .history_box .item[data-v-b5ca7150]{align-items:flex-start;margin:23px auto 35px}.chat_history_pop .history_box .item.user[data-v-b5ca7150]{justify-content:flex-start}.chat_history_pop .history_box .item.user .head[data-v-b5ca7150]{margin-right:14px}.chat_history_pop .history_box .item.kefu[data-v-b5ca7150]{justify-content:flex-end}.chat_history_pop .history_box .item.kefu .head[data-v-b5ca7150]{margin-left:14px}.chat_history_pop .history_box .item .head[data-v-b5ca7150]{width:45px;height:45px;border-radius:100%}.chat_history_pop .history_box .item .txt[data-v-b5ca7150]{max-width:calc(100% - 90px - 28px);background:#f5f5f5;padding:12px 14px;border-radius:8px;line-height:1.5}.chat_history_pop .history_box .item .txt[data-v-b5ca7150]  img{width:200px;height:200px}.chat_history_pop .history_box .item .txt .copy_btn[data-v-b5ca7150]{font-size:13px;color:#007aff;text-decoration:underline;text-align:right;margin-top:8px}.chat_history_pop .history_box .item .txt .pic_grid[data-v-b5ca7150]{display:grid;grid-template-columns:repeat(3,1fr);grid-gap:10px}.chat_history_pop .history_box .item .txt .pic_grid img[data-v-b5ca7150]{width:114px;height:114px;border-radius:4px}.chat_history_pop .history_box .item .txt .emoji[data-v-b5ca7150]{width:30px;height:30px}.chat_history_pop .history_box .item .txt .order_card .goods_msg[data-v-b5ca7150]{justify-content:flex-start;margin:2px 0}.chat_history_pop .history_box .item .txt .order_card .goods_msg .img[data-v-b5ca7150]{width:60px;height:60px;border-radius:5px;margin-right:12px}.chat_history_pop .history_box .item .txt .order_card .goods_msg .tit[data-v-b5ca7150]{flex:1}.chat_history_pop .history_box .item .txt .order_card .goods_msg .tit .name[data-v-b5ca7150]{font-size:16px;font-weight:700}.chat_history_pop .history_box .item .txt .order_card .goods_msg .tit .status[data-v-b5ca7150]{margin-top:7px;color:#007aff}.chat_history_pop .history_box .item .txt .order_card .num_msg[data-v-b5ca7150]{border-top:1px solid #ddd;padding-top:10px;margin-top:14px}.chat_history_pop .history_box .item .txt .order_card .num_msg .order_num[data-v-b5ca7150]{color:#555}.transfer_pop[data-v-b5ca7150]{height:100%;background:#fff;border-radius:10px;overflow-y:scroll}.transfer_pop .list .col[data-v-b5ca7150]{display:flex;justify-content:space-between;align-items:center;padding:12px 0;border-bottom:1px solid #eee;margin:0 12px}.transfer_pop .list .col[data-v-b5ca7150]:last-child{border-bottom:none}.transfer_pop .list .col .head[data-v-b5ca7150]{width:45px;height:45px;border-radius:100%}.transfer_pop .list .col .nickname[data-v-b5ca7150]{flex:1;margin:0 12px;font-size:16px;font-size:15px}.transfer_pop .list .col .btn[data-v-b5ca7150]{background:#ffe610;min-width:66px;padding:0 14px;height:33px;line-height:33px;border-radius:33px;text-align:center;font-weight:700;font-size:13px}.preview-container[data-v-b5ca7150]{display:flex;flex-wrap:wrap;gap:%?20?%;padding:%?40?%}.preview-item[data-v-b5ca7150]{position:relative;width:%?300?%;height:%?220?%}.preview-img[data-v-b5ca7150]{width:100%;height:100%;border-radius:%?8?%}.delete-btn[data-v-b5ca7150]{position:absolute;top:%?-12?%;right:%?-12?%;width:%?60?%;height:%?60?%;background-color:#ff4d4f;color:#fff;border-radius:50%;display:flex;align-items:center;justify-content:center;font-size:%?24?%;cursor:pointer}',
          "",
        ]),
        (t.exports = e);
    },
  },
]);
//# sourceMappingURL=pages_sub1-chat-index.0c78e943.js.map
