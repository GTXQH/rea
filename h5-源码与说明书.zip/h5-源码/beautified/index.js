(function (e) {
  function n(n) {
    for (
      var a, r, s = n[0], u = n[1], c = n[2], d = 0, f = [];
      d < s.length;
      d++
    )
      (r = s[d]),
        Object.prototype.hasOwnProperty.call(i, r) && i[r] && f.push(i[r][0]),
        (i[r] = 0);
    for (a in u) Object.prototype.hasOwnProperty.call(u, a) && (e[a] = u[a]);
    l && l(n);
    while (f.length) f.shift()();
    return o.push.apply(o, c || []), t();
  }
  function t() {
    for (var e, n = 0; n < o.length; n++) {
      for (var t = o[n], a = !0, s = 1; s < t.length; s++) {
        var u = t[s];
        0 !== i[u] && (a = !1);
      }
      a && (o.splice(n--, 1), (e = r((r.s = t[0]))));
    }
    return e;
  }
  var a = {},
    i = { index: 0 },
    o = [];
  function r(n) {
    if (a[n]) return a[n].exports;
    var t = (a[n] = { i: n, l: !1, exports: {} });
    return e[n].call(t.exports, t, t.exports, r), (t.l = !0), t.exports;
  }
  (r.e = function (e) {
    var n = [],
      t = i[e];
    if (0 !== t)
      if (t) n.push(t[2]);
      else {
        var a = new Promise(function (n, a) {
          t = i[e] = [n, a];
        });
        n.push((t[2] = a));
        var o,
          s = document.createElement("script");
        (s.charset = "utf-8"),
          (s.timeout = 120),
          r.nc && s.setAttribute("nonce", r.nc),
          (s.src = (function (e) {
            return (
              r.p +
              "static/js/" +
              ({
                "pages-active-goods~pages-active-turntable~pages-index-goods~pages-index-index~pages-pay-raffle~pages~c8bef51b":
                  "pages-active-goods~pages-active-turntable~pages-index-goods~pages-index-index~pages-pay-raffle~pages~c8bef51b",
                "pages-active-goods~pages-index-goods~pages-index-index~pages-user-index~pages-user-level":
                  "pages-active-goods~pages-index-goods~pages-index-index~pages-user-index~pages-user-level",
                "pages-active-goods": "pages-active-goods",
                "pages-index-goods": "pages-index-goods",
                "pages-index-index~pages_sub1-chat-info":
                  "pages-index-index~pages_sub1-chat-info",
                "pages-index-index": "pages-index-index",
                "pages-active-turntable": "pages-active-turntable",
                "pages-agent-cash_score~pages-pay-raffle~pages-pay-submit~pages-user-apply~pages-user-certification~p~2f537e91":
                  "pages-agent-cash_score~pages-pay-raffle~pages-pay-submit~pages-user-apply~pages-user-certification~p~2f537e91",
                "pages-cat-index~pages-cat-index2~pages-pay-index~pages-pay-raffle~pages-pay-submit~pages_sub1-order-~58b36340":
                  "pages-cat-index~pages-cat-index2~pages-pay-index~pages-pay-raffle~pages-pay-submit~pages_sub1-order-~58b36340",
                "pages-pay-raffle~pages-user-huifu~pages_sub1-kefu-service~pages_sub1-seller-index":
                  "pages-pay-raffle~pages-user-huifu~pages_sub1-kefu-service~pages_sub1-seller-index",
                "pages-pay-raffle": "pages-pay-raffle",
                "pages_sub1-seller-index": "pages_sub1-seller-index",
                "pages-user-article": "pages-user-article",
                "pages_sub1-active-lucky_draw": "pages_sub1-active-lucky_draw",
                "pages_sub1-chat-notice": "pages_sub1-chat-notice",
                "pages_sub1-seller-notice_detail":
                  "pages_sub1-seller-notice_detail",
                "pages-active-order": "pages-active-order",
                "pages-agent-cash_score_log": "pages-agent-cash_score_log",
                "pages-agent-cash_score~pages-cat-list~pages-follow-index~pages-index-search~pages-pay-submit~pages-u~420041f8":
                  "pages-agent-cash_score~pages-cat-list~pages-follow-index~pages-index-search~pages-pay-submit~pages-u~420041f8",
                "pages-pay-submit": "pages-pay-submit",
                "pages-agent-cash_score": "pages-agent-cash_score",
                "pages-user-withdraw": "pages-user-withdraw",
                "pages_sub1-order-invite_fupei":
                  "pages_sub1-order-invite_fupei",
                "pages-cat-list": "pages-cat-list",
                "pages-follow-index": "pages-follow-index",
                "pages-index-search": "pages-index-search",
                "pages-user-apply~pages-user-certification~pages-user-huifu~pages-user-index~pages-user-level~pages-u~6bd29fe7":
                  "pages-user-apply~pages-user-certification~pages-user-huifu~pages-user-index~pages-user-level~pages-u~6bd29fe7",
                "pages-user-apply": "pages-user-apply",
                "pages_sub1-chat-info": "pages_sub1-chat-info",
                "pages-user-index": "pages-user-index",
                "pages-user-huifu": "pages-user-huifu",
                "pages-user-certification~pages-user-personal~pages_sub1-order-audit_detail~pages_sub1-order-comment~~ea7a9f35":
                  "pages-user-certification~pages-user-personal~pages_sub1-order-audit_detail~pages_sub1-order-comment~~ea7a9f35",
                "pages-user-certification": "pages-user-certification",
                "pages-user-personal": "pages-user-personal",
                "pages_sub1-order-audit_detail":
                  "pages_sub1-order-audit_detail",
                "pages_sub1-order-seller_info": "pages_sub1-order-seller_info",
                "pages-user-bind_mobile~pages-user-bind_mobile_weapp~pages-user-login_old":
                  "pages-user-bind_mobile~pages-user-bind_mobile_weapp~pages-user-login_old",
                "pages-user-bind_mobile~pages-user-login_old":
                  "pages-user-bind_mobile~pages-user-login_old",
                "pages-user-bind_mobile": "pages-user-bind_mobile",
                "pages-user-login_old": "pages-user-login_old",
                "pages_sub1-kefu-audit": "pages_sub1-kefu-audit",
                "pages_sub1-kefu-info": "pages_sub1-kefu-info",
                "pages_sub1-kefu-order": "pages_sub1-kefu-order",
                "pages_sub1-order-audit_list": "pages_sub1-order-audit_list",
                "pages_sub1-order-seller": "pages_sub1-order-seller",
                "pages_sub1-seller-invited": "pages_sub1-seller-invited",
                "pages_sub1-seller-edit_profile":
                  "pages_sub1-seller-edit_profile",
                "pages-agent-child": "pages-agent-child",
                "pages-agent-index": "pages-agent-index",
                "pages-agent-score_log": "pages-agent-score_log",
                "pages-alipay-index": "pages-alipay-index",
                "pages-alipay-paid": "pages-alipay-paid",
                "pages-cat-index~pages-cat-index2~pages_sub1-seller-message":
                  "pages-cat-index~pages-cat-index2~pages_sub1-seller-message",
                "pages-cat-index": "pages-cat-index",
                "pages-cat-index2": "pages-cat-index2",
                "pages-pay-index": "pages-pay-index",
                "pages_sub1-seller-rank": "pages_sub1-seller-rank",
                "pages_sub1-seller-message": "pages_sub1-seller-message",
                "pages-chat-list": "pages-chat-list",
                "pages-index-agree": "pages-index-agree",
                "pages-index-daren": "pages-index-daren",
                "pages-index-error": "pages-index-error",
                "pages-index-incomer": "pages-index-incomer",
                "pages-index-seller": "pages-index-seller",
                "pages-pay-check_result": "pages-pay-check_result",
                "pages-pay-deposit": "pages-pay-deposit",
                "pages_sub1-kefu-service": "pages_sub1-kefu-service",
                "pages-pay-recharge": "pages-pay-recharge",
                "pages-pay-success": "pages-pay-success",
                "pages-pay-vip": "pages-pay-vip",
                "pages-system-index": "pages-system-index",
                "pages_sub1-chat-history": "pages_sub1-chat-history",
                "pages_sub1-chat-index": "pages_sub1-chat-index",
                "pages-user-level": "pages-user-level",
                "pages_sub1-order-comment": "pages_sub1-order-comment",
                "pages_sub1-order-service": "pages_sub1-order-service",
                "pages_sub1-chat-test": "pages_sub1-chat-test",
                "pages_sub1-order-seller_service":
                  "pages_sub1-order-seller_service",
                "pages-user-bind_mobile_weapp": "pages-user-bind_mobile_weapp",
                "pages-user-deposit_withdraw": "pages-user-deposit_withdraw",
                "pages-user-fine_list": "pages-user-fine_list",
                "pages-user-login": "pages-user-login",
                "pages-user-money_log": "pages-user-money_log",
                "pages-user-order_log": "pages-user-order_log",
                "pages-user-withdraw_log": "pages-user-withdraw_log",
                "pages_sub1-kefu-audit_detail": "pages_sub1-kefu-audit_detail",
                "pages_sub1-kefu-daka": "pages_sub1-kefu-daka",
                "pages_sub1-kefu-fine_add": "pages_sub1-kefu-fine_add",
                "pages_sub1-kefu-fine_detail": "pages_sub1-kefu-fine_detail",
                "pages_sub1-kefu-fine_edit": "pages_sub1-kefu-fine_edit",
                "pages_sub1-kefu-fine_list": "pages_sub1-kefu-fine_list",
                "pages_sub1-kefu-test": "pages_sub1-kefu-test",
                "pages_sub1-kefu-total": "pages_sub1-kefu-total",
                "pages_sub1-order-index": "pages_sub1-order-index",
                "pages_sub1-order-info": "pages_sub1-order-info",
                "pages_sub1-seller-hall": "pages_sub1-seller-hall",
                "pages_sub1-seller-hall_info": "pages_sub1-seller-hall_info",
                "pages_sub1-seller-notice": "pages_sub1-seller-notice",
                "pages_sub1-seller-seller_pay": "pages_sub1-seller-seller_pay",
              }[e] || e) +
              "." +
              {
                "pages-active-goods~pages-active-turntable~pages-index-goods~pages-index-index~pages-pay-raffle~pages~c8bef51b":
                  "dd513651",
                "pages-active-goods~pages-index-goods~pages-index-index~pages-user-index~pages-user-level":
                  "772671e7",
                "pages-active-goods": "b202661c",
                "pages-index-goods": "25c74f14",
                "pages-index-index~pages_sub1-chat-info": "677e3086",
                "pages-index-index": "d5551ea4",
                "pages-active-turntable": "34d86a7c",
                "pages-agent-cash_score~pages-pay-raffle~pages-pay-submit~pages-user-apply~pages-user-certification~p~2f537e91":
                  "6fe07194",
                "pages-cat-index~pages-cat-index2~pages-pay-index~pages-pay-raffle~pages-pay-submit~pages_sub1-order-~58b36340":
                  "e433c596",
                "pages-pay-raffle~pages-user-huifu~pages_sub1-kefu-service~pages_sub1-seller-index":
                  "cd7fa62e",
                "pages-pay-raffle": "5e10b974",
                "pages_sub1-seller-index": "6a5e3b2c",
                "pages-user-article": "348ba8be",
                "pages_sub1-active-lucky_draw": "8bf6fd42",
                "pages_sub1-chat-notice": "a8b44b61",
                "pages_sub1-seller-notice_detail": "ae974852",
                "pages-active-order": "73b14612",
                "pages-agent-cash_score_log": "2205f66b",
                "pages-agent-cash_score~pages-cat-list~pages-follow-index~pages-index-search~pages-pay-submit~pages-u~420041f8":
                  "103dc4d4",
                "pages-pay-submit": "d387d34c",
                "pages-agent-cash_score": "39fa5499",
                "pages-user-withdraw": "60bbb5f8",
                "pages_sub1-order-invite_fupei": "2db0a532",
                "pages-cat-list": "fbae5bce",
                "pages-follow-index": "12546315",
                "pages-index-search": "6d20e684",
                "pages-user-apply~pages-user-certification~pages-user-huifu~pages-user-index~pages-user-level~pages-u~6bd29fe7":
                  "c200b5e3",
                "pages-user-apply": "84c6ff4f",
                "pages_sub1-chat-info": "9a1d46eb",
                "pages-user-index": "5fd75138",
                "pages-user-huifu": "e6a7c3e8",
                "pages-user-certification~pages-user-personal~pages_sub1-order-audit_detail~pages_sub1-order-comment~~ea7a9f35":
                  "f36dc5b6",
                "pages-user-certification": "61def474",
                "pages-user-personal": "171b68b4",
                "pages_sub1-order-audit_detail": "6445d290",
                "pages_sub1-order-seller_info": "0de376ae",
                "pages-user-bind_mobile~pages-user-bind_mobile_weapp~pages-user-login_old":
                  "d71f24ce",
                "pages-user-bind_mobile~pages-user-login_old": "73c99fe1",
                "pages-user-bind_mobile": "0ba19f63",
                "pages-user-login_old": "68382c87",
                "pages_sub1-kefu-audit": "9e519039",
                "pages_sub1-kefu-info": "fe9faee9",
                "pages_sub1-kefu-order": "91e298f6",
                "pages_sub1-order-audit_list": "7fa6d193",
                "pages_sub1-order-seller": "8fa72818",
                "pages_sub1-seller-invited": "5e4e9094",
                "pages_sub1-seller-edit_profile": "95876992",
                "pages-agent-child": "d4c2b18b",
                "pages-agent-index": "d7fc5abc",
                "pages-agent-score_log": "1202bffb",
                "pages-alipay-index": "6fda5b88",
                "pages-alipay-paid": "feb7f280",
                "pages-cat-index~pages-cat-index2~pages_sub1-seller-message":
                  "e0cec060",
                "pages-cat-index": "f57e5ae8",
                "pages-cat-index2": "fde94c40",
                "pages-pay-index": "e5e1f121",
                "pages_sub1-seller-rank": "e8402ae7",
                "pages_sub1-seller-message": "ac062a9b",
                "pages-chat-list": "85333525",
                "pages-index-agree": "cc9463d2",
                "pages-index-daren": "3cdcc42b",
                "pages-index-error": "4081e17f",
                "pages-index-incomer": "c4c71c8b",
                "pages-index-seller": "57ec112f",
                "pages-pay-check_result": "167925a1",
                "pages-pay-deposit": "20c53947",
                "pages_sub1-kefu-service": "782a78ec",
                "pages-pay-recharge": "620acf99",
                "pages-pay-success": "a74b34a1",
                "pages-pay-vip": "ad66e7fb",
                "pages-system-index": "cbe42feb",
                "pages_sub1-chat-history": "555c56a6",
                "pages_sub1-chat-index": "0c78e943",
                "pages-user-level": "1e4196b0",
                "pages_sub1-order-comment": "944ef5ad",
                "pages_sub1-order-service": "7d7ce628",
                "pages_sub1-chat-test": "0ff32db8",
                "pages_sub1-order-seller_service": "1d7c1c07",
                "pages-user-bind_mobile_weapp": "d66333b2",
                "pages-user-deposit_withdraw": "58300fee",
                "pages-user-fine_list": "541d2578",
                "pages-user-login": "6e82339e",
                "pages-user-money_log": "e7bc9a14",
                "pages-user-order_log": "65270c80",
                "pages-user-withdraw_log": "db04b9f4",
                "pages_sub1-kefu-audit_detail": "fa426463",
                "pages_sub1-kefu-daka": "1c354e18",
                "pages_sub1-kefu-fine_add": "18ee73e0",
                "pages_sub1-kefu-fine_detail": "63d11c1d",
                "pages_sub1-kefu-fine_edit": "3469cad9",
                "pages_sub1-kefu-fine_list": "76eb4492",
                "pages_sub1-kefu-test": "8549b20c",
                "pages_sub1-kefu-total": "f2e2cd02",
                "pages_sub1-order-index": "c889e8e5",
                "pages_sub1-order-info": "128e7b64",
                "pages_sub1-seller-hall": "7d87d2ce",
                "pages_sub1-seller-hall_info": "b9323537",
                "pages_sub1-seller-notice": "83940c0e",
                "pages_sub1-seller-seller_pay": "eeaef8d6",
              }[e] +
              ".js"
            );
          })(e));
        var u = new Error();
        o = function (n) {
          (s.onerror = s.onload = null), clearTimeout(c);
          var t = i[e];
          if (0 !== t) {
            if (t) {
              var a = n && ("load" === n.type ? "missing" : n.type),
                o = n && n.target && n.target.src;
              (u.message =
                "Loading chunk " + e + " failed.\n(" + a + ": " + o + ")"),
                (u.name = "ChunkLoadError"),
                (u.type = a),
                (u.request = o),
                t[1](u);
            }
            i[e] = void 0;
          }
        };
        var c = setTimeout(function () {
          o({ type: "timeout", target: s });
        }, 12e4);
        (s.onerror = s.onload = o), document.head.appendChild(s);
      }
    return Promise.all(n);
  }),
    (r.m = e),
    (r.c = a),
    (r.d = function (e, n, t) {
      r.o(e, n) || Object.defineProperty(e, n, { enumerable: !0, get: t });
    }),
    (r.r = function (e) {
      "undefined" !== typeof Symbol &&
        Symbol.toStringTag &&
        Object.defineProperty(e, Symbol.toStringTag, { value: "Module" }),
        Object.defineProperty(e, "__esModule", { value: !0 });
    }),
    (r.t = function (e, n) {
      if ((1 & n && (e = r(e)), 8 & n)) return e;
      if (4 & n && "object" === typeof e && e && e.__esModule) return e;
      var t = Object.create(null);
      if (
        (r.r(t),
        Object.defineProperty(t, "default", { enumerable: !0, value: e }),
        2 & n && "string" != typeof e)
      )
        for (var a in e)
          r.d(
            t,
            a,
            function (n) {
              return e[n];
            }.bind(null, a),
          );
      return t;
    }),
    (r.n = function (e) {
      var n =
        e && e.__esModule
          ? function () {
              return e["default"];
            }
          : function () {
              return e;
            };
      return r.d(n, "a", n), n;
    }),
    (r.o = function (e, n) {
      return Object.prototype.hasOwnProperty.call(e, n);
    }),
    (r.p = "/h5/"),
    (r.oe = function (e) {
      throw (console.error(e), e);
    });
  var s = (window["webpackJsonp"] = window["webpackJsonp"] || []),
    u = s.push.bind(s);
  (s.push = n), (s = s.slice());
  for (var c = 0; c < s.length; c++) n(s[c]);
  var l = u;
  o.push([0, "chunk-vendors"]), t();
})({
  0: function (e, n, t) {
    e.exports = t("5c9c");
  },
  "0232": function (e, n, t) {
    "use strict";
    t("6a54");
    var a = t("f5bd").default;
    Object.defineProperty(n, "__esModule", { value: !0 }),
      (n.default = function (e, n) {
        if (e && !(0, i.default)(n)) return (0, o.default)(e, n);
        return n;
      });
    var i = a(t("9b17")),
      o = a(t("e1c2"));
  },
  "0250": function (e, n, t) {
    "use strict";
    t.d(n, "b", function () {
      return a;
    }),
      t.d(n, "c", function () {
        return i;
      }),
      t.d(n, "a", function () {});
    var a = function () {
        var e = this.$createElement,
          n = this._self._c || e;
        return n(
          "v-uni-view",
          { staticClass: "uv-status-bar", style: [this.style] },
          [this._t("default")],
          2,
        );
      },
      i = [];
  },
  "0261": function (e, n, t) {
    "use strict";
    t.r(n);
    var a = t("85577"),
      i = t("b987");
    for (var o in i)
      ["default"].indexOf(o) < 0 &&
        (function (e) {
          t.d(n, e, function () {
            return i[e];
          });
        })(o);
    t("709f");
    var r = t("828b"),
      s = Object(r["a"])(
        i["default"],
        a["b"],
        a["c"],
        !1,
        null,
        "84c0c8a4",
        null,
        !1,
        a["a"],
        void 0,
      );
    n["default"] = s.exports;
  },
  "0368": function (e, n, t) {
    "use strict";
    var a;
    t("6a54"),
      Object.defineProperty(n, "__esModule", { value: !0 }),
      (n.default = void 0);
    var i = function (e) {
      var n =
          arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : 500,
        t = !(arguments.length > 2 && void 0 !== arguments[2]) || arguments[2];
      t
        ? a ||
          ((a = !0),
          "function" === typeof e && e(),
          setTimeout(function () {
            a = !1;
          }, n))
        : a ||
          ((a = !0),
          setTimeout(function () {
            (a = !1), "function" === typeof e && e();
          }, n));
    };
    n.default = i;
  },
  "07b7": function (e, n, t) {
    var a = t("2ed2");
    a.__esModule && (a = a.default),
      "string" === typeof a && (a = [[e.i, a, ""]]),
      a.locals && (e.exports = a.locals);
    var i = t("967d").default;
    i("158846f6", a, !0, { sourceMap: !1, shadowMode: !1 });
  },
  "0ab3": function (e, n, t) {
    "use strict";
    t("6a54");
    var a = t("f5bd").default;
    Object.defineProperty(n, "__esModule", { value: !0 }),
      (n.default = void 0),
      t("bf0f"),
      t("2797"),
      t("3efd"),
      t("aa9c");
    var i = a(t("9b1b")),
      o = a(t("80b1")),
      r = a(t("efe5")),
      s = a(t("a329")),
      u = a(t("758d")),
      c = a(t("a823")),
      l = a(t("855f")),
      d = t("117a"),
      f = a(t("c724")),
      p = (function () {
        function e() {
          var n =
            arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : {};
          (0, o.default)(this, e),
            (0, d.isPlainObject)(n) ||
              ((n = {}), console.warn("设置全局参数必须接收一个Object")),
            (this.config = (0, f.default)(
              (0, i.default)((0, i.default)({}, l.default), n),
            )),
            (this.interceptors = {
              request: new u.default(),
              response: new u.default(),
            });
        }
        return (
          (0, r.default)(e, [
            {
              key: "setConfig",
              value: function (e) {
                this.config = e(this.config);
              },
            },
            {
              key: "middleware",
              value: function (e) {
                e = (0, c.default)(this.config, e);
                var n = [s.default, void 0],
                  t = Promise.resolve(e);
                this.interceptors.request.forEach(function (e) {
                  n.unshift(e.fulfilled, e.rejected);
                }),
                  this.interceptors.response.forEach(function (e) {
                    n.push(e.fulfilled, e.rejected);
                  });
                while (n.length) t = t.then(n.shift(), n.shift());
                return t;
              },
            },
            {
              key: "request",
              value: function () {
                var e =
                  arguments.length > 0 && void 0 !== arguments[0]
                    ? arguments[0]
                    : {};
                return this.middleware(e);
              },
            },
            {
              key: "get",
              value: function (e) {
                var n =
                  arguments.length > 1 && void 0 !== arguments[1]
                    ? arguments[1]
                    : {};
                return this.middleware(
                  (0, i.default)({ url: e, method: "GET" }, n),
                );
              },
            },
            {
              key: "post",
              value: function (e, n) {
                var t =
                  arguments.length > 2 && void 0 !== arguments[2]
                    ? arguments[2]
                    : {};
                return this.middleware(
                  (0, i.default)({ url: e, data: n, method: "POST" }, t),
                );
              },
            },
            {
              key: "put",
              value: function (e, n) {
                var t =
                  arguments.length > 2 && void 0 !== arguments[2]
                    ? arguments[2]
                    : {};
                return this.middleware(
                  (0, i.default)({ url: e, data: n, method: "PUT" }, t),
                );
              },
            },
            {
              key: "delete",
              value: function (e, n) {
                var t =
                  arguments.length > 2 && void 0 !== arguments[2]
                    ? arguments[2]
                    : {};
                return this.middleware(
                  (0, i.default)({ url: e, data: n, method: "DELETE" }, t),
                );
              },
            },
            {
              key: "connect",
              value: function (e, n) {
                var t =
                  arguments.length > 2 && void 0 !== arguments[2]
                    ? arguments[2]
                    : {};
                return this.middleware(
                  (0, i.default)({ url: e, data: n, method: "CONNECT" }, t),
                );
              },
            },
            {
              key: "head",
              value: function (e, n) {
                var t =
                  arguments.length > 2 && void 0 !== arguments[2]
                    ? arguments[2]
                    : {};
                return this.middleware(
                  (0, i.default)({ url: e, data: n, method: "HEAD" }, t),
                );
              },
            },
            {
              key: "options",
              value: function (e, n) {
                var t =
                  arguments.length > 2 && void 0 !== arguments[2]
                    ? arguments[2]
                    : {};
                return this.middleware(
                  (0, i.default)({ url: e, data: n, method: "OPTIONS" }, t),
                );
              },
            },
            {
              key: "trace",
              value: function (e, n) {
                var t =
                  arguments.length > 2 && void 0 !== arguments[2]
                    ? arguments[2]
                    : {};
                return this.middleware(
                  (0, i.default)({ url: e, data: n, method: "TRACE" }, t),
                );
              },
            },
            {
              key: "upload",
              value: function (e) {
                var n =
                  arguments.length > 1 && void 0 !== arguments[1]
                    ? arguments[1]
                    : {};
                return (n.url = e), (n.method = "UPLOAD"), this.middleware(n);
              },
            },
            {
              key: "download",
              value: function (e) {
                var n =
                  arguments.length > 1 && void 0 !== arguments[1]
                    ? arguments[1]
                    : {};
                return (n.url = e), (n.method = "DOWNLOAD"), this.middleware(n);
              },
            },
            {
              key: "version",
              get: function () {
                return "3.1.0";
              },
            },
          ]),
          e
        );
      })();
    n.default = p;
  },
  "0bdb": function (e, n, t) {
    "use strict";
    t("6a54");
    var a = t("f5bd").default;
    Object.defineProperty(n, "__esModule", { value: !0 }),
      (n.default = void 0),
      t("bf0f"),
      t("18f7"),
      t("de6c"),
      t("dc89"),
      t("2425"),
      t("5ef2");
    var i = a(t("fcf3")),
      o = a(t("3e38"));
    (function () {
      function e() {
        WeixinJSBridge.invoke("setFontSizeCallback", { fontSize: 0 }),
          WeixinJSBridge.on("menu:setfont", function () {
            WeixinJSBridge.invoke("setFontSizeCallback", { fontSize: 0 });
          });
      }
      "object" ===
        ("undefined" === typeof WeixinJSBridge
          ? "undefined"
          : (0, i.default)(WeixinJSBridge)) &&
      "function" === typeof WeixinJSBridge.invoke
        ? e()
        : document.addEventListener
          ? document.addEventListener("WeixinJSBridgeReady", e, !1)
          : document.attachEvent &&
            (document.attachEvent("WeixinJSBridgeReady", e),
            document.attachEvent("onWeixinJSBridgeReady", e));
    })();
    var r = {
      onLaunch: function (e) {
        console.log("App Launch"),
          uni.hideTabBar(),
          this.getQueryToken(),
          uni.setStorageSync("enter_system_notice", 0),
          this.checkWeappUpdate(),
          o.default.dispatch("websocket/connect", e.query),
          this.initAudioCtx();
      },
      onShow: function () {
        console.log("App Show");
      },
      onHide: function () {
        console.log("App Hide");
      },
      methods: {
        getHashParam: function (e) {
          var n = new URL(window.location.href),
            t = n.hash.substring(1),
            a = t.indexOf("?");
          if (-1 === a) return null;
          var i = t.substring(a + 1),
            o = new URLSearchParams(i);
          return o.get(e);
        },
        getQueryToken: function () {
          var e = this.getHashParam("token");
          e && uni.setStorageSync("token", e);
        },
        checkWeappUpdate: function () {},
        initAudioCtx: function () {
          if (!uni.$audioCtx) {
            var e = uni.createInnerAudioContext();
            (e.loop = !0),
              (e.autoplay = !1),
              e.onPlay(function () {
                (uni.$audioPlaying = !0), uni.$emit("audioPlayStateChange", !0);
              }),
              e.onPause(function () {
                (uni.$audioPlaying = !1), uni.$emit("audioPlayStateChange", !1);
              }),
              e.onStop(function () {
                (uni.$audioPlaying = !1), uni.$emit("audioPlayStateChange", !1);
              }),
              e.onError(function (e) {
                console.log("audio error", e);
              }),
              (uni.$audioCtx = e),
              (uni.$audioPlaying = !1),
              (uni.$audioConfig = null),
              (uni.$audioWantPlay = !1);
          }
        },
      },
    };
    n.default = r;
  },
  "0c56": function (e, n, t) {
    "use strict";
    t("6a54"),
      Object.defineProperty(n, "__esModule", { value: !0 }),
      (n.default = void 0);
    var a = { props: { bgColor: { type: String, default: "transparent" } } };
    n.default = a;
  },
  "0ed3": function (e, n, t) {
    "use strict";
    t("6a54");
    var a = t("f5bd").default;
    Object.defineProperty(n, "__esModule", { value: !0 }),
      (n.default = void 0),
      t("64aa");
    var i,
      o,
      r = a(t("9b1b")),
      s = {
        props: (0, r.default)(
          {
            status: { type: String, default: "loadmore" },
            bgColor: { type: String, default: "transparent" },
            icon: { type: Boolean, default: !0 },
            fontSize: { type: [String, Number], default: 14 },
            iconSize: { type: [String, Number], default: 16 },
            color: { type: String, default: "#606266" },
            loadingIcon: { type: String, default: "spinner" },
            loadmoreText: { type: String, default: "加载更多" },
            loadingText: { type: String, default: "正在加载..." },
            nomoreText: { type: String, default: "没有更多了" },
            isDot: { type: Boolean, default: !1 },
            iconColor: { type: String, default: "#b7b7b7" },
            marginTop: { type: [String, Number], default: 10 },
            marginBottom: { type: [String, Number], default: 10 },
            height: { type: [String, Number], default: "auto" },
            line: { type: Boolean, default: !1 },
            lineColor: { type: String, default: "#E6E8EB" },
            dashed: { type: Boolean, default: !1 },
          },
          null === (i = uni.$uv) ||
            void 0 === i ||
            null === (o = i.props) ||
            void 0 === o
            ? void 0
            : o.loadmore,
        ),
      };
    n.default = s;
  },
  "0fe0": function (e, n, t) {
    var a = t("fbc9");
    a.__esModule && (a = a.default),
      "string" === typeof a && (a = [[e.i, a, ""]]),
      a.locals && (e.exports = a.locals);
    var i = t("967d").default;
    i("c2c0b138", a, !0, { sourceMap: !1, shadowMode: !1 });
  },
  1030: function (e, n, t) {
    "use strict";
    t("6a54"),
      Object.defineProperty(n, "__esModule", { value: !0 }),
      (n.default = void 0),
      t("d4b5"),
      t("c223");
    var a = t("e74a"),
      i = {
        namespaced: !0,
        state: {
          socket: null,
          isConnected: !1,
          message: "",
          heartbeatTimer: null,
          heartbeatInterval: 5e4,
          reconnectAttempts: 0,
          maxReconnectAttempts: 5,
          reconnectTimer: null,
          lastActiveTime: 0,
        },
        mutations: {
          init_socket: function (e, n) {
            var t = this;
            e.isConnected ||
              (console.log(n.ws_url),
              (e.socket = uni.connectSocket({
                url: n.ws_url,
                success: function () {
                  (e.isConnected = !0),
                    (e.reconnectAttempts = 0),
                    t.commit("websocket/startHeartbeat");
                },
              })),
              e.socket.onOpen(function () {
                (e.isConnected = !0),
                  (e.reconnectAttempts = 0),
                  t.commit("websocket/startHeartbeat"),
                  uni.$emit("websocket_connected");
              }),
              e.socket.onMessage(function (t) {
                var i = JSON.parse(t.data);
                if (
                  ((e.lastActiveTime = Date.now()),
                  console.log(i),
                  "init" == i.label)
                )
                  if (0 == n.kefu.length) {
                    var o = { client_id: i.client_id, user_id: n.user_id };
                    (0, a.post)(
                      "/wechat/ChatClient/bindUser",
                      o,
                      uni.getStorageSync("token"),
                    );
                  } else {
                    var r = { client_id: i.client_id, user_id: n.kefu.user_id };
                    (0, a.post)(
                      "/wechat/ChatClient/bindKefu",
                      r,
                      uni.getStorageSync("token"),
                    );
                  }
                i.label, (e.message = i), uni.$emit("websocket_message", i);
              }),
              e.socket.onError(function (a) {
                console.error("websocket error:", a),
                  (e.isConnected = !1),
                  t.commit("websocket/stopHeartbeat"),
                  t.commit("websocket/tryReconnect", n),
                  uni.$emit("websocket_error", a);
              }),
              e.socket.onClose(function () {
                (e.isConnected = !1),
                  t.commit("websocket/stopHeartbeat"),
                  t.commit("websocket/tryReconnect", n),
                  uni.$emit("websocket_closed");
              }));
          },
          close_socket: function (e) {
            e.socket &&
              (e.socket.close(), (e.socket = null), (e.isConnected = !1)),
              this.commit("websocket/stopHeartbeat"),
              e.reconnectTimer &&
                (clearTimeout(e.reconnectTimer), (e.reconnectTimer = null));
          },
          send_message: function (e, n) {
            e.isConnected &&
              e.socket &&
              e.socket.send({
                data: JSON.stringify(n),
                success: function () {
                  e.lastActiveTime = Date.now();
                },
                fail: function (e) {
                  console.error("消息发送失败:", e);
                },
              });
          },
          startHeartbeat: function (e) {
            var n = this;
            this.commit("websocket/stopHeartbeat"),
              this.commit("websocket/sendHeartbeat"),
              (e.heartbeatTimer = setInterval(function () {
                n.commit("websocket/sendHeartbeat"),
                  Date.now() - e.lastActiveTime > 2 * e.heartbeatInterval &&
                    (console.warn("连接可能已断开，尝试重新连接..."),
                    e.socket.close({ code: 1e3, reason: "心跳超时" }));
              }, e.heartbeatInterval));
          },
          stopHeartbeat: function (e) {
            e.heartbeatTimer &&
              (clearInterval(e.heartbeatTimer), (e.heartbeatTimer = null));
          },
          sendHeartbeat: function (e) {
            if (e.isConnected)
              try {
                this.commit("websocket/send_message", { label: "ping" });
              } catch (n) {
                console.error("发送心跳失败:", n);
              }
          },
          tryReconnect: function (e, n) {
            var t = this;
            if (e.reconnectAttempts >= e.maxReconnectAttempts)
              console.log("已达到最大重试次数，停止重连");
            else {
              e.reconnectTimer && clearTimeout(e.reconnectTimer),
                e.reconnectAttempts++;
              var a = Math.min(1e3 * Math.pow(2, e.reconnectAttempts), 3e4);
              console.log(
                "将在 "
                  .concat(a, "ms 后尝试第 ")
                  .concat(e.reconnectAttempts, " 次重连..."),
              ),
                (e.reconnectTimer = setTimeout(function () {
                  console.log("尝试重新连接..."),
                    t.commit("websocket/init_socket", n);
                }, a));
            }
          },
          checkConnection: function (e, n) {
            var t = this;
            e.isConnected &&
              Date.now() - e.lastActiveTime > 2 * e.heartbeatInterval &&
              (console.log("检查连接状态..."),
              this.commit("websocket/send_message", { label: "ping" }),
              setTimeout(function () {
                Date.now() - e.lastActiveTime > 3 * e.heartbeatInterval &&
                  (console.log("连接无响应，强制重连"),
                  t.commit("websocket/close_socket"),
                  t.commit("websocket/init_socket", n));
              }, 5e3));
          },
        },
        actions: {
          connect: function (e, n) {
            var t = e.commit;
            setTimeout(function () {
              (0, a.send)(
                "/wechat/Chat/getChatConfig",
                { kefu_token: n.kefu_token },
                !1,
              ).then(function (e) {
                var n = e.status,
                  a = (e.msg, e.data);
                1 == n && t("init_socket", a);
              });
            }, 2e3);
          },
          disconnect: function (e) {
            var n = e.commit;
            n("close_socket");
          },
          send: function (e, n) {
            var t = e.commit;
            t("send_message", n);
          },
          checkConnection: function (e, n) {
            var t = e.commit;
            e.state;
            t("checkConnection", n);
          },
        },
      },
      o = i;
    n.default = o;
  },
  "10e0": function (e, n, t) {
    "use strict";
    var a = t("cc43"),
      i = t.n(a);
    i.a;
  },
  "117a": function (e, n, t) {
    "use strict";
    t("6a54"), t("2797");
    var a = t("f5bd").default;
    Object.defineProperty(n, "__esModule", { value: !0 }),
      (n.deepMerge = function e() {
        var n = {};
        function t(t, a) {
          "object" === (0, i.default)(n[a]) && "object" === (0, i.default)(t)
            ? (n[a] = e(n[a], t))
            : "object" === (0, i.default)(t)
              ? (n[a] = e({}, t))
              : (n[a] = t);
        }
        for (var a = 0, o = arguments.length; a < o; a++) s(arguments[a], t);
        return n;
      }),
      (n.forEach = s),
      (n.isArray = r),
      (n.isBoolean = function (e) {
        return "boolean" === typeof e;
      }),
      (n.isDate = function (e) {
        return "[object Date]" === o.call(e);
      }),
      (n.isObject = function (e) {
        return null !== e && "object" === (0, i.default)(e);
      }),
      (n.isPlainObject = function (e) {
        return "[object Object]" === Object.prototype.toString.call(e);
      }),
      (n.isURLSearchParams = function (e) {
        return (
          "undefined" !== typeof URLSearchParams && e instanceof URLSearchParams
        );
      }),
      (n.isUndefined = function (e) {
        return "undefined" === typeof e;
      });
    var i = a(t("fcf3"));
    t("bf0f"), t("18f7"), t("de6c"), t("2425");
    var o = Object.prototype.toString;
    function r(e) {
      return "[object Array]" === o.call(e);
    }
    function s(e, n) {
      if (null !== e && "undefined" !== typeof e)
        if (("object" !== (0, i.default)(e) && (e = [e]), r(e)))
          for (var t = 0, a = e.length; t < a; t++) n.call(null, e[t], t, e);
        else
          for (var o in e)
            Object.prototype.hasOwnProperty.call(e, o) &&
              n.call(null, e[o], o, e);
    }
  },
  1239: function (e, n, t) {
    "use strict";
    t("6a54");
    var a = t("f5bd").default;
    Object.defineProperty(n, "__esModule", { value: !0 }), (n.default = void 0);
    var i = a(t("b7c7")),
      o = a(t("fcf3")),
      r = a(t("9b1b"));
    t("64aa"), t("bf0f"), t("2797"), t("c223"), t("5c47"), t("a1c1");
    var s = a(t("4d8f0")),
      u = a(t("9463")),
      c = t("9ba2"),
      l = {
        name: "uv-transition",
        mixins: [s.default, u.default],
        emits: ["click", "change"],
        props: {
          show: { type: Boolean, default: !1 },
          mode: {
            type: [Array, String, null],
            default: function () {
              return "fade";
            },
          },
          duration: { type: [String, Number], default: 300 },
          timingFunction: { type: String, default: "ease-out" },
          customClass: { type: String, default: "" },
          cellChild: { type: Boolean, default: !1 },
        },
        data: function () {
          return {
            isShow: !1,
            transform: "",
            opacity: 1,
            animationData: {},
            durationTime: 300,
            config: {},
          };
        },
        watch: {
          show: {
            handler: function (e) {
              e ? this.open() : this.isShow && this.close();
            },
            immediate: !0,
          },
        },
        computed: {
          transformStyles: function () {
            var e = (0, r.default)(
              (0, r.default)(
                { transform: this.transform, opacity: this.opacity },
                this.$uv.addStyle(this.customStyle),
              ),
              {},
              { "transition-duration": "".concat(this.duration / 1e3, "s") },
            );
            return this.$uv.addStyle(e, "string");
          },
        },
        created: function () {
          (this.config = {
            duration: this.duration,
            timingFunction: this.timingFunction,
            transformOrigin: "50% 50%",
            delay: 0,
          }),
            (this.durationTime = this.duration);
        },
        methods: {
          init: function () {
            var e =
              arguments.length > 0 && void 0 !== arguments[0]
                ? arguments[0]
                : {};
            e.duration && (this.durationTime = e.duration),
              (this.animation = (0, c.createAnimation)(
                Object.assign(this.config, e),
                this,
              ));
          },
          onClick: function () {
            this.$emit("click", { detail: this.isShow });
          },
          step: function (e) {
            var n =
              arguments.length > 1 && void 0 !== arguments[1]
                ? arguments[1]
                : {};
            if (this.animation) {
              for (var t in e)
                try {
                  var a;
                  if ("object" === (0, o.default)(e[t]))
                    (a = this.animation)[t].apply(a, (0, i.default)(e[t]));
                  else this.animation[t](e[t]);
                } catch (r) {
                  console.error("方法 ".concat(t, " 不存在"));
                }
              return this.animation.step(n), this;
            }
          },
          run: function (e) {
            this.animation && this.animation.run(e);
          },
          open: function () {
            var e = this;
            clearTimeout(this.timer), (this.transform = ""), (this.isShow = !0);
            var n = this.styleInit(!1),
              t = n.opacity,
              a = n.transform;
            "undefined" !== typeof t && (this.opacity = t),
              (this.transform = a),
              this.$nextTick(function () {
                e.timer = setTimeout(function () {
                  (e.animation = (0, c.createAnimation)(e.config, e)),
                    e.tranfromInit(!1).step(),
                    e.animation.run(),
                    e.$emit("change", { detail: e.isShow });
                }, 20);
              });
          },
          close: function (e) {
            var n = this;
            this.animation &&
              this.tranfromInit(!0)
                .step()
                .run(function () {
                  (n.isShow = !1),
                    (n.animationData = null),
                    (n.animation = null);
                  var e = n.styleInit(!1),
                    t = e.opacity,
                    a = e.transform;
                  (n.opacity = t || 1),
                    (n.transform = a),
                    n.$emit("change", { detail: n.isShow });
                });
          },
          styleInit: function (e) {
            var n = this,
              t = { transform: "" },
              a = function (e, a) {
                "fade" === a
                  ? (t.opacity = n.animationType(e)[a])
                  : (t.transform += n.animationType(e)[a] + " ");
              };
            return (
              "string" === typeof this.mode
                ? a(e, this.mode)
                : this.mode.forEach(function (n) {
                    a(e, n);
                  }),
              t
            );
          },
          tranfromInit: function (e) {
            var n = this,
              t = function (e, t) {
                var a = null;
                "fade" === t
                  ? (a = e ? 0 : 1)
                  : ((a = e ? "-100%" : "0"),
                    "zoom-in" === t && (a = e ? 0.8 : 1),
                    "zoom-out" === t && (a = e ? 1.2 : 1),
                    "slide-right" === t && (a = e ? "100%" : "0"),
                    "slide-bottom" === t && (a = e ? "100%" : "0")),
                  n.animation[n.animationMode()[t]](a);
              };
            return (
              "string" === typeof this.mode
                ? t(e, this.mode)
                : this.mode.forEach(function (n) {
                    t(e, n);
                  }),
              this.animation
            );
          },
          animationType: function (e) {
            return {
              fade: e ? 1 : 0,
              "slide-top": "translateY(".concat(e ? "0" : "-100%", ")"),
              "slide-right": "translateX(".concat(e ? "0" : "100%", ")"),
              "slide-bottom": "translateY(".concat(e ? "0" : "100%", ")"),
              "slide-left": "translateX(".concat(e ? "0" : "-100%", ")"),
              "zoom-in": "scaleX("
                .concat(e ? 1 : 0.8, ") scaleY(")
                .concat(e ? 1 : 0.8, ")"),
              "zoom-out": "scaleX("
                .concat(e ? 1 : 1.2, ") scaleY(")
                .concat(e ? 1 : 1.2, ")"),
            };
          },
          animationMode: function () {
            return {
              fade: "opacity",
              "slide-top": "translateY",
              "slide-right": "translateX",
              "slide-bottom": "translateY",
              "slide-left": "translateX",
              "zoom-in": "scale",
              "zoom-out": "scale",
            };
          },
          toLine: function (e) {
            return e.replace(/([A-Z])/g, "-$1").toLowerCase();
          },
        },
      };
    n.default = l;
  },
  "12fd": function (e, n, t) {
    "use strict";
    t.r(n);
    var a = t("f1e6"),
      i = t.n(a);
    for (var o in a)
      ["default"].indexOf(o) < 0 &&
        (function (e) {
          t.d(n, e, function () {
            return a[e];
          });
        })(o);
    n["default"] = i.a;
  },
  "131d": function (e, n, t) {
    "use strict";
    t.d(n, "b", function () {
      return i;
    }),
      t.d(n, "c", function () {
        return o;
      }),
      t.d(n, "a", function () {
        return a;
      });
    var a = { uvLine: t("73b2").default, uvLoadingIcon: t("17f5").default },
      i = function () {
        var e = this,
          n = e.$createElement,
          t = e._self._c || n;
        return t(
          "v-uni-view",
          {
            staticClass: "uv-loadmore",
            style: [
              {
                backgroundColor: e.bgColor,
                marginBottom: e.$uv.addUnit(e.marginBottom),
                marginTop: e.$uv.addUnit(e.marginTop),
                height: e.$uv.addUnit(e.height),
              },
              e.$uv.addStyle(e.customStyle),
            ],
          },
          [
            e.line
              ? t("uv-line", {
                  attrs: {
                    length: "140rpx",
                    color: e.lineColor,
                    hairline: !1,
                    dashed: e.dashed,
                  },
                })
              : e._e(),
            t(
              "v-uni-view",
              {
                staticClass: "uv-loadmore__content",
                class:
                  "loadmore" == e.status || "nomore" == e.status
                    ? "uv-more"
                    : "",
              },
              [
                "loading" === e.status && e.icon
                  ? t(
                      "v-uni-view",
                      { staticClass: "uv-loadmore__content__icon-wrap" },
                      [
                        t("uv-loading-icon", {
                          attrs: {
                            color: e.iconColor,
                            size: e.iconSize,
                            mode: e.loadingIcon,
                          },
                        }),
                      ],
                      1,
                    )
                  : e._e(),
                t(
                  "v-uni-text",
                  {
                    staticClass: "uv-line-1",
                    class: [
                      "nomore" == e.status && 1 == e.isDot
                        ? "uv-loadmore__content__dot-text"
                        : "uv-loadmore__content__text",
                    ],
                    style: [e.loadTextStyle],
                    on: {
                      click: function (n) {
                        (arguments[0] = n = e.$handleEvent(n)),
                          e.loadMore.apply(void 0, arguments);
                      },
                    },
                  },
                  [e._v(e._s(e.showText))],
                ),
              ],
              1,
            ),
            e.line
              ? t("uv-line", {
                  attrs: {
                    length: "140rpx",
                    color: e.lineColor,
                    hairline: !1,
                    dashed: e.dashed,
                  },
                })
              : e._e(),
          ],
          1,
        );
      },
      o = [];
  },
  "146d": function (e, n, t) {
    "use strict";
    t.r(n);
    var a = t("20d7"),
      i = t("e5ca");
    for (var o in i)
      ["default"].indexOf(o) < 0 &&
        (function (e) {
          t.d(n, e, function () {
            return i[e];
          });
        })(o);
    t("9a98");
    var r = t("828b"),
      s = Object(r["a"])(
        i["default"],
        a["b"],
        a["c"],
        !1,
        null,
        "2a4c32bc",
        null,
        !1,
        a["a"],
        void 0,
      );
    n["default"] = s.exports;
  },
  1509: function (e, n, t) {
    "use strict";
    t("6a54");
    var a = t("f5bd").default;
    Object.defineProperty(n, "__esModule", { value: !0 }),
      (n.amount = function (e) {
        return /^[1-9]\d*(,\d{3})*(\.\d{1,2})?$|^0\.\d{1,2}$/.test(e);
      }),
      (n.array = function (e) {
        if ("function" === typeof Array.isArray) return Array.isArray(e);
        return "[object Array]" === Object.prototype.toString.call(e);
      }),
      (n.carNo = function (e) {
        if (7 === e.length)
          return /^[京津沪渝冀豫云辽黑湘皖鲁新苏浙赣鄂桂甘晋蒙陕吉闽贵粤青藏川宁琼使领A-Z]{1}[A-Z]{1}[A-HJ-NP-Z0-9]{4}[A-HJ-NP-Z0-9挂学警港澳]{1}$/.test(
            e,
          );
        if (8 === e.length)
          return /^[京津沪渝冀豫云辽黑湘皖鲁新苏浙赣鄂桂甘晋蒙陕吉闽贵粤青藏川宁琼使领A-Z]{1}[A-Z]{1}(([0-9]{5}[DF]$)|([DF][A-HJ-NP-Z0-9][0-9]{4}$))/.test(
            e,
          );
        return !1;
      }),
      (n.chinese = function (e) {
        return /^[\u4e00-\u9fa5]+$/gi.test(e);
      }),
      (n.code = function (e) {
        var n =
          arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : 6;
        return new RegExp("^\\d{".concat(n, "}$")).test(e);
      }),
      (n.contains = function (e, n) {
        return e.indexOf(n) >= 0;
      }),
      (n.date = function (e) {
        if (!e) return !1;
        o(e) && (e = +e);
        return !/Invalid|NaN/.test(new Date(e).toString());
      }),
      (n.dateISO = function (e) {
        return /^\d{4}[\/\-](0?[1-9]|1[012])[\/\-](0?[1-9]|[12][0-9]|3[01])$/.test(
          e,
        );
      }),
      (n.digits = function (e) {
        return /^\d+$/.test(e);
      }),
      (n.email = function (e) {
        return /^\w+((-\w+)|(\.\w+))*\@[A-Za-z0-9]+((\.|-)[A-Za-z0-9]+)*\.[A-Za-z0-9]+$/.test(
          e,
        );
      }),
      (n.empty = function (e) {
        switch ((0, i.default)(e)) {
          case "undefined":
            return !0;
          case "string":
            if (0 == e.replace(/(^[ \t\n\r]*)|([ \t\n\r]*$)/g, "").length)
              return !0;
            break;
          case "boolean":
            if (!e) return !0;
            break;
          case "number":
            if (0 === e || isNaN(e)) return !0;
            break;
          case "object":
            if (null === e || 0 === e.length) return !0;
            for (var n in e) return !1;
            return !0;
        }
        return !1;
      }),
      (n.enOrNum = function (e) {
        return /^[0-9a-zA-Z]*$/g.test(e);
      }),
      (n.func = s),
      (n.idCard = function (e) {
        return /^[1-9]\d{5}[1-9]\d{3}((0\d)|(1[0-2]))(([0|1|2]\d)|3[0-1])\d{3}([0-9]|X)$/.test(
          e,
        );
      }),
      (n.image = function (e) {
        var n = e.split("?")[0];
        return /\.(jpeg|jpg|gif|png|svg|webp|jfif|bmp|dpg)/i.test(n);
      }),
      (n.jsonString = function (e) {
        if ("string" === typeof e)
          try {
            var n = JSON.parse(e);
            return !("object" !== (0, i.default)(n) || !n);
          } catch (t) {
            return !1;
          }
        return !1;
      }),
      (n.landline = function (e) {
        return /^\d{3,4}-\d{7,8}(-\d{3,4})?$/.test(e);
      }),
      (n.letter = function (e) {
        return /^[a-zA-Z]*$/.test(e);
      }),
      (n.mobile = function (e) {
        return /^1([3589]\d|4[5-9]|6[1-2,4-7]|7[0-8])\d{8}$/.test(e);
      }),
      (n.number = o),
      (n.object = r),
      (n.promise = function (e) {
        return r(e) && s(e.then) && s(e.catch);
      }),
      (n.range = function (e, n) {
        return e >= n[0] && e <= n[1];
      }),
      (n.rangeLength = function (e, n) {
        return e.length >= n[0] && e.length <= n[1];
      }),
      (n.regExp = function (e) {
        return e && "[object RegExp]" === Object.prototype.toString.call(e);
      }),
      (n.string = function (e) {
        return "string" === typeof e;
      }),
      (n.url = function (e) {
        return /^((https|http|ftp|rtsp|mms):\/\/)(([0-9a-zA-Z_!~*'().&=+$%-]+: )?[0-9a-zA-Z_!~*'().&=+$%-]+@)?(([0-9]{1,3}.){3}[0-9]{1,3}|([0-9a-zA-Z_!~*'()-]+.)*([0-9a-zA-Z][0-9a-zA-Z-]{0,61})?[0-9a-zA-Z].[a-zA-Z]{2,6})(:[0-9]{1,4})?((\/?)|(\/[0-9a-zA-Z_!~*'().;?:@&=+$,%#-]+)+\/?)$/.test(
          e,
        );
      }),
      (n.video = function (e) {
        return /\.(mp4|mpg|mpeg|dat|asf|avi|rm|rmvb|mov|wmv|flv|mkv|m3u8)/i.test(
          e,
        );
      });
    var i = a(t("fcf3"));
    function o(e) {
      return /^[\+-]?(\d+\.?\d*|\.\d+|\d\.\d+e\+\d+)$/.test(e);
    }
    function r(e) {
      return "[object Object]" === Object.prototype.toString.call(e);
    }
    function s(e) {
      return "function" === typeof e;
    }
    t("5c47"),
      t("0506"),
      t("c9b5"),
      t("bf0f"),
      t("ab80"),
      t("5ef2"),
      t("a1c1"),
      t("23f4"),
      t("7d2f"),
      t("9c4e");
  },
  "15b8": function (e, n, t) {
    t("4626"), t("5ac7"), t("bf0f"), t("7a76"), t("c9b5");
    var a = !1,
      i = "";
    (a = "localhost" == location.hostname), (i = location.origin);
    i.includes("localhost") && (i = "https://xiaocho.qiangshenyiyou.cn");
    var o = function (e) {
      var n = arguments.length > 1 && void 0 !== arguments[1] && arguments[1];
      return new Promise(function (t, a) {
        n && uni.showLoading({ title: "请求中", mask: !0 });
        var o = "";
        (o = i),
          uni.request({
            url: o + e.url,
            method: "POST",
            data: e.data,
            success: function (e) {
              200 === e.statusCode
                ? t(e.data)
                : (uni.showToast({ title: e.msg, icon: "none", duration: 2e3 }),
                  a(e.msg));
            },
            fail: function (e) {
              console.log(e), a(e);
            },
            complete: function () {},
          });
      });
    };
    e.exports = {
      request: o,
      sendPost: function (e) {
        var n = this,
          t = arguments.length > 1 && void 0 !== arguments[1] && arguments[1];
        return new Promise(function (a, i) {
          o(e, t, { env: n.env, api: n.api })
            .then(function (e) {
              var n = e;
              a(n);
            })
            .catch(function (e) {
              i(e);
            });
        });
      },
      uploadImg: function (e, n) {
        var t = "";
        return (
          (t = i),
          new Promise(function (a, i) {
            uni.uploadFile({
              url: t + e,
              filePath: n,
              name: "img",
              formData: { user: "test" },
              success: function (e) {
                var n = {};
                if (200 != e.statusCode)
                  n = { status: 0, msg: "上传失败", data: "" };
                else {
                  n = JSON.parse(e.data);
                  var t = n,
                    i = t.status;
                  t.msg;
                  if (1 != i)
                    return uni.showToast({
                      title: e.msg,
                      icon: "none",
                      duration: 2e3,
                    });
                }
                a(n);
              },
            });
          })
        );
      },
      uploadImgs: function (e, n) {
        return new Promise(function (t, a) {
          uni.uploadFile({
            url: i + e,
            files: n,
            name: "img",
            formData: { user: "test" },
            success: function (e) {
              var n = {};
              if (200 != e.statusCode)
                n = { status: 0, msg: "上传失败", data: "" };
              else {
                n = JSON.parse(e.data);
                var a = n,
                  i = a.status;
                a.msg;
                if (1 != i)
                  return uni.showToast({
                    title: e.msg,
                    icon: "none",
                    duration: 2e3,
                  });
              }
              t(n);
            },
          });
        });
      },
      uploadFile: function (e, n, t) {
        var a = "";
        return (
          (a = i),
          new Promise(function (i, o) {
            var r = uni.uploadFile({
              url: a + e,
              filePath: n,
              name: "file",
              formData: { user: "test" },
              success: function (e) {
                var n = {};
                200 != e.statusCode
                  ? (n = { status: 0, msg: "上传失败", data: "" })
                  : ((n = JSON.parse(e.data)), i(n)),
                  i(n);
              },
            });
            t &&
              r.onProgressUpdate(function (e) {
                t(e.progress);
              });
          })
        );
      },
      uploadCompressImgs: function (e) {
        return new Promise(function (n, t) {
          var a = new Image();
          a.src = e;
          a.addEventListener("load", function e() {
            a.removeEventListener("load", e);
            var t = document.createElement("canvas"),
              i = t.getContext("2d"),
              o = a.width,
              r = a.height;
            if (o > 1500 || r > 1500) {
              var s = Math.min(1500 / o, 1500 / r);
              (o *= s), (r *= s);
            }
            (t.width = o), (t.height = r), i.drawImage(a, 0, 0, o, r);
            var u = t.toDataURL("image/jpeg", 0.8);
            n(u);
          }),
            a.addEventListener("error", function () {
              t(new Error("Failed to load image: " + e));
            });
        });
      },
      dubug: a,
      baseUrl: i,
    };
  },
  "15e6": function (e, n, t) {
    "use strict";
    var a = t("4766"),
      i = t.n(a);
    i.a;
  },
  "17ba": function (e, n, t) {
    "use strict";
    t.r(n);
    var a = t("5ff2"),
      i = t.n(a);
    for (var o in a)
      ["default"].indexOf(o) < 0 &&
        (function (e) {
          t.d(n, e, function () {
            return a[e];
          });
        })(o);
    n["default"] = i.a;
  },
  "17f5": function (e, n, t) {
    "use strict";
    t.r(n);
    var a = t("8f77"),
      i = t("bf17");
    for (var o in i)
      ["default"].indexOf(o) < 0 &&
        (function (e) {
          t.d(n, e, function () {
            return i[e];
          });
        })(o);
    t("808e");
    var r = t("828b"),
      s = Object(r["a"])(
        i["default"],
        a["b"],
        a["c"],
        !1,
        null,
        "9c879764",
        null,
        !1,
        a["a"],
        void 0,
      );
    n["default"] = s.exports;
  },
  "1a07": function (e, n, t) {
    "use strict";
    t.r(n);
    var a = t("b3c8"),
      i = t("4755");
    for (var o in i)
      ["default"].indexOf(o) < 0 &&
        (function (e) {
          t.d(n, e, function () {
            return i[e];
          });
        })(o);
    t("71ab");
    var r = t("828b"),
      s = Object(r["a"])(
        i["default"],
        a["b"],
        a["c"],
        !1,
        null,
        "14309c6b",
        null,
        !1,
        a["a"],
        void 0,
      );
    n["default"] = s.exports;
  },
  "1dedb": function (e, n, t) {
    "use strict";
    t.r(n);
    var a = t("0bdb"),
      i = t.n(a);
    for (var o in a)
      ["default"].indexOf(o) < 0 &&
        (function (e) {
          t.d(n, e, function () {
            return a[e];
          });
        })(o);
    n["default"] = i.a;
  },
  "20d7": function (e, n, t) {
    "use strict";
    t.d(n, "b", function () {
      return i;
    }),
      t.d(n, "c", function () {
        return o;
      }),
      t.d(n, "a", function () {
        return a;
      });
    var a = { uvIcon: t("1a07").default },
      i = function () {
        var e = this,
          n = e.$createElement,
          t = e._self._c || n;
        return t(
          "v-uni-view",
          {
            staticClass: "uv-search",
            style: [{ margin: e.margin }, e.$uv.addStyle(e.customStyle)],
            on: {
              click: function (n) {
                (arguments[0] = n = e.$handleEvent(n)),
                  e.clickHandler.apply(void 0, arguments);
              },
            },
          },
          [
            t(
              "v-uni-view",
              {
                staticClass: "uv-search__content",
                style: [
                  {
                    backgroundColor: e.bgColor,
                    borderRadius: "round" == e.shape ? "100px" : "4px",
                    borderColor: e.borderColor,
                  },
                  e.$uv.addStyle(e.boxStyle),
                ],
              },
              [
                e.disabled
                  ? t("v-uni-view", {
                      staticClass: "uv-search__content__disabled",
                    })
                  : e._e(),
                e._t("prefix", [
                  t(
                    "v-uni-view",
                    { staticClass: "uv-search__content__icon" },
                    [
                      t("uv-icon", {
                        attrs: {
                          size: e.searchIconSize,
                          name: e.searchIcon,
                          color: e.searchIconColor
                            ? e.searchIconColor
                            : e.color,
                        },
                        on: {
                          click: function (n) {
                            (arguments[0] = n = e.$handleEvent(n)),
                              e.clickIcon.apply(void 0, arguments);
                          },
                        },
                      }),
                    ],
                    1,
                  ),
                ]),
                t("v-uni-input", {
                  staticClass: "uv-search__content__input",
                  style: [
                    {
                      textAlign: e.inputAlign,
                      color: e.color,
                      backgroundColor: e.bgColor,
                      height: e.$uv.addUnit(e.height),
                    },
                    e.inputStyle,
                  ],
                  attrs: {
                    "confirm-type": "search",
                    value: e.keyword,
                    disabled: e.disabled,
                    focus: e.focus,
                    maxlength: e.maxlength,
                    "placeholder-class":
                      "uv-search__content__input--placeholder",
                    placeholder: e.placeholder,
                    "placeholder-style": "color: " + e.placeholderColor,
                    type: "text",
                  },
                  on: {
                    blur: function (n) {
                      (arguments[0] = n = e.$handleEvent(n)),
                        e.blur.apply(void 0, arguments);
                    },
                    confirm: function (n) {
                      (arguments[0] = n = e.$handleEvent(n)),
                        e.search.apply(void 0, arguments);
                    },
                    input: function (n) {
                      (arguments[0] = n = e.$handleEvent(n)),
                        e.inputChange.apply(void 0, arguments);
                    },
                    focus: function (n) {
                      (arguments[0] = n = e.$handleEvent(n)),
                        e.getFocus.apply(void 0, arguments);
                    },
                  },
                }),
                e.keyword && e.clearabled && e.focused
                  ? t(
                      "v-uni-view",
                      {
                        staticClass:
                          "uv-search__content__icon uv-search__content__close",
                        on: {
                          click: function (n) {
                            (arguments[0] = n = e.$handleEvent(n)),
                              e.clear.apply(void 0, arguments);
                          },
                        },
                      },
                      [
                        t("uv-icon", {
                          attrs: {
                            name: "close",
                            size: "11",
                            color: "#ffffff",
                            customStyle: "line-height: 12px",
                          },
                        }),
                      ],
                      1,
                    )
                  : e._e(),
                e._t("suffix"),
              ],
              2,
            ),
            t(
              "v-uni-text",
              {
                staticClass: "uv-search__action",
                class: [
                  (e.showActionBtn || e.show) && "uv-search__action--active",
                ],
                style: [e.actionStyle],
                on: {
                  click: function (n) {
                    n.stopPropagation(),
                      n.preventDefault(),
                      (arguments[0] = n = e.$handleEvent(n)),
                      e.custom.apply(void 0, arguments);
                  },
                },
              },
              [e._v(e._s(e.actionText))],
            ),
          ],
          1,
        );
      },
      o = [];
  },
  2144: function (e, n, t) {
    "use strict";
    t.r(n);
    var a = t("ca83"),
      i = t("ab99");
    for (var o in i)
      ["default"].indexOf(o) < 0 &&
        (function (e) {
          t.d(n, e, function () {
            return i[e];
          });
        })(o);
    t("87b7");
    var r = t("828b"),
      s = Object(r["a"])(
        i["default"],
        a["b"],
        a["c"],
        !1,
        null,
        "469f4a54",
        null,
        !1,
        a["a"],
        void 0,
      );
    n["default"] = s.exports;
  },
  "214f": function (e, n, t) {
    "use strict";
    t.r(n);
    var a = t("8450"),
      i = t.n(a);
    for (var o in a)
      ["default"].indexOf(o) < 0 &&
        (function (e) {
          t.d(n, e, function () {
            return a[e];
          });
        })(o);
    n["default"] = i.a;
  },
  2169: function (e, n, t) {
    "use strict";
    t("6a54"),
      Object.defineProperty(n, "__esModule", { value: !0 }),
      (n.default = void 0);
    var a = t("e74a"),
      i = {
        props: ["selected"],
        data: function () {
          return {
            nav_select: 0,
            canFine: !0,
            canAudit: !0,
            tabMap: {
              daka: "daka",
              order: "order?current=0",
              audit: "audit",
              shouhou: "order?current=5",
              wenti: "order?current=7",
              fine: "fine_list",
              total: "total",
            },
          };
        },
        computed: {
          currentTab: function () {
            return (
              ["daka", "order", "audit", "shouhou", "wenti", "fine", "total"][
                this.selected
              ] || "daka"
            );
          },
          filteredTabs: function () {
            return [
              {
                name: "daka",
                text: "首页",
                activeIcon: "/static/tabbar_home_cur.png",
                inactiveIcon: "/static/tabbar_home.png",
              },
              {
                name: "order",
                text: "订单",
                activeIcon: "/static/tabbar_cat_cur.png",
                inactiveIcon: "/static/tabbar_cat.png",
              },
              {
                name: "audit",
                text: "结单审核",
                activeIcon: "/static/audit_active.png",
                inactiveIcon: "/static/audit.png",
              },
              {
                name: "shouhou",
                text: "售后",
                activeIcon: "/static/tabbar_follow_cur.png",
                inactiveIcon: "/static/tabbar_follow.png",
              },
              {
                name: "wenti",
                text: "问题单",
                activeIcon: "/static/kefu/ic_tabbar_message_sel.png",
                inactiveIcon: "/static/kefu/ic_tabbar_message_nor.png",
              },
              {
                name: "fine",
                text: "罚款",
                activeIcon: "/static/fine_active.png",
                inactiveIcon: "/static/fine.png",
              },
              {
                name: "total",
                text: "单量总和",
                activeIcon: "/static/tabbar_user_cur.png",
                inactiveIcon: "/static/tabbar_user.png",
              },
            ];
          },
        },
        mounted: function () {
          this.getKefuInfo();
        },
        methods: {
          getKefuInfo: function () {
            var e = this;
            (0, a.send)("/wechat/Kefu/getKefuInfo", {}, !1)
              .then(function (n) {
                1 == n.status &&
                  n.data &&
                  ((e.canFine = 1 == n.data.can_fine),
                  (e.canAudit = 1 == n.data.audit_enabled));
              })
              .catch(function () {
                (e.canFine = !1), (e.canAudit = !1);
              });
          },
          setSelected: function (e) {
            var n = this.tabMap[e];
            n && uni.redirectTo({ url: "/pages_sub1/kefu/" + n });
          },
          jump: function (e) {
            uni.navigateTo({ url: e });
          },
        },
      };
    n.default = i;
  },
  "239e": function (e, n, t) {
    var a = t("573c");
    a.__esModule && (a = a.default),
      "string" === typeof a && (a = [[e.i, a, ""]]),
      a.locals && (e.exports = a.locals);
    var i = t("967d").default;
    i("54e16736", a, !0, { sourceMap: !1, shadowMode: !1 });
  },
  "25cd": function (e, n, t) {
    var a = t("c86c");
    (n = a(!1)),
      n.push([
        e.i,
        '@charset "UTF-8";\r\n/**\r\n * 这里是uni-app内置的常用样式变量\r\n *\r\n * uni-app 官方扩展插件及插件市场（https://ext.dcloud.net.cn）上很多三方插件均使用了这些样式变量\r\n * 如果你是插件开发者，建议你使用scss预处理，并在插件代码中直接使用这些变量（无需 import 这个文件），方便用户通过搭积木的方式开发整体风格一致的App\r\n *\r\n */\r\n/**\r\n * 如果你是App开发者（插件使用者），你可以通过修改这些变量来定制自己的插件主题，实现自定义主题功能\r\n *\r\n * 如果你的项目同样使用了scss预处理，你也可以直接在你的 scss 代码中使用如下变量，同时无需 import 这个文件\r\n */\r\n/* 颜色变量 */\r\n/* 行为相关颜色 */\r\n/* 文字基本颜色 */\r\n/* 背景颜色 */\r\n/* 边框颜色 */\r\n/* 尺寸变量 */\r\n/* 文字尺寸 */\r\n/* 图片尺寸 */\r\n/* Border Radius */\r\n/* 水平间距 */\r\n/* 垂直间距 */\r\n/* 透明度 */\r\n/* 文章场景相关 */.uv-tabbar[data-v-1a80c36c]{position:relative}.up_button[data-v-1a80c36c]{background-color:initial!important;font-size:12.2px;position:absolute;top:0;bottom:25%;left:65%;-webkit-transform:translate(-65%);transform:translate(-65%);z-index:30!important;width:16vw!important;text-align:center!important;padding:0!important;line-height:%?340?%!important;-webkit-tap-highlight-color:transparent!important\r\n  /* 禁用点击高亮 */}\r\n/* 覆盖微信按钮默认样式:比如边框 */uni-button[data-v-1a80c36c]::after{border:none!important;box-shadow:none!important;border-radius:0!important;\r\n  /* 如果需要也可重置圆角 */display:none!important}.icon[data-v-1a80c36c]{width:%?46?%;max-width:26px;height:%?46?%;max-height:26px}.ysShow[data-v-1a80c36c]{background:#fff;border-radius:%?30?%;padding:%?0?% %?46?% %?30?%;text-align:center}.ysShow .title[data-v-1a80c36c]{font-weight:700;padding:%?40?% 0;font-size:17px}.ysShow .con_box[data-v-1a80c36c]{margin:%?5?% auto %?15?%;text-align:left;line-height:1.6;font-size:14.4px}.ysShow .con_box .blue[data-v-1a80c36c]{color:#2979ff;margin:0 %?4?%}.ysShow .btn_box[data-v-1a80c36c]{margin:%?60?% auto %?15?%}.ysShow .btn_box uni-view[data-v-1a80c36c]{background:#ffe610;width:42%;font-size:16px;font-weight:700;height:%?80?%;line-height:%?80?%;border-radius:%?80?%}.ysShow .btn_box uni-view.cancle[data-v-1a80c36c]{background:#eee;color:#999}.gzhShow[data-v-1a80c36c]{background:#fff;border-radius:%?30?%;padding:%?0?% %?46?% %?30?%;text-align:center}.gzhShow .title[data-v-1a80c36c]{font-weight:700;padding:%?40?% 0;font-size:17px}.gzhShow .qrcode[data-v-1a80c36c]{width:%?360?%;height:%?360?%;margin:%?8?% auto %?25?%}.gzhShow .tips[data-v-1a80c36c]{font-size:13px;margin:%?30?% auto %?32?%;text-align:center;color:#777}',
        "",
      ]),
      (e.exports = n);
  },
  2650: function (e, n, t) {
    "use strict";
    t("6a54");
    var a = t("f5bd").default;
    Object.defineProperty(n, "__esModule", { value: !0 }),
      (n.default = void 0),
      t("5ef2");
    var i = a(t("4d8f0")),
      o = a(t("9463")),
      r = a(t("b0e1")),
      s = {
        name: "uv-empty",
        mixins: [i.default, o.default, r.default],
        data: function () {
          return {
            icons: {
              car: "购物车为空",
              page: "页面不存在",
              search: "没有搜索结果",
              address: "没有收货地址",
              "wifi-off": "没有WiFi",
              order: "订单为空",
              coupon: "没有优惠券",
              favor: "暂无收藏",
              permission: "无权限",
              history: "无历史记录",
              news: "无新闻列表",
              message: "消息列表为空",
              list: "列表为空",
              data: "数据为空",
              comment: "暂无评论",
            },
          };
        },
        computed: {
          emptyStyle: function () {
            var e = {};
            return (
              (e.marginTop = this.$uv.addUnit(this.marginTop)),
              this.$uv.deepMerge(e, this.$uv.addStyle(this.customStyle))
            );
          },
          textStyle: function () {
            var e = {};
            return (
              (e.color = this.textColor),
              (e.fontSize = this.$uv.addUnit(this.textSize)),
              e
            );
          },
          isImg: function () {
            var e =
              this.icon.indexOf("data:") > -1 &&
              this.icon.indexOf("base64") > -1;
            return -1 !== this.icon.indexOf("/") || e;
          },
        },
      };
    n.default = s;
  },
  "2bc3": function (e, n, t) {
    "use strict";
    t.d(n, "b", function () {
      return i;
    }),
      t.d(n, "c", function () {
        return o;
      }),
      t.d(n, "a", function () {
        return a;
      });
    var a = {
        uvPopup: t("ce8a").default,
        uvIcon: t("1a07").default,
        uvSearch: t("146d").default,
        uvLoadingIcon: t("17f5").default,
        uvEmpty: t("caef").default,
        uvLoadMore: t("bd68").default,
      },
      i = function () {
        var e = this,
          n = e.$createElement,
          t = e._self._c || n;
        return t(
          "uv-popup",
          {
            ref: "popup",
            attrs: { mode: "bottom", safeAreaInsetBottom: !1, bgColor: "#fff" },
            on: {
              change: function (n) {
                (arguments[0] = n = e.$handleEvent(n)),
                  e.popupChange.apply(void 0, arguments);
              },
            },
          },
          [
            t(
              "v-uni-view",
              { staticClass: "goods_select" },
              [
                t(
                  "v-uni-view",
                  { staticClass: "header" },
                  [
                    t("v-uni-view", { staticClass: "title" }, [
                      e._v("选择商品"),
                    ]),
                    t(
                      "v-uni-view",
                      {
                        staticClass: "close",
                        on: {
                          click: function (n) {
                            (arguments[0] = n = e.$handleEvent(n)),
                              e.close.apply(void 0, arguments);
                          },
                        },
                      },
                      [
                        t("uv-icon", {
                          attrs: { name: "close", size: "22", color: "#333" },
                        }),
                      ],
                      1,
                    ),
                  ],
                  1,
                ),
                t(
                  "v-uni-view",
                  { staticClass: "search_row" },
                  [
                    t(
                      "v-uni-view",
                      { staticClass: "search_box" },
                      [
                        t("uv-search", {
                          attrs: {
                            placeholder: "搜索商品",
                            showAction: !1,
                            shape: "square",
                            bgColor: "#f7f8fa",
                          },
                          on: {
                            search: function (n) {
                              (arguments[0] = n = e.$handleEvent(n)),
                                e.searchFun.apply(void 0, arguments);
                            },
                            clear: function (n) {
                              (arguments[0] = n = e.$handleEvent(n)),
                                e.clearSearch.apply(void 0, arguments);
                            },
                          },
                          model: {
                            value: e.keyword,
                            callback: function (n) {
                              e.keyword = n;
                            },
                            expression: "keyword",
                          },
                        }),
                      ],
                      1,
                    ),
                    e.keyword
                      ? e._e()
                      : t(
                          "v-uni-view",
                          {
                            staticClass: "cat_toggle",
                            on: {
                              click: function (n) {
                                (arguments[0] = n = e.$handleEvent(n)),
                                  (e.showCat = !e.showCat);
                              },
                            },
                          },
                          [
                            t("uv-icon", {
                              attrs: {
                                name: e.showCat ? "arrow-up" : "list",
                                size: "22",
                                color: "#333",
                              },
                            }),
                          ],
                          1,
                        ),
                  ],
                  1,
                ),
                !e.keyword && e.showCat
                  ? t(
                      "v-uni-view",
                      { staticClass: "cat_box" },
                      [
                        e.cat1_list.length > 0
                          ? t(
                              "v-uni-scroll-view",
                              {
                                staticClass: "cat_row",
                                attrs: { "scroll-x": !0, "show-scrollbar": !1 },
                              },
                              [
                                t(
                                  "v-uni-view",
                                  {
                                    staticClass: "cat_item",
                                    class: { active: 0 === e.cat1_id },
                                    on: {
                                      click: function (n) {
                                        (arguments[0] = n = e.$handleEvent(n)),
                                          e.changeCat1({ id: 0, name: "全部" });
                                      },
                                    },
                                  },
                                  [e._v("全部")],
                                ),
                                e._l(e.cat1_list, function (n, a) {
                                  return t(
                                    "v-uni-view",
                                    {
                                      key: a,
                                      staticClass: "cat_item",
                                      class: { active: e.cat1_id === n.id },
                                      on: {
                                        click: function (t) {
                                          (arguments[0] = t =
                                            e.$handleEvent(t)),
                                            e.changeCat1(n);
                                        },
                                      },
                                    },
                                    [e._v(" " + e._s(n.name) + " ")],
                                  );
                                }),
                              ],
                              2,
                            )
                          : e._e(),
                        e.cat2_list.length > 0
                          ? t(
                              "v-uni-scroll-view",
                              {
                                staticClass: "cat_row",
                                attrs: { "scroll-x": !0, "show-scrollbar": !1 },
                              },
                              e._l(e.cat2_list, function (n, a) {
                                return t(
                                  "v-uni-view",
                                  {
                                    key: a,
                                    staticClass: "cat_item sub",
                                    class: { active: e.cat2_id === n.id },
                                    on: {
                                      click: function (t) {
                                        (arguments[0] = t = e.$handleEvent(t)),
                                          e.changeCat2(n);
                                      },
                                    },
                                  },
                                  [e._v(" " + e._s(n.name) + " ")],
                                );
                              }),
                              1,
                            )
                          : e._e(),
                        e.cat3_list.length > 0
                          ? t(
                              "v-uni-scroll-view",
                              {
                                staticClass: "cat_row",
                                attrs: { "scroll-x": !0, "show-scrollbar": !1 },
                              },
                              e._l(e.cat3_list, function (n, a) {
                                return t(
                                  "v-uni-view",
                                  {
                                    key: a,
                                    staticClass: "cat_item sub",
                                    class: { active: e.cat3_id === n.id },
                                    on: {
                                      click: function (t) {
                                        (arguments[0] = t = e.$handleEvent(t)),
                                          e.changeCat3(n);
                                      },
                                    },
                                  },
                                  [e._v(" " + e._s(n.name) + " ")],
                                );
                              }),
                              1,
                            )
                          : e._e(),
                      ],
                      1,
                    )
                  : e._e(),
                t(
                  "v-uni-scroll-view",
                  {
                    staticClass: "goods_list",
                    attrs: { "scroll-y": !0, "lower-threshold": "60" },
                    on: {
                      scrolltolower: function (n) {
                        (arguments[0] = n = e.$handleEvent(n)),
                          e.loadMore.apply(void 0, arguments);
                      },
                    },
                  },
                  [
                    e.loading && 0 == e.list.length
                      ? t(
                          "v-uni-view",
                          { staticClass: "list_loading" },
                          [
                            t("uv-loading-icon", {
                              attrs: {
                                mode: "circle",
                                color: "#999",
                                size: "28",
                              },
                            }),
                            t("v-uni-text", { staticClass: "loading_text" }, [
                              e._v("加载中..."),
                            ]),
                          ],
                          1,
                        )
                      : e._e(),
                    e._l(e.list, function (n, a) {
                      return t(
                        "v-uni-view",
                        { key: a, staticClass: "goods_col" },
                        [
                          t(
                            "v-uni-view",
                            {
                              staticClass: "img_box",
                              on: {
                                click: function (t) {
                                  (arguments[0] = t = e.$handleEvent(t)),
                                    e.selectGoods(n);
                                },
                              },
                            },
                            [
                              t("img", {
                                attrs: {
                                  src: n.thumb
                                    ? n.thumb
                                    : n.cat3
                                      ? n.cat3.thumb
                                      : "",
                                },
                              }),
                            ],
                          ),
                          t(
                            "v-uni-view",
                            {
                              staticClass: "goods_msg",
                              on: {
                                click: function (t) {
                                  (arguments[0] = t = e.$handleEvent(t)),
                                    e.selectGoods(n);
                                },
                              },
                            },
                            [
                              t(
                                "v-uni-view",
                                { staticClass: "goods_name uv-line-1" },
                                [e._v(e._s(n.title))],
                              ),
                              t(
                                "v-uni-view",
                                { staticClass: "goods_intro uv-line-2" },
                                [e._v(e._s(n.intro))],
                              ),
                              t(
                                "v-uni-view",
                                { staticClass: "goods_price" },
                                [
                                  t("v-uni-text", { staticClass: "icon" }, [
                                    e._v("￥"),
                                  ]),
                                  t("v-uni-text", { staticClass: "num" }, [
                                    e._v(e._s(n.price)),
                                  ]),
                                ],
                                1,
                              ),
                            ],
                            1,
                          ),
                          t(
                            "v-uni-view",
                            {
                              staticClass: "order_btn",
                              on: {
                                click: function (t) {
                                  t.stopPropagation(),
                                    (arguments[0] = t = e.$handleEvent(t)),
                                    e.selectGoods(n);
                                },
                              },
                            },
                            [e._v("下单")],
                          ),
                        ],
                        1,
                      );
                    }),
                    0 != e.list.length || e.loading
                      ? e._e()
                      : t("uv-empty", {
                          attrs: {
                            mode: "data",
                            text: "暂无数据",
                            icon: "/static/imgs/no-data.png",
                          },
                        }),
                    e.list.length > 0
                      ? t("uv-load-more", { attrs: { status: e.status } })
                      : e._e(),
                  ],
                  2,
                ),
                t("v-uni-view", { staticClass: "safe_bottom" }),
              ],
              1,
            ),
            e.showSpecPopup
              ? t(
                  "uv-popup",
                  {
                    ref: "specsPop",
                    attrs: {
                      mode: "bottom",
                      zIndex: "10075",
                      safeAreaInsetBottom: !0,
                    },
                    on: {
                      change: function (n) {
                        (arguments[0] = n = e.$handleEvent(n)),
                          e.specPopupChange.apply(void 0, arguments);
                      },
                    },
                  },
                  [
                    t(
                      "v-uni-view",
                      { staticClass: "specsShow" },
                      [
                        t(
                          "v-uni-view",
                          { staticClass: "goods_msg flex_box" },
                          [
                            t("img", {
                              staticClass: "img",
                              attrs: {
                                src: e.currentGoods.thumb
                                  ? e.currentGoods.thumb
                                  : e.currentGoods.pics &&
                                      e.currentGoods.pics[0]
                                    ? e.currentGoods.pics[0]
                                    : "",
                              },
                            }),
                            t(
                              "v-uni-view",
                              { staticClass: "txt" },
                              [
                                t(
                                  "v-uni-view",
                                  { staticClass: "name uv-line-1" },
                                  [e._v(e._s(e.currentGoods.title))],
                                ),
                                t(
                                  "v-uni-view",
                                  { staticClass: "price_box flex_box" },
                                  [
                                    t(
                                      "v-uni-view",
                                      { staticClass: "new_price" },
                                      [
                                        t(
                                          "v-uni-text",
                                          { staticClass: "unit" },
                                          [e._v("￥")],
                                        ),
                                        t("v-uni-text", [
                                          e._v(e._s(e.currentGoods.price)),
                                        ]),
                                      ],
                                      1,
                                    ),
                                  ],
                                  1,
                                ),
                              ],
                              1,
                            ),
                          ],
                          1,
                        ),
                        t(
                          "v-uni-view",
                          { staticClass: "reason_box" },
                          [
                            t(
                              "v-uni-view",
                              { staticClass: "tit flex_box" },
                              [
                                t("v-uni-text", [e._v("商品规格")]),
                                t(
                                  "v-uni-view",
                                  {
                                    staticClass: "switch_btn",
                                    on: {
                                      click: function (n) {
                                        (arguments[0] = n = e.$handleEvent(n)),
                                          (e.specViewMode =
                                            "img" == e.specViewMode
                                              ? "text"
                                              : "img");
                                      },
                                    },
                                  },
                                  [
                                    e._v(
                                      e._s(
                                        "img" == e.specViewMode
                                          ? "切换到文字"
                                          : "切换到图片",
                                      ),
                                    ),
                                  ],
                                ),
                              ],
                              1,
                            ),
                            e.specLoading
                              ? t(
                                  "v-uni-view",
                                  { staticClass: "specs_loading" },
                                  [
                                    t("uv-loading-icon", {
                                      attrs: {
                                        mode: "circle",
                                        color: "#999",
                                        size: "28",
                                      },
                                    }),
                                    t(
                                      "v-uni-text",
                                      { staticClass: "loading_text" },
                                      [e._v("加载规格中...")],
                                    ),
                                  ],
                                  1,
                                )
                              : e._e(),
                            !e.specLoading && e.childList.length > 0
                              ? t(
                                  "v-uni-view",
                                  {
                                    class: [
                                      "specs_grid",
                                      "specs_" + e.specViewMode,
                                    ],
                                  },
                                  e._l(e.childList, function (n, a) {
                                    return t(
                                      "v-uni-view",
                                      {
                                        key: a,
                                        class: {
                                          col: !0,
                                          cur: e.selectId == n.id,
                                        },
                                        on: {
                                          click: function (t) {
                                            (arguments[0] = t =
                                              e.$handleEvent(t)),
                                              e.selectSpec(n);
                                          },
                                        },
                                      },
                                      [
                                        "img" == e.specViewMode
                                          ? t("v-uni-image", {
                                              staticClass: "col_img",
                                              attrs: {
                                                src: n.thumb
                                                  ? n.thumb
                                                  : n.pics && n.pics[0]
                                                    ? n.pics[0]
                                                    : "",
                                                mode: "aspectFill",
                                              },
                                            })
                                          : e._e(),
                                        t(
                                          "v-uni-view",
                                          {
                                            class: [
                                              "col_title",
                                              "text" == e.specViewMode
                                                ? "col_title_text"
                                                : "",
                                            ],
                                          },
                                          [e._v(e._s(n.title))],
                                        ),
                                      ],
                                      1,
                                    );
                                  }),
                                  1,
                                )
                              : e._e(),
                          ],
                          1,
                        ),
                        t(
                          "v-uni-view",
                          { staticClass: "spec_daohang_box" },
                          [
                            t(
                              "v-uni-view",
                              {
                                staticClass: "xiadan",
                                class: { cancel: 0 == e.selectId },
                                on: {
                                  click: function (n) {
                                    (arguments[0] = n = e.$handleEvent(n)),
                                      e.confirmSpec.apply(void 0, arguments);
                                  },
                                },
                              },
                              [
                                e._v(
                                  e._s(
                                    0 == e.selectId ? "请选择规格" : "确认下单",
                                  ),
                                ),
                              ],
                            ),
                          ],
                          1,
                        ),
                      ],
                      1,
                    ),
                  ],
                  1,
                )
              : e._e(),
          ],
          1,
        );
      },
      o = [];
  },
  "2cf6": function (e, n, t) {
    var a = t("de33");
    a.__esModule && (a = a.default),
      "string" === typeof a && (a = [[e.i, a, ""]]),
      a.locals && (e.exports = a.locals);
    var i = t("967d").default;
    i("bb92d4d4", a, !0, { sourceMap: !1, shadowMode: !1 });
  },
  "2ed2": function (e, n, t) {
    var a = t("c86c");
    (n = a(!1)),
      n.push([
        e.i,
        '@charset "UTF-8";\r\n/**\r\n * 这里是uni-app内置的常用样式变量\r\n *\r\n * uni-app 官方扩展插件及插件市场（https://ext.dcloud.net.cn）上很多三方插件均使用了这些样式变量\r\n * 如果你是插件开发者，建议你使用scss预处理，并在插件代码中直接使用这些变量（无需 import 这个文件），方便用户通过搭积木的方式开发整体风格一致的App\r\n *\r\n */\r\n/**\r\n * 如果你是App开发者（插件使用者），你可以通过修改这些变量来定制自己的插件主题，实现自定义主题功能\r\n *\r\n * 如果你的项目同样使用了scss预处理，你也可以直接在你的 scss 代码中使用如下变量，同时无需 import 这个文件\r\n */\r\n/* 颜色变量 */\r\n/* 行为相关颜色 */\r\n/* 文字基本颜色 */\r\n/* 背景颜色 */\r\n/* 边框颜色 */\r\n/* 尺寸变量 */\r\n/* 文字尺寸 */\r\n/* 图片尺寸 */\r\n/* Border Radius */\r\n/* 水平间距 */\r\n/* 垂直间距 */\r\n/* 透明度 */\r\n/* 文章场景相关 */.uv-overlay[data-v-12ad5b32]{position:fixed;top:0;left:0;width:100%;height:100%;background-color:rgba(0,0,0,.7)}',
        "",
      ]),
      (e.exports = n);
  },
  3774: function (e, n, t) {
    "use strict";
    t.r(n);
    var a = t("da5e"),
      i = t.n(a);
    for (var o in a)
      ["default"].indexOf(o) < 0 &&
        (function (e) {
          t.d(n, e, function () {
            return a[e];
          });
        })(o);
    n["default"] = i.a;
  },
  "37cc": function (e, n, t) {
    "use strict";
    t.r(n);
    var a = t("5a99"),
      i = t.n(a);
    for (var o in a)
      ["default"].indexOf(o) < 0 &&
        (function (e) {
          t.d(n, e, function () {
            return a[e];
          });
        })(o);
    n["default"] = i.a;
  },
  "3ae7": function (e, n, t) {
    var a = t("4911");
    a.__esModule && (a = a.default),
      "string" === typeof a && (a = [[e.i, a, ""]]),
      a.locals && (e.exports = a.locals);
    var i = t("967d").default;
    i("1a6e53e3", a, !0, { sourceMap: !1, shadowMode: !1 });
  },
  "3b2d": function (e, n, t) {
    var a = t("bde0");
    a.__esModule && (a = a.default),
      "string" === typeof a && (a = [[e.i, a, ""]]),
      a.locals && (e.exports = a.locals);
    var i = t("967d").default;
    i("2dc39a5b", a, !0, { sourceMap: !1, shadowMode: !1 });
  },
  "3b72": function (e, n, t) {
    "use strict";
    t("6a54");
    var a = t("f5bd").default;
    Object.defineProperty(n, "__esModule", { value: !0 }),
      (n.default = void 0),
      t("aa9c"),
      t("4626"),
      t("5ac7"),
      t("5ef2");
    var i = a(t("4d8f0")),
      o = a(t("9463")),
      r = a(t("6299")),
      s = a(t("aa1a")),
      u = {
        name: "uv-icon",
        emits: ["click"],
        mixins: [i.default, o.default, s.default],
        data: function () {
          return {
            colorType: ["primary", "success", "info", "error", "warning"],
          };
        },
        computed: {
          uClasses: function () {
            var e = [];
            return (
              e.push(this.customPrefix),
              e.push(this.customPrefix + "-" + this.name),
              this.color &&
                this.colorType.includes(this.color) &&
                e.push("uv-icon__icon--" + this.color),
              e
            );
          },
          iconStyle: function () {
            var e = {};
            return (
              (e = {
                fontSize: this.$uv.addUnit(this.size),
                lineHeight: this.$uv.addUnit(this.size),
                fontWeight: this.bold ? "bold" : "normal",
                top: this.$uv.addUnit(this.top),
              }),
              this.color &&
                !this.colorType.includes(this.color) &&
                (e.color = this.color),
              e
            );
          },
          isImg: function () {
            var e =
              this.name.indexOf("data:") > -1 &&
              this.name.indexOf("base64") > -1;
            return -1 !== this.name.indexOf("/") || e;
          },
          imgStyle: function () {
            var e = {};
            return (
              (e.width = this.width
                ? this.$uv.addUnit(this.width)
                : this.$uv.addUnit(this.size)),
              (e.height = this.height
                ? this.$uv.addUnit(this.height)
                : this.$uv.addUnit(this.size)),
              e
            );
          },
          icon: function () {
            var e = r.default["uvicon-" + this.name];
            return e
              ? unescape("%u".concat(e))
              : ["uvicon"].indexOf(this.customPrefix) > -1
                ? this.name
                : "";
          },
        },
        methods: {
          clickHandler: function (e) {
            this.$emit("click", this.index), this.stop && this.preventEvent(e);
          },
        },
      };
    n.default = u;
  },
  "3c53": function (e, n, t) {
    "use strict";
    t("6a54");
    var a = t("f5bd").default;
    Object.defineProperty(n, "__esModule", { value: !0 }),
      (n.default = void 0),
      t("64aa");
    var i,
      o,
      r = a(t("9b1b")),
      s = {
        props: (0, r.default)(
          {
            show: { type: Boolean, default: !0 },
            color: { type: String, default: "#909193" },
            textColor: { type: String, default: "#909193" },
            vertical: { type: Boolean, default: !1 },
            mode: { type: String, default: "spinner" },
            size: { type: [String, Number], default: 24 },
            textSize: { type: [String, Number], default: 15 },
            textStyle: {
              type: Object,
              default: function () {
                return {};
              },
            },
            text: { type: [String, Number], default: "" },
            timingFunction: { type: String, default: "linear" },
            duration: { type: [String, Number], default: 1200 },
            inactiveColor: { type: String, default: "" },
          },
          null === (i = uni.$uv) ||
            void 0 === i ||
            null === (o = i.props) ||
            void 0 === o
            ? void 0
            : o.loadingIcon,
        ),
      };
    n.default = s;
  },
  "3e38": function (e, n, t) {
    "use strict";
    t("6a54");
    var a = t("f5bd").default;
    Object.defineProperty(n, "__esModule", { value: !0 }), (n.default = void 0);
    var i = a(t("9b8e")),
      o = a(t("8f59")),
      r = a(t("1030"));
    i.default.use(o.default);
    var s = new o.default.Store({ modules: { websocket: r.default } });
    n.default = s;
  },
  "3e9c": function (e, n, t) {
    var a = t("8580");
    a.__esModule && (a = a.default),
      "string" === typeof a && (a = [[e.i, a, ""]]),
      a.locals && (e.exports = a.locals);
    var i = t("967d").default;
    i("3101f063", a, !0, { sourceMap: !1, shadowMode: !1 });
  },
  "40c2": function (e, n, t) {
    "use strict";
    var a = t("2cf6"),
      i = t.n(a);
    i.a;
  },
  "42e1": function (e, n, t) {
    "use strict";
    t.r(n);
    var a = t("0250"),
      i = t("12fd");
    for (var o in i)
      ["default"].indexOf(o) < 0 &&
        (function (e) {
          t.d(n, e, function () {
            return i[e];
          });
        })(o);
    t("15e6");
    var r = t("828b"),
      s = Object(r["a"])(
        i["default"],
        a["b"],
        a["c"],
        !1,
        null,
        "2453ff08",
        null,
        !1,
        a["a"],
        void 0,
      );
    n["default"] = s.exports;
  },
  "439e": function (e, n, t) {
    var a = t("c86c");
    (n = a(!1)),
      n.push([
        e.i,
        '@charset "UTF-8";\r\n/**\r\n * 这里是uni-app内置的常用样式变量\r\n *\r\n * uni-app 官方扩展插件及插件市场（https://ext.dcloud.net.cn）上很多三方插件均使用了这些样式变量\r\n * 如果你是插件开发者，建议你使用scss预处理，并在插件代码中直接使用这些变量（无需 import 这个文件），方便用户通过搭积木的方式开发整体风格一致的App\r\n *\r\n */\r\n/**\r\n * 如果你是App开发者（插件使用者），你可以通过修改这些变量来定制自己的插件主题，实现自定义主题功能\r\n *\r\n * 如果你的项目同样使用了scss预处理，你也可以直接在你的 scss 代码中使用如下变量，同时无需 import 这个文件\r\n */\r\n/* 颜色变量 */\r\n/* 行为相关颜色 */\r\n/* 文字基本颜色 */\r\n/* 背景颜色 */\r\n/* 边框颜色 */\r\n/* 尺寸变量 */\r\n/* 文字尺寸 */\r\n/* 图片尺寸 */\r\n/* Border Radius */\r\n/* 水平间距 */\r\n/* 垂直间距 */\r\n/* 透明度 */\r\n/* 文章场景相关 */uni-view[data-v-b6f66da4], uni-scroll-view[data-v-b6f66da4], uni-swiper-item[data-v-b6f66da4]{display:flex;flex-direction:column;flex-shrink:0;flex-grow:0;flex-basis:auto;align-items:stretch;align-content:flex-start}.uv-empty[data-v-b6f66da4]{display:flex;flex-direction:row;flex-direction:column;justify-content:center;align-items:center}.uv-empty__text[data-v-b6f66da4]{display:flex;flex-direction:row;justify-content:center;align-items:center;margin-top:%?20?%}.uv-slot-wrap[data-v-b6f66da4]{display:flex;flex-direction:row;justify-content:center;align-items:center;margin-top:%?20?%}',
        "",
      ]),
      (e.exports = n);
  },
  "445c": function (e, n, t) {
    "use strict";
    t("6a54");
    var a = t("f5bd").default;
    Object.defineProperty(n, "__esModule", { value: !0 }), (n.default = void 0);
    var i = a(t("4d8f0")),
      o = a(t("9463")),
      r = a(t("9192")),
      s = {
        name: "uv-overlay",
        emits: ["click"],
        mixins: [i.default, o.default, r.default],
        watch: {
          show: function (e) {
            document.querySelector("body").style.overflow = e ? "hidden" : "";
          },
        },
        computed: {
          overlayStyle: function () {
            var e = {
              position: "fixed",
              top: 0,
              left: 0,
              right: 0,
              zIndex: this.zIndex,
              bottom: 0,
              "background-color": "rgba(0, 0, 0, ".concat(this.opacity, ")"),
            };
            return this.$uv.deepMerge(e, this.$uv.addStyle(this.customStyle));
          },
        },
        methods: {
          clickHandler: function () {
            this.$emit("click");
          },
          clear: function () {},
        },
      };
    n.default = s;
  },
  "46e2": function (e, n, t) {
    "use strict";
    t.d(n, "b", function () {
      return i;
    }),
      t.d(n, "c", function () {
        return o;
      }),
      t.d(n, "a", function () {
        return a;
      });
    var a = {
        uvOverlay: t("5ef7").default,
        uvTransition: t("7fd8").default,
        uvStatusBar: t("42e1").default,
        uvSafeBottom: t("e787").default,
        uvIcon: t("1a07").default,
      },
      i = function () {
        var e = this,
          n = e.$createElement,
          t = e._self._c || n;
        return e.showPopup
          ? t(
              "v-uni-view",
              {
                staticClass: "uv-popup",
                class: [e.popupClass, e.isDesktop ? "fixforpc-z-index" : ""],
                style: [{ zIndex: e.zIndex }],
              },
              [
                t(
                  "v-uni-view",
                  {
                    on: {
                      touchstart: function (n) {
                        (arguments[0] = n = e.$handleEvent(n)),
                          e.touchstart.apply(void 0, arguments);
                      },
                    },
                  },
                  [
                    e.maskShow && e.overlay
                      ? t("uv-overlay", {
                          key: "1",
                          attrs: {
                            show: e.showTrans,
                            duration: e.duration,
                            "custom-style": e.overlayStyle,
                            opacity: e.overlayOpacity,
                            zIndex: e.zIndex,
                          },
                          on: {
                            click: function (n) {
                              (arguments[0] = n = e.$handleEvent(n)),
                                e.onTap.apply(void 0, arguments);
                            },
                          },
                        })
                      : e._e(),
                    t(
                      "uv-transition",
                      {
                        key: "2",
                        attrs: {
                          mode: e.ani,
                          name: "content",
                          "custom-style": e.transitionStyle,
                          duration: e.duration,
                          show: e.showTrans,
                        },
                        on: {
                          click: function (n) {
                            (arguments[0] = n = e.$handleEvent(n)),
                              e.onTap.apply(void 0, arguments);
                          },
                        },
                      },
                      [
                        t(
                          "v-uni-view",
                          {
                            staticClass: "uv-popup__content",
                            class: [e.popupClass],
                            style: [e.contentStyle],
                            on: {
                              click: function (n) {
                                (arguments[0] = n = e.$handleEvent(n)),
                                  e.clear.apply(void 0, arguments);
                              },
                            },
                          },
                          [
                            e.safeAreaInsetTop ? t("uv-status-bar") : e._e(),
                            e._t("default"),
                            e.safeAreaInsetBottom
                              ? t("uv-safe-bottom")
                              : e._e(),
                            e.closeable
                              ? t(
                                  "v-uni-view",
                                  {
                                    staticClass: "uv-popup__content__close",
                                    class: [
                                      "uv-popup__content__close--" +
                                        e.closeIconPos,
                                    ],
                                    attrs: {
                                      "hover-class":
                                        "uv-popup__content__close--hover",
                                      "hover-stay-time": "150",
                                    },
                                    on: {
                                      click: function (n) {
                                        n.stopPropagation(),
                                          (arguments[0] = n =
                                            e.$handleEvent(n)),
                                          e.close.apply(void 0, arguments);
                                      },
                                    },
                                  },
                                  [
                                    t("uv-icon", {
                                      attrs: {
                                        name: "close",
                                        color: "#909399",
                                        size: "18",
                                        bold: !0,
                                      },
                                    }),
                                  ],
                                  1,
                                )
                              : e._e(),
                          ],
                          2,
                        ),
                      ],
                      1,
                    ),
                  ],
                  1,
                ),
                e.maskShow
                  ? t("keypress", {
                      on: {
                        esc: function (n) {
                          (arguments[0] = n = e.$handleEvent(n)),
                            e.onTap.apply(void 0, arguments);
                        },
                      },
                    })
                  : e._e(),
              ],
              1,
            )
          : e._e();
      },
      o = [];
  },
  4755: function (e, n, t) {
    "use strict";
    t.r(n);
    var a = t("3b72"),
      i = t.n(a);
    for (var o in a)
      ["default"].indexOf(o) < 0 &&
        (function (e) {
          t.d(n, e, function () {
            return a[e];
          });
        })(o);
    n["default"] = i.a;
  },
  4766: function (e, n, t) {
    var a = t("92c9");
    a.__esModule && (a = a.default),
      "string" === typeof a && (a = [[e.i, a, ""]]),
      a.locals && (e.exports = a.locals);
    var i = t("967d").default;
    i("3eb64d90", a, !0, { sourceMap: !1, shadowMode: !1 });
  },
  "47e2": function (e, n, t) {
    var a = t("8326");
    a.__esModule && (a = a.default),
      "string" === typeof a && (a = [[e.i, a, ""]]),
      a.locals && (e.exports = a.locals);
    var i = t("967d").default;
    i("0404e33a", a, !0, { sourceMap: !1, shadowMode: !1 });
  },
  4911: function (e, n, t) {
    var a = t("c86c");
    (n = a(!1)),
      n.push([
        e.i,
        '@charset "UTF-8";\r\n/**\r\n * 这里是uni-app内置的常用样式变量\r\n *\r\n * uni-app 官方扩展插件及插件市场（https://ext.dcloud.net.cn）上很多三方插件均使用了这些样式变量\r\n * 如果你是插件开发者，建议你使用scss预处理，并在插件代码中直接使用这些变量（无需 import 这个文件），方便用户通过搭积木的方式开发整体风格一致的App\r\n *\r\n */\r\n/**\r\n * 如果你是App开发者（插件使用者），你可以通过修改这些变量来定制自己的插件主题，实现自定义主题功能\r\n *\r\n * 如果你的项目同样使用了scss预处理，你也可以直接在你的 scss 代码中使用如下变量，同时无需 import 这个文件\r\n */\r\n/* 颜色变量 */\r\n/* 行为相关颜色 */\r\n/* 文字基本颜色 */\r\n/* 背景颜色 */\r\n/* 边框颜色 */\r\n/* 尺寸变量 */\r\n/* 文字尺寸 */\r\n/* 图片尺寸 */\r\n/* Border Radius */\r\n/* 水平间距 */\r\n/* 垂直间距 */\r\n/* 透明度 */\r\n/* 文章场景相关 */.icon[data-v-e1d4828a]{width:%?46?%;height:%?46?%}',
        "",
      ]),
      (e.exports = n);
  },
  4942: function (e, n, t) {
    "use strict";
    var a = t("68bd"),
      i = t.n(a);
    i.a;
  },
  "49a9": function (e, n, t) {
    "use strict";
    t("6a54");
    var a = t("f5bd").default;
    Object.defineProperty(n, "__esModule", { value: !0 }),
      (n.default = void 0),
      t("64aa");
    var i = a(t("4d8f0")),
      o = a(t("9463")),
      r = a(t("b92c")),
      s = {
        name: "uv-badge",
        mixins: [i.default, o.default, r.default],
        computed: {
          boxStyle: function () {
            return {};
          },
          badgeStyle: function () {
            var e = {};
            if (
              (this.color && (e.color = this.color),
              this.bgColor &&
                !this.inverted &&
                (e.backgroundColor = this.bgColor),
              this.absolute && ((e.position = "absolute"), this.offset.length))
            ) {
              var n = this.offset[0],
                t = this.offset[1] || n;
              (e.top = this.$uv.addUnit(n)), (e.right = this.$uv.addUnit(t));
            }
            return e;
          },
          showValue: function () {
            switch (this.numberType) {
              case "overflow":
                return Number(this.value) > Number(this.max)
                  ? this.max + "+"
                  : this.value;
              case "ellipsis":
                return Number(this.value) > Number(this.max)
                  ? "..."
                  : this.value;
              case "limit":
                return Number(this.value) > 999
                  ? Number(this.value) >= 9999
                    ? Math.floor((this.value / 1e4) * 100) / 100 + "w"
                    : Math.floor((this.value / 1e3) * 100) / 100 + "k"
                  : this.value;
              default:
                return Number(this.value);
            }
          },
          propsType: function () {
            return this.type || "error";
          },
        },
      };
    n.default = s;
  },
  "4cbe": function (e, n, t) {
    var a = t("f0f3");
    a.__esModule && (a = a.default),
      "string" === typeof a && (a = [[e.i, a, ""]]),
      a.locals && (e.exports = a.locals);
    var i = t("967d").default;
    i("2252d371", a, !0, { sourceMap: !1, shadowMode: !1 });
  },
  "4d8f0": function (e, n, t) {
    "use strict";
    t("6a54"),
      Object.defineProperty(n, "__esModule", { value: !0 }),
      (n.default = void 0);
    n.default = {};
  },
  "4def": function (e, n, t) {
    "use strict";
    t("6a54");
    var a = t("f5bd").default;
    Object.defineProperty(n, "__esModule", { value: !0 }),
      (n.default = void 0),
      t("64aa");
    var i,
      o,
      r = a(t("9b1b")),
      s = {
        props: (0, r.default)(
          {
            color: { type: String, default: "#d6d7d9" },
            length: { type: [String, Number], default: "100%" },
            direction: { type: String, default: "row" },
            hairline: { type: Boolean, default: !0 },
            margin: { type: [String, Number], default: 0 },
            dashed: { type: Boolean, default: !1 },
          },
          null === (i = uni.$uv) ||
            void 0 === i ||
            null === (o = i.props) ||
            void 0 === o
            ? void 0
            : o.line,
        ),
      };
    n.default = s;
  },
  "4f84": function (e, n, t) {
    "use strict";
    t("6a54"),
      Object.defineProperty(n, "__esModule", { value: !0 }),
      (n.default = void 0);
    t("e74a");
    var a = {
      data: function () {
        return {};
      },
      mounted: function () {},
      methods: {
        jump: function (e) {
          uni.navigateTo({ url: e });
        },
      },
    };
    n.default = a;
  },
  "509e": function (e, n, t) {
    "use strict";
    t("6a54"),
      Object.defineProperty(n, "__esModule", { value: !0 }),
      (n.default = function (e, n, t) {
        var a = t.config.validateStatus,
          i = t.statusCode;
        !i || (a && !a(i)) ? n(t) : e(t);
      });
  },
  5118: function (e, n, t) {
    "use strict";
    t("6a54");
    var a = t("f5bd").default;
    Object.defineProperty(n, "__esModule", { value: !0 }), (n.default = void 0);
    var i = a(t("4d8f0")),
      o = a(t("9463")),
      r = {
        name: "uv-safe-bottom",
        mixins: [i.default, o.default],
        data: function () {
          return { safeAreaBottomHeight: 0, isNvue: !1 };
        },
        computed: {
          style: function () {
            return this.$uv.deepMerge({}, this.$uv.addStyle(this.customStyle));
          },
        },
        mounted: function () {},
      };
    n.default = r;
  },
  "51e8": function (e, n, t) {
    var a = t("c86c");
    (n = a(!1)),
      n.push([
        e.i,
        '@charset "UTF-8";\r\n/**\r\n * 这里是uni-app内置的常用样式变量\r\n *\r\n * uni-app 官方扩展插件及插件市场（https://ext.dcloud.net.cn）上很多三方插件均使用了这些样式变量\r\n * 如果你是插件开发者，建议你使用scss预处理，并在插件代码中直接使用这些变量（无需 import 这个文件），方便用户通过搭积木的方式开发整体风格一致的App\r\n *\r\n */\r\n/**\r\n * 如果你是App开发者（插件使用者），你可以通过修改这些变量来定制自己的插件主题，实现自定义主题功能\r\n *\r\n * 如果你的项目同样使用了scss预处理，你也可以直接在你的 scss 代码中使用如下变量，同时无需 import 这个文件\r\n */\r\n/* 颜色变量 */\r\n/* 行为相关颜色 */\r\n/* 文字基本颜色 */\r\n/* 背景颜色 */\r\n/* 边框颜色 */\r\n/* 尺寸变量 */\r\n/* 文字尺寸 */\r\n/* 图片尺寸 */\r\n/* Border Radius */\r\n/* 水平间距 */\r\n/* 垂直间距 */\r\n/* 透明度 */\r\n/* 文章场景相关 */.uv-line-1{display:-webkit-box!important;overflow:hidden;text-overflow:ellipsis;word-break:break-all;-webkit-line-clamp:1;-webkit-box-orient:vertical!important}.uv-line-2{display:-webkit-box!important;overflow:hidden;text-overflow:ellipsis;word-break:break-all;-webkit-line-clamp:2;-webkit-box-orient:vertical!important}.uv-line-3{display:-webkit-box!important;overflow:hidden;text-overflow:ellipsis;word-break:break-all;-webkit-line-clamp:3;-webkit-box-orient:vertical!important}.uv-line-4{display:-webkit-box!important;overflow:hidden;text-overflow:ellipsis;word-break:break-all;-webkit-line-clamp:4;-webkit-box-orient:vertical!important}.uv-line-5{display:-webkit-box!important;overflow:hidden;text-overflow:ellipsis;word-break:break-all;-webkit-line-clamp:5;-webkit-box-orient:vertical!important}.uv-border{border-width:.5px!important;border-color:#dadbde!important;border-style:solid}.uv-border-top{border-top-width:.5px!important;border-color:#dadbde!important;border-top-style:solid}.uv-border-left{border-left-width:.5px!important;border-color:#dadbde!important;border-left-style:solid}.uv-border-right{border-right-width:.5px!important;border-color:#dadbde!important;border-right-style:solid}.uv-border-bottom{border-bottom-width:.5px!important;border-color:#dadbde!important;border-bottom-style:solid}.uv-border-top-bottom{border-top-width:.5px!important;border-bottom-width:.5px!important;border-color:#dadbde!important;border-top-style:solid;border-bottom-style:solid}.uv-reset-button{padding:0;background-color:initial;font-size:inherit;line-height:inherit;color:inherit}.uv-reset-button::after{border:none}.uv-hover-class{opacity:.7}.uv-safe-area-inset-top{padding-top:0;padding-top:constant(safe-area-inset-top);padding-top:env(safe-area-inset-top)}.uv-safe-area-inset-right{padding-right:0;padding-right:constant(safe-area-inset-right);padding-right:env(safe-area-inset-right)}.uv-safe-area-inset-bottom{padding-bottom:0;padding-bottom:constant(safe-area-inset-bottom);padding-bottom:env(safe-area-inset-bottom)}.uv-safe-area-inset-left{padding-left:0;padding-left:constant(safe-area-inset-left);padding-left:env(safe-area-inset-left)}uni-toast{z-index:10090}uni-toast .uni-toast{z-index:10090}::-webkit-scrollbar{display:none;width:0!important;height:0!important;-webkit-appearance:none;background:transparent}uni-page-body{background:#fff}body.?%PAGE?%{background:#fff}.content{max-width:480px;width:100%;margin:0 auto}uni-view{margin:0;padding:0;box-sizing:border-box;font-size:14px;overflow:hidden}uni-image{display:block;width:100%;height:100%;margin:0}img{display:block;width:100%;height:100%;margin:0;object-fit:cover}.to-line-1{text-overflow:ellipsis;white-space:nowrap;overflow:hidden}.to-line-2{text-overflow:ellipsis;display:-webkit-box;-webkit-line-clamp:2;-webkit-box-orient:vertical;overflow-wrap:break-word;word-break:break-all;white-space:normal;overflow:hidden}.flex_box{display:flex;align-items:center;justify-content:space-between;overflow:hidden}uni-button{border:none}.no_more{color:#999;font-size:14px;text-align:center;margin:%?30?% auto}.no-padding{padding:0!important} .uv-transition{max-width:480px;width:100%;margin:0 auto} uni-modal{z-index:10999}.uni-tabbar{display:none!important}.uni-page-head,\r\n.uv-tabbar__content{max-width:480px!important;width:100%!important;margin:0 auto!important}.uv-tabbar__content{z-index:1000!important} .uni-system-preview-image{z-index:10076!important} .uni-system-preview-image img.image-view-img{height:auto!important;object-fit:contain!important;max-width:480px!important} .uv-empty{margin:%?100?% auto!important} .image-cropper{z-index:10000!important} .uv-tabs__wrapper__nav{overflow:inherit}.sticky_tabs_box{background:#fff;z-index:30;position:fixed;left:0;right:0;top:0;max-width:480px;width:100%;margin:0 auto;padding-bottom:%?2?%;box-shadow:0 0 %?10?% #ddd} .uv-popup__content{max-width:408px;width:85%;margin:0 auto}.line_box{background:#f8f8f8;width:100%;height:%?14?%;margin:%?30?% auto} .uv-loadmore{margin:%?35?% auto!important} .uv-loadmore__content__text{color:#999!important} uni-page-refresh .uni-page-refresh{z-index:1020!important} .uni-page-head__title{font-weight:400!important} .lang-dialog__wrapper .lang-dialog__body > uni-view{overflow:visible!important} .lang-dialog__wrapper .lang-dialog__body .slider-refresh{margin-top:1px!important} .lang-dialog__wrapper .lang-dialog__body .slider-refresh:nth-child(2) .slider-tools-btn{margin-top:1px!important;width:23px!important;height:23px!important}\r\n/* 强制缩小小程序端所有字体（根据实际差异调整比例） */\r\n/* 针对特定组件调整（如按钮、标题） */body{-webkit-text-size-adjust:100%!important;text-size-adjust:100%!important}uni-modal .uni-modal__bd{color:#4e4e4e;font-size:14px;padding:30px;padding-top:40px}',
        "",
      ]),
      (e.exports = n);
  },
  "533b": function (e, n, t) {
    "use strict";
    t.r(n);
    var a = t("fa53"),
      i = t.n(a);
    for (var o in a)
      ["default"].indexOf(o) < 0 &&
        (function (e) {
          t.d(n, e, function () {
            return a[e];
          });
        })(o);
    n["default"] = i.a;
  },
  "53b8": function (e, n, t) {
    "use strict";
    t.r(n);
    var a = t("80b5"),
      i = t.n(a);
    for (var o in a)
      ["default"].indexOf(o) < 0 &&
        (function (e) {
          t.d(n, e, function () {
            return a[e];
          });
        })(o);
    n["default"] = i.a;
  },
  "564a": function (e, n, t) {
    "use strict";
    t.r(n);
    var a = t("ed43"),
      i = t("53b8");
    for (var o in i)
      ["default"].indexOf(o) < 0 &&
        (function (e) {
          t.d(n, e, function () {
            return i[e];
          });
        })(o);
    t("d011");
    var r = t("828b"),
      s = Object(r["a"])(
        i["default"],
        a["b"],
        a["c"],
        !1,
        null,
        "5117495a",
        null,
        !1,
        a["a"],
        void 0,
      );
    n["default"] = s.exports;
  },
  "569e": function (e, n, t) {
    "use strict";
    t.d(n, "b", function () {
      return i;
    }),
      t.d(n, "c", function () {
        return o;
      }),
      t.d(n, "a", function () {
        return a;
      });
    var a = { uvTransition: t("7fd8").default },
      i = function () {
        var e = this,
          n = e.$createElement,
          t = e._self._c || n;
        return t(
          "uv-transition",
          {
            attrs: {
              show: e.show,
              mode: "fade",
              "custom-class": "uv-overlay",
              duration: e.duration,
              "custom-style": e.overlayStyle,
            },
            on: {
              click: function (n) {
                (arguments[0] = n = e.$handleEvent(n)),
                  e.clickHandler.apply(void 0, arguments);
              },
              touchmove: function (n) {
                n.stopPropagation(),
                  n.preventDefault(),
                  (arguments[0] = n = e.$handleEvent(n)),
                  e.clear.apply(void 0, arguments);
              },
            },
          },
          [e._t("default")],
          2,
        );
      },
      o = [];
  },
  "573c": function (e, n, t) {
    var a = t("c86c");
    (n = a(!1)),
      n.push([
        e.i,
        '@charset "UTF-8";\r\n/**\r\n * 这里是uni-app内置的常用样式变量\r\n *\r\n * uni-app 官方扩展插件及插件市场（https://ext.dcloud.net.cn）上很多三方插件均使用了这些样式变量\r\n * 如果你是插件开发者，建议你使用scss预处理，并在插件代码中直接使用这些变量（无需 import 这个文件），方便用户通过搭积木的方式开发整体风格一致的App\r\n *\r\n */\r\n/**\r\n * 如果你是App开发者（插件使用者），你可以通过修改这些变量来定制自己的插件主题，实现自定义主题功能\r\n *\r\n * 如果你的项目同样使用了scss预处理，你也可以直接在你的 scss 代码中使用如下变量，同时无需 import 这个文件\r\n */\r\n/* 颜色变量 */\r\n/* 行为相关颜色 */\r\n/* 文字基本颜色 */\r\n/* 背景颜色 */\r\n/* 边框颜色 */\r\n/* 尺寸变量 */\r\n/* 文字尺寸 */\r\n/* 图片尺寸 */\r\n/* Border Radius */\r\n/* 水平间距 */\r\n/* 垂直间距 */\r\n/* 透明度 */\r\n/* 文章场景相关 */uni-view[data-v-15277242], uni-scroll-view[data-v-15277242], uni-swiper-item[data-v-15277242]{display:flex;flex-direction:column;flex-shrink:0;flex-grow:0;flex-basis:auto;align-items:stretch;align-content:flex-start}.uv-tabbar-item[data-v-15277242]{display:flex;flex-direction:column;align-items:center;justify-content:center;flex:1}.uv-tabbar-item__icon[data-v-15277242]{display:flex;flex-direction:row;position:relative;width:%?150?%;justify-content:center}.uv-tabbar-item__text[data-v-15277242]{margin-top:2px;font-size:12px;color:#606266}',
        "",
      ]),
      (e.exports = n);
  },
  "5a85": function (e, n, t) {
    "use strict";
    t("6a54");
    var a = t("3639").default,
      i = t("f5bd").default;
    Object.defineProperty(n, "__esModule", { value: !0 }),
      (n.default = void 0),
      t("8f71"),
      t("bf0f");
    var o = i(t("9b1b")),
      r = i(t("615c")),
      s = i(t("9463")),
      u = i(t("4d8f0")),
      c = i(t("8d8b")),
      l = a(t("a991")),
      d = i(t("89e3")),
      f = i(t("0368")),
      p = a(t("1509")),
      g = a(t("5d41")),
      _ = i(t("7d16")),
      h = i(t("7b84")),
      m = (0, o.default)(
        (0, o.default)(
          { route: c.default, config: _.default, test: p, date: l.timeFormat },
          l,
        ),
        {},
        {
          colorGradient: g.colorGradient,
          hexToRgb: g.hexToRgb,
          rgbToHex: g.rgbToHex,
          colorToRgba: g.colorToRgba,
          http: new r.default(),
          debounce: d.default,
          throttle: f.default,
          platform: h.default,
          mixin: s.default,
          mpMixin: u.default,
        },
      );
    uni.$uv = m;
    var v = {
      install: function (e) {
        var n,
          t,
          a = l.deepClone(s.default);
        null === a ||
          void 0 === a ||
          null === (n = a.props) ||
          void 0 === n ||
          delete n.customClass,
          null === a ||
            void 0 === a ||
            null === (t = a.props) ||
            void 0 === t ||
            delete t.customStyle,
          e.mixin(a),
          e.filter("timeFormat", function (e, n) {
            return uni.$uv.timeFormat(e, n);
          }),
          e.filter("date", function (e, n) {
            return uni.$uv.timeFormat(e, n);
          }),
          e.filter("timeFrom", function (e, n) {
            return uni.$uv.timeFrom(e, n);
          }),
          (e.prototype.$uv = m);
      },
    };
    n.default = v;
  },
  "5a99": function (e, n, t) {
    "use strict";
    t("6a54");
    var a = t("f5bd").default;
    Object.defineProperty(n, "__esModule", { value: !0 }), (n.default = void 0);
    var i = a(t("4d8f0")),
      o = a(t("9463")),
      r = a(t("4def")),
      s = {
        name: "uv-line",
        mixins: [i.default, o.default, r.default],
        computed: {
          lineStyle: function () {
            var e = {};
            return (
              (e.margin = this.margin),
              "row" === this.direction
                ? ((e.borderBottomWidth = "1px"),
                  (e.borderBottomStyle = this.dashed ? "dashed" : "solid"),
                  (e.width = this.$uv.addUnit(this.length)),
                  this.hairline && (e.transform = "scaleY(0.5)"))
                : ((e.borderLeftWidth = "1px"),
                  (e.borderLeftStyle = this.dashed ? "dashed" : "solid"),
                  (e.height = this.$uv.addUnit(this.length)),
                  this.hairline && (e.transform = "scaleX(0.5)")),
              (e.borderColor = this.color),
              this.$uv.deepMerge(e, this.$uv.addStyle(this.customStyle))
            );
          },
        },
      };
    n.default = s;
  },
  "5ad5": function (e, n, t) {
    "use strict";
    t.d(n, "b", function () {
      return i;
    }),
      t.d(n, "c", function () {
        return o;
      }),
      t.d(n, "a", function () {
        return a;
      });
    var a = { uvIcon: t("1a07").default },
      i = function () {
        var e = this,
          n = e.$createElement,
          t = e._self._c || n;
        return e.show
          ? t(
              "v-uni-view",
              { staticClass: "uv-empty", style: [e.emptyStyle] },
              [
                e.isImg
                  ? t("v-uni-image", {
                      style: {
                        width: e.$uv.addUnit(e.width),
                        height: e.$uv.addUnit(e.height),
                      },
                      attrs: { src: e.icon, mode: "widthFix" },
                    })
                  : t("uv-icon", {
                      attrs: {
                        name: "message" === e.mode ? "chat" : "empty-" + e.mode,
                        size: e.iconSize,
                        color: e.iconColor,
                        "margin-top": "14",
                      },
                    }),
                t(
                  "v-uni-text",
                  { staticClass: "uv-empty__text", style: [e.textStyle] },
                  [e._v(e._s(e.text ? e.text : e.icons[e.mode]))],
                ),
                t(
                  "v-uni-view",
                  { staticClass: "uv-empty__wrap" },
                  [e._t("default")],
                  2,
                ),
              ],
              1,
            )
          : e._e();
      },
      o = [];
  },
  "5c9c": function (e, n, t) {
    "use strict";
    var a = t("f5bd").default,
      i = a(t("9b1b"));
    t("3dde"), t("a8b2"), t("1480"), t("6e4a"), t("affe"), t("9337");
    var o = a(t("f10e")),
      r = a(t("9b8e")),
      s = a(t("d235")),
      u = a(t("ca70")),
      c = a(t("98ed")),
      l = a(t("d025")),
      d = a(t("564a")),
      f = a(t("5a85")),
      p = a(t("749d"));
    r.default.component("tab-bar", s.default),
      r.default.component("kefu-bar", u.default),
      r.default.component("copy-right", c.default),
      r.default.component("goodsSelect", l.default),
      r.default.component("status-bar", d.default),
      r.default.use(f.default),
      r.default.mixin(p.default),
      (r.default.config.productionTip = !1),
      (o.default.mpType = "app");
    var g = new r.default((0, i.default)({}, o.default));
    g.$mount();
  },
  "5d41": function (e, n, t) {
    "use strict";
    function a(e) {
      var n =
          !(arguments.length > 1 && void 0 !== arguments[1]) || arguments[1],
        t = /^#([0-9a-fA-f]{3}|[0-9a-fA-f]{6})$/;
      if (((e = String(e).toLowerCase()), e && t.test(e))) {
        if (4 === e.length) {
          for (var a = "#", i = 1; i < 4; i += 1)
            a += e.slice(i, i + 1).concat(e.slice(i, i + 1));
          e = a;
        }
        for (var o = [], r = 1; r < 7; r += 2)
          o.push(parseInt("0x".concat(e.slice(r, r + 2))));
        return n
          ? "rgb(".concat(o[0], ",").concat(o[1], ",").concat(o[2], ")")
          : o;
      }
      if (/^(rgb|RGB)/.test(e)) {
        var s = e.replace(/(?:\(|\)|rgb|RGB)*/g, "").split(",");
        return s.map(function (e) {
          return Number(e);
        });
      }
      return e;
    }
    function i(e) {
      var n = e;
      if (/^(rgb|RGB)/.test(n)) {
        for (
          var t = n.replace(/(?:\(|\)|rgb|RGB)*/g, "").split(","),
            a = "#",
            i = 0;
          i < t.length;
          i++
        ) {
          var o = Number(t[i]).toString(16);
          (o = 1 == String(o).length ? "".concat(0, o) : o),
            "0" === o && (o += o),
            (a += o);
        }
        return 7 !== a.length && (a = n), a;
      }
      if (!/^#([0-9a-fA-f]{3}|[0-9a-fA-f]{6})$/.test(n)) return n;
      var r = n.replace(/#/, "").split("");
      if (6 === r.length) return n;
      if (3 === r.length) {
        for (var s = "#", u = 0; u < r.length; u += 1) s += r[u] + r[u];
        return s;
      }
    }
    t("6a54"),
      Object.defineProperty(n, "__esModule", { value: !0 }),
      (n.colorGradient = function () {
        for (
          var e =
              arguments.length > 0 && void 0 !== arguments[0]
                ? arguments[0]
                : "rgb(0, 0, 0)",
            n =
              arguments.length > 1 && void 0 !== arguments[1]
                ? arguments[1]
                : "rgb(255, 255, 255)",
            t =
              arguments.length > 2 && void 0 !== arguments[2]
                ? arguments[2]
                : 10,
            o = a(e, !1),
            r = o[0],
            s = o[1],
            u = o[2],
            c = a(n, !1),
            l = c[0],
            d = c[1],
            f = c[2],
            p = (l - r) / t,
            g = (d - s) / t,
            _ = (f - u) / t,
            h = [],
            m = 0;
          m < t;
          m++
        ) {
          var v = i(
            "rgb("
              .concat(Math.round(p * m + r), ",")
              .concat(Math.round(g * m + s), ",")
              .concat(Math.round(_ * m + u), ")"),
          );
          0 === m && (v = i(e)), m === t - 1 && (v = i(n)), h.push(v);
        }
        return h;
      }),
      (n.colorToRgba = function (e, n) {
        e = i(e);
        var t = String(e).toLowerCase();
        if (t && /^#([0-9a-fA-f]{3}|[0-9a-fA-f]{6})$/.test(t)) {
          if (4 === t.length) {
            for (var a = "#", o = 1; o < 4; o += 1)
              a += t.slice(o, o + 1).concat(t.slice(o, o + 1));
            t = a;
          }
          for (var r = [], s = 1; s < 7; s += 2)
            r.push(parseInt("0x".concat(t.slice(s, s + 2))));
          return "rgba(".concat(r.join(","), ",").concat(n, ")");
        }
        return t;
      }),
      (n.hexToRgb = a),
      (n.rgbToHex = i),
      t("c223"),
      t("aa9c"),
      t("5c47"),
      t("0506"),
      t("f7a5"),
      t("e966"),
      t("a1c1"),
      t("fd3c"),
      t("64aa"),
      t("c9b5"),
      t("bf0f"),
      t("ab80");
  },
  "5ef7": function (e, n, t) {
    "use strict";
    t.r(n);
    var a = t("569e"),
      i = t("e2a3");
    for (var o in i)
      ["default"].indexOf(o) < 0 &&
        (function (e) {
          t.d(n, e, function () {
            return i[e];
          });
        })(o);
    t("8bc6");
    var r = t("828b"),
      s = Object(r["a"])(
        i["default"],
        a["b"],
        a["c"],
        !1,
        null,
        "12ad5b32",
        null,
        !1,
        a["a"],
        void 0,
      );
    n["default"] = s.exports;
  },
  "5ff2": function (e, n, t) {
    "use strict";
    t("6a54");
    var a = t("f5bd").default;
    Object.defineProperty(n, "__esModule", { value: !0 }),
      (n.default = void 0),
      t("5ef2");
    var i = a(t("4d8f0")),
      o = a(t("9463")),
      r = a(t("992d")),
      s = {
        name: "uv-tabbar-item",
        mixins: [i.default, o.default, r.default],
        emits: ["click", "change"],
        data: function () {
          return {
            isActive: !1,
            parentData: {
              value: null,
              activeColor: "",
              inactiveColor: "",
              iconSize: 20,
            },
          };
        },
        created: function () {
          this.init();
        },
        methods: {
          init: function () {
            this.updateParentData(),
              this.parent ||
                this.$uv.error("uv-tabbar-item必须搭配uv-tabbar组件使用");
            var e = this.parent.children.indexOf(this);
            this.isActive = (this.name || e) === this.parentData.value;
          },
          updateParentData: function () {
            this.getParentData("uv-tabbar");
          },
          updateFromParent: function () {
            this.init();
          },
          clickHandler: function () {
            var e = this;
            this.$nextTick(function () {
              var n = e.parent.children.indexOf(e),
                t = e.name || n;
              t !== e.parent.value && e.parent.$emit("change", t),
                e.$emit("click", t);
            });
          },
        },
      };
    n.default = s;
  },
  6052: function (e, n, t) {
    "use strict";
    var a = t("0fe0"),
      i = t.n(a);
    i.a;
  },
  "615c": function (e, n, t) {
    "use strict";
    t("6a54");
    var a = t("f5bd").default;
    Object.defineProperty(n, "__esModule", { value: !0 }), (n.default = void 0);
    var i = a(t("0ab3")),
      o = i.default;
    n.default = o;
  },
  "620b": function (e, n, t) {
    "use strict";
    t.r(n);
    var a = t("d932"),
      i = t("17ba");
    for (var o in i)
      ["default"].indexOf(o) < 0 &&
        (function (e) {
          t.d(n, e, function () {
            return i[e];
          });
        })(o);
    t("b50f");
    var r = t("828b"),
      s = Object(r["a"])(
        i["default"],
        a["b"],
        a["c"],
        !1,
        null,
        "15277242",
        null,
        !1,
        a["a"],
        void 0,
      );
    n["default"] = s.exports;
  },
  6299: function (e, n, t) {
    "use strict";
    t("6a54"),
      Object.defineProperty(n, "__esModule", { value: !0 }),
      (n.default = void 0);
    n.default = {
      "uvicon-level": "e68f",
      "uvicon-checkbox-mark": "e659",
      "uvicon-folder": "e694",
      "uvicon-movie": "e67c",
      "uvicon-star-fill": "e61e",
      "uvicon-star": "e618",
      "uvicon-phone-fill": "e6ac",
      "uvicon-phone": "e6ba",
      "uvicon-apple-fill": "e635",
      "uvicon-backspace": "e64d",
      "uvicon-attach": "e640",
      "uvicon-empty-data": "e671",
      "uvicon-empty-address": "e68a",
      "uvicon-empty-favor": "e662",
      "uvicon-empty-car": "e657",
      "uvicon-empty-order": "e66b",
      "uvicon-empty-list": "e672",
      "uvicon-empty-search": "e677",
      "uvicon-empty-permission": "e67d",
      "uvicon-empty-news": "e67e",
      "uvicon-empty-history": "e685",
      "uvicon-empty-coupon": "e69b",
      "uvicon-empty-page": "e60e",
      "uvicon-empty-wifi-off": "e6cc",
      "uvicon-reload": "e627",
      "uvicon-order": "e695",
      "uvicon-server-man": "e601",
      "uvicon-search": "e632",
      "uvicon-more-dot-fill": "e66f",
      "uvicon-scan": "e631",
      "uvicon-map": "e665",
      "uvicon-map-fill": "e6a8",
      "uvicon-tags": "e621",
      "uvicon-tags-fill": "e613",
      "uvicon-eye": "e664",
      "uvicon-eye-fill": "e697",
      "uvicon-eye-off": "e69c",
      "uvicon-eye-off-outline": "e688",
      "uvicon-mic": "e66d",
      "uvicon-mic-off": "e691",
      "uvicon-calendar": "e65c",
      "uvicon-trash": "e623",
      "uvicon-trash-fill": "e6ce",
      "uvicon-play-left": "e6bf",
      "uvicon-play-right": "e6b3",
      "uvicon-minus": "e614",
      "uvicon-plus": "e625",
      "uvicon-info-circle": "e69f",
      "uvicon-info-circle-fill": "e6a7",
      "uvicon-question-circle": "e622",
      "uvicon-question-circle-fill": "e6bc",
      "uvicon-close": "e65a",
      "uvicon-checkmark": "e64a",
      "uvicon-checkmark-circle": "e643",
      "uvicon-checkmark-circle-fill": "e668",
      "uvicon-setting": "e602",
      "uvicon-setting-fill": "e6d0",
      "uvicon-heart": "e6a2",
      "uvicon-heart-fill": "e68b",
      "uvicon-camera": "e642",
      "uvicon-camera-fill": "e650",
      "uvicon-more-circle": "e69e",
      "uvicon-more-circle-fill": "e684",
      "uvicon-chat": "e656",
      "uvicon-chat-fill": "e63f",
      "uvicon-bag": "e647",
      "uvicon-error-circle": "e66e",
      "uvicon-error-circle-fill": "e655",
      "uvicon-close-circle": "e64e",
      "uvicon-close-circle-fill": "e666",
      "uvicon-share": "e629",
      "uvicon-share-fill": "e6bb",
      "uvicon-share-square": "e6c4",
      "uvicon-shopping-cart": "e6cb",
      "uvicon-shopping-cart-fill": "e630",
      "uvicon-bell": "e651",
      "uvicon-bell-fill": "e604",
      "uvicon-list": "e690",
      "uvicon-list-dot": "e6a9",
      "uvicon-zhifubao-circle-fill": "e617",
      "uvicon-weixin-circle-fill": "e6cd",
      "uvicon-weixin-fill": "e620",
      "uvicon-qq-fill": "e608",
      "uvicon-qq-circle-fill": "e6b9",
      "uvicon-moments-circel-fill": "e6c2",
      "uvicon-moments": "e6a0",
      "uvicon-car": "e64f",
      "uvicon-car-fill": "e648",
      "uvicon-warning-fill": "e6c7",
      "uvicon-warning": "e6c1",
      "uvicon-clock-fill": "e64b",
      "uvicon-clock": "e66c",
      "uvicon-edit-pen": "e65d",
      "uvicon-edit-pen-fill": "e679",
      "uvicon-email": "e673",
      "uvicon-email-fill": "e683",
      "uvicon-minus-circle": "e6a5",
      "uvicon-plus-circle": "e603",
      "uvicon-plus-circle-fill": "e611",
      "uvicon-file-text": "e687",
      "uvicon-file-text-fill": "e67f",
      "uvicon-pushpin": "e6d1",
      "uvicon-pushpin-fill": "e6b6",
      "uvicon-grid": "e68c",
      "uvicon-grid-fill": "e698",
      "uvicon-play-circle": "e6af",
      "uvicon-play-circle-fill": "e62a",
      "uvicon-pause-circle-fill": "e60c",
      "uvicon-pause": "e61c",
      "uvicon-pause-circle": "e696",
      "uvicon-gift-fill": "e6b0",
      "uvicon-gift": "e680",
      "uvicon-kefu-ermai": "e660",
      "uvicon-server-fill": "e610",
      "uvicon-coupon-fill": "e64c",
      "uvicon-coupon": "e65f",
      "uvicon-integral": "e693",
      "uvicon-integral-fill": "e6b1",
      "uvicon-home-fill": "e68e",
      "uvicon-home": "e67b",
      "uvicon-account": "e63a",
      "uvicon-account-fill": "e653",
      "uvicon-thumb-down-fill": "e628",
      "uvicon-thumb-down": "e60a",
      "uvicon-thumb-up": "e612",
      "uvicon-thumb-up-fill": "e62c",
      "uvicon-lock-fill": "e6a6",
      "uvicon-lock-open": "e68d",
      "uvicon-lock-opened-fill": "e6a1",
      "uvicon-lock": "e69d",
      "uvicon-red-packet": "e6c3",
      "uvicon-photo-fill": "e6b4",
      "uvicon-photo": "e60d",
      "uvicon-volume-off-fill": "e6c8",
      "uvicon-volume-off": "e6bd",
      "uvicon-volume-fill": "e624",
      "uvicon-volume": "e605",
      "uvicon-download": "e670",
      "uvicon-arrow-up-fill": "e636",
      "uvicon-arrow-down-fill": "e638",
      "uvicon-play-left-fill": "e6ae",
      "uvicon-play-right-fill": "e6ad",
      "uvicon-arrow-downward": "e634",
      "uvicon-arrow-leftward": "e63b",
      "uvicon-arrow-rightward": "e644",
      "uvicon-arrow-upward": "e641",
      "uvicon-arrow-down": "e63e",
      "uvicon-arrow-right": "e63c",
      "uvicon-arrow-left": "e646",
      "uvicon-arrow-up": "e633",
      "uvicon-skip-back-left": "e6c5",
      "uvicon-skip-forward-right": "e61f",
      "uvicon-arrow-left-double": "e637",
      "uvicon-man": "e675",
      "uvicon-woman": "e626",
      "uvicon-en": "e6b8",
      "uvicon-twitte": "e607",
      "uvicon-twitter-circle-fill": "e6cf",
    };
  },
  6382: function (e, n, t) {
    "use strict";
    var a = t("e249"),
      i = t.n(a);
    i.a;
  },
  "68bd": function (e, n, t) {
    var a = t("51e8");
    a.__esModule && (a = a.default),
      "string" === typeof a && (a = [[e.i, a, ""]]),
      a.locals && (e.exports = a.locals);
    var i = t("967d").default;
    i("0df3aafb", a, !0, { sourceMap: !1, shadowMode: !1 });
  },
  "6e0d": function (e, n, t) {
    "use strict";
    t("6a54");
    var a = t("f5bd").default;
    Object.defineProperty(n, "__esModule", { value: !0 }),
      (n.default = void 0),
      t("08eb"),
      t("18f7");
    var i = t("5d41"),
      o = a(t("4d8f0")),
      r = a(t("9463")),
      s = a(t("3c53")),
      u = {
        name: "uv-loading-icon",
        mixins: [o.default, r.default, s.default],
        data: function () {
          return {
            array12: Array.from({ length: 12 }),
            aniAngel: 360,
            webviewHide: !1,
            loading: !1,
          };
        },
        computed: {
          otherBorderColor: function () {
            var e = (0, i.colorGradient)(this.color, "#ffffff", 100)[80];
            return "circle" === this.mode
              ? this.inactiveColor
                ? this.inactiveColor
                : e
              : "transparent";
          },
        },
        watch: { show: function (e) {} },
        mounted: function () {
          this.init();
        },
        methods: {
          init: function () {
            setTimeout(function () {}, 20);
          },
          addEventListenerToWebview: function () {
            var e = this,
              n = getCurrentPages(),
              t = n[n.length - 1],
              a = t.$getAppWebview();
            a.addEventListener("hide", function () {
              e.webviewHide = !0;
            }),
              a.addEventListener("show", function () {
                e.webviewHide = !1;
              });
          },
        },
      };
    n.default = u;
  },
  "709f": function (e, n, t) {
    "use strict";
    var a = t("f510"),
      i = t.n(a);
    i.a;
  },
  "71ab": function (e, n, t) {
    "use strict";
    var a = t("e320"),
      i = t.n(a);
    i.a;
  },
  7264: function (e, n, t) {
    "use strict";
    var a = t("47e2"),
      i = t.n(a);
    i.a;
  },
  "73b2": function (e, n, t) {
    "use strict";
    t.r(n);
    var a = t("9e89"),
      i = t("37cc");
    for (var o in i)
      ["default"].indexOf(o) < 0 &&
        (function (e) {
          t.d(n, e, function () {
            return i[e];
          });
        })(o);
    t("6052");
    var r = t("828b"),
      s = Object(r["a"])(
        i["default"],
        a["b"],
        a["c"],
        !1,
        null,
        "ff035a16",
        null,
        !1,
        a["a"],
        void 0,
      );
    n["default"] = s.exports;
  },
  "749d": function (e, n, t) {
    "use strict";
    t("6a54"),
      Object.defineProperty(n, "__esModule", { value: !0 }),
      (n.default = void 0);
    n.default = {
      data: function () {
        return {
          shareConfig: {
            title: "默认分享标题",
            path: "/pages/index/index",
            imageUrl: "/static/share-default.png",
            query: "",
          },
        };
      },
      onShareAppMessage: function () {},
      onShareTimeline: function () {},
    };
  },
  "758d": function (e, n, t) {
    "use strict";
    function a() {
      this.handlers = [];
    }
    t("6a54"),
      Object.defineProperty(n, "__esModule", { value: !0 }),
      (n.default = void 0),
      t("aa9c"),
      t("bf0f"),
      t("2797"),
      (a.prototype.use = function (e, n) {
        return (
          this.handlers.push({ fulfilled: e, rejected: n }),
          this.handlers.length - 1
        );
      }),
      (a.prototype.eject = function (e) {
        this.handlers[e] && (this.handlers[e] = null);
      }),
      (a.prototype.forEach = function (e) {
        this.handlers.forEach(function (n) {
          null !== n && e(n);
        });
      });
    var i = a;
    n.default = i;
  },
  "7b84": function (e, n, t) {
    "use strict";
    t("6a54"),
      Object.defineProperty(n, "__esModule", { value: !0 }),
      (n.default = void 0);
    n.default = "h5";
  },
  "7d16": function (e, n, t) {
    "use strict";
    t("6a54"),
      Object.defineProperty(n, "__esModule", { value: !0 }),
      (n.default = void 0);
    var a = {
      v: "1.1.20",
      version: "1.1.20",
      type: ["primary", "success", "info", "error", "warning"],
      color: {
        "uv-primary": "#2979ff",
        "uv-warning": "#ff9900",
        "uv-success": "#19be6b",
        "uv-error": "#fa3534",
        "uv-info": "#909399",
        "uv-main-color": "#303133",
        "uv-content-color": "#606266",
        "uv-tips-color": "#909399",
        "uv-light-color": "#c0c4cc",
      },
      unit: "px",
    };
    n.default = a;
  },
  "7dd5": function (e, n, t) {
    "use strict";
    var a = t("3e9c"),
      i = t.n(a);
    i.a;
  },
  "7fd8": function (e, n, t) {
    "use strict";
    t.r(n);
    var a = t("c4df"),
      i = t("d06d");
    for (var o in i)
      ["default"].indexOf(o) < 0 &&
        (function (e) {
          t.d(n, e, function () {
            return i[e];
          });
        })(o);
    var r = t("828b"),
      s = Object(r["a"])(
        i["default"],
        a["b"],
        a["c"],
        !1,
        null,
        null,
        null,
        !1,
        a["a"],
        void 0,
      );
    n["default"] = s.exports;
  },
  "808e": function (e, n, t) {
    "use strict";
    var a = t("ff7b"),
      i = t.n(a);
    i.a;
  },
  "80b5": function (e, n, t) {
    "use strict";
    t("6a54"),
      Object.defineProperty(n, "__esModule", { value: !0 }),
      (n.default = void 0);
    var a = {
      data: function () {
        return { statusBarHeight: 20 };
      },
      created: function () {
        var e = uni.getSystemInfoSync();
        this.statusBarHeight = e.statusBarHeight || 20;
      },
    };
    n.default = a;
  },
  8326: function (e, n, t) {
    var a = t("c86c");
    (n = a(!1)),
      n.push([
        e.i,
        '@charset "UTF-8";\r\n/**\r\n * 这里是uni-app内置的常用样式变量\r\n *\r\n * uni-app 官方扩展插件及插件市场（https://ext.dcloud.net.cn）上很多三方插件均使用了这些样式变量\r\n * 如果你是插件开发者，建议你使用scss预处理，并在插件代码中直接使用这些变量（无需 import 这个文件），方便用户通过搭积木的方式开发整体风格一致的App\r\n *\r\n */\r\n/**\r\n * 如果你是App开发者（插件使用者），你可以通过修改这些变量来定制自己的插件主题，实现自定义主题功能\r\n *\r\n * 如果你的项目同样使用了scss预处理，你也可以直接在你的 scss 代码中使用如下变量，同时无需 import 这个文件\r\n */\r\n/* 颜色变量 */\r\n/* 行为相关颜色 */\r\n/* 文字基本颜色 */\r\n/* 背景颜色 */\r\n/* 边框颜色 */\r\n/* 尺寸变量 */\r\n/* 文字尺寸 */\r\n/* 图片尺寸 */\r\n/* Border Radius */\r\n/* 水平间距 */\r\n/* 垂直间距 */\r\n/* 透明度 */\r\n/* 文章场景相关 */[data-v-55b48544] .uv-popup__content{max-width:480px;width:100%;margin:0 auto;border-radius:%?24?% %?24?% 0 0;overflow:hidden}.goods_select[data-v-55b48544]{display:flex;flex-direction:column;height:70vh;background:#fff}.goods_select .header[data-v-55b48544]{position:relative;height:%?96?%;line-height:%?96?%;text-align:center;border-bottom:%?2?% solid #f7f8fa}.goods_select .header .title[data-v-55b48544]{font-size:14px;font-weight:700;color:#000}.goods_select .header .close[data-v-55b48544]{position:absolute;right:%?24?%;top:50%;-webkit-transform:translateY(-50%);transform:translateY(-50%);width:%?60?%;height:%?60?%;display:flex;align-items:center;justify-content:center}.goods_select .search_row[data-v-55b48544]{display:flex;align-items:center;padding:%?16?% %?24?%;border-bottom:%?2?% solid #f7f8fa}.goods_select .search_row .search_box[data-v-55b48544]{flex:1}.goods_select .search_row .cat_toggle[data-v-55b48544]{flex-shrink:0;width:%?60?%;height:%?60?%;display:flex;align-items:center;justify-content:center;margin-left:%?16?%}.goods_select .cat_box[data-v-55b48544]{border-bottom:%?2?% solid #f7f8fa}.goods_select .cat_box .cat_row[data-v-55b48544]{white-space:nowrap;padding:%?16?% %?24?%}.goods_select .cat_box .cat_row[data-v-55b48544]:nth-child(n+2){border-top:%?2?% solid #f7f8fa}.goods_select .cat_box .cat_row .cat_item[data-v-55b48544]{display:inline-flex;align-items:center;justify-content:center;padding:0 %?24?%;height:%?60?%;line-height:%?60?%;margin-right:%?16?%;font-size:13px;color:#333;background:#f7f8fa;border-radius:%?60?%;white-space:nowrap;transition:all .2s}.goods_select .cat_box .cat_row .cat_item.sub[data-v-55b48544]{background:#fff;border:%?2?% solid #eee}.goods_select .cat_box .cat_row .cat_item.active[data-v-55b48544]{background:#ffe610;color:#000;font-weight:700;border-color:#ffe610}.goods_select .goods_list[data-v-55b48544]{flex:1;overflow:hidden;padding:0 %?24?%;box-sizing:border-box}.goods_select .goods_list .list_loading[data-v-55b48544]{display:flex;flex-direction:column;align-items:center;justify-content:center;padding:%?80?% 0}.goods_select .goods_list .list_loading .loading_text[data-v-55b48544]{margin-top:%?16?%;font-size:13px;color:#999}.goods_select .goods_list .goods_col[data-v-55b48544]{display:flex;align-items:center;padding:%?24?% 0;border-bottom:%?2?% solid #f7f7fa}.goods_select .goods_list .goods_col[data-v-55b48544]:last-child{border-bottom:none}.goods_select .goods_list .goods_col .img_box[data-v-55b48544]{width:%?160?%;height:%?160?%;border-radius:%?16?%;background:#f7f8fa;flex-shrink:0;display:flex;align-items:center;justify-content:center;overflow:hidden}.goods_select .goods_list .goods_col .img_box img[data-v-55b48544]{width:100%;height:100%;border-radius:%?16?%}.goods_select .goods_list .goods_col .goods_msg[data-v-55b48544]{flex:1;min-width:0;margin-left:%?24?%}.goods_select .goods_list .goods_col .goods_msg .goods_name[data-v-55b48544]{font-size:15px;font-weight:700;color:#000}.goods_select .goods_list .goods_col .goods_msg .goods_intro[data-v-55b48544]{margin-top:%?8?%;font-size:13px;color:#999;line-height:1.4}.goods_select .goods_list .goods_col .goods_msg .goods_price[data-v-55b48544]{margin-top:%?12?%;color:#fd2c28}.goods_select .goods_list .goods_col .goods_msg .goods_price .icon[data-v-55b48544]{font-size:12px;font-weight:700}.goods_select .goods_list .goods_col .goods_msg .goods_price .num[data-v-55b48544]{font-size:17px;font-weight:700}.goods_select .goods_list .goods_col .order_btn[data-v-55b48544]{flex-shrink:0;width:%?100?%;height:%?56?%;line-height:%?56?%;text-align:center;background:#ffe610;color:#000;font-size:13px;font-weight:700;border-radius:%?56?%;margin-left:%?16?%}.goods_select .safe_bottom[data-v-55b48544]{height:constant(safe-area-inset-bottom);height:env(safe-area-inset-bottom);background:#fff}.specsShow[data-v-55b48544]{background:#fff;border-radius:%?30?% %?30?% 0 0}.specsShow .goods_msg[data-v-55b48544]{padding:%?32?% %?0?%;margin:%?0?% %?30?%;border-bottom:%?2?% solid #eee;display:flex}.specsShow .goods_msg .img[data-v-55b48544]{width:%?110?%;height:%?110?%;border-radius:%?10?%}.specsShow .goods_msg .txt[data-v-55b48544]{width:calc(100% - %?135?%);margin-left:%?24?%}.specsShow .goods_msg .txt .name[data-v-55b48544]{font-weight:700;font-size:15px}.specsShow .goods_msg .txt .price_box[data-v-55b48544]{margin-top:%?14?%;justify-content:flex-start}.specsShow .goods_msg .txt .price_box .new_price[data-v-55b48544]{color:#fd2c28;font-weight:700;font-size:17px}.specsShow .goods_msg .txt .price_box .new_price .unit[data-v-55b48544]{font-size:12px}.specsShow .reason_box[data-v-55b48544]{margin:%?32?% %?30?% %?50?%}.specsShow .reason_box .tit[data-v-55b48544]{font-size:15px;font-weight:700;position:relative;z-index:10;display:flex;align-items:center;justify-content:space-between;text-align:left;width:100%}.specsShow .reason_box .tit > uni-text[data-v-55b48544]{display:inline-block;position:relative;z-index:10}.specsShow .reason_box .tit > uni-text[data-v-55b48544]::before{z-index:-1;display:block;content:"";width:72%;height:%?20?%;border-radius:%?20?%;background:#ffe610;position:absolute;left:50%;bottom:%?6?%;-webkit-transform:translate(-50%);transform:translate(-50%)}.specsShow .reason_box .tit .switch_btn[data-v-55b48544]{font-size:11px;font-weight:400;color:#333;padding:%?8?% %?20?%;background:#fff;border:%?1?% solid #ddd;border-radius:%?40?%;position:relative;z-index:20}.specsShow .reason_box .specs_loading[data-v-55b48544]{display:flex;flex-direction:column;align-items:center;justify-content:center;padding:%?60?% 0}.specsShow .reason_box .specs_loading .loading_text[data-v-55b48544]{margin-top:%?16?%;font-size:13px;color:#999}.specsShow .reason_box .specs_grid[data-v-55b48544]{margin:%?28?% auto 0}.specsShow .reason_box .specs_grid.specs_img[data-v-55b48544]{max-height:%?500?%;overflow-y:scroll;display:grid;grid-template-columns:repeat(3,1fr);grid-gap:%?20?%}.specsShow .reason_box .specs_grid.specs_img .col[data-v-55b48544]{display:flex;flex-direction:column;align-items:center;justify-content:center;padding:%?16?% %?10?%;background:#eee;border-radius:%?16?%;color:#555;text-align:center}.specsShow .reason_box .specs_grid.specs_img .col .col_img[data-v-55b48544]{width:%?120?%;height:%?120?%;margin-bottom:%?12?%}.specsShow .reason_box .specs_grid.specs_img .col .col_title[data-v-55b48544]{font-size:12px;text-overflow:ellipsis;white-space:nowrap;overflow:hidden;max-width:100%}.specsShow .reason_box .specs_grid.specs_img .col.cur[data-v-55b48544]{background:#ffe610;color:#000}.specsShow .reason_box .specs_grid.specs_img .col.cur .col_title[data-v-55b48544]{font-weight:700}.specsShow .reason_box .specs_grid.specs_text[data-v-55b48544]{max-height:%?500?%;overflow-y:scroll;display:grid;grid-template-columns:repeat(2,1fr);grid-gap:%?24?% %?12?%}.specsShow .reason_box .specs_grid.specs_text .col[data-v-55b48544]{padding:0 %?16?%;height:%?54?%;line-height:%?54?%;font-size:12px;text-overflow:ellipsis;white-space:nowrap;overflow:hidden;background:#eee;border-radius:%?10?%;color:#555;text-align:center}.specsShow .reason_box .specs_grid.specs_text .col .col_title_text[data-v-55b48544]{display:block}.specsShow .reason_box .specs_grid.specs_text .col.cur[data-v-55b48544]{background:#ffe610;color:#000;font-weight:700}.specsShow .spec_daohang_box[data-v-55b48544]{background:#fff;box-shadow:0 0 %?10?% #ddd;padding:%?20?% %?30?%;position:relative}.specsShow .spec_daohang_box .xiadan[data-v-55b48544]{background:#ffe610;width:100%;height:%?90?%;line-height:%?90?%;border-radius:%?90?%;font-size:15px;font-weight:700;text-align:center}.specsShow .spec_daohang_box .xiadan.cancel[data-v-55b48544]{background:#dadada}',
        "",
      ]),
      (e.exports = n);
  },
  8450: function (e, n, t) {
    "use strict";
    t("6a54"),
      Object.defineProperty(n, "__esModule", { value: !0 }),
      (n.default = void 0),
      t("8f71"),
      t("bf0f"),
      t("5ef2"),
      t("dd2b"),
      t("aa9c"),
      t("d4b5"),
      t("bd06");
    var a = t("e74a"),
      i = {
        props: ["selected", "numnew"],
        data: function () {
          return {
            nav_select: 0,
            nav_list: [],
            curIndex: 0,
            kefu: [],
            qrcode: "",
            agree_rule: uni.getStorageSync("agree_rule"),
            palte: "h5",
            new_msg_num: 0,
            localMessage: "",
          };
        },
        watch: {
          selected: function () {
            this.resolveSelected();
          },
        },
        created: function () {
          var e = uni.$navListData;
          if (e && e.list && e.list.length)
            (this.nav_list = e.list),
              (this.qrcode = e.qrcode),
              (this.kefu = e.kefu);
          else {
            var n = uni.getStorageSync("nav_list") || [],
              t = uni.getStorageSync("show_daren_nav");
            if (0 == t)
              n = n.filter(function (e) {
                return !(e.path && e.path.indexOf("/pages/index/daren") > -1);
              });
            else {
              for (var a = !1, i = 0; i < n.length; i++)
                if (n[i].path && n[i].path.indexOf("/pages/index/daren") > -1) {
                  a = !0;
                  break;
                }
              if (!a) {
                var o = {
                  name: "达人",
                  path: "/pages/index/daren",
                  icon: "/static/tabbar/daren_gray.png",
                  cur_icon: "/static/tabbar/daren_cur.png",
                };
                n.length >= 2 ? n.splice(2, 0, o) : n.push(o);
              }
            }
            this.nav_list = n;
          }
          this.resolveSelected();
        },
        mounted: function () {
          var e = this;
          1 != this.agree_rule && this.open1(),
            this.syncNavList(),
            setTimeout(function () {
              e.getUserSubscribeInfo(),
                uni.hideTabBar(),
                uni.$on("websocket_message", e.handleWebsocketMessage);
            }, 3e3);
        },
        beforeDestroy: function () {},
        methods: {
          setSelected: function (e) {
            uni.switchTab({ url: this.nav_list[e].path });
          },
          handleWebsocketMessage: function (e) {
            (this.localMessage = e),
              "sync_msg" == e.label &&
                0 == e.me_kefu_id &&
                (this.new_msg_num += 1),
              "sys_new_num" == e.label && (this.new_msg_num = e.new_num);
          },
          open1: function () {
            "h5" == this.palte && this.$refs.popup1.open();
          },
          open2: function () {
            this.$refs.popup2.open();
          },
          jump: function (e) {
            uni.navigateTo({ url: e });
          },
          agreeYs: function () {
            uni.setStorageSync("agree_rule", 1),
              this.$refs.popup1.close(),
              this.getUserSubscribeInfo();
          },
          getUserSubscribeInfo: function () {
            var e = this,
              n = uni.getStorageSync("token");
            (0, a.post)(
              "/wechat/Wechat/getUserSubscribeInfo",
              { label: 1 },
              n,
            ).then(function (n) {
              var t = n.status,
                a = n.msg,
                i = n.data;
              if (1 != t) return uni.$uv.toast(a);
              (e.new_msg_num = i.new_num), 0 == i.subscribe && e.open2();
            });
          },
          syncNavList: function () {
            var e,
              n = this,
              t = uni.$navListData;
            t && t.list && t.list.length && Date.now() - t.fetchTime < 3e5
              ? this.applyNavData(t)
              : ((e = uni.$navListFetching
                  ? uni.$navListFetching
                  : (uni.$navListFetching = new Promise(function (e) {
                      n.requestNavList(e);
                    }))),
                e.then(function () {
                  (uni.$navListFetching = null),
                    uni.$navListData && n.applyNavData(uni.$navListData);
                }));
          },
          requestNavList: function (e) {
            var n = uni.getStorageSync("token");
            (0, a.post)("/wechat/Wechat/getNavList", { label: 1 }, n)
              .then(function (e) {
                var n = e.status,
                  t = e.msg,
                  a = e.data;
                if (1 != n) return uni.$uv.toast(t);
                (uni.$navListData = {
                  list: a.nav_list,
                  kefu: a.kefu,
                  qrcode: a.qrcode,
                  cat_tpl: a.cat_tpl,
                  show_daren_nav:
                    void 0 !== a.show_daren_nav ? a.show_daren_nav : 1,
                  fetchTime: Date.now(),
                }),
                  uni.setStorageSync("nav_list", a.nav_list),
                  uni.setStorageSync(
                    "show_daren_nav",
                    uni.$navListData.show_daren_nav,
                  ),
                  void 0 !== a.cat_tpl &&
                    uni.setStorageSync("cat_tpl", a.cat_tpl);
              })
              .catch(function () {})
              .then(function () {
                e();
              });
          },
          applyNavData: function (e) {
            (JSON.stringify(this.nav_list) === JSON.stringify(e.list) &&
              JSON.stringify(this.kefu || {}) ===
                JSON.stringify(e.kefu || {}) &&
              this.qrcode === e.qrcode) ||
              ((this.nav_list = e.list),
              (this.kefu = e.kefu),
              (this.qrcode = e.qrcode),
              this.resolveSelected());
          },
          resolveSelected: function () {
            var e = "";
            try {
              var n = getCurrentPages();
              n.length && (e = "/" + n[n.length - 1].route);
            } catch (a) {}
            var t = this.nav_list.findIndex(function (n) {
              return n.path == e;
            });
            this.curIndex =
              t > -1 ? t : "/pages/index/daren" != e ? this.selected || 0 : -1;
          },
        },
      };
    n.default = i;
  },
  "84e9": function (e, n, t) {
    "use strict";
    t.r(n);
    var a = t("2169"),
      i = t.n(a);
    for (var o in a)
      ["default"].indexOf(o) < 0 &&
        (function (e) {
          t.d(n, e, function () {
            return a[e];
          });
        })(o);
    n["default"] = i.a;
  },
  85577: function (e, n, t) {
    "use strict";
    t.d(n, "b", function () {
      return a;
    }),
      t.d(n, "c", function () {
        return i;
      }),
      t.d(n, "a", function () {});
    var a = function () {
        var e = this,
          n = e.$createElement,
          t = e._self._c || n;
        return e.show && (0 !== Number(e.value) || e.showZero || e.isDot)
          ? t(
              "v-uni-text",
              {
                staticClass: "uv-badge",
                class: [
                  e.isDot ? "uv-badge--dot" : "uv-badge--not-dot",
                  e.inverted && "uv-badge--inverted",
                  "horn" === e.shape && "uv-badge--horn",
                  "uv-badge--" + e.propsType + (e.inverted ? "--inverted" : ""),
                ],
                style: [e.$uv.addStyle(e.customStyle), e.badgeStyle],
              },
              [e._v(e._s(e.isDot ? "" : e.showValue))],
            )
          : e._e();
      },
      i = [];
  },
  "855f": function (e, n, t) {
    "use strict";
    t("6a54"),
      Object.defineProperty(n, "__esModule", { value: !0 }),
      (n.default = void 0);
    n.default = {
      baseURL: "",
      header: {},
      method: "GET",
      dataType: "json",
      paramsSerializer: null,
      responseType: "text",
      custom: {},
      timeout: 6e4,
      withCredentials: !1,
      validateStatus: function (e) {
        return e >= 200 && e < 300;
      },
      forcedJSONParsing: !0,
    };
  },
  8580: function (e, n, t) {
    var a = t("c86c");
    (n = a(!1)),
      n.push([
        e.i,
        '@charset "UTF-8";\r\n/**\r\n * 这里是uni-app内置的常用样式变量\r\n *\r\n * uni-app 官方扩展插件及插件市场（https://ext.dcloud.net.cn）上很多三方插件均使用了这些样式变量\r\n * 如果你是插件开发者，建议你使用scss预处理，并在插件代码中直接使用这些变量（无需 import 这个文件），方便用户通过搭积木的方式开发整体风格一致的App\r\n *\r\n */\r\n/**\r\n * 如果你是App开发者（插件使用者），你可以通过修改这些变量来定制自己的插件主题，实现自定义主题功能\r\n *\r\n * 如果你的项目同样使用了scss预处理，你也可以直接在你的 scss 代码中使用如下变量，同时无需 import 这个文件\r\n */\r\n/* 颜色变量 */\r\n/* 行为相关颜色 */\r\n/* 文字基本颜色 */\r\n/* 背景颜色 */\r\n/* 边框颜色 */\r\n/* 尺寸变量 */\r\n/* 文字尺寸 */\r\n/* 图片尺寸 */\r\n/* Border Radius */\r\n/* 水平间距 */\r\n/* 垂直间距 */\r\n/* 透明度 */\r\n/* 文章场景相关 */.game-banner[data-v-116f9d20]{display:flex;align-items:center;justify-content:center;margin:%?20?% auto %?40?%;width:-webkit-fit-content;width:fit-content;padding:%?6?% %?10?%;border-radius:%?10?%;background:linear-gradient(145deg,#f8f2e3,#f0e6d0);position:relative;overflow:hidden;flex-shrink:0;box-shadow:0 %?2?% %?4?% rgba(0,0,0,.08)}.game-banner .diamond[data-v-116f9d20]{width:%?24?%;height:%?24?%;margin-right:%?8?%;background:linear-gradient(45deg,#fff9e6,#d4af37,#b8860b);-webkit-clip-path:polygon(50% 0,100% 25%,100% 75%,50% 100%,0 75%,0 25%);clip-path:polygon(50% 0,100% 25%,100% 75%,50% 100%,0 75%,0 25%);-webkit-transform:rotate(8deg) scale(.95);transform:rotate(8deg) scale(.95);flex-shrink:0;box-shadow:0 %?1?% %?3?% rgba(0,0,0,.12)}.game-banner .text-l[data-v-116f9d20]{font-size:%?26?%;font-weight:600;color:rgba(17,17,17,.55);letter-spacing:%?4?%;position:relative;z-index:2}.game-banner .split-line[data-v-116f9d20]{width:%?1.5?%;height:%?30?%;background:linear-gradient(180deg,transparent,#d4af37,transparent);margin:0 %?10?%;flex-shrink:0}.game-banner .text-r[data-v-116f9d20]{font-size:%?27?%;font-weight:800;color:#111;letter-spacing:%?3?%;-webkit-font-feature-settings:"liga" off;font-feature-settings:"liga" off;position:relative;z-index:2}.game-banner[data-v-116f9d20]::before{content:"";position:absolute;top:0;left:-100%;width:50%;height:100%;background:linear-gradient(90deg,transparent,rgba(212,175,55,.4),rgba(255,249,230,.25),transparent);-webkit-animation:textLight-data-v-116f9d20 3.2s linear infinite;animation:textLight-data-v-116f9d20 3.2s linear infinite;z-index:1;-webkit-transform:skewX(-12deg);transform:skewX(-12deg)}@-webkit-keyframes textLight-data-v-116f9d20{0%{left:-100%}100%{left:120%}}@keyframes textLight-data-v-116f9d20{0%{left:-100%}100%{left:120%}}@media (max-width:%?750?%){.game-banner[data-v-116f9d20]{padding:%?5?% %?8?%}.game-banner .diamond[data-v-116f9d20]{width:%?22?%;height:%?22?%;margin-right:%?6?%}.game-banner .text-l[data-v-116f9d20]{font-size:%?24?%;letter-spacing:%?3?%;color:rgba(17,17,17,.6)}.game-banner .text-r[data-v-116f9d20]{font-size:%?25?%;font-weight:700;letter-spacing:%?2.5?%}.game-banner .split-line[data-v-116f9d20]{width:%?1.2?%;height:%?28?%;margin:0 %?8?%}.esports-build-btn[data-v-116f9d20]{width:90%;padding:%?14?% 0}}.personal-footer[data-v-116f9d20]{width:100%;padding:0 %?30?% %?25?%;box-sizing:border-box;display:flex;flex-direction:column;align-items:center;margin:0!important}.personal-footer .esports-build-btn[data-v-116f9d20]{width:80%;padding:%?16?% 0;background:linear-gradient(135deg,#1e88e5,#9c27b0,#ff4d6d);color:#fff;font-size:14px;font-weight:600;border-radius:%?60?%;text-align:center;box-shadow:0 %?6?% %?20?% rgba(255,77,109,.3);cursor:pointer;display:flex;align-items:center;justify-content:center;gap:%?10?%;position:relative;overflow:hidden;transition:all .2s ease}.personal-footer .esports-build-btn[data-v-116f9d20]::before{content:"";position:absolute;top:0;left:0;width:100%;height:%?3?%;background:linear-gradient(90deg,transparent,hsla(0,0%,100%,.6),transparent)}.personal-footer .esports-build-btn[data-v-116f9d20]:active{-webkit-transform:scale(.96);transform:scale(.96);box-shadow:0 %?4?% %?12?% rgba(255,77,109,.2);background:linear-gradient(135deg,#1976d2,#8e24aa,#f53f5e)}.personal-footer .esports-build-btn .btn-text[data-v-116f9d20]{line-height:1;text-shadow:0 %?2?% %?4?% rgba(0,0,0,.1)}.personal-footer .esports-build-btn .btn-icon-box[data-v-116f9d20]{width:%?32?%;height:%?32?%;border-radius:50%;background-color:hsla(0,0%,100%,.2);display:flex;align-items:center;justify-content:center;-webkit-animation:iconBreath-data-v-116f9d20 2s ease-in-out infinite;animation:iconBreath-data-v-116f9d20 2s ease-in-out infinite}.personal-footer .esports-build-btn .btn-icon-text[data-v-116f9d20]{font-size:16px;color:#ff4d6d;font-weight:700}@-webkit-keyframes iconBreath-data-v-116f9d20{0%{-webkit-transform:scale(1);transform:scale(1);opacity:.8;background-color:hsla(0,0%,100%,.2)}50%{-webkit-transform:scale(1.2);transform:scale(1.2);opacity:1;background-color:hsla(0,0%,100%,.3)}100%{-webkit-transform:scale(1);transform:scale(1);opacity:.8;background-color:hsla(0,0%,100%,.2)}}@keyframes iconBreath-data-v-116f9d20{0%{-webkit-transform:scale(1);transform:scale(1);opacity:.8;background-color:hsla(0,0%,100%,.2)}50%{-webkit-transform:scale(1.2);transform:scale(1.2);opacity:1;background-color:hsla(0,0%,100%,.3)}100%{-webkit-transform:scale(1);transform:scale(1);opacity:.8;background-color:hsla(0,0%,100%,.2)}}',
        "",
      ]),
      (e.exports = n);
  },
  "87b7": function (e, n, t) {
    "use strict";
    var a = t("4cbe"),
      i = t.n(a);
    i.a;
  },
  "89e3": function (e, n, t) {
    "use strict";
    t("6a54"),
      Object.defineProperty(n, "__esModule", { value: !0 }),
      (n.default = void 0);
    var a = null;
    var i = function (e) {
      var n =
          arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : 500,
        t = arguments.length > 2 && void 0 !== arguments[2] && arguments[2];
      if ((null !== a && clearTimeout(a), t)) {
        var i = !a;
        (a = setTimeout(function () {
          a = null;
        }, n)),
          i && "function" === typeof e && e();
      } else
        a = setTimeout(function () {
          "function" === typeof e && e();
        }, n);
    };
    n.default = i;
  },
  "8bc6": function (e, n, t) {
    "use strict";
    var a = t("07b7"),
      i = t.n(a);
    i.a;
  },
  "8d8b": function (e, n, t) {
    "use strict";
    t("6a54");
    var a = t("f5bd").default;
    Object.defineProperty(n, "__esModule", { value: !0 }),
      (n.default = void 0),
      t("5c47"),
      t("0506"),
      t("bf0f");
    var i = a(t("2634")),
      o = a(t("2fdc")),
      r = a(t("80b1")),
      s = a(t("efe5")),
      u = t("a991"),
      c = (function () {
        function e() {
          (0, r.default)(this, e),
            (this.config = {
              type: "navigateTo",
              url: "",
              delta: 1,
              params: {},
              animationType: "pop-in",
              animationDuration: 300,
              intercept: !1,
              events: {},
            }),
            (this.route = this.route.bind(this));
        }
        return (
          (0, s.default)(e, [
            {
              key: "addRootPath",
              value: function (e) {
                return "/" === e[0] ? e : "/".concat(e);
              },
            },
            {
              key: "mixinParam",
              value: function (e, n) {
                e = e && this.addRootPath(e);
                var t = "";
                return /.*\/.*\?.*=.*/.test(e)
                  ? ((t = (0, u.queryParams)(n, !1)), e + "&".concat(t))
                  : ((t = (0, u.queryParams)(n)), e + t);
              },
            },
            {
              key: "route",
              value: (function () {
                var e = (0, o.default)(
                  (0, i.default)().mark(function e() {
                    var n,
                      t,
                      a,
                      o,
                      r = arguments;
                    return (0, i.default)().wrap(
                      function (e) {
                        while (1)
                          switch ((e.prev = e.next)) {
                            case 0:
                              if (
                                ((n =
                                  r.length > 0 && void 0 !== r[0] ? r[0] : {}),
                                (t =
                                  r.length > 1 && void 0 !== r[1] ? r[1] : {}),
                                (a = {}),
                                "string" === typeof n
                                  ? ((a.url = this.mixinParam(n, t)),
                                    (a.type = "navigateTo"))
                                  : ((a = (0, u.deepMerge)(this.config, n)),
                                    (a.url = this.mixinParam(n.url, n.params))),
                                a.url !== (0, u.page)())
                              ) {
                                e.next = 6;
                                break;
                              }
                              return e.abrupt("return");
                            case 6:
                              if (
                                (t.intercept && (a.intercept = t.intercept),
                                (a.params = t),
                                (a = (0, u.deepMerge)(this.config, a)),
                                "function" !== typeof a.intercept)
                              ) {
                                e.next = 16;
                                break;
                              }
                              return (
                                (e.next = 12),
                                new Promise(function (e, n) {
                                  a.intercept(a, e);
                                })
                              );
                            case 12:
                              (o = e.sent),
                                o && this.openPage(a),
                                (e.next = 17);
                              break;
                            case 16:
                              this.openPage(a);
                            case 17:
                            case "end":
                              return e.stop();
                          }
                      },
                      e,
                      this,
                    );
                  }),
                );
                return function () {
                  return e.apply(this, arguments);
                };
              })(),
            },
            {
              key: "openPage",
              value: function (e) {
                var n = e.url,
                  t = (e.type, e.delta),
                  a = e.animationType,
                  i = e.animationDuration,
                  o = e.events;
                ("navigateTo" != e.type && "to" != e.type) ||
                  uni.navigateTo({
                    url: n,
                    animationType: a,
                    animationDuration: i,
                    events: o,
                  }),
                  ("redirectTo" != e.type && "redirect" != e.type) ||
                    uni.redirectTo({ url: n }),
                  ("switchTab" != e.type && "tab" != e.type) ||
                    uni.switchTab({ url: n }),
                  ("reLaunch" != e.type && "launch" != e.type) ||
                    uni.reLaunch({ url: n }),
                  ("navigateBack" != e.type && "back" != e.type) ||
                    uni.navigateBack({ delta: t });
              },
            },
          ]),
          e
        );
      })(),
      l = new c().route;
    n.default = l;
  },
  "8f77": function (e, n, t) {
    "use strict";
    t.d(n, "b", function () {
      return a;
    }),
      t.d(n, "c", function () {
        return i;
      }),
      t.d(n, "a", function () {});
    var a = function () {
        var e = this,
          n = e.$createElement,
          t = e._self._c || n;
        return e.show
          ? t(
              "v-uni-view",
              {
                staticClass: "uv-loading-icon",
                class: [e.vertical && "uv-loading-icon--vertical"],
                style: [e.$uv.addStyle(e.customStyle)],
              },
              [
                e.webviewHide
                  ? e._e()
                  : t(
                      "v-uni-view",
                      {
                        ref: "ani",
                        staticClass: "uv-loading-icon__spinner",
                        class: ["uv-loading-icon__spinner--" + e.mode],
                        style: {
                          color: e.color,
                          width: e.$uv.addUnit(e.size),
                          height: e.$uv.addUnit(e.size),
                          borderTopColor: e.color,
                          borderBottomColor: e.otherBorderColor,
                          borderLeftColor: e.otherBorderColor,
                          borderRightColor: e.otherBorderColor,
                          "animation-duration": e.duration + "ms",
                          "animation-timing-function":
                            "semicircle" === e.mode || "circle" === e.mode
                              ? e.timingFunction
                              : "",
                        },
                      },
                      [
                        "spinner" === e.mode
                          ? e._l(e.array12, function (e, n) {
                              return t("v-uni-view", {
                                key: n,
                                staticClass: "uv-loading-icon__dot",
                              });
                            })
                          : e._e(),
                      ],
                      2,
                    ),
                e.text
                  ? t(
                      "v-uni-text",
                      {
                        staticClass: "uv-loading-icon__text",
                        style: [
                          {
                            fontSize: e.$uv.addUnit(e.textSize),
                            color: e.textColor,
                          },
                          e.$uv.addStyle(e.textStyle),
                        ],
                      },
                      [e._v(e._s(e.text))],
                    )
                  : e._e(),
              ],
              1,
            )
          : e._e();
      },
      i = [];
  },
  "913f": function (e, n, t) {
    "use strict";
    t.d(n, "b", function () {
      return a;
    }),
      t.d(n, "c", function () {
        return i;
      }),
      t.d(n, "a", function () {});
    var a = function () {
        var e = this.$createElement,
          n = this._self._c || e;
        return n("v-uni-view", {
          staticClass: "uv-safe-bottom",
          class: [!this.isNvue && "uv-safe-area-inset-bottom"],
          style: [this.style],
        });
      },
      i = [];
  },
  9192: function (e, n, t) {
    "use strict";
    t("6a54");
    var a = t("f5bd").default;
    Object.defineProperty(n, "__esModule", { value: !0 }),
      (n.default = void 0),
      t("64aa");
    var i,
      o,
      r = a(t("9b1b")),
      s = {
        props: (0, r.default)(
          {
            show: { type: Boolean, default: !1 },
            zIndex: { type: [String, Number], default: 10070 },
            duration: { type: [String, Number], default: 300 },
            opacity: { type: [String, Number], default: 0.5 },
          },
          null === (i = uni.$uv) ||
            void 0 === i ||
            null === (o = i.props) ||
            void 0 === o
            ? void 0
            : o.overlay,
        ),
      };
    n.default = s;
  },
  9264: function (e, n, t) {
    var a = t("c86c");
    (n = a(!1)),
      n.push([
        e.i,
        '@charset "UTF-8";\r\n/**\r\n * 这里是uni-app内置的常用样式变量\r\n *\r\n * uni-app 官方扩展插件及插件市场（https://ext.dcloud.net.cn）上很多三方插件均使用了这些样式变量\r\n * 如果你是插件开发者，建议你使用scss预处理，并在插件代码中直接使用这些变量（无需 import 这个文件），方便用户通过搭积木的方式开发整体风格一致的App\r\n *\r\n */\r\n/**\r\n * 如果你是App开发者（插件使用者），你可以通过修改这些变量来定制自己的插件主题，实现自定义主题功能\r\n *\r\n * 如果你的项目同样使用了scss预处理，你也可以直接在你的 scss 代码中使用如下变量，同时无需 import 这个文件\r\n */\r\n/* 颜色变量 */\r\n/* 行为相关颜色 */\r\n/* 文字基本颜色 */\r\n/* 背景颜色 */\r\n/* 边框颜色 */\r\n/* 尺寸变量 */\r\n/* 文字尺寸 */\r\n/* 图片尺寸 */\r\n/* Border Radius */\r\n/* 水平间距 */\r\n/* 垂直间距 */\r\n/* 透明度 */\r\n/* 文章场景相关 */uni-view[data-v-84c0c8a4], uni-scroll-view[data-v-84c0c8a4], uni-swiper-item[data-v-84c0c8a4]{display:flex;flex-direction:column;flex-shrink:0;flex-grow:0;flex-basis:auto;align-items:stretch;align-content:flex-start}.uv-badge[data-v-84c0c8a4]{border-top-right-radius:100px;border-top-left-radius:100px;border-bottom-left-radius:100px;border-bottom-right-radius:100px;display:flex;flex-direction:row;line-height:11px;text-align:center;font-size:11px;color:#fff}.uv-badge--dot[data-v-84c0c8a4]{height:8px;width:8px}.uv-badge--inverted[data-v-84c0c8a4]{font-size:13px}.uv-badge--not-dot[data-v-84c0c8a4]{padding:2px 5px}.uv-badge--horn[data-v-84c0c8a4]{border-bottom-left-radius:0}.uv-badge--primary[data-v-84c0c8a4]{background-color:#3c9cff}.uv-badge--primary--inverted[data-v-84c0c8a4]{color:#3c9cff}.uv-badge--error[data-v-84c0c8a4]{background-color:#f56c6c}.uv-badge--error--inverted[data-v-84c0c8a4]{color:#f56c6c}.uv-badge--success[data-v-84c0c8a4]{background-color:#5ac725}.uv-badge--success--inverted[data-v-84c0c8a4]{color:#5ac725}.uv-badge--info[data-v-84c0c8a4]{background-color:#909399}.uv-badge--info--inverted[data-v-84c0c8a4]{color:#909399}.uv-badge--warning[data-v-84c0c8a4]{background-color:#f9ae3d}.uv-badge--warning--inverted[data-v-84c0c8a4]{color:#f9ae3d}',
        "",
      ]),
      (e.exports = n);
  },
  "92c9": function (e, n, t) {
    var a = t("c86c");
    (n = a(!1)),
      n.push([
        e.i,
        '@charset "UTF-8";\r\n/**\r\n * 这里是uni-app内置的常用样式变量\r\n *\r\n * uni-app 官方扩展插件及插件市场（https://ext.dcloud.net.cn）上很多三方插件均使用了这些样式变量\r\n * 如果你是插件开发者，建议你使用scss预处理，并在插件代码中直接使用这些变量（无需 import 这个文件），方便用户通过搭积木的方式开发整体风格一致的App\r\n *\r\n */\r\n/**\r\n * 如果你是App开发者（插件使用者），你可以通过修改这些变量来定制自己的插件主题，实现自定义主题功能\r\n *\r\n * 如果你的项目同样使用了scss预处理，你也可以直接在你的 scss 代码中使用如下变量，同时无需 import 这个文件\r\n */\r\n/* 颜色变量 */\r\n/* 行为相关颜色 */\r\n/* 文字基本颜色 */\r\n/* 背景颜色 */\r\n/* 边框颜色 */\r\n/* 尺寸变量 */\r\n/* 文字尺寸 */\r\n/* 图片尺寸 */\r\n/* Border Radius */\r\n/* 水平间距 */\r\n/* 垂直间距 */\r\n/* 透明度 */\r\n/* 文章场景相关 */.uv-status-bar[data-v-2453ff08]{width:100%}',
        "",
      ]),
      (e.exports = n);
  },
  9463: function (e, n, t) {
    "use strict";
    t("6a54");
    var a = t("3639").default,
      i = t("f5bd").default;
    Object.defineProperty(n, "__esModule", { value: !0 }),
      (n.default = void 0),
      t("fd3c"),
      t("dc8a"),
      t("bf0f"),
      t("5c47"),
      t("5ef2"),
      t("aa9c"),
      t("dd2b");
    var o = i(t("9b1b")),
      r = a(t("a991")),
      s = a(t("1509")),
      u = i(t("8d8b")),
      c = i(t("89e3")),
      l = i(t("0368")),
      d = {
        props: {
          customStyle: {
            type: [Object, String],
            default: function () {
              return {};
            },
          },
          customClass: { type: String, default: "" },
          url: { type: String, default: "" },
          linkType: { type: String, default: "navigateTo" },
        },
        data: function () {
          return {};
        },
        onLoad: function () {
          this.$uv.getRect = this.$uvGetRect;
        },
        created: function () {
          this.$uv.getRect = this.$uvGetRect;
        },
        computed: {
          $uv: function () {
            var e, n, t;
            return (0, o.default)(
              (0, o.default)({}, r),
              {},
              {
                test: s,
                route: u.default,
                debounce: c.default,
                throttle: l.default,
                unit:
                  null === (e = uni) ||
                  void 0 === e ||
                  null === (n = e.$uv) ||
                  void 0 === n ||
                  null === (t = n.config) ||
                  void 0 === t
                    ? void 0
                    : t.unit,
              },
            );
          },
          bem: function () {
            return function (e, n, t) {
              var a = this,
                i = "uv-".concat(e, "--"),
                o = {};
              return (
                n &&
                  n.map(function (e) {
                    o[i + a[e]] = !0;
                  }),
                t &&
                  t.map(function (e) {
                    a[e] ? (o[i + e] = a[e]) : delete o[i + e];
                  }),
                Object.keys(o)
              );
            };
          },
        },
        methods: {
          openPage: function () {
            var e =
                arguments.length > 0 && void 0 !== arguments[0]
                  ? arguments[0]
                  : "url",
              n = this[e];
            n && uni[this.linkType]({ url: n });
          },
          $uvGetRect: function (e, n) {
            var t = this;
            return new Promise(function (a) {
              uni
                .createSelectorQuery()
                .in(t)
                [n ? "selectAll" : "select"](e)
                .boundingClientRect(function (e) {
                  n && Array.isArray(e) && e.length && a(e), !n && e && a(e);
                })
                .exec();
            });
          },
          getParentData: function () {
            var e = this,
              n =
                arguments.length > 0 && void 0 !== arguments[0]
                  ? arguments[0]
                  : "";
            this.parent || (this.parent = {}),
              (this.parent = this.$uv.$parent.call(this, n)),
              this.parent.children &&
                -1 === this.parent.children.indexOf(this) &&
                this.parent.children.push(this),
              this.parent &&
                this.parentData &&
                Object.keys(this.parentData).map(function (n) {
                  e.parentData[n] = e.parent[n];
                });
          },
          preventEvent: function (e) {
            e && "function" === typeof e.stopPropagation && e.stopPropagation();
          },
          noop: function (e) {
            this.preventEvent(e);
          },
        },
        onReachBottom: function () {
          uni.$emit("uvOnReachBottom");
        },
        beforeDestroy: function () {
          var e = this;
          if (this.parent && s.array(this.parent.children)) {
            var n = this.parent.children;
            n.map(function (t, a) {
              t === e && n.splice(a, 1);
            });
          }
        },
        unmounted: function () {
          var e = this;
          if (this.parent && s.array(this.parent.children)) {
            var n = this.parent.children;
            n.map(function (t, a) {
              t === e && n.splice(a, 1);
            });
          }
        },
      };
    n.default = d;
  },
  9527: function (e, n, t) {
    "use strict";
    t.r(n);
    var a = t("5118"),
      i = t.n(a);
    for (var o in a)
      ["default"].indexOf(o) < 0 &&
        (function (e) {
          t.d(n, e, function () {
            return a[e];
          });
        })(o);
    n["default"] = i.a;
  },
  9766: function (e, n, t) {
    "use strict";
    t("6a54");
    var a = t("f5bd").default;
    Object.defineProperty(n, "__esModule", { value: !0 }),
      (n.default = void 0),
      t("64aa"),
      t("5c47"),
      t("af8f");
    var i,
      o,
      r = a(t("9b1b")),
      s = {
        props: (0, r.default)(
          {
            value: { type: [String, Number], default: "" },
            modelValue: { type: [String, Number], default: "" },
            shape: { type: String, default: "round" },
            bgColor: { type: String, default: "#f2f2f2" },
            placeholder: { type: String, default: "请输入关键字" },
            clearabled: { type: Boolean, default: !0 },
            focus: { type: Boolean, default: !1 },
            showAction: { type: Boolean, default: !0 },
            actionStyle: {
              type: Object,
              default: function () {
                return {};
              },
            },
            actionText: { type: String, default: "搜索" },
            inputAlign: { type: String, default: "left" },
            inputStyle: {
              type: Object,
              default: function () {
                return {};
              },
            },
            disabled: { type: Boolean, default: !1 },
            borderColor: { type: String, default: "transparent" },
            searchIconColor: { type: String, default: "#909399" },
            color: { type: String, default: "#606266" },
            placeholderColor: { type: String, default: "#909399" },
            searchIcon: { type: String, default: "search" },
            searchIconSize: { type: [Number, String], default: 22 },
            margin: { type: String, default: "0" },
            animation: { type: Boolean, default: !1 },
            maxlength: { type: [String, Number], default: -1 },
            height: { type: [String, Number], default: 32 },
            label: { type: [String, Number, null], default: null },
            boxStyle: {
              type: [String, Object],
              default: function () {
                return {};
              },
            },
          },
          null === (i = uni.$uv) ||
            void 0 === i ||
            null === (o = i.props) ||
            void 0 === o
            ? void 0
            : o.search,
        ),
      };
    n.default = s;
  },
  9767: function (e, n, t) {
    "use strict";
    t.d(n, "b", function () {
      return a;
    }),
      t.d(n, "c", function () {
        return i;
      }),
      t.d(n, "a", function () {});
    var a = function () {
        var e = this.$createElement,
          n = this._self._c || e;
        return n("App", { attrs: { keepAliveInclude: this.keepAliveInclude } });
      },
      i = [];
  },
  "98ed": function (e, n, t) {
    "use strict";
    t.r(n);
    var a = t("c653"),
      i = t("ea33");
    for (var o in i)
      ["default"].indexOf(o) < 0 &&
        (function (e) {
          t.d(n, e, function () {
            return i[e];
          });
        })(o);
    t("7dd5");
    var r = t("828b"),
      s = Object(r["a"])(
        i["default"],
        a["b"],
        a["c"],
        !1,
        null,
        "116f9d20",
        null,
        !1,
        a["a"],
        void 0,
      );
    n["default"] = s.exports;
  },
  "992d": function (e, n, t) {
    "use strict";
    t("6a54");
    var a = t("f5bd").default;
    Object.defineProperty(n, "__esModule", { value: !0 }),
      (n.default = void 0),
      t("64aa");
    var i,
      o,
      r = a(t("9b1b")),
      s = {
        props: (0, r.default)(
          {
            name: { type: [String, Number, null], default: null },
            icon: { icon: String, default: "" },
            iconSize: { type: [String, Number], default: "" },
            badge: { type: [String, Number, null], default: null },
            dot: { type: Boolean, default: !1 },
            text: { type: String, default: "" },
            badgeStyle: {
              type: [Object, String],
              default: "top: 6px;right:2px;",
            },
          },
          null === (i = uni.$uv) ||
            void 0 === i ||
            null === (o = i.props) ||
            void 0 === o
            ? void 0
            : o.tabbarItem,
        ),
      };
    n.default = s;
  },
  "9a98": function (e, n, t) {
    "use strict";
    var a = t("e0a2"),
      i = t.n(a);
    i.a;
  },
  "9b17": function (e, n, t) {
    "use strict";
    t("6a54"),
      Object.defineProperty(n, "__esModule", { value: !0 }),
      (n.default = function (e) {
        return /^([a-z][a-z\d+\-.]*:)?\/\//i.test(e);
      }),
      t("5c47"),
      t("0506");
  },
  "9ba2": function (e, n, t) {
    "use strict";
    t("6a54");
    var a = t("f5bd").default;
    Object.defineProperty(n, "__esModule", { value: !0 }),
      (n.createAnimation = function (e, n) {
        if (!n) return;
        return clearTimeout(n.timer), new s(e, n);
      }),
      t("4626"),
      t("5ac7"),
      t("c223"),
      t("bf0f"),
      t("2797");
    var i = a(t("9b1b")),
      o = a(t("80b1")),
      r = a(t("efe5")),
      s = (function () {
        function e(n, t) {
          (0, o.default)(this, e),
            (this.options = n),
            (this.animation = uni.createAnimation((0, i.default)({}, n))),
            (this.currentStepAnimates = {}),
            (this.next = 0),
            (this.$ = t);
        }
        return (
          (0, r.default)(e, [
            {
              key: "_nvuePushAnimates",
              value: function (e, n) {
                var t = this.currentStepAnimates[this.next],
                  a = {};
                if (((a = t || { styles: {}, config: {} }), u.includes(e))) {
                  a.styles.transform || (a.styles.transform = "");
                  var i = "";
                  "rotate" === e && (i = "deg"),
                    (a.styles.transform += ""
                      .concat(e, "(")
                      .concat(n + i, ") "));
                } else a.styles[e] = "".concat(n);
                this.currentStepAnimates[this.next] = a;
              },
            },
            {
              key: "_animateRun",
              value: function () {
                var e =
                    arguments.length > 0 && void 0 !== arguments[0]
                      ? arguments[0]
                      : {},
                  n =
                    arguments.length > 1 && void 0 !== arguments[1]
                      ? arguments[1]
                      : {},
                  t = this.$.$refs["ani"].ref;
                if (t)
                  return new Promise(function (a, o) {
                    nvueAnimation.transition(
                      t,
                      (0, i.default)({ styles: e }, n),
                      function (e) {
                        a();
                      },
                    );
                  });
              },
            },
            {
              key: "_nvueNextAnimate",
              value: function (e) {
                var n = this,
                  t =
                    arguments.length > 1 && void 0 !== arguments[1]
                      ? arguments[1]
                      : 0,
                  a = arguments.length > 2 ? arguments[2] : void 0,
                  i = e[t];
                if (i) {
                  var o = i.styles,
                    r = i.config;
                  this._animateRun(o, r).then(function () {
                    (t += 1), n._nvueNextAnimate(e, t, a);
                  });
                } else
                  (this.currentStepAnimates = {}),
                    "function" === typeof a && a(),
                    (this.isEnd = !0);
              },
            },
            {
              key: "step",
              value: function () {
                var e =
                  arguments.length > 0 && void 0 !== arguments[0]
                    ? arguments[0]
                    : {};
                return this.animation.step(e), this;
              },
            },
            {
              key: "run",
              value: function (e) {
                (this.$.animationData = this.animation.export()),
                  (this.$.timer = setTimeout(function () {
                    "function" === typeof e && e();
                  }, this.$.durationTime));
              },
            },
          ]),
          e
        );
      })(),
      u = [
        "matrix",
        "matrix3d",
        "rotate",
        "rotate3d",
        "rotateX",
        "rotateY",
        "rotateZ",
        "scale",
        "scale3d",
        "scaleX",
        "scaleY",
        "scaleZ",
        "skew",
        "skewX",
        "skewY",
        "translate",
        "translate3d",
        "translateX",
        "translateY",
        "translateZ",
      ];
    u.concat(
      ["opacity", "backgroundColor"],
      ["width", "height", "left", "right", "top", "bottom"],
    ).forEach(function (e) {
      s.prototype[e] = function () {
        var n;
        return (n = this.animation)[e].apply(n, arguments), this;
      };
    });
  },
  "9e89": function (e, n, t) {
    "use strict";
    t.d(n, "b", function () {
      return a;
    }),
      t.d(n, "c", function () {
        return i;
      }),
      t.d(n, "a", function () {});
    var a = function () {
        var e = this.$createElement,
          n = this._self._c || e;
        return n("v-uni-view", {
          staticClass: "uv-line",
          style: [this.lineStyle],
        });
      },
      i = [];
  },
  a329: function (e, n, t) {
    "use strict";
    t("6a54");
    var a = t("f5bd").default;
    Object.defineProperty(n, "__esModule", { value: !0 }), (n.default = void 0);
    var i = a(t("d755"));
    n.default = function (e) {
      return (0, i.default)(e);
    };
  },
  a823: function (e, n, t) {
    "use strict";
    t("6a54");
    var a = t("f5bd").default;
    Object.defineProperty(n, "__esModule", { value: !0 }), (n.default = void 0);
    var i = a(t("9b1b"));
    t("bf0f"), t("2797");
    var o = t("117a"),
      r = function (e, n, t) {
        var a = {};
        return (
          e.forEach(function (e) {
            (0, o.isUndefined)(t[e])
              ? (0, o.isUndefined)(n[e]) || (a[e] = n[e])
              : (a[e] = t[e]);
          }),
          a
        );
      };
    n.default = function (e) {
      var n =
          arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : {},
        t = n.method || e.method || "GET",
        a = {
          baseURL: n.baseURL || e.baseURL || "",
          method: t,
          url: n.url || "",
          params: n.params || {},
          custom: (0, i.default)(
            (0, i.default)({}, e.custom || {}),
            n.custom || {},
          ),
          header: (0, o.deepMerge)(e.header || {}, n.header || {}),
        },
        s = [
          "getTask",
          "validateStatus",
          "paramsSerializer",
          "forcedJSONParsing",
        ];
      if (
        ((a = (0, i.default)((0, i.default)({}, a), r(s, e, n))),
        "DOWNLOAD" === t)
      ) {
        var u = ["timeout"];
        a = (0, i.default)((0, i.default)({}, a), r(u, e, n));
      } else if ("UPLOAD" === t) {
        delete a.header["content-type"], delete a.header["Content-Type"];
        var c = ["files", "file", "filePath", "name", "timeout", "formData"];
        c.forEach(function (e) {
          (0, o.isUndefined)(n[e]) || (a[e] = n[e]);
        }),
          (0, o.isUndefined)(a.timeout) &&
            !(0, o.isUndefined)(e.timeout) &&
            (a["timeout"] = e["timeout"]);
      } else {
        var l = [
          "data",
          "timeout",
          "dataType",
          "responseType",
          "withCredentials",
        ];
        a = (0, i.default)((0, i.default)({}, a), r(l, e, n));
      }
      return a;
    };
  },
  a991: function (e, n, t) {
    "use strict";
    t("6a54");
    var a = t("f5bd").default;
    Object.defineProperty(n, "__esModule", { value: !0 }),
      (n.$parent = u),
      (n.addStyle = function (e) {
        var n =
          arguments.length > 1 && void 0 !== arguments[1]
            ? arguments[1]
            : "object";
        if (
          (0, r.empty)(e) ||
          ("object" === (0, o.default)(e) && "object" === n) ||
          ("string" === n && "string" === typeof e)
        )
          return e;
        if ("object" === n) {
          e = d(e);
          for (var t = e.split(";"), a = {}, i = 0; i < t.length; i++)
            if (t[i]) {
              var s = t[i].split(":");
              a[d(s[0])] = d(s[1]);
            }
          return a;
        }
        var u = "";
        for (var c in e) {
          var l = c.replace(/([A-Z])/g, "-$1").toLowerCase();
          u += "".concat(l, ":").concat(e[c], ";");
        }
        return d(u);
      }),
      (n.addUnit = function () {
        var e,
          n,
          t,
          a,
          i,
          o,
          s =
            arguments.length > 0 && void 0 !== arguments[0]
              ? arguments[0]
              : "auto",
          u =
            arguments.length > 1 && void 0 !== arguments[1]
              ? arguments[1]
              : null !== (e = uni) &&
                  void 0 !== e &&
                  null !== (n = e.$uv) &&
                  void 0 !== n &&
                  null !== (t = n.config) &&
                  void 0 !== t &&
                  t.unit
                ? null === (a = uni) ||
                  void 0 === a ||
                  null === (i = a.$uv) ||
                  void 0 === i ||
                  null === (o = i.config) ||
                  void 0 === o
                  ? void 0
                  : o.unit
                : "px";
        return (s = String(s)), (0, r.number)(s) ? "".concat(s).concat(u) : s;
      }),
      (n.deepClone = c),
      (n.deepMerge = function e() {
        var n =
            arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : {},
          t =
            arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : {};
        if (
          ((n = c(n)),
          "object" !== (0, o.default)(n) ||
            null === n ||
            "object" !== (0, o.default)(t) ||
            null === t)
        )
          return n;
        var a = Array.isArray(n) ? n.slice() : Object.assign({}, n);
        for (var i in t)
          if (t.hasOwnProperty(i)) {
            var r = t[i],
              s = a[i];
            r instanceof Date
              ? (a[i] = new Date(r))
              : r instanceof RegExp
                ? (a[i] = new RegExp(r))
                : r instanceof Map
                  ? (a[i] = new Map(r))
                  : r instanceof Set
                    ? (a[i] = new Set(r))
                    : "object" === (0, o.default)(r) && null !== r
                      ? (a[i] = e(s, r))
                      : (a[i] = r);
          }
        return a;
      }),
      (n.error = function (e) {
        0;
      }),
      (n.formValidate = function (e, n) {
        var t = u.call(e, "uv-form-item"),
          a = u.call(e, "uv-form");
        t && a && a.validateField(t.prop, function () {}, n);
      }),
      (n.getDuration = function (e) {
        var n =
            !(arguments.length > 1 && void 0 !== arguments[1]) || arguments[1],
          t = parseInt(e);
        if (n) return /s$/.test(e) ? e : "".concat(e, e > 30 ? "ms" : "s");
        return /ms$/.test(e) ? t : /s$/.test(e) ? (t > 30 ? t : 1e3 * t) : t;
      }),
      (n.getHistoryPage = function () {
        var e =
            arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : 0,
          n = getCurrentPages(),
          t = n.length;
        return n[t - 1 + e];
      }),
      (n.getProperty = function (e, n) {
        if (!e) return;
        if ("string" !== typeof n || "" === n) return "";
        if (-1 !== n.indexOf(".")) {
          for (
            var t = n.split("."), a = e[t[0]] || {}, i = 1;
            i < t.length;
            i++
          )
            a && (a = a[t[i]]);
          return a;
        }
        return e[n];
      }),
      (n.getPx = function (e) {
        var n = arguments.length > 1 && void 0 !== arguments[1] && arguments[1];
        if ((0, r.number)(e)) return n ? "".concat(e, "px") : Number(e);
        if (/(rpx|upx)$/.test(e))
          return n
            ? "".concat(uni.upx2px(parseInt(e)), "px")
            : Number(uni.upx2px(parseInt(e)));
        return n ? "".concat(parseInt(e), "px") : parseInt(e);
      }),
      (n.guid = function () {
        var e =
            arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : 32,
          n =
            !(arguments.length > 1 && void 0 !== arguments[1]) || arguments[1],
          t =
            arguments.length > 2 && void 0 !== arguments[2]
              ? arguments[2]
              : null,
          a =
            "0123456789ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz".split(
              "",
            ),
          i = [];
        if (((t = t || a.length), e))
          for (var o = 0; o < e; o++) i[o] = a[0 | (Math.random() * t)];
        else {
          var r;
          (i[8] = i[13] = i[18] = i[23] = "-"), (i[14] = "4");
          for (var s = 0; s < 36; s++)
            i[s] ||
              ((r = 0 | (16 * Math.random())),
              (i[s] = a[19 == s ? (3 & r) | 8 : r]));
        }
        if (n) return i.shift(), "u".concat(i.join(""));
        return i.join("");
      }),
      (n.os = function () {
        return uni.getSystemInfoSync().platform.toLowerCase();
      }),
      (n.padZero = function (e) {
        return "00".concat(e).slice(-2);
      }),
      (n.page = function () {
        var e,
          n = getCurrentPages(),
          t = null === (e = n[n.length - 1]) || void 0 === e ? void 0 : e.route;
        return "/".concat(t || "");
      }),
      (n.pages = function () {
        var e = getCurrentPages();
        return e;
      }),
      (n.priceFormat = function (e) {
        var n =
            arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : 0,
          t =
            arguments.length > 2 && void 0 !== arguments[2]
              ? arguments[2]
              : ".",
          a =
            arguments.length > 3 && void 0 !== arguments[3]
              ? arguments[3]
              : ",";
        e = "".concat(e).replace(/[^0-9+-Ee.]/g, "");
        var i = isFinite(+e) ? +e : 0,
          o = isFinite(+n) ? Math.abs(n) : 0,
          r = "undefined" === typeof a ? "," : a,
          u = "undefined" === typeof t ? "." : t,
          c = "";
        c = (o ? (0, s.round)(i, o) + "" : "".concat(Math.round(i))).split(".");
        var l = /(-?\d+)(\d{3})/;
        while (l.test(c[0])) c[0] = c[0].replace(l, "$1".concat(r, "$2"));
        (c[1] || "").length < o &&
          ((c[1] = c[1] || ""),
          (c[1] += new Array(o - c[1].length + 1).join("0")));
        return c.join(u);
      }),
      (n.queryParams = function () {
        var e =
            arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : {},
          n =
            !(arguments.length > 1 && void 0 !== arguments[1]) || arguments[1],
          t =
            arguments.length > 2 && void 0 !== arguments[2]
              ? arguments[2]
              : "brackets",
          a = n ? "?" : "",
          i = [];
        -1 == ["indices", "brackets", "repeat", "comma"].indexOf(t) &&
          (t = "brackets");
        var o = function (n) {
          var a = e[n];
          if (["", void 0, null].indexOf(a) >= 0) return "continue";
          if (a.constructor === Array)
            switch (t) {
              case "indices":
                for (var o = 0; o < a.length; o++)
                  i.push("".concat(n, "[").concat(o, "]=").concat(a[o]));
                break;
              case "brackets":
                a.forEach(function (e) {
                  i.push("".concat(n, "[]=").concat(e));
                });
                break;
              case "repeat":
                a.forEach(function (e) {
                  i.push("".concat(n, "=").concat(e));
                });
                break;
              case "comma":
                var r = "";
                a.forEach(function (e) {
                  r += (r ? "," : "") + e;
                }),
                  i.push("".concat(n, "=").concat(r));
                break;
              default:
                a.forEach(function (e) {
                  i.push("".concat(n, "[]=").concat(e));
                });
            }
          else i.push("".concat(n, "=").concat(a));
        };
        for (var r in e) o(r);
        return i.length ? a + i.join("&") : "";
      }),
      (n.random = function (e, n) {
        if (e >= 0 && n > 0 && n >= e) {
          var t = n - e + 1;
          return Math.floor(Math.random() * t + e);
        }
        return 0;
      }),
      (n.randomArray = function () {
        var e =
          arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : [];
        return e.sort(function () {
          return Math.random() - 0.5;
        });
      }),
      (n.range = function () {
        var e =
            arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : 0,
          n =
            arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : 0,
          t =
            arguments.length > 2 && void 0 !== arguments[2] ? arguments[2] : 0;
        return Math.max(e, Math.min(n, Number(t)));
      }),
      (n.setConfig = function (e) {
        var n = e.props,
          t = void 0 === n ? {} : n,
          a = e.config,
          i = void 0 === a ? {} : a,
          o = e.color,
          r = void 0 === o ? {} : o,
          s = e.zIndex,
          u = void 0 === s ? {} : s,
          c = uni.$uv.deepMerge;
        (uni.$uv.config = c(uni.$uv.config, i)),
          (uni.$uv.props = c(uni.$uv.props, t)),
          (uni.$uv.color = c(uni.$uv.color, r)),
          (uni.$uv.zIndex = c(uni.$uv.zIndex, u));
      }),
      (n.setProperty = function (e, n, t) {
        if (!e) return;
        if ("string" !== typeof n || "" === n);
        else if (-1 !== n.indexOf(".")) {
          var a = n.split(".");
          (function e(n, t, a) {
            if (1 !== t.length)
              while (t.length > 1) {
                var i = t[0];
                (n[i] && "object" === (0, o.default)(n[i])) || (n[i] = {});
                t.shift();
                e(n[i], t, a);
              }
            else n[t[0]] = a;
          })(e, a, t);
        } else e[n] = t;
      }),
      (n.sleep = function () {
        var e =
          arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : 30;
        return new Promise(function (n) {
          setTimeout(function () {
            n();
          }, e);
        });
      }),
      (n.sys = function () {
        return uni.getSystemInfoSync();
      }),
      (n.timeFormat = l),
      (n.timeFrom = function () {
        var e =
            arguments.length > 0 && void 0 !== arguments[0]
              ? arguments[0]
              : null,
          n =
            arguments.length > 1 && void 0 !== arguments[1]
              ? arguments[1]
              : "yyyy-mm-dd";
        null == e && (e = Number(new Date()));
        (e = parseInt(e)), 10 == e.toString().length && (e *= 1e3);
        var t = new Date().getTime() - e;
        t = parseInt(t / 1e3);
        var a = "";
        switch (!0) {
          case t < 300:
            a = "刚刚";
            break;
          case t >= 300 && t < 3600:
            a = "".concat(parseInt(t / 60), "分钟前");
            break;
          case t >= 3600 && t < 86400:
            a = "".concat(parseInt(t / 3600), "小时前");
            break;
          case t >= 86400 && t < 2592e3:
            a = "".concat(parseInt(t / 86400), "天前");
            break;
          default:
            a =
              !1 === n
                ? t >= 2592e3 && t < 31536e3
                  ? "".concat(parseInt(t / 2592e3), "个月前")
                  : "".concat(parseInt(t / 31536e3), "年前")
                : l(e, n);
        }
        return a;
      }),
      (n.toast = function (e) {
        var n =
          arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : 2e3;
        uni.showToast({ title: String(e), icon: "none", duration: n });
      }),
      (n.trim = d),
      (n.type2icon = function () {
        var e =
            arguments.length > 0 && void 0 !== arguments[0]
              ? arguments[0]
              : "success",
          n = arguments.length > 1 && void 0 !== arguments[1] && arguments[1];
        -1 == ["primary", "info", "error", "warning", "success"].indexOf(e) &&
          (e = "success");
        var t = "";
        switch (e) {
          case "primary":
            t = "info-circle";
            break;
          case "info":
            t = "info-circle";
            break;
          case "error":
            t = "close-circle";
            break;
          case "warning":
            t = "error-circle";
            break;
          case "success":
            t = "checkmark-circle";
            break;
          default:
            t = "checkmark-circle";
        }
        n && (t += "-fill");
        return t;
      });
    var i = a(t("5de6")),
      o = a(t("fcf3"));
    t("64aa"),
      t("5c47"),
      t("0506"),
      t("e966"),
      t("bf0f"),
      t("a1c1"),
      t("c223"),
      t("18f7"),
      t("d0af"),
      t("de6c"),
      t("23f4"),
      t("7d2f"),
      t("9c4e"),
      t("ab80"),
      t("c1a3"),
      t("08eb"),
      t("f3f7"),
      t("fd3c"),
      t("926e"),
      t("0829"),
      t("f7a5"),
      t("4100"),
      t("795c"),
      t("7a76"),
      t("c9b5"),
      t("0c26"),
      t("4626"),
      t("5ac7"),
      t("5ef2"),
      t("aa9c"),
      t("2797");
    var r = t("1509"),
      s = t("c5a3");
    function u() {
      var e =
          arguments.length > 0 && void 0 !== arguments[0]
            ? arguments[0]
            : void 0,
        n = this.$parent;
      while (n) {
        if (!n.$options || n.$options.name === e) return n;
        n = n.$parent;
      }
      return !1;
    }
    function c(e) {
      var n,
        t =
          arguments.length > 1 && void 0 !== arguments[1]
            ? arguments[1]
            : new WeakMap();
      if (null === e || "object" !== (0, o.default)(e)) return e;
      if (t.has(e)) return t.get(e);
      if (e instanceof Date) n = new Date(e.getTime());
      else if (e instanceof RegExp) n = new RegExp(e);
      else if (e instanceof Map)
        n = new Map(
          Array.from(e, function (e) {
            var n = (0, i.default)(e, 2),
              a = n[0],
              o = n[1];
            return [a, c(o, t)];
          }),
        );
      else if (e instanceof Set)
        n = new Set(
          Array.from(e, function (e) {
            return c(e, t);
          }),
        );
      else if (Array.isArray(e))
        n = e.map(function (e) {
          return c(e, t);
        });
      else if ("[object Object]" === Object.prototype.toString.call(e)) {
        (n = Object.create(Object.getPrototypeOf(e))), t.set(e, n);
        for (var a = 0, r = Object.entries(e); a < r.length; a++) {
          var s = (0, i.default)(r[a], 2),
            u = s[0],
            l = s[1];
          n[u] = c(l, t);
        }
      } else n = Object.assign({}, e);
      return t.set(e, n), n;
    }
    function l() {
      var e,
        n =
          arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : null,
        t =
          arguments.length > 1 && void 0 !== arguments[1]
            ? arguments[1]
            : "yyyy-mm-dd";
      e = n
        ? /^\d{10}$/.test(
            null === n || void 0 === n ? void 0 : n.toString().trim(),
          )
          ? new Date(1e3 * n)
          : "string" === typeof n && /^\d+$/.test(n.trim())
            ? new Date(Number(n))
            : "string" === typeof n && n.includes("-") && !n.includes("T")
              ? new Date(n.replace(/-/g, "/"))
              : new Date(n)
        : new Date();
      var a = {
        y: e.getFullYear().toString(),
        m: (e.getMonth() + 1).toString().padStart(2, "0"),
        d: e.getDate().toString().padStart(2, "0"),
        h: e.getHours().toString().padStart(2, "0"),
        M: e.getMinutes().toString().padStart(2, "0"),
        s: e.getSeconds().toString().padStart(2, "0"),
      };
      for (var o in a) {
        var r = new RegExp("".concat(o, "+")).exec(t) || [],
          s = (0, i.default)(r, 1),
          u = s[0];
        if (u) {
          var c = "y" === o && 2 === u.length ? 2 : 0;
          t = t.replace(u, a[o].slice(c));
        }
      }
      return t;
    }
    function d(e) {
      var n =
        arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : "both";
      return (
        (e = String(e)),
        "both" == n
          ? e.replace(/^\s+|\s+$/g, "")
          : "left" == n
            ? e.replace(/^\s*/, "")
            : "right" == n
              ? e.replace(/(\s*$)/g, "")
              : "all" == n
                ? e.replace(/\s+/g, "")
                : e
      );
    }
    String.prototype.padStart ||
      (String.prototype.padStart = function (e) {
        var n =
          arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : " ";
        if ("[object String]" !== Object.prototype.toString.call(n))
          throw new TypeError("fillString must be String");
        var t = this;
        if (t.length >= e) return String(t);
        var a = e - t.length,
          i = Math.ceil(a / n.length);
        while ((i >>= 1)) (n += n), 1 === i && (n += n);
        return n.slice(0, a) + t;
      });
  },
  aa1a: function (e, n, t) {
    "use strict";
    t("6a54");
    var a = t("f5bd").default;
    Object.defineProperty(n, "__esModule", { value: !0 }),
      (n.default = void 0),
      t("64aa");
    var i,
      o,
      r = a(t("9b1b")),
      s = {
        props: (0, r.default)(
          {
            name: { type: String, default: "" },
            color: { type: String, default: "#606266" },
            size: { type: [String, Number], default: "16px" },
            bold: { type: Boolean, default: !1 },
            index: { type: [String, Number], default: null },
            hoverClass: { type: String, default: "" },
            customPrefix: { type: String, default: "uvicon" },
            label: { type: [String, Number], default: "" },
            labelPos: { type: String, default: "right" },
            labelSize: { type: [String, Number], default: "15px" },
            labelColor: { type: String, default: "#606266" },
            space: { type: [String, Number], default: "3px" },
            imgMode: { type: String, default: "aspectFit" },
            width: { type: [String, Number], default: "" },
            height: { type: [String, Number], default: "" },
            top: { type: [String, Number], default: 0 },
            stop: { type: Boolean, default: !1 },
          },
          null === (i = uni.$uv) ||
            void 0 === i ||
            null === (o = i.props) ||
            void 0 === o
            ? void 0
            : o.icon,
        ),
      };
    n.default = s;
  },
  ab99: function (e, n, t) {
    "use strict";
    t.r(n);
    var a = t("ddaa"),
      i = t.n(a);
    for (var o in a)
      ["default"].indexOf(o) < 0 &&
        (function (e) {
          t.d(n, e, function () {
            return a[e];
          });
        })(o);
    n["default"] = i.a;
  },
  ad5b: function (e, n, t) {
    var a = t("c86c");
    (n = a(!1)),
      n.push([
        e.i,
        ".status-bar[data-v-5117495a]{width:100%;background-color:initial /* 可根据需求调整 */}",
        "",
      ]),
      (e.exports = n);
  },
  ad8a: function (e, n, t) {
    var a = t("439e");
    a.__esModule && (a = a.default),
      "string" === typeof a && (a = [[e.i, a, ""]]),
      a.locals && (e.exports = a.locals);
    var i = t("967d").default;
    i("656ab871", a, !0, { sourceMap: !1, shadowMode: !1 });
  },
  affe: function (e, n, t) {
    "use strict";
    (function (e) {
      var n = t("f5bd").default;
      t("473f"), t("bf0f"), t("de6c"), t("5c47"), t("a1c1");
      var a = n(t("9b8e")),
        i = {
          keys: function () {
            return [];
          },
        };
      (e["____1F1B05A____"] = !0),
        delete e["____1F1B05A____"],
        (e.__uniConfig = {
          preloadRule: {
            "pages/index/index": { network: "all", packages: ["pages_sub1"] },
          },
          globalStyle: {
            navigationBarTextStyle: "black",
            navigationBarTitleText: "",
            navigationBarBackgroundColor: "#fff",
            backgroundColor: "#fff",
            rpxCalcMaxDeviceWidth: 0,
          },
          tabBar: {
            color: "#fff",
            borderStyle: "white",
            backgroundColor: "#fff",
            selectedColor: "#fff",
            list: [
              {
                pagePath: "pages/index/index",
                text: "首页",
                iconPath: "",
                selectedIconPath: "",
                redDot: !1,
                badge: "",
              },
              {
                pagePath: "pages/cat/index",
                text: "分类",
                iconPath: "",
                selectedIconPath: "",
                redDot: !1,
                badge: "",
              },
              {
                pagePath: "pages/index/daren",
                text: "达人",
                iconPath: "",
                selectedIconPath: "",
                redDot: !1,
                badge: "",
              },
              {
                pagePath: "pages/chat/list",
                text: "客服",
                iconPath: "",
                selectedIconPath: "",
                redDot: !1,
                badge: "",
              },
              {
                pagePath: "pages/user/index",
                text: "我的",
                iconPath: "",
                selectedIconPath: "",
                redDot: !1,
                badge: "",
              },
            ],
          },
          uniIdRouter: {},
        }),
        (e.__uniConfig.compilerVersion = "5.07"),
        (e.__uniConfig.darkmode = !1),
        (e.__uniConfig.themeConfig = {}),
        (e.__uniConfig.uniPlatform = "h5"),
        (e.__uniConfig.appId = "__UNI__1F1B05A"),
        (e.__uniConfig.appName = "游趣网络科技"),
        (e.__uniConfig.appVersion = "2.0.9"),
        (e.__uniConfig.appVersionCode = "209"),
        (e.__uniConfig.router = { mode: "hash", base: "/h5/" }),
        (e.__uniConfig.publicPath = "/h5/"),
        (e.__uniConfig["async"] = {
          loading: "AsyncLoading",
          error: "AsyncError",
          delay: 200,
          timeout: 6e4,
        }),
        (e.__uniConfig.debug = !1),
        (e.__uniConfig.networkTimeout = {
          request: 6e4,
          connectSocket: 6e4,
          uploadFile: 6e4,
          downloadFile: 6e4,
        }),
        (e.__uniConfig.sdkConfigs = {}),
        (e.__uniConfig.qqMapKey = void 0),
        (e.__uniConfig.googleMapKey = void 0),
        (e.__uniConfig.aMapKey = void 0),
        (e.__uniConfig.aMapSecurityJsCode = void 0),
        (e.__uniConfig.aMapServiceHost = void 0),
        (e.__uniConfig.locale = ""),
        (e.__uniConfig.fallbackLocale = void 0),
        (e.__uniConfig.locales = i.keys().reduce(function (e, n) {
          var t = n.replace(/\.\/(uni-app.)?(.*).json/, "$2"),
            a = i(n);
          return Object.assign(e[t] || (e[t] = {}), a.common || a), e;
        }, {})),
        (e.__uniConfig.nvue = { "flex-direction": "column" }),
        (e.__uniConfig.__webpack_chunk_load__ = t.e),
        a.default.component("pages-index-index", function (e) {
          var n = {
            component: Promise.all([
              t.e(
                "pages-active-goods~pages-active-turntable~pages-index-goods~pages-index-index~pages-pay-raffle~pages~c8bef51b",
              ),
              t.e(
                "pages-active-goods~pages-index-goods~pages-index-index~pages-user-index~pages-user-level",
              ),
              t.e("pages-index-index~pages_sub1-chat-info"),
              t.e("pages-index-index"),
            ])
              .then(
                function () {
                  return e(t("4648"));
                }.bind(null, t),
              )
              .catch(t.oe),
            delay: __uniConfig["async"].delay,
            timeout: __uniConfig["async"].timeout,
          };
          return (
            __uniConfig["async"]["loading"] &&
              (n.loading = {
                name: "SystemAsyncLoading",
                render: function (e) {
                  return e(__uniConfig["async"]["loading"]);
                },
              }),
            __uniConfig["async"]["error"] &&
              (n.error = {
                name: "SystemAsyncError",
                render: function (e) {
                  return e(__uniConfig["async"]["error"]);
                },
              }),
            n
          );
        }),
        a.default.component("pages-user-index", function (e) {
          var n = {
            component: Promise.all([
              t.e(
                "pages-agent-cash_score~pages-cat-list~pages-follow-index~pages-index-search~pages-pay-submit~pages-u~420041f8",
              ),
              t.e(
                "pages-user-apply~pages-user-certification~pages-user-huifu~pages-user-index~pages-user-level~pages-u~6bd29fe7",
              ),
              t.e(
                "pages-agent-cash_score~pages-pay-raffle~pages-pay-submit~pages-user-apply~pages-user-certification~p~2f537e91",
              ),
              t.e(
                "pages-active-goods~pages-index-goods~pages-index-index~pages-user-index~pages-user-level",
              ),
              t.e("pages-user-index"),
            ])
              .then(
                function () {
                  return e(t("9b74"));
                }.bind(null, t),
              )
              .catch(t.oe),
            delay: __uniConfig["async"].delay,
            timeout: __uniConfig["async"].timeout,
          };
          return (
            __uniConfig["async"]["loading"] &&
              (n.loading = {
                name: "SystemAsyncLoading",
                render: function (e) {
                  return e(__uniConfig["async"]["loading"]);
                },
              }),
            __uniConfig["async"]["error"] &&
              (n.error = {
                name: "SystemAsyncError",
                render: function (e) {
                  return e(__uniConfig["async"]["error"]);
                },
              }),
            n
          );
        }),
        a.default.component("pages-follow-index", function (e) {
          var n = {
            component: Promise.all([
              t.e(
                "pages-agent-cash_score~pages-cat-list~pages-follow-index~pages-index-search~pages-pay-submit~pages-u~420041f8",
              ),
              t.e("pages-follow-index"),
            ])
              .then(
                function () {
                  return e(t("0e25"));
                }.bind(null, t),
              )
              .catch(t.oe),
            delay: __uniConfig["async"].delay,
            timeout: __uniConfig["async"].timeout,
          };
          return (
            __uniConfig["async"]["loading"] &&
              (n.loading = {
                name: "SystemAsyncLoading",
                render: function (e) {
                  return e(__uniConfig["async"]["loading"]);
                },
              }),
            __uniConfig["async"]["error"] &&
              (n.error = {
                name: "SystemAsyncError",
                render: function (e) {
                  return e(__uniConfig["async"]["error"]);
                },
              }),
            n
          );
        }),
        a.default.component("pages-cat-index", function (e) {
          var n = {
            component: Promise.all([
              t.e(
                "pages-cat-index~pages-cat-index2~pages-pay-index~pages-pay-raffle~pages-pay-submit~pages_sub1-order-~58b36340",
              ),
              t.e("pages-cat-index~pages-cat-index2~pages_sub1-seller-message"),
              t.e("pages-cat-index"),
            ])
              .then(
                function () {
                  return e(t("f282"));
                }.bind(null, t),
              )
              .catch(t.oe),
            delay: __uniConfig["async"].delay,
            timeout: __uniConfig["async"].timeout,
          };
          return (
            __uniConfig["async"]["loading"] &&
              (n.loading = {
                name: "SystemAsyncLoading",
                render: function (e) {
                  return e(__uniConfig["async"]["loading"]);
                },
              }),
            __uniConfig["async"]["error"] &&
              (n.error = {
                name: "SystemAsyncError",
                render: function (e) {
                  return e(__uniConfig["async"]["error"]);
                },
              }),
            n
          );
        }),
        a.default.component("pages-cat-index2", function (e) {
          var n = {
            component: Promise.all([
              t.e(
                "pages-cat-index~pages-cat-index2~pages-pay-index~pages-pay-raffle~pages-pay-submit~pages_sub1-order-~58b36340",
              ),
              t.e("pages-cat-index~pages-cat-index2~pages_sub1-seller-message"),
              t.e("pages-cat-index2"),
            ])
              .then(
                function () {
                  return e(t("8fbf"));
                }.bind(null, t),
              )
              .catch(t.oe),
            delay: __uniConfig["async"].delay,
            timeout: __uniConfig["async"].timeout,
          };
          return (
            __uniConfig["async"]["loading"] &&
              (n.loading = {
                name: "SystemAsyncLoading",
                render: function (e) {
                  return e(__uniConfig["async"]["loading"]);
                },
              }),
            __uniConfig["async"]["error"] &&
              (n.error = {
                name: "SystemAsyncError",
                render: function (e) {
                  return e(__uniConfig["async"]["error"]);
                },
              }),
            n
          );
        }),
        a.default.component("pages-index-goods", function (e) {
          var n = {
            component: Promise.all([
              t.e(
                "pages-active-goods~pages-active-turntable~pages-index-goods~pages-index-index~pages-pay-raffle~pages~c8bef51b",
              ),
              t.e(
                "pages-active-goods~pages-index-goods~pages-index-index~pages-user-index~pages-user-level",
              ),
              t.e("pages-index-goods"),
            ])
              .then(
                function () {
                  return e(t("e8c3"));
                }.bind(null, t),
              )
              .catch(t.oe),
            delay: __uniConfig["async"].delay,
            timeout: __uniConfig["async"].timeout,
          };
          return (
            __uniConfig["async"]["loading"] &&
              (n.loading = {
                name: "SystemAsyncLoading",
                render: function (e) {
                  return e(__uniConfig["async"]["loading"]);
                },
              }),
            __uniConfig["async"]["error"] &&
              (n.error = {
                name: "SystemAsyncError",
                render: function (e) {
                  return e(__uniConfig["async"]["error"]);
                },
              }),
            n
          );
        }),
        a.default.component("pages-active-goods", function (e) {
          var n = {
            component: Promise.all([
              t.e(
                "pages-active-goods~pages-active-turntable~pages-index-goods~pages-index-index~pages-pay-raffle~pages~c8bef51b",
              ),
              t.e(
                "pages-active-goods~pages-index-goods~pages-index-index~pages-user-index~pages-user-level",
              ),
              t.e("pages-active-goods"),
            ])
              .then(
                function () {
                  return e(t("b72e"));
                }.bind(null, t),
              )
              .catch(t.oe),
            delay: __uniConfig["async"].delay,
            timeout: __uniConfig["async"].timeout,
          };
          return (
            __uniConfig["async"]["loading"] &&
              (n.loading = {
                name: "SystemAsyncLoading",
                render: function (e) {
                  return e(__uniConfig["async"]["loading"]);
                },
              }),
            __uniConfig["async"]["error"] &&
              (n.error = {
                name: "SystemAsyncError",
                render: function (e) {
                  return e(__uniConfig["async"]["error"]);
                },
              }),
            n
          );
        }),
        a.default.component("pages-active-order", function (e) {
          var n = {
            component: t
              .e("pages-active-order")
              .then(
                function () {
                  return e(t("73ec"));
                }.bind(null, t),
              )
              .catch(t.oe),
            delay: __uniConfig["async"].delay,
            timeout: __uniConfig["async"].timeout,
          };
          return (
            __uniConfig["async"]["loading"] &&
              (n.loading = {
                name: "SystemAsyncLoading",
                render: function (e) {
                  return e(__uniConfig["async"]["loading"]);
                },
              }),
            __uniConfig["async"]["error"] &&
              (n.error = {
                name: "SystemAsyncError",
                render: function (e) {
                  return e(__uniConfig["async"]["error"]);
                },
              }),
            n
          );
        }),
        a.default.component("pages-index-search", function (e) {
          var n = {
            component: Promise.all([
              t.e(
                "pages-agent-cash_score~pages-cat-list~pages-follow-index~pages-index-search~pages-pay-submit~pages-u~420041f8",
              ),
              t.e("pages-index-search"),
            ])
              .then(
                function () {
                  return e(t("31a4"));
                }.bind(null, t),
              )
              .catch(t.oe),
            delay: __uniConfig["async"].delay,
            timeout: __uniConfig["async"].timeout,
          };
          return (
            __uniConfig["async"]["loading"] &&
              (n.loading = {
                name: "SystemAsyncLoading",
                render: function (e) {
                  return e(__uniConfig["async"]["loading"]);
                },
              }),
            __uniConfig["async"]["error"] &&
              (n.error = {
                name: "SystemAsyncError",
                render: function (e) {
                  return e(__uniConfig["async"]["error"]);
                },
              }),
            n
          );
        }),
        a.default.component("pages-user-login", function (e) {
          var n = {
            component: t
              .e("pages-user-login")
              .then(
                function () {
                  return e(t("a9dc"));
                }.bind(null, t),
              )
              .catch(t.oe),
            delay: __uniConfig["async"].delay,
            timeout: __uniConfig["async"].timeout,
          };
          return (
            __uniConfig["async"]["loading"] &&
              (n.loading = {
                name: "SystemAsyncLoading",
                render: function (e) {
                  return e(__uniConfig["async"]["loading"]);
                },
              }),
            __uniConfig["async"]["error"] &&
              (n.error = {
                name: "SystemAsyncError",
                render: function (e) {
                  return e(__uniConfig["async"]["error"]);
                },
              }),
            n
          );
        }),
        a.default.component("pages-user-login_old", function (e) {
          var n = {
            component: Promise.all([
              t.e(
                "pages-agent-cash_score~pages-cat-list~pages-follow-index~pages-index-search~pages-pay-submit~pages-u~420041f8",
              ),
              t.e(
                "pages-user-bind_mobile~pages-user-bind_mobile_weapp~pages-user-login_old",
              ),
              t.e("pages-user-bind_mobile~pages-user-login_old"),
              t.e("pages-user-login_old"),
            ])
              .then(
                function () {
                  return e(t("9bd4"));
                }.bind(null, t),
              )
              .catch(t.oe),
            delay: __uniConfig["async"].delay,
            timeout: __uniConfig["async"].timeout,
          };
          return (
            __uniConfig["async"]["loading"] &&
              (n.loading = {
                name: "SystemAsyncLoading",
                render: function (e) {
                  return e(__uniConfig["async"]["loading"]);
                },
              }),
            __uniConfig["async"]["error"] &&
              (n.error = {
                name: "SystemAsyncError",
                render: function (e) {
                  return e(__uniConfig["async"]["error"]);
                },
              }),
            n
          );
        }),
        a.default.component("pages-cat-list", function (e) {
          var n = {
            component: Promise.all([
              t.e(
                "pages-agent-cash_score~pages-cat-list~pages-follow-index~pages-index-search~pages-pay-submit~pages-u~420041f8",
              ),
              t.e("pages-cat-list"),
            ])
              .then(
                function () {
                  return e(t("73e0"));
                }.bind(null, t),
              )
              .catch(t.oe),
            delay: __uniConfig["async"].delay,
            timeout: __uniConfig["async"].timeout,
          };
          return (
            __uniConfig["async"]["loading"] &&
              (n.loading = {
                name: "SystemAsyncLoading",
                render: function (e) {
                  return e(__uniConfig["async"]["loading"]);
                },
              }),
            __uniConfig["async"]["error"] &&
              (n.error = {
                name: "SystemAsyncError",
                render: function (e) {
                  return e(__uniConfig["async"]["error"]);
                },
              }),
            n
          );
        }),
        a.default.component("pages-index-seller", function (e) {
          var n = {
            component: t
              .e("pages-index-seller")
              .then(
                function () {
                  return e(t("f817"));
                }.bind(null, t),
              )
              .catch(t.oe),
            delay: __uniConfig["async"].delay,
            timeout: __uniConfig["async"].timeout,
          };
          return (
            __uniConfig["async"]["loading"] &&
              (n.loading = {
                name: "SystemAsyncLoading",
                render: function (e) {
                  return e(__uniConfig["async"]["loading"]);
                },
              }),
            __uniConfig["async"]["error"] &&
              (n.error = {
                name: "SystemAsyncError",
                render: function (e) {
                  return e(__uniConfig["async"]["error"]);
                },
              }),
            n
          );
        }),
        a.default.component("pages-index-daren", function (e) {
          var n = {
            component: t
              .e("pages-index-daren")
              .then(
                function () {
                  return e(t("d5dc"));
                }.bind(null, t),
              )
              .catch(t.oe),
            delay: __uniConfig["async"].delay,
            timeout: __uniConfig["async"].timeout,
          };
          return (
            __uniConfig["async"]["loading"] &&
              (n.loading = {
                name: "SystemAsyncLoading",
                render: function (e) {
                  return e(__uniConfig["async"]["loading"]);
                },
              }),
            __uniConfig["async"]["error"] &&
              (n.error = {
                name: "SystemAsyncError",
                render: function (e) {
                  return e(__uniConfig["async"]["error"]);
                },
              }),
            n
          );
        }),
        a.default.component("pages-pay-recharge", function (e) {
          var n = {
            component: t
              .e("pages-pay-recharge")
              .then(
                function () {
                  return e(t("840a"));
                }.bind(null, t),
              )
              .catch(t.oe),
            delay: __uniConfig["async"].delay,
            timeout: __uniConfig["async"].timeout,
          };
          return (
            __uniConfig["async"]["loading"] &&
              (n.loading = {
                name: "SystemAsyncLoading",
                render: function (e) {
                  return e(__uniConfig["async"]["loading"]);
                },
              }),
            __uniConfig["async"]["error"] &&
              (n.error = {
                name: "SystemAsyncError",
                render: function (e) {
                  return e(__uniConfig["async"]["error"]);
                },
              }),
            n
          );
        }),
        a.default.component("pages-pay-vip", function (e) {
          var n = {
            component: t
              .e("pages-pay-vip")
              .then(
                function () {
                  return e(t("82fd"));
                }.bind(null, t),
              )
              .catch(t.oe),
            delay: __uniConfig["async"].delay,
            timeout: __uniConfig["async"].timeout,
          };
          return (
            __uniConfig["async"]["loading"] &&
              (n.loading = {
                name: "SystemAsyncLoading",
                render: function (e) {
                  return e(__uniConfig["async"]["loading"]);
                },
              }),
            __uniConfig["async"]["error"] &&
              (n.error = {
                name: "SystemAsyncError",
                render: function (e) {
                  return e(__uniConfig["async"]["error"]);
                },
              }),
            n
          );
        }),
        a.default.component("pages-pay-deposit", function (e) {
          var n = {
            component: t
              .e("pages-pay-deposit")
              .then(
                function () {
                  return e(t("13f0"));
                }.bind(null, t),
              )
              .catch(t.oe),
            delay: __uniConfig["async"].delay,
            timeout: __uniConfig["async"].timeout,
          };
          return (
            __uniConfig["async"]["loading"] &&
              (n.loading = {
                name: "SystemAsyncLoading",
                render: function (e) {
                  return e(__uniConfig["async"]["loading"]);
                },
              }),
            __uniConfig["async"]["error"] &&
              (n.error = {
                name: "SystemAsyncError",
                render: function (e) {
                  return e(__uniConfig["async"]["error"]);
                },
              }),
            n
          );
        }),
        a.default.component("pages-pay-check_result", function (e) {
          var n = {
            component: t
              .e("pages-pay-check_result")
              .then(
                function () {
                  return e(t("09db"));
                }.bind(null, t),
              )
              .catch(t.oe),
            delay: __uniConfig["async"].delay,
            timeout: __uniConfig["async"].timeout,
          };
          return (
            __uniConfig["async"]["loading"] &&
              (n.loading = {
                name: "SystemAsyncLoading",
                render: function (e) {
                  return e(__uniConfig["async"]["loading"]);
                },
              }),
            __uniConfig["async"]["error"] &&
              (n.error = {
                name: "SystemAsyncError",
                render: function (e) {
                  return e(__uniConfig["async"]["error"]);
                },
              }),
            n
          );
        }),
        a.default.component("pages-pay-success", function (e) {
          var n = {
            component: t
              .e("pages-pay-success")
              .then(
                function () {
                  return e(t("3885"));
                }.bind(null, t),
              )
              .catch(t.oe),
            delay: __uniConfig["async"].delay,
            timeout: __uniConfig["async"].timeout,
          };
          return (
            __uniConfig["async"]["loading"] &&
              (n.loading = {
                name: "SystemAsyncLoading",
                render: function (e) {
                  return e(__uniConfig["async"]["loading"]);
                },
              }),
            __uniConfig["async"]["error"] &&
              (n.error = {
                name: "SystemAsyncError",
                render: function (e) {
                  return e(__uniConfig["async"]["error"]);
                },
              }),
            n
          );
        }),
        a.default.component("pages-alipay-index", function (e) {
          var n = {
            component: t
              .e("pages-alipay-index")
              .then(
                function () {
                  return e(t("065b"));
                }.bind(null, t),
              )
              .catch(t.oe),
            delay: __uniConfig["async"].delay,
            timeout: __uniConfig["async"].timeout,
          };
          return (
            __uniConfig["async"]["loading"] &&
              (n.loading = {
                name: "SystemAsyncLoading",
                render: function (e) {
                  return e(__uniConfig["async"]["loading"]);
                },
              }),
            __uniConfig["async"]["error"] &&
              (n.error = {
                name: "SystemAsyncError",
                render: function (e) {
                  return e(__uniConfig["async"]["error"]);
                },
              }),
            n
          );
        }),
        a.default.component("pages-alipay-paid", function (e) {
          var n = {
            component: t
              .e("pages-alipay-paid")
              .then(
                function () {
                  return e(t("5224"));
                }.bind(null, t),
              )
              .catch(t.oe),
            delay: __uniConfig["async"].delay,
            timeout: __uniConfig["async"].timeout,
          };
          return (
            __uniConfig["async"]["loading"] &&
              (n.loading = {
                name: "SystemAsyncLoading",
                render: function (e) {
                  return e(__uniConfig["async"]["loading"]);
                },
              }),
            __uniConfig["async"]["error"] &&
              (n.error = {
                name: "SystemAsyncError",
                render: function (e) {
                  return e(__uniConfig["async"]["error"]);
                },
              }),
            n
          );
        }),
        a.default.component("pages-user-withdraw", function (e) {
          var n = {
            component: Promise.all([
              t.e(
                "pages-agent-cash_score~pages-cat-list~pages-follow-index~pages-index-search~pages-pay-submit~pages-u~420041f8",
              ),
              t.e(
                "pages-agent-cash_score~pages-pay-raffle~pages-pay-submit~pages-user-apply~pages-user-certification~p~2f537e91",
              ),
              t.e("pages-user-withdraw"),
            ])
              .then(
                function () {
                  return e(t("b29b"));
                }.bind(null, t),
              )
              .catch(t.oe),
            delay: __uniConfig["async"].delay,
            timeout: __uniConfig["async"].timeout,
          };
          return (
            __uniConfig["async"]["loading"] &&
              (n.loading = {
                name: "SystemAsyncLoading",
                render: function (e) {
                  return e(__uniConfig["async"]["loading"]);
                },
              }),
            __uniConfig["async"]["error"] &&
              (n.error = {
                name: "SystemAsyncError",
                render: function (e) {
                  return e(__uniConfig["async"]["error"]);
                },
              }),
            n
          );
        }),
        a.default.component("pages-user-withdraw_log", function (e) {
          var n = {
            component: t
              .e("pages-user-withdraw_log")
              .then(
                function () {
                  return e(t("384a"));
                }.bind(null, t),
              )
              .catch(t.oe),
            delay: __uniConfig["async"].delay,
            timeout: __uniConfig["async"].timeout,
          };
          return (
            __uniConfig["async"]["loading"] &&
              (n.loading = {
                name: "SystemAsyncLoading",
                render: function (e) {
                  return e(__uniConfig["async"]["loading"]);
                },
              }),
            __uniConfig["async"]["error"] &&
              (n.error = {
                name: "SystemAsyncError",
                render: function (e) {
                  return e(__uniConfig["async"]["error"]);
                },
              }),
            n
          );
        }),
        a.default.component("pages-user-money_log", function (e) {
          var n = {
            component: t
              .e("pages-user-money_log")
              .then(
                function () {
                  return e(t("0f97"));
                }.bind(null, t),
              )
              .catch(t.oe),
            delay: __uniConfig["async"].delay,
            timeout: __uniConfig["async"].timeout,
          };
          return (
            __uniConfig["async"]["loading"] &&
              (n.loading = {
                name: "SystemAsyncLoading",
                render: function (e) {
                  return e(__uniConfig["async"]["loading"]);
                },
              }),
            __uniConfig["async"]["error"] &&
              (n.error = {
                name: "SystemAsyncError",
                render: function (e) {
                  return e(__uniConfig["async"]["error"]);
                },
              }),
            n
          );
        }),
        a.default.component("pages-user-order_log", function (e) {
          var n = {
            component: t
              .e("pages-user-order_log")
              .then(
                function () {
                  return e(t("93ef"));
                }.bind(null, t),
              )
              .catch(t.oe),
            delay: __uniConfig["async"].delay,
            timeout: __uniConfig["async"].timeout,
          };
          return (
            __uniConfig["async"]["loading"] &&
              (n.loading = {
                name: "SystemAsyncLoading",
                render: function (e) {
                  return e(__uniConfig["async"]["loading"]);
                },
              }),
            __uniConfig["async"]["error"] &&
              (n.error = {
                name: "SystemAsyncError",
                render: function (e) {
                  return e(__uniConfig["async"]["error"]);
                },
              }),
            n
          );
        }),
        a.default.component("pages-user-article", function (e) {
          var n = {
            component: Promise.all([
              t.e(
                "pages-active-goods~pages-active-turntable~pages-index-goods~pages-index-index~pages-pay-raffle~pages~c8bef51b",
              ),
              t.e("pages-user-article"),
            ])
              .then(
                function () {
                  return e(t("1e5de"));
                }.bind(null, t),
              )
              .catch(t.oe),
            delay: __uniConfig["async"].delay,
            timeout: __uniConfig["async"].timeout,
          };
          return (
            __uniConfig["async"]["loading"] &&
              (n.loading = {
                name: "SystemAsyncLoading",
                render: function (e) {
                  return e(__uniConfig["async"]["loading"]);
                },
              }),
            __uniConfig["async"]["error"] &&
              (n.error = {
                name: "SystemAsyncError",
                render: function (e) {
                  return e(__uniConfig["async"]["error"]);
                },
              }),
            n
          );
        }),
        a.default.component("pages-user-deposit_withdraw", function (e) {
          var n = {
            component: t
              .e("pages-user-deposit_withdraw")
              .then(
                function () {
                  return e(t("1db9"));
                }.bind(null, t),
              )
              .catch(t.oe),
            delay: __uniConfig["async"].delay,
            timeout: __uniConfig["async"].timeout,
          };
          return (
            __uniConfig["async"]["loading"] &&
              (n.loading = {
                name: "SystemAsyncLoading",
                render: function (e) {
                  return e(__uniConfig["async"]["loading"]);
                },
              }),
            __uniConfig["async"]["error"] &&
              (n.error = {
                name: "SystemAsyncError",
                render: function (e) {
                  return e(__uniConfig["async"]["error"]);
                },
              }),
            n
          );
        }),
        a.default.component("pages-user-certification", function (e) {
          var n = {
            component: Promise.all([
              t.e(
                "pages-agent-cash_score~pages-cat-list~pages-follow-index~pages-index-search~pages-pay-submit~pages-u~420041f8",
              ),
              t.e(
                "pages-user-apply~pages-user-certification~pages-user-huifu~pages-user-index~pages-user-level~pages-u~6bd29fe7",
              ),
              t.e(
                "pages-agent-cash_score~pages-pay-raffle~pages-pay-submit~pages-user-apply~pages-user-certification~p~2f537e91",
              ),
              t.e(
                "pages-user-certification~pages-user-personal~pages_sub1-order-audit_detail~pages_sub1-order-comment~~ea7a9f35",
              ),
              t.e("pages-user-certification"),
            ])
              .then(
                function () {
                  return e(t("334a"));
                }.bind(null, t),
              )
              .catch(t.oe),
            delay: __uniConfig["async"].delay,
            timeout: __uniConfig["async"].timeout,
          };
          return (
            __uniConfig["async"]["loading"] &&
              (n.loading = {
                name: "SystemAsyncLoading",
                render: function (e) {
                  return e(__uniConfig["async"]["loading"]);
                },
              }),
            __uniConfig["async"]["error"] &&
              (n.error = {
                name: "SystemAsyncError",
                render: function (e) {
                  return e(__uniConfig["async"]["error"]);
                },
              }),
            n
          );
        }),
        a.default.component("pages-user-huifu", function (e) {
          var n = {
            component: Promise.all([
              t.e(
                "pages-agent-cash_score~pages-cat-list~pages-follow-index~pages-index-search~pages-pay-submit~pages-u~420041f8",
              ),
              t.e(
                "pages-user-apply~pages-user-certification~pages-user-huifu~pages-user-index~pages-user-level~pages-u~6bd29fe7",
              ),
              t.e(
                "pages-agent-cash_score~pages-pay-raffle~pages-pay-submit~pages-user-apply~pages-user-certification~p~2f537e91",
              ),
              t.e(
                "pages-pay-raffle~pages-user-huifu~pages_sub1-kefu-service~pages_sub1-seller-index",
              ),
              t.e("pages-user-huifu"),
            ])
              .then(
                function () {
                  return e(t("fb95"));
                }.bind(null, t),
              )
              .catch(t.oe),
            delay: __uniConfig["async"].delay,
            timeout: __uniConfig["async"].timeout,
          };
          return (
            __uniConfig["async"]["loading"] &&
              (n.loading = {
                name: "SystemAsyncLoading",
                render: function (e) {
                  return e(__uniConfig["async"]["loading"]);
                },
              }),
            __uniConfig["async"]["error"] &&
              (n.error = {
                name: "SystemAsyncError",
                render: function (e) {
                  return e(__uniConfig["async"]["error"]);
                },
              }),
            n
          );
        }),
        a.default.component("pages-user-personal", function (e) {
          var n = {
            component: Promise.all([
              t.e(
                "pages-agent-cash_score~pages-cat-list~pages-follow-index~pages-index-search~pages-pay-submit~pages-u~420041f8",
              ),
              t.e(
                "pages-user-apply~pages-user-certification~pages-user-huifu~pages-user-index~pages-user-level~pages-u~6bd29fe7",
              ),
              t.e(
                "pages-agent-cash_score~pages-pay-raffle~pages-pay-submit~pages-user-apply~pages-user-certification~p~2f537e91",
              ),
              t.e(
                "pages-user-certification~pages-user-personal~pages_sub1-order-audit_detail~pages_sub1-order-comment~~ea7a9f35",
              ),
              t.e("pages-user-personal"),
            ])
              .then(
                function () {
                  return e(t("4f9c"));
                }.bind(null, t),
              )
              .catch(t.oe),
            delay: __uniConfig["async"].delay,
            timeout: __uniConfig["async"].timeout,
          };
          return (
            __uniConfig["async"]["loading"] &&
              (n.loading = {
                name: "SystemAsyncLoading",
                render: function (e) {
                  return e(__uniConfig["async"]["loading"]);
                },
              }),
            __uniConfig["async"]["error"] &&
              (n.error = {
                name: "SystemAsyncError",
                render: function (e) {
                  return e(__uniConfig["async"]["error"]);
                },
              }),
            n
          );
        }),
        a.default.component("pages-pay-index", function (e) {
          var n = {
            component: Promise.all([
              t.e(
                "pages-cat-index~pages-cat-index2~pages-pay-index~pages-pay-raffle~pages-pay-submit~pages_sub1-order-~58b36340",
              ),
              t.e("pages-pay-index"),
            ])
              .then(
                function () {
                  return e(t("511f"));
                }.bind(null, t),
              )
              .catch(t.oe),
            delay: __uniConfig["async"].delay,
            timeout: __uniConfig["async"].timeout,
          };
          return (
            __uniConfig["async"]["loading"] &&
              (n.loading = {
                name: "SystemAsyncLoading",
                render: function (e) {
                  return e(__uniConfig["async"]["loading"]);
                },
              }),
            __uniConfig["async"]["error"] &&
              (n.error = {
                name: "SystemAsyncError",
                render: function (e) {
                  return e(__uniConfig["async"]["error"]);
                },
              }),
            n
          );
        }),
        a.default.component("pages-pay-submit", function (e) {
          var n = {
            component: Promise.all([
              t.e(
                "pages-agent-cash_score~pages-cat-list~pages-follow-index~pages-index-search~pages-pay-submit~pages-u~420041f8",
              ),
              t.e(
                "pages-active-goods~pages-active-turntable~pages-index-goods~pages-index-index~pages-pay-raffle~pages~c8bef51b",
              ),
              t.e(
                "pages-agent-cash_score~pages-pay-raffle~pages-pay-submit~pages-user-apply~pages-user-certification~p~2f537e91",
              ),
              t.e(
                "pages-cat-index~pages-cat-index2~pages-pay-index~pages-pay-raffle~pages-pay-submit~pages_sub1-order-~58b36340",
              ),
              t.e("pages-pay-submit"),
            ])
              .then(
                function () {
                  return e(t("19f3"));
                }.bind(null, t),
              )
              .catch(t.oe),
            delay: __uniConfig["async"].delay,
            timeout: __uniConfig["async"].timeout,
          };
          return (
            __uniConfig["async"]["loading"] &&
              (n.loading = {
                name: "SystemAsyncLoading",
                render: function (e) {
                  return e(__uniConfig["async"]["loading"]);
                },
              }),
            __uniConfig["async"]["error"] &&
              (n.error = {
                name: "SystemAsyncError",
                render: function (e) {
                  return e(__uniConfig["async"]["error"]);
                },
              }),
            n
          );
        }),
        a.default.component("pages-pay-raffle", function (e) {
          var n = {
            component: Promise.all([
              t.e(
                "pages-active-goods~pages-active-turntable~pages-index-goods~pages-index-index~pages-pay-raffle~pages~c8bef51b",
              ),
              t.e(
                "pages-agent-cash_score~pages-pay-raffle~pages-pay-submit~pages-user-apply~pages-user-certification~p~2f537e91",
              ),
              t.e(
                "pages-cat-index~pages-cat-index2~pages-pay-index~pages-pay-raffle~pages-pay-submit~pages_sub1-order-~58b36340",
              ),
              t.e(
                "pages-pay-raffle~pages-user-huifu~pages_sub1-kefu-service~pages_sub1-seller-index",
              ),
              t.e("pages-pay-raffle"),
            ])
              .then(
                function () {
                  return e(t("310e"));
                }.bind(null, t),
              )
              .catch(t.oe),
            delay: __uniConfig["async"].delay,
            timeout: __uniConfig["async"].timeout,
          };
          return (
            __uniConfig["async"]["loading"] &&
              (n.loading = {
                name: "SystemAsyncLoading",
                render: function (e) {
                  return e(__uniConfig["async"]["loading"]);
                },
              }),
            __uniConfig["async"]["error"] &&
              (n.error = {
                name: "SystemAsyncError",
                render: function (e) {
                  return e(__uniConfig["async"]["error"]);
                },
              }),
            n
          );
        }),
        a.default.component("pages-index-incomer", function (e) {
          var n = {
            component: t
              .e("pages-index-incomer")
              .then(
                function () {
                  return e(t("b390"));
                }.bind(null, t),
              )
              .catch(t.oe),
            delay: __uniConfig["async"].delay,
            timeout: __uniConfig["async"].timeout,
          };
          return (
            __uniConfig["async"]["loading"] &&
              (n.loading = {
                name: "SystemAsyncLoading",
                render: function (e) {
                  return e(__uniConfig["async"]["loading"]);
                },
              }),
            __uniConfig["async"]["error"] &&
              (n.error = {
                name: "SystemAsyncError",
                render: function (e) {
                  return e(__uniConfig["async"]["error"]);
                },
              }),
            n
          );
        }),
        a.default.component("pages-active-turntable", function (e) {
          var n = {
            component: Promise.all([
              t.e(
                "pages-active-goods~pages-active-turntable~pages-index-goods~pages-index-index~pages-pay-raffle~pages~c8bef51b",
              ),
              t.e("pages-active-turntable"),
            ])
              .then(
                function () {
                  return e(t("1c8c"));
                }.bind(null, t),
              )
              .catch(t.oe),
            delay: __uniConfig["async"].delay,
            timeout: __uniConfig["async"].timeout,
          };
          return (
            __uniConfig["async"]["loading"] &&
              (n.loading = {
                name: "SystemAsyncLoading",
                render: function (e) {
                  return e(__uniConfig["async"]["loading"]);
                },
              }),
            __uniConfig["async"]["error"] &&
              (n.error = {
                name: "SystemAsyncError",
                render: function (e) {
                  return e(__uniConfig["async"]["error"]);
                },
              }),
            n
          );
        }),
        a.default.component("pages-user-bind_mobile", function (e) {
          var n = {
            component: Promise.all([
              t.e(
                "pages-agent-cash_score~pages-cat-list~pages-follow-index~pages-index-search~pages-pay-submit~pages-u~420041f8",
              ),
              t.e(
                "pages-user-bind_mobile~pages-user-bind_mobile_weapp~pages-user-login_old",
              ),
              t.e("pages-user-bind_mobile~pages-user-login_old"),
              t.e("pages-user-bind_mobile"),
            ])
              .then(
                function () {
                  return e(t("4d90"));
                }.bind(null, t),
              )
              .catch(t.oe),
            delay: __uniConfig["async"].delay,
            timeout: __uniConfig["async"].timeout,
          };
          return (
            __uniConfig["async"]["loading"] &&
              (n.loading = {
                name: "SystemAsyncLoading",
                render: function (e) {
                  return e(__uniConfig["async"]["loading"]);
                },
              }),
            __uniConfig["async"]["error"] &&
              (n.error = {
                name: "SystemAsyncError",
                render: function (e) {
                  return e(__uniConfig["async"]["error"]);
                },
              }),
            n
          );
        }),
        a.default.component("pages-agent-index", function (e) {
          var n = {
            component: t
              .e("pages-agent-index")
              .then(
                function () {
                  return e(t("9743"));
                }.bind(null, t),
              )
              .catch(t.oe),
            delay: __uniConfig["async"].delay,
            timeout: __uniConfig["async"].timeout,
          };
          return (
            __uniConfig["async"]["loading"] &&
              (n.loading = {
                name: "SystemAsyncLoading",
                render: function (e) {
                  return e(__uniConfig["async"]["loading"]);
                },
              }),
            __uniConfig["async"]["error"] &&
              (n.error = {
                name: "SystemAsyncError",
                render: function (e) {
                  return e(__uniConfig["async"]["error"]);
                },
              }),
            n
          );
        }),
        a.default.component("pages-agent-child", function (e) {
          var n = {
            component: t
              .e("pages-agent-child")
              .then(
                function () {
                  return e(t("a74d"));
                }.bind(null, t),
              )
              .catch(t.oe),
            delay: __uniConfig["async"].delay,
            timeout: __uniConfig["async"].timeout,
          };
          return (
            __uniConfig["async"]["loading"] &&
              (n.loading = {
                name: "SystemAsyncLoading",
                render: function (e) {
                  return e(__uniConfig["async"]["loading"]);
                },
              }),
            __uniConfig["async"]["error"] &&
              (n.error = {
                name: "SystemAsyncError",
                render: function (e) {
                  return e(__uniConfig["async"]["error"]);
                },
              }),
            n
          );
        }),
        a.default.component("pages-agent-score_log", function (e) {
          var n = {
            component: t
              .e("pages-agent-score_log")
              .then(
                function () {
                  return e(t("e156"));
                }.bind(null, t),
              )
              .catch(t.oe),
            delay: __uniConfig["async"].delay,
            timeout: __uniConfig["async"].timeout,
          };
          return (
            __uniConfig["async"]["loading"] &&
              (n.loading = {
                name: "SystemAsyncLoading",
                render: function (e) {
                  return e(__uniConfig["async"]["loading"]);
                },
              }),
            __uniConfig["async"]["error"] &&
              (n.error = {
                name: "SystemAsyncError",
                render: function (e) {
                  return e(__uniConfig["async"]["error"]);
                },
              }),
            n
          );
        }),
        a.default.component("pages-agent-cash_score", function (e) {
          var n = {
            component: Promise.all([
              t.e(
                "pages-agent-cash_score~pages-cat-list~pages-follow-index~pages-index-search~pages-pay-submit~pages-u~420041f8",
              ),
              t.e(
                "pages-agent-cash_score~pages-pay-raffle~pages-pay-submit~pages-user-apply~pages-user-certification~p~2f537e91",
              ),
              t.e("pages-agent-cash_score"),
            ])
              .then(
                function () {
                  return e(t("294c"));
                }.bind(null, t),
              )
              .catch(t.oe),
            delay: __uniConfig["async"].delay,
            timeout: __uniConfig["async"].timeout,
          };
          return (
            __uniConfig["async"]["loading"] &&
              (n.loading = {
                name: "SystemAsyncLoading",
                render: function (e) {
                  return e(__uniConfig["async"]["loading"]);
                },
              }),
            __uniConfig["async"]["error"] &&
              (n.error = {
                name: "SystemAsyncError",
                render: function (e) {
                  return e(__uniConfig["async"]["error"]);
                },
              }),
            n
          );
        }),
        a.default.component("pages-agent-cash_score_log", function (e) {
          var n = {
            component: t
              .e("pages-agent-cash_score_log")
              .then(
                function () {
                  return e(t("af6b"));
                }.bind(null, t),
              )
              .catch(t.oe),
            delay: __uniConfig["async"].delay,
            timeout: __uniConfig["async"].timeout,
          };
          return (
            __uniConfig["async"]["loading"] &&
              (n.loading = {
                name: "SystemAsyncLoading",
                render: function (e) {
                  return e(__uniConfig["async"]["loading"]);
                },
              }),
            __uniConfig["async"]["error"] &&
              (n.error = {
                name: "SystemAsyncError",
                render: function (e) {
                  return e(__uniConfig["async"]["error"]);
                },
              }),
            n
          );
        }),
        a.default.component("pages-index-error", function (e) {
          var n = {
            component: t
              .e("pages-index-error")
              .then(
                function () {
                  return e(t("67e2"));
                }.bind(null, t),
              )
              .catch(t.oe),
            delay: __uniConfig["async"].delay,
            timeout: __uniConfig["async"].timeout,
          };
          return (
            __uniConfig["async"]["loading"] &&
              (n.loading = {
                name: "SystemAsyncLoading",
                render: function (e) {
                  return e(__uniConfig["async"]["loading"]);
                },
              }),
            __uniConfig["async"]["error"] &&
              (n.error = {
                name: "SystemAsyncError",
                render: function (e) {
                  return e(__uniConfig["async"]["error"]);
                },
              }),
            n
          );
        }),
        a.default.component("pages-index-agree", function (e) {
          var n = {
            component: t
              .e("pages-index-agree")
              .then(
                function () {
                  return e(t("307f"));
                }.bind(null, t),
              )
              .catch(t.oe),
            delay: __uniConfig["async"].delay,
            timeout: __uniConfig["async"].timeout,
          };
          return (
            __uniConfig["async"]["loading"] &&
              (n.loading = {
                name: "SystemAsyncLoading",
                render: function (e) {
                  return e(__uniConfig["async"]["loading"]);
                },
              }),
            __uniConfig["async"]["error"] &&
              (n.error = {
                name: "SystemAsyncError",
                render: function (e) {
                  return e(__uniConfig["async"]["error"]);
                },
              }),
            n
          );
        }),
        a.default.component("pages-user-bind_mobile_weapp", function (e) {
          var n = {
            component: Promise.all([
              t.e(
                "pages-user-bind_mobile~pages-user-bind_mobile_weapp~pages-user-login_old",
              ),
              t.e("pages-user-bind_mobile_weapp"),
            ])
              .then(
                function () {
                  return e(t("fc4f"));
                }.bind(null, t),
              )
              .catch(t.oe),
            delay: __uniConfig["async"].delay,
            timeout: __uniConfig["async"].timeout,
          };
          return (
            __uniConfig["async"]["loading"] &&
              (n.loading = {
                name: "SystemAsyncLoading",
                render: function (e) {
                  return e(__uniConfig["async"]["loading"]);
                },
              }),
            __uniConfig["async"]["error"] &&
              (n.error = {
                name: "SystemAsyncError",
                render: function (e) {
                  return e(__uniConfig["async"]["error"]);
                },
              }),
            n
          );
        }),
        a.default.component("pages-chat-list", function (e) {
          var n = {
            component: t
              .e("pages-chat-list")
              .then(
                function () {
                  return e(t("f19d"));
                }.bind(null, t),
              )
              .catch(t.oe),
            delay: __uniConfig["async"].delay,
            timeout: __uniConfig["async"].timeout,
          };
          return (
            __uniConfig["async"]["loading"] &&
              (n.loading = {
                name: "SystemAsyncLoading",
                render: function (e) {
                  return e(__uniConfig["async"]["loading"]);
                },
              }),
            __uniConfig["async"]["error"] &&
              (n.error = {
                name: "SystemAsyncError",
                render: function (e) {
                  return e(__uniConfig["async"]["error"]);
                },
              }),
            n
          );
        }),
        a.default.component("pages-system-index", function (e) {
          var n = {
            component: t
              .e("pages-system-index")
              .then(
                function () {
                  return e(t("7f4b"));
                }.bind(null, t),
              )
              .catch(t.oe),
            delay: __uniConfig["async"].delay,
            timeout: __uniConfig["async"].timeout,
          };
          return (
            __uniConfig["async"]["loading"] &&
              (n.loading = {
                name: "SystemAsyncLoading",
                render: function (e) {
                  return e(__uniConfig["async"]["loading"]);
                },
              }),
            __uniConfig["async"]["error"] &&
              (n.error = {
                name: "SystemAsyncError",
                render: function (e) {
                  return e(__uniConfig["async"]["error"]);
                },
              }),
            n
          );
        }),
        a.default.component("pages-user-level", function (e) {
          var n = {
            component: Promise.all([
              t.e(
                "pages-user-apply~pages-user-certification~pages-user-huifu~pages-user-index~pages-user-level~pages-u~6bd29fe7",
              ),
              t.e(
                "pages-active-goods~pages-index-goods~pages-index-index~pages-user-index~pages-user-level",
              ),
              t.e("pages-user-level"),
            ])
              .then(
                function () {
                  return e(t("8709"));
                }.bind(null, t),
              )
              .catch(t.oe),
            delay: __uniConfig["async"].delay,
            timeout: __uniConfig["async"].timeout,
          };
          return (
            __uniConfig["async"]["loading"] &&
              (n.loading = {
                name: "SystemAsyncLoading",
                render: function (e) {
                  return e(__uniConfig["async"]["loading"]);
                },
              }),
            __uniConfig["async"]["error"] &&
              (n.error = {
                name: "SystemAsyncError",
                render: function (e) {
                  return e(__uniConfig["async"]["error"]);
                },
              }),
            n
          );
        }),
        a.default.component("pages-user-apply", function (e) {
          var n = {
            component: Promise.all([
              t.e(
                "pages-agent-cash_score~pages-cat-list~pages-follow-index~pages-index-search~pages-pay-submit~pages-u~420041f8",
              ),
              t.e(
                "pages-user-apply~pages-user-certification~pages-user-huifu~pages-user-index~pages-user-level~pages-u~6bd29fe7",
              ),
              t.e(
                "pages-active-goods~pages-active-turntable~pages-index-goods~pages-index-index~pages-pay-raffle~pages~c8bef51b",
              ),
              t.e(
                "pages-agent-cash_score~pages-pay-raffle~pages-pay-submit~pages-user-apply~pages-user-certification~p~2f537e91",
              ),
              t.e("pages-user-apply"),
            ])
              .then(
                function () {
                  return e(t("6068"));
                }.bind(null, t),
              )
              .catch(t.oe),
            delay: __uniConfig["async"].delay,
            timeout: __uniConfig["async"].timeout,
          };
          return (
            __uniConfig["async"]["loading"] &&
              (n.loading = {
                name: "SystemAsyncLoading",
                render: function (e) {
                  return e(__uniConfig["async"]["loading"]);
                },
              }),
            __uniConfig["async"]["error"] &&
              (n.error = {
                name: "SystemAsyncError",
                render: function (e) {
                  return e(__uniConfig["async"]["error"]);
                },
              }),
            n
          );
        }),
        a.default.component("pages-user-fine_list", function (e) {
          var n = {
            component: t
              .e("pages-user-fine_list")
              .then(
                function () {
                  return e(t("b6df"));
                }.bind(null, t),
              )
              .catch(t.oe),
            delay: __uniConfig["async"].delay,
            timeout: __uniConfig["async"].timeout,
          };
          return (
            __uniConfig["async"]["loading"] &&
              (n.loading = {
                name: "SystemAsyncLoading",
                render: function (e) {
                  return e(__uniConfig["async"]["loading"]);
                },
              }),
            __uniConfig["async"]["error"] &&
              (n.error = {
                name: "SystemAsyncError",
                render: function (e) {
                  return e(__uniConfig["async"]["error"]);
                },
              }),
            n
          );
        }),
        a.default.component("pages_sub1-chat-index", function (e) {
          var n = {
            component: Promise.all([
              t.e(
                "pages-user-apply~pages-user-certification~pages-user-huifu~pages-user-index~pages-user-level~pages-u~6bd29fe7",
              ),
              t.e(
                "pages-active-goods~pages-active-turntable~pages-index-goods~pages-index-index~pages-pay-raffle~pages~c8bef51b",
              ),
              t.e("pages_sub1-chat-index"),
            ])
              .then(
                function () {
                  return e(t("0fba"));
                }.bind(null, t),
              )
              .catch(t.oe),
            delay: __uniConfig["async"].delay,
            timeout: __uniConfig["async"].timeout,
          };
          return (
            __uniConfig["async"]["loading"] &&
              (n.loading = {
                name: "SystemAsyncLoading",
                render: function (e) {
                  return e(__uniConfig["async"]["loading"]);
                },
              }),
            __uniConfig["async"]["error"] &&
              (n.error = {
                name: "SystemAsyncError",
                render: function (e) {
                  return e(__uniConfig["async"]["error"]);
                },
              }),
            n
          );
        }),
        a.default.component("pages_sub1-chat-info", function (e) {
          var n = {
            component: Promise.all([
              t.e(
                "pages-agent-cash_score~pages-cat-list~pages-follow-index~pages-index-search~pages-pay-submit~pages-u~420041f8",
              ),
              t.e(
                "pages-user-apply~pages-user-certification~pages-user-huifu~pages-user-index~pages-user-level~pages-u~6bd29fe7",
              ),
              t.e(
                "pages-active-goods~pages-active-turntable~pages-index-goods~pages-index-index~pages-pay-raffle~pages~c8bef51b",
              ),
              t.e("pages-index-index~pages_sub1-chat-info"),
              t.e("pages_sub1-chat-info"),
            ])
              .then(
                function () {
                  return e(t("49d9"));
                }.bind(null, t),
              )
              .catch(t.oe),
            delay: __uniConfig["async"].delay,
            timeout: __uniConfig["async"].timeout,
          };
          return (
            __uniConfig["async"]["loading"] &&
              (n.loading = {
                name: "SystemAsyncLoading",
                render: function (e) {
                  return e(__uniConfig["async"]["loading"]);
                },
              }),
            __uniConfig["async"]["error"] &&
              (n.error = {
                name: "SystemAsyncError",
                render: function (e) {
                  return e(__uniConfig["async"]["error"]);
                },
              }),
            n
          );
        }),
        a.default.component("pages_sub1-chat-notice", function (e) {
          var n = {
            component: Promise.all([
              t.e(
                "pages-active-goods~pages-active-turntable~pages-index-goods~pages-index-index~pages-pay-raffle~pages~c8bef51b",
              ),
              t.e("pages_sub1-chat-notice"),
            ])
              .then(
                function () {
                  return e(t("476e"));
                }.bind(null, t),
              )
              .catch(t.oe),
            delay: __uniConfig["async"].delay,
            timeout: __uniConfig["async"].timeout,
          };
          return (
            __uniConfig["async"]["loading"] &&
              (n.loading = {
                name: "SystemAsyncLoading",
                render: function (e) {
                  return e(__uniConfig["async"]["loading"]);
                },
              }),
            __uniConfig["async"]["error"] &&
              (n.error = {
                name: "SystemAsyncError",
                render: function (e) {
                  return e(__uniConfig["async"]["error"]);
                },
              }),
            n
          );
        }),
        a.default.component("pages_sub1-chat-history", function (e) {
          var n = {
            component: Promise.all([
              t.e(
                "pages-user-apply~pages-user-certification~pages-user-huifu~pages-user-index~pages-user-level~pages-u~6bd29fe7",
              ),
              t.e(
                "pages-active-goods~pages-active-turntable~pages-index-goods~pages-index-index~pages-pay-raffle~pages~c8bef51b",
              ),
              t.e("pages_sub1-chat-history"),
            ])
              .then(
                function () {
                  return e(t("8bcb"));
                }.bind(null, t),
              )
              .catch(t.oe),
            delay: __uniConfig["async"].delay,
            timeout: __uniConfig["async"].timeout,
          };
          return (
            __uniConfig["async"]["loading"] &&
              (n.loading = {
                name: "SystemAsyncLoading",
                render: function (e) {
                  return e(__uniConfig["async"]["loading"]);
                },
              }),
            __uniConfig["async"]["error"] &&
              (n.error = {
                name: "SystemAsyncError",
                render: function (e) {
                  return e(__uniConfig["async"]["error"]);
                },
              }),
            n
          );
        }),
        a.default.component("pages_sub1-chat-test", function (e) {
          var n = {
            component: Promise.all([
              t.e(
                "pages-user-apply~pages-user-certification~pages-user-huifu~pages-user-index~pages-user-level~pages-u~6bd29fe7",
              ),
              t.e("pages_sub1-chat-test"),
            ])
              .then(
                function () {
                  return e(t("c851"));
                }.bind(null, t),
              )
              .catch(t.oe),
            delay: __uniConfig["async"].delay,
            timeout: __uniConfig["async"].timeout,
          };
          return (
            __uniConfig["async"]["loading"] &&
              (n.loading = {
                name: "SystemAsyncLoading",
                render: function (e) {
                  return e(__uniConfig["async"]["loading"]);
                },
              }),
            __uniConfig["async"]["error"] &&
              (n.error = {
                name: "SystemAsyncError",
                render: function (e) {
                  return e(__uniConfig["async"]["error"]);
                },
              }),
            n
          );
        }),
        a.default.component("pages_sub1-kefu-daka", function (e) {
          var n = {
            component: t
              .e("pages_sub1-kefu-daka")
              .then(
                function () {
                  return e(t("ea19"));
                }.bind(null, t),
              )
              .catch(t.oe),
            delay: __uniConfig["async"].delay,
            timeout: __uniConfig["async"].timeout,
          };
          return (
            __uniConfig["async"]["loading"] &&
              (n.loading = {
                name: "SystemAsyncLoading",
                render: function (e) {
                  return e(__uniConfig["async"]["loading"]);
                },
              }),
            __uniConfig["async"]["error"] &&
              (n.error = {
                name: "SystemAsyncError",
                render: function (e) {
                  return e(__uniConfig["async"]["error"]);
                },
              }),
            n
          );
        }),
        a.default.component("pages_sub1-kefu-order", function (e) {
          var n = {
            component: Promise.all([
              t.e(
                "pages-agent-cash_score~pages-cat-list~pages-follow-index~pages-index-search~pages-pay-submit~pages-u~420041f8",
              ),
              t.e("pages_sub1-kefu-order"),
            ])
              .then(
                function () {
                  return e(t("1c46"));
                }.bind(null, t),
              )
              .catch(t.oe),
            delay: __uniConfig["async"].delay,
            timeout: __uniConfig["async"].timeout,
          };
          return (
            __uniConfig["async"]["loading"] &&
              (n.loading = {
                name: "SystemAsyncLoading",
                render: function (e) {
                  return e(__uniConfig["async"]["loading"]);
                },
              }),
            __uniConfig["async"]["error"] &&
              (n.error = {
                name: "SystemAsyncError",
                render: function (e) {
                  return e(__uniConfig["async"]["error"]);
                },
              }),
            n
          );
        }),
        a.default.component("pages_sub1-kefu-audit", function (e) {
          var n = {
            component: Promise.all([
              t.e(
                "pages-agent-cash_score~pages-cat-list~pages-follow-index~pages-index-search~pages-pay-submit~pages-u~420041f8",
              ),
              t.e("pages_sub1-kefu-audit"),
            ])
              .then(
                function () {
                  return e(t("3768"));
                }.bind(null, t),
              )
              .catch(t.oe),
            delay: __uniConfig["async"].delay,
            timeout: __uniConfig["async"].timeout,
          };
          return (
            __uniConfig["async"]["loading"] &&
              (n.loading = {
                name: "SystemAsyncLoading",
                render: function (e) {
                  return e(__uniConfig["async"]["loading"]);
                },
              }),
            __uniConfig["async"]["error"] &&
              (n.error = {
                name: "SystemAsyncError",
                render: function (e) {
                  return e(__uniConfig["async"]["error"]);
                },
              }),
            n
          );
        }),
        a.default.component("pages_sub1-kefu-audit_detail", function (e) {
          var n = {
            component: t
              .e("pages_sub1-kefu-audit_detail")
              .then(
                function () {
                  return e(t("808c"));
                }.bind(null, t),
              )
              .catch(t.oe),
            delay: __uniConfig["async"].delay,
            timeout: __uniConfig["async"].timeout,
          };
          return (
            __uniConfig["async"]["loading"] &&
              (n.loading = {
                name: "SystemAsyncLoading",
                render: function (e) {
                  return e(__uniConfig["async"]["loading"]);
                },
              }),
            __uniConfig["async"]["error"] &&
              (n.error = {
                name: "SystemAsyncError",
                render: function (e) {
                  return e(__uniConfig["async"]["error"]);
                },
              }),
            n
          );
        }),
        a.default.component("pages_sub1-kefu-info", function (e) {
          var n = {
            component: Promise.all([
              t.e(
                "pages-agent-cash_score~pages-cat-list~pages-follow-index~pages-index-search~pages-pay-submit~pages-u~420041f8",
              ),
              t.e("pages_sub1-kefu-info"),
            ])
              .then(
                function () {
                  return e(t("4915"));
                }.bind(null, t),
              )
              .catch(t.oe),
            delay: __uniConfig["async"].delay,
            timeout: __uniConfig["async"].timeout,
          };
          return (
            __uniConfig["async"]["loading"] &&
              (n.loading = {
                name: "SystemAsyncLoading",
                render: function (e) {
                  return e(__uniConfig["async"]["loading"]);
                },
              }),
            __uniConfig["async"]["error"] &&
              (n.error = {
                name: "SystemAsyncError",
                render: function (e) {
                  return e(__uniConfig["async"]["error"]);
                },
              }),
            n
          );
        }),
        a.default.component("pages_sub1-kefu-service", function (e) {
          var n = {
            component: Promise.all([
              t.e(
                "pages-pay-raffle~pages-user-huifu~pages_sub1-kefu-service~pages_sub1-seller-index",
              ),
              t.e("pages_sub1-kefu-service"),
            ])
              .then(
                function () {
                  return e(t("aac2"));
                }.bind(null, t),
              )
              .catch(t.oe),
            delay: __uniConfig["async"].delay,
            timeout: __uniConfig["async"].timeout,
          };
          return (
            __uniConfig["async"]["loading"] &&
              (n.loading = {
                name: "SystemAsyncLoading",
                render: function (e) {
                  return e(__uniConfig["async"]["loading"]);
                },
              }),
            __uniConfig["async"]["error"] &&
              (n.error = {
                name: "SystemAsyncError",
                render: function (e) {
                  return e(__uniConfig["async"]["error"]);
                },
              }),
            n
          );
        }),
        a.default.component("pages_sub1-kefu-total", function (e) {
          var n = {
            component: t
              .e("pages_sub1-kefu-total")
              .then(
                function () {
                  return e(t("0c48"));
                }.bind(null, t),
              )
              .catch(t.oe),
            delay: __uniConfig["async"].delay,
            timeout: __uniConfig["async"].timeout,
          };
          return (
            __uniConfig["async"]["loading"] &&
              (n.loading = {
                name: "SystemAsyncLoading",
                render: function (e) {
                  return e(__uniConfig["async"]["loading"]);
                },
              }),
            __uniConfig["async"]["error"] &&
              (n.error = {
                name: "SystemAsyncError",
                render: function (e) {
                  return e(__uniConfig["async"]["error"]);
                },
              }),
            n
          );
        }),
        a.default.component("pages_sub1-kefu-test", function (e) {
          var n = {
            component: t
              .e("pages_sub1-kefu-test")
              .then(
                function () {
                  return e(t("2a43"));
                }.bind(null, t),
              )
              .catch(t.oe),
            delay: __uniConfig["async"].delay,
            timeout: __uniConfig["async"].timeout,
          };
          return (
            __uniConfig["async"]["loading"] &&
              (n.loading = {
                name: "SystemAsyncLoading",
                render: function (e) {
                  return e(__uniConfig["async"]["loading"]);
                },
              }),
            __uniConfig["async"]["error"] &&
              (n.error = {
                name: "SystemAsyncError",
                render: function (e) {
                  return e(__uniConfig["async"]["error"]);
                },
              }),
            n
          );
        }),
        a.default.component("pages_sub1-kefu-fine_list", function (e) {
          var n = {
            component: t
              .e("pages_sub1-kefu-fine_list")
              .then(
                function () {
                  return e(t("e438"));
                }.bind(null, t),
              )
              .catch(t.oe),
            delay: __uniConfig["async"].delay,
            timeout: __uniConfig["async"].timeout,
          };
          return (
            __uniConfig["async"]["loading"] &&
              (n.loading = {
                name: "SystemAsyncLoading",
                render: function (e) {
                  return e(__uniConfig["async"]["loading"]);
                },
              }),
            __uniConfig["async"]["error"] &&
              (n.error = {
                name: "SystemAsyncError",
                render: function (e) {
                  return e(__uniConfig["async"]["error"]);
                },
              }),
            n
          );
        }),
        a.default.component("pages_sub1-kefu-fine_add", function (e) {
          var n = {
            component: t
              .e("pages_sub1-kefu-fine_add")
              .then(
                function () {
                  return e(t("88bb"));
                }.bind(null, t),
              )
              .catch(t.oe),
            delay: __uniConfig["async"].delay,
            timeout: __uniConfig["async"].timeout,
          };
          return (
            __uniConfig["async"]["loading"] &&
              (n.loading = {
                name: "SystemAsyncLoading",
                render: function (e) {
                  return e(__uniConfig["async"]["loading"]);
                },
              }),
            __uniConfig["async"]["error"] &&
              (n.error = {
                name: "SystemAsyncError",
                render: function (e) {
                  return e(__uniConfig["async"]["error"]);
                },
              }),
            n
          );
        }),
        a.default.component("pages_sub1-kefu-fine_detail", function (e) {
          var n = {
            component: t
              .e("pages_sub1-kefu-fine_detail")
              .then(
                function () {
                  return e(t("f846"));
                }.bind(null, t),
              )
              .catch(t.oe),
            delay: __uniConfig["async"].delay,
            timeout: __uniConfig["async"].timeout,
          };
          return (
            __uniConfig["async"]["loading"] &&
              (n.loading = {
                name: "SystemAsyncLoading",
                render: function (e) {
                  return e(__uniConfig["async"]["loading"]);
                },
              }),
            __uniConfig["async"]["error"] &&
              (n.error = {
                name: "SystemAsyncError",
                render: function (e) {
                  return e(__uniConfig["async"]["error"]);
                },
              }),
            n
          );
        }),
        a.default.component("pages_sub1-kefu-fine_edit", function (e) {
          var n = {
            component: t
              .e("pages_sub1-kefu-fine_edit")
              .then(
                function () {
                  return e(t("0bd1"));
                }.bind(null, t),
              )
              .catch(t.oe),
            delay: __uniConfig["async"].delay,
            timeout: __uniConfig["async"].timeout,
          };
          return (
            __uniConfig["async"]["loading"] &&
              (n.loading = {
                name: "SystemAsyncLoading",
                render: function (e) {
                  return e(__uniConfig["async"]["loading"]);
                },
              }),
            __uniConfig["async"]["error"] &&
              (n.error = {
                name: "SystemAsyncError",
                render: function (e) {
                  return e(__uniConfig["async"]["error"]);
                },
              }),
            n
          );
        }),
        a.default.component("pages_sub1-seller-index", function (e) {
          var n = {
            component: Promise.all([
              t.e(
                "pages-active-goods~pages-active-turntable~pages-index-goods~pages-index-index~pages-pay-raffle~pages~c8bef51b",
              ),
              t.e(
                "pages-pay-raffle~pages-user-huifu~pages_sub1-kefu-service~pages_sub1-seller-index",
              ),
              t.e("pages_sub1-seller-index"),
            ])
              .then(
                function () {
                  return e(t("21d8"));
                }.bind(null, t),
              )
              .catch(t.oe),
            delay: __uniConfig["async"].delay,
            timeout: __uniConfig["async"].timeout,
          };
          return (
            __uniConfig["async"]["loading"] &&
              (n.loading = {
                name: "SystemAsyncLoading",
                render: function (e) {
                  return e(__uniConfig["async"]["loading"]);
                },
              }),
            __uniConfig["async"]["error"] &&
              (n.error = {
                name: "SystemAsyncError",
                render: function (e) {
                  return e(__uniConfig["async"]["error"]);
                },
              }),
            n
          );
        }),
        a.default.component("pages_sub1-order-index", function (e) {
          var n = {
            component: t
              .e("pages_sub1-order-index")
              .then(
                function () {
                  return e(t("32c0"));
                }.bind(null, t),
              )
              .catch(t.oe),
            delay: __uniConfig["async"].delay,
            timeout: __uniConfig["async"].timeout,
          };
          return (
            __uniConfig["async"]["loading"] &&
              (n.loading = {
                name: "SystemAsyncLoading",
                render: function (e) {
                  return e(__uniConfig["async"]["loading"]);
                },
              }),
            __uniConfig["async"]["error"] &&
              (n.error = {
                name: "SystemAsyncError",
                render: function (e) {
                  return e(__uniConfig["async"]["error"]);
                },
              }),
            n
          );
        }),
        a.default.component("pages_sub1-order-info", function (e) {
          var n = {
            component: t
              .e("pages_sub1-order-info")
              .then(
                function () {
                  return e(t("660b"));
                }.bind(null, t),
              )
              .catch(t.oe),
            delay: __uniConfig["async"].delay,
            timeout: __uniConfig["async"].timeout,
          };
          return (
            __uniConfig["async"]["loading"] &&
              (n.loading = {
                name: "SystemAsyncLoading",
                render: function (e) {
                  return e(__uniConfig["async"]["loading"]);
                },
              }),
            __uniConfig["async"]["error"] &&
              (n.error = {
                name: "SystemAsyncError",
                render: function (e) {
                  return e(__uniConfig["async"]["error"]);
                },
              }),
            n
          );
        }),
        a.default.component("pages_sub1-order-seller", function (e) {
          var n = {
            component: Promise.all([
              t.e(
                "pages-agent-cash_score~pages-cat-list~pages-follow-index~pages-index-search~pages-pay-submit~pages-u~420041f8",
              ),
              t.e("pages_sub1-order-seller"),
            ])
              .then(
                function () {
                  return e(t("1dcc"));
                }.bind(null, t),
              )
              .catch(t.oe),
            delay: __uniConfig["async"].delay,
            timeout: __uniConfig["async"].timeout,
          };
          return (
            __uniConfig["async"]["loading"] &&
              (n.loading = {
                name: "SystemAsyncLoading",
                render: function (e) {
                  return e(__uniConfig["async"]["loading"]);
                },
              }),
            __uniConfig["async"]["error"] &&
              (n.error = {
                name: "SystemAsyncError",
                render: function (e) {
                  return e(__uniConfig["async"]["error"]);
                },
              }),
            n
          );
        }),
        a.default.component("pages_sub1-order-seller_info", function (e) {
          var n = {
            component: Promise.all([
              t.e(
                "pages-agent-cash_score~pages-cat-list~pages-follow-index~pages-index-search~pages-pay-submit~pages-u~420041f8",
              ),
              t.e(
                "pages-user-apply~pages-user-certification~pages-user-huifu~pages-user-index~pages-user-level~pages-u~6bd29fe7",
              ),
              t.e(
                "pages-agent-cash_score~pages-pay-raffle~pages-pay-submit~pages-user-apply~pages-user-certification~p~2f537e91",
              ),
              t.e(
                "pages-user-certification~pages-user-personal~pages_sub1-order-audit_detail~pages_sub1-order-comment~~ea7a9f35",
              ),
              t.e("pages_sub1-order-seller_info"),
            ])
              .then(
                function () {
                  return e(t("5e25"));
                }.bind(null, t),
              )
              .catch(t.oe),
            delay: __uniConfig["async"].delay,
            timeout: __uniConfig["async"].timeout,
          };
          return (
            __uniConfig["async"]["loading"] &&
              (n.loading = {
                name: "SystemAsyncLoading",
                render: function (e) {
                  return e(__uniConfig["async"]["loading"]);
                },
              }),
            __uniConfig["async"]["error"] &&
              (n.error = {
                name: "SystemAsyncError",
                render: function (e) {
                  return e(__uniConfig["async"]["error"]);
                },
              }),
            n
          );
        }),
        a.default.component("pages_sub1-order-audit_list", function (e) {
          var n = {
            component: Promise.all([
              t.e(
                "pages-agent-cash_score~pages-cat-list~pages-follow-index~pages-index-search~pages-pay-submit~pages-u~420041f8",
              ),
              t.e("pages_sub1-order-audit_list"),
            ])
              .then(
                function () {
                  return e(t("23ad"));
                }.bind(null, t),
              )
              .catch(t.oe),
            delay: __uniConfig["async"].delay,
            timeout: __uniConfig["async"].timeout,
          };
          return (
            __uniConfig["async"]["loading"] &&
              (n.loading = {
                name: "SystemAsyncLoading",
                render: function (e) {
                  return e(__uniConfig["async"]["loading"]);
                },
              }),
            __uniConfig["async"]["error"] &&
              (n.error = {
                name: "SystemAsyncError",
                render: function (e) {
                  return e(__uniConfig["async"]["error"]);
                },
              }),
            n
          );
        }),
        a.default.component("pages_sub1-order-audit_detail", function (e) {
          var n = {
            component: Promise.all([
              t.e(
                "pages-agent-cash_score~pages-cat-list~pages-follow-index~pages-index-search~pages-pay-submit~pages-u~420041f8",
              ),
              t.e(
                "pages-user-apply~pages-user-certification~pages-user-huifu~pages-user-index~pages-user-level~pages-u~6bd29fe7",
              ),
              t.e(
                "pages-agent-cash_score~pages-pay-raffle~pages-pay-submit~pages-user-apply~pages-user-certification~p~2f537e91",
              ),
              t.e(
                "pages-user-certification~pages-user-personal~pages_sub1-order-audit_detail~pages_sub1-order-comment~~ea7a9f35",
              ),
              t.e("pages_sub1-order-audit_detail"),
            ])
              .then(
                function () {
                  return e(t("0d66"));
                }.bind(null, t),
              )
              .catch(t.oe),
            delay: __uniConfig["async"].delay,
            timeout: __uniConfig["async"].timeout,
          };
          return (
            __uniConfig["async"]["loading"] &&
              (n.loading = {
                name: "SystemAsyncLoading",
                render: function (e) {
                  return e(__uniConfig["async"]["loading"]);
                },
              }),
            __uniConfig["async"]["error"] &&
              (n.error = {
                name: "SystemAsyncError",
                render: function (e) {
                  return e(__uniConfig["async"]["error"]);
                },
              }),
            n
          );
        }),
        a.default.component("pages_sub1-order-service", function (e) {
          var n = {
            component: Promise.all([
              t.e(
                "pages-user-apply~pages-user-certification~pages-user-huifu~pages-user-index~pages-user-level~pages-u~6bd29fe7",
              ),
              t.e(
                "pages-agent-cash_score~pages-pay-raffle~pages-pay-submit~pages-user-apply~pages-user-certification~p~2f537e91",
              ),
              t.e(
                "pages-user-certification~pages-user-personal~pages_sub1-order-audit_detail~pages_sub1-order-comment~~ea7a9f35",
              ),
              t.e("pages_sub1-order-service"),
            ])
              .then(
                function () {
                  return e(t("bd38"));
                }.bind(null, t),
              )
              .catch(t.oe),
            delay: __uniConfig["async"].delay,
            timeout: __uniConfig["async"].timeout,
          };
          return (
            __uniConfig["async"]["loading"] &&
              (n.loading = {
                name: "SystemAsyncLoading",
                render: function (e) {
                  return e(__uniConfig["async"]["loading"]);
                },
              }),
            __uniConfig["async"]["error"] &&
              (n.error = {
                name: "SystemAsyncError",
                render: function (e) {
                  return e(__uniConfig["async"]["error"]);
                },
              }),
            n
          );
        }),
        a.default.component("pages_sub1-order-seller_service", function (e) {
          var n = {
            component: Promise.all([
              t.e(
                "pages-user-apply~pages-user-certification~pages-user-huifu~pages-user-index~pages-user-level~pages-u~6bd29fe7",
              ),
              t.e("pages_sub1-order-seller_service"),
            ])
              .then(
                function () {
                  return e(t("e557"));
                }.bind(null, t),
              )
              .catch(t.oe),
            delay: __uniConfig["async"].delay,
            timeout: __uniConfig["async"].timeout,
          };
          return (
            __uniConfig["async"]["loading"] &&
              (n.loading = {
                name: "SystemAsyncLoading",
                render: function (e) {
                  return e(__uniConfig["async"]["loading"]);
                },
              }),
            __uniConfig["async"]["error"] &&
              (n.error = {
                name: "SystemAsyncError",
                render: function (e) {
                  return e(__uniConfig["async"]["error"]);
                },
              }),
            n
          );
        }),
        a.default.component("pages_sub1-order-comment", function (e) {
          var n = {
            component: Promise.all([
              t.e(
                "pages-user-apply~pages-user-certification~pages-user-huifu~pages-user-index~pages-user-level~pages-u~6bd29fe7",
              ),
              t.e(
                "pages-agent-cash_score~pages-pay-raffle~pages-pay-submit~pages-user-apply~pages-user-certification~p~2f537e91",
              ),
              t.e(
                "pages-user-certification~pages-user-personal~pages_sub1-order-audit_detail~pages_sub1-order-comment~~ea7a9f35",
              ),
              t.e("pages_sub1-order-comment"),
            ])
              .then(
                function () {
                  return e(t("d712"));
                }.bind(null, t),
              )
              .catch(t.oe),
            delay: __uniConfig["async"].delay,
            timeout: __uniConfig["async"].timeout,
          };
          return (
            __uniConfig["async"]["loading"] &&
              (n.loading = {
                name: "SystemAsyncLoading",
                render: function (e) {
                  return e(__uniConfig["async"]["loading"]);
                },
              }),
            __uniConfig["async"]["error"] &&
              (n.error = {
                name: "SystemAsyncError",
                render: function (e) {
                  return e(__uniConfig["async"]["error"]);
                },
              }),
            n
          );
        }),
        a.default.component("pages_sub1-order-invite_fupei", function (e) {
          var n = {
            component: Promise.all([
              t.e(
                "pages-agent-cash_score~pages-cat-list~pages-follow-index~pages-index-search~pages-pay-submit~pages-u~420041f8",
              ),
              t.e(
                "pages-cat-index~pages-cat-index2~pages-pay-index~pages-pay-raffle~pages-pay-submit~pages_sub1-order-~58b36340",
              ),
              t.e("pages_sub1-order-invite_fupei"),
            ])
              .then(
                function () {
                  return e(t("770c"));
                }.bind(null, t),
              )
              .catch(t.oe),
            delay: __uniConfig["async"].delay,
            timeout: __uniConfig["async"].timeout,
          };
          return (
            __uniConfig["async"]["loading"] &&
              (n.loading = {
                name: "SystemAsyncLoading",
                render: function (e) {
                  return e(__uniConfig["async"]["loading"]);
                },
              }),
            __uniConfig["async"]["error"] &&
              (n.error = {
                name: "SystemAsyncError",
                render: function (e) {
                  return e(__uniConfig["async"]["error"]);
                },
              }),
            n
          );
        }),
        a.default.component("pages_sub1-seller-invited", function (e) {
          var n = {
            component: Promise.all([
              t.e(
                "pages-agent-cash_score~pages-cat-list~pages-follow-index~pages-index-search~pages-pay-submit~pages-u~420041f8",
              ),
              t.e("pages_sub1-seller-invited"),
            ])
              .then(
                function () {
                  return e(t("789b"));
                }.bind(null, t),
              )
              .catch(t.oe),
            delay: __uniConfig["async"].delay,
            timeout: __uniConfig["async"].timeout,
          };
          return (
            __uniConfig["async"]["loading"] &&
              (n.loading = {
                name: "SystemAsyncLoading",
                render: function (e) {
                  return e(__uniConfig["async"]["loading"]);
                },
              }),
            __uniConfig["async"]["error"] &&
              (n.error = {
                name: "SystemAsyncError",
                render: function (e) {
                  return e(__uniConfig["async"]["error"]);
                },
              }),
            n
          );
        }),
        a.default.component("pages_sub1-seller-rank", function (e) {
          var n = {
            component: Promise.all([
              t.e(
                "pages-cat-index~pages-cat-index2~pages-pay-index~pages-pay-raffle~pages-pay-submit~pages_sub1-order-~58b36340",
              ),
              t.e("pages_sub1-seller-rank"),
            ])
              .then(
                function () {
                  return e(t("b71d"));
                }.bind(null, t),
              )
              .catch(t.oe),
            delay: __uniConfig["async"].delay,
            timeout: __uniConfig["async"].timeout,
          };
          return (
            __uniConfig["async"]["loading"] &&
              (n.loading = {
                name: "SystemAsyncLoading",
                render: function (e) {
                  return e(__uniConfig["async"]["loading"]);
                },
              }),
            __uniConfig["async"]["error"] &&
              (n.error = {
                name: "SystemAsyncError",
                render: function (e) {
                  return e(__uniConfig["async"]["error"]);
                },
              }),
            n
          );
        }),
        a.default.component("pages_sub1-seller-hall", function (e) {
          var n = {
            component: t
              .e("pages_sub1-seller-hall")
              .then(
                function () {
                  return e(t("47e0"));
                }.bind(null, t),
              )
              .catch(t.oe),
            delay: __uniConfig["async"].delay,
            timeout: __uniConfig["async"].timeout,
          };
          return (
            __uniConfig["async"]["loading"] &&
              (n.loading = {
                name: "SystemAsyncLoading",
                render: function (e) {
                  return e(__uniConfig["async"]["loading"]);
                },
              }),
            __uniConfig["async"]["error"] &&
              (n.error = {
                name: "SystemAsyncError",
                render: function (e) {
                  return e(__uniConfig["async"]["error"]);
                },
              }),
            n
          );
        }),
        a.default.component("pages_sub1-seller-hall_info", function (e) {
          var n = {
            component: t
              .e("pages_sub1-seller-hall_info")
              .then(
                function () {
                  return e(t("bf85"));
                }.bind(null, t),
              )
              .catch(t.oe),
            delay: __uniConfig["async"].delay,
            timeout: __uniConfig["async"].timeout,
          };
          return (
            __uniConfig["async"]["loading"] &&
              (n.loading = {
                name: "SystemAsyncLoading",
                render: function (e) {
                  return e(__uniConfig["async"]["loading"]);
                },
              }),
            __uniConfig["async"]["error"] &&
              (n.error = {
                name: "SystemAsyncError",
                render: function (e) {
                  return e(__uniConfig["async"]["error"]);
                },
              }),
            n
          );
        }),
        a.default.component("pages_sub1-seller-seller_pay", function (e) {
          var n = {
            component: t
              .e("pages_sub1-seller-seller_pay")
              .then(
                function () {
                  return e(t("1187"));
                }.bind(null, t),
              )
              .catch(t.oe),
            delay: __uniConfig["async"].delay,
            timeout: __uniConfig["async"].timeout,
          };
          return (
            __uniConfig["async"]["loading"] &&
              (n.loading = {
                name: "SystemAsyncLoading",
                render: function (e) {
                  return e(__uniConfig["async"]["loading"]);
                },
              }),
            __uniConfig["async"]["error"] &&
              (n.error = {
                name: "SystemAsyncError",
                render: function (e) {
                  return e(__uniConfig["async"]["error"]);
                },
              }),
            n
          );
        }),
        a.default.component("pages_sub1-seller-message", function (e) {
          var n = {
            component: Promise.all([
              t.e("pages-cat-index~pages-cat-index2~pages_sub1-seller-message"),
              t.e("pages_sub1-seller-message"),
            ])
              .then(
                function () {
                  return e(t("4bd0"));
                }.bind(null, t),
              )
              .catch(t.oe),
            delay: __uniConfig["async"].delay,
            timeout: __uniConfig["async"].timeout,
          };
          return (
            __uniConfig["async"]["loading"] &&
              (n.loading = {
                name: "SystemAsyncLoading",
                render: function (e) {
                  return e(__uniConfig["async"]["loading"]);
                },
              }),
            __uniConfig["async"]["error"] &&
              (n.error = {
                name: "SystemAsyncError",
                render: function (e) {
                  return e(__uniConfig["async"]["error"]);
                },
              }),
            n
          );
        }),
        a.default.component("pages_sub1-seller-notice", function (e) {
          var n = {
            component: t
              .e("pages_sub1-seller-notice")
              .then(
                function () {
                  return e(t("2e78"));
                }.bind(null, t),
              )
              .catch(t.oe),
            delay: __uniConfig["async"].delay,
            timeout: __uniConfig["async"].timeout,
          };
          return (
            __uniConfig["async"]["loading"] &&
              (n.loading = {
                name: "SystemAsyncLoading",
                render: function (e) {
                  return e(__uniConfig["async"]["loading"]);
                },
              }),
            __uniConfig["async"]["error"] &&
              (n.error = {
                name: "SystemAsyncError",
                render: function (e) {
                  return e(__uniConfig["async"]["error"]);
                },
              }),
            n
          );
        }),
        a.default.component("pages_sub1-seller-notice_detail", function (e) {
          var n = {
            component: Promise.all([
              t.e(
                "pages-active-goods~pages-active-turntable~pages-index-goods~pages-index-index~pages-pay-raffle~pages~c8bef51b",
              ),
              t.e("pages_sub1-seller-notice_detail"),
            ])
              .then(
                function () {
                  return e(t("8dff"));
                }.bind(null, t),
              )
              .catch(t.oe),
            delay: __uniConfig["async"].delay,
            timeout: __uniConfig["async"].timeout,
          };
          return (
            __uniConfig["async"]["loading"] &&
              (n.loading = {
                name: "SystemAsyncLoading",
                render: function (e) {
                  return e(__uniConfig["async"]["loading"]);
                },
              }),
            __uniConfig["async"]["error"] &&
              (n.error = {
                name: "SystemAsyncError",
                render: function (e) {
                  return e(__uniConfig["async"]["error"]);
                },
              }),
            n
          );
        }),
        a.default.component("pages_sub1-seller-edit_profile", function (e) {
          var n = {
            component: Promise.all([
              t.e(
                "pages-agent-cash_score~pages-pay-raffle~pages-pay-submit~pages-user-apply~pages-user-certification~p~2f537e91",
              ),
              t.e("pages_sub1-seller-edit_profile"),
            ])
              .then(
                function () {
                  return e(t("33ae"));
                }.bind(null, t),
              )
              .catch(t.oe),
            delay: __uniConfig["async"].delay,
            timeout: __uniConfig["async"].timeout,
          };
          return (
            __uniConfig["async"]["loading"] &&
              (n.loading = {
                name: "SystemAsyncLoading",
                render: function (e) {
                  return e(__uniConfig["async"]["loading"]);
                },
              }),
            __uniConfig["async"]["error"] &&
              (n.error = {
                name: "SystemAsyncError",
                render: function (e) {
                  return e(__uniConfig["async"]["error"]);
                },
              }),
            n
          );
        }),
        a.default.component("pages_sub1-active-lucky_draw", function (e) {
          var n = {
            component: Promise.all([
              t.e(
                "pages-active-goods~pages-active-turntable~pages-index-goods~pages-index-index~pages-pay-raffle~pages~c8bef51b",
              ),
              t.e("pages_sub1-active-lucky_draw"),
            ])
              .then(
                function () {
                  return e(t("200a"));
                }.bind(null, t),
              )
              .catch(t.oe),
            delay: __uniConfig["async"].delay,
            timeout: __uniConfig["async"].timeout,
          };
          return (
            __uniConfig["async"]["loading"] &&
              (n.loading = {
                name: "SystemAsyncLoading",
                render: function (e) {
                  return e(__uniConfig["async"]["loading"]);
                },
              }),
            __uniConfig["async"]["error"] &&
              (n.error = {
                name: "SystemAsyncError",
                render: function (e) {
                  return e(__uniConfig["async"]["error"]);
                },
              }),
            n
          );
        }),
        (e.__uniRoutes = [
          {
            path: "/",
            alias: "/pages/index/index",
            component: {
              render: function (e) {
                return e(
                  "Page",
                  {
                    props: Object.assign(
                      { isQuit: !0, isEntry: !0, isTabBar: !0, tabBarIndex: 0 },
                      __uniConfig.globalStyle,
                      {
                        navigationBarTitleText: "首页",
                        enableShareAppMessage: !0,
                        enableShareTimeline: !0,
                        "mp-weixin": {
                          navigationBarTitleText: "首页",
                          navigationStyle: "custom",
                        },
                        titleNView: !1,
                      },
                    ),
                  },
                  [e("pages-index-index", { slot: "page" })],
                );
              },
            },
            meta: {
              id: 1,
              name: "pages-index-index",
              isNVue: !1,
              maxWidth: 0,
              pagePath: "pages/index/index",
              isQuit: !0,
              isEntry: !0,
              isTabBar: !0,
              tabBarIndex: 0,
              windowTop: 0,
            },
          },
          {
            path: "/pages/user/index",
            component: {
              render: function (e) {
                return e(
                  "Page",
                  {
                    props: Object.assign(
                      { isQuit: !0, isTabBar: !0, tabBarIndex: 4 },
                      __uniConfig.globalStyle,
                      {
                        navigationBarTitleText: "个人中心",
                        enablePullDownRefresh: !0,
                        titleNView: !1,
                      },
                    ),
                  },
                  [e("pages-user-index", { slot: "page" })],
                );
              },
            },
            meta: {
              id: 2,
              name: "pages-user-index",
              isNVue: !1,
              maxWidth: 0,
              pagePath: "pages/user/index",
              isQuit: !0,
              isTabBar: !0,
              tabBarIndex: 4,
              windowTop: 0,
            },
          },
          {
            path: "/pages/follow/index",
            component: {
              render: function (e) {
                return e(
                  "Page",
                  {
                    props: Object.assign({}, __uniConfig.globalStyle, {
                      navigationBarTitleText: "关注",
                      enablePullDownRefresh: !0,
                      titleNView: !1,
                    }),
                  },
                  [e("pages-follow-index", { slot: "page" })],
                );
              },
            },
            meta: {
              name: "pages-follow-index",
              isNVue: !1,
              maxWidth: 0,
              pagePath: "pages/follow/index",
              windowTop: 0,
            },
          },
          {
            path: "/pages/cat/index",
            component: {
              render: function (e) {
                return e(
                  "Page",
                  {
                    props: Object.assign(
                      { isQuit: !0, isTabBar: !0, tabBarIndex: 1 },
                      __uniConfig.globalStyle,
                      {
                        navigationBarTitleText: "分类",
                        enablePullDownRefresh: !0,
                        titleNView: !1,
                      },
                    ),
                  },
                  [e("pages-cat-index", { slot: "page" })],
                );
              },
            },
            meta: {
              id: 3,
              name: "pages-cat-index",
              isNVue: !1,
              maxWidth: 0,
              pagePath: "pages/cat/index",
              isQuit: !0,
              isTabBar: !0,
              tabBarIndex: 1,
              windowTop: 0,
            },
          },
          {
            path: "/pages/cat/index2",
            component: {
              render: function (e) {
                return e(
                  "Page",
                  {
                    props: Object.assign({}, __uniConfig.globalStyle, {
                      navigationBarTitleText: "分类",
                      enablePullDownRefresh: !0,
                      titleNView: !1,
                    }),
                  },
                  [e("pages-cat-index2", { slot: "page" })],
                );
              },
            },
            meta: {
              name: "pages-cat-index2",
              isNVue: !1,
              maxWidth: 0,
              pagePath: "pages/cat/index2",
              windowTop: 0,
            },
          },
          {
            path: "/pages/index/goods",
            component: {
              render: function (e) {
                return e(
                  "Page",
                  {
                    props: Object.assign({}, __uniConfig.globalStyle, {
                      navigationBarTitleText: "商品详情",
                      enablePullDownRefresh: !0,
                    }),
                  },
                  [e("pages-index-goods", { slot: "page" })],
                );
              },
            },
            meta: {
              name: "pages-index-goods",
              isNVue: !1,
              maxWidth: 0,
              pagePath: "pages/index/goods",
              windowTop: 44,
            },
          },
          {
            path: "/pages/active/goods",
            component: {
              render: function (e) {
                return e(
                  "Page",
                  {
                    props: Object.assign({}, __uniConfig.globalStyle, {
                      navigationBarTitleText: "商品详情",
                      enablePullDownRefresh: !0,
                    }),
                  },
                  [e("pages-active-goods", { slot: "page" })],
                );
              },
            },
            meta: {
              name: "pages-active-goods",
              isNVue: !1,
              maxWidth: 0,
              pagePath: "pages/active/goods",
              windowTop: 44,
            },
          },
          {
            path: "/pages/active/order",
            component: {
              render: function (e) {
                return e(
                  "Page",
                  {
                    props: Object.assign({}, __uniConfig.globalStyle, {
                      navigationBarTitleText: "我的抽奖",
                      enablePullDownRefresh: !0,
                    }),
                  },
                  [e("pages-active-order", { slot: "page" })],
                );
              },
            },
            meta: {
              name: "pages-active-order",
              isNVue: !1,
              maxWidth: 0,
              pagePath: "pages/active/order",
              windowTop: 44,
            },
          },
          {
            path: "/pages/index/search",
            component: {
              render: function (e) {
                return e(
                  "Page",
                  {
                    props: Object.assign({}, __uniConfig.globalStyle, {
                      navigationBarTitleText: "搜索页面",
                      enablePullDownRefresh: !0,
                    }),
                  },
                  [e("pages-index-search", { slot: "page" })],
                );
              },
            },
            meta: {
              name: "pages-index-search",
              isNVue: !1,
              maxWidth: 0,
              pagePath: "pages/index/search",
              windowTop: 44,
            },
          },
          {
            path: "/pages/user/login",
            component: {
              render: function (e) {
                return e(
                  "Page",
                  {
                    props: Object.assign({}, __uniConfig.globalStyle, {
                      navigationBarTitleText: "正在登录..",
                      enablePullDownRefresh: !1,
                      navigationStyle: "custom",
                    }),
                  },
                  [e("pages-user-login", { slot: "page" })],
                );
              },
            },
            meta: {
              name: "pages-user-login",
              isNVue: !1,
              maxWidth: 0,
              pagePath: "pages/user/login",
              windowTop: 0,
            },
          },
          {
            path: "/pages/user/login_old",
            component: {
              render: function (e) {
                return e(
                  "Page",
                  {
                    props: Object.assign({}, __uniConfig.globalStyle, {
                      navigationBarTitleText: "登录",
                      enablePullDownRefresh: !1,
                      navigationStyle: "custom",
                    }),
                  },
                  [e("pages-user-login_old", { slot: "page" })],
                );
              },
            },
            meta: {
              name: "pages-user-login_old",
              isNVue: !1,
              maxWidth: 0,
              pagePath: "pages/user/login_old",
              windowTop: 0,
            },
          },
          {
            path: "/pages/cat/list",
            component: {
              render: function (e) {
                return e(
                  "Page",
                  {
                    props: Object.assign({}, __uniConfig.globalStyle, {
                      navigationBarTitleText: "商品列表",
                      enablePullDownRefresh: !0,
                    }),
                  },
                  [e("pages-cat-list", { slot: "page" })],
                );
              },
            },
            meta: {
              name: "pages-cat-list",
              isNVue: !1,
              maxWidth: 0,
              pagePath: "pages/cat/list",
              windowTop: 44,
            },
          },
          {
            path: "/pages/index/seller",
            component: {
              render: function (e) {
                return e(
                  "Page",
                  {
                    props: Object.assign({}, __uniConfig.globalStyle, {
                      navigationBarTitleText: "达人详情页",
                      enablePullDownRefresh: !1,
                    }),
                  },
                  [e("pages-index-seller", { slot: "page" })],
                );
              },
            },
            meta: {
              name: "pages-index-seller",
              isNVue: !1,
              maxWidth: 0,
              pagePath: "pages/index/seller",
              windowTop: 44,
            },
          },
          {
            path: "/pages/index/daren",
            component: {
              render: function (e) {
                return e(
                  "Page",
                  {
                    props: Object.assign(
                      { isQuit: !0, isTabBar: !0, tabBarIndex: 2 },
                      __uniConfig.globalStyle,
                      {
                        navigationBarTitleText: "达人列表页",
                        enablePullDownRefresh: !1,
                        titleNView: !1,
                      },
                    ),
                  },
                  [e("pages-index-daren", { slot: "page" })],
                );
              },
            },
            meta: {
              id: 4,
              name: "pages-index-daren",
              isNVue: !1,
              maxWidth: 0,
              pagePath: "pages/index/daren",
              isQuit: !0,
              isTabBar: !0,
              tabBarIndex: 2,
              windowTop: 0,
            },
          },
          {
            path: "/pages/pay/recharge",
            component: {
              render: function (e) {
                return e(
                  "Page",
                  {
                    props: Object.assign({}, __uniConfig.globalStyle, {
                      navigationBarTitleText: "余额充值",
                      enablePullDownRefresh: !0,
                    }),
                  },
                  [e("pages-pay-recharge", { slot: "page" })],
                );
              },
            },
            meta: {
              name: "pages-pay-recharge",
              isNVue: !1,
              maxWidth: 0,
              pagePath: "pages/pay/recharge",
              windowTop: 44,
            },
          },
          {
            path: "/pages/pay/vip",
            component: {
              render: function (e) {
                return e(
                  "Page",
                  {
                    props: Object.assign({}, __uniConfig.globalStyle, {
                      navigationBarTitleText: "开通vip",
                      enablePullDownRefresh: !0,
                    }),
                  },
                  [e("pages-pay-vip", { slot: "page" })],
                );
              },
            },
            meta: {
              name: "pages-pay-vip",
              isNVue: !1,
              maxWidth: 0,
              pagePath: "pages/pay/vip",
              windowTop: 44,
            },
          },
          {
            path: "/pages/pay/deposit",
            component: {
              render: function (e) {
                return e(
                  "Page",
                  {
                    props: Object.assign({}, __uniConfig.globalStyle, {
                      navigationBarTitleText: "保证金充值",
                      enablePullDownRefresh: !0,
                    }),
                  },
                  [e("pages-pay-deposit", { slot: "page" })],
                );
              },
            },
            meta: {
              name: "pages-pay-deposit",
              isNVue: !1,
              maxWidth: 0,
              pagePath: "pages/pay/deposit",
              windowTop: 44,
            },
          },
          {
            path: "/pages/pay/check_result",
            component: {
              render: function (e) {
                return e(
                  "Page",
                  {
                    props: Object.assign({}, __uniConfig.globalStyle, {
                      navigationBarTitleText: "",
                      enablePullDownRefresh: !0,
                    }),
                  },
                  [e("pages-pay-check_result", { slot: "page" })],
                );
              },
            },
            meta: {
              name: "pages-pay-check_result",
              isNVue: !1,
              maxWidth: 0,
              pagePath: "pages/pay/check_result",
              windowTop: 44,
            },
          },
          {
            path: "/pages/pay/success",
            component: {
              render: function (e) {
                return e(
                  "Page",
                  {
                    props: Object.assign({}, __uniConfig.globalStyle, {
                      navigationBarTitleText: "",
                      enablePullDownRefresh: !1,
                    }),
                  },
                  [e("pages-pay-success", { slot: "page" })],
                );
              },
            },
            meta: {
              name: "pages-pay-success",
              isNVue: !1,
              maxWidth: 0,
              pagePath: "pages/pay/success",
              windowTop: 44,
            },
          },
          {
            path: "/pages/alipay/index",
            component: {
              render: function (e) {
                return e(
                  "Page",
                  {
                    props: Object.assign({}, __uniConfig.globalStyle, {
                      navigationBarTitleText: "请在浏览器打开",
                      enablePullDownRefresh: !0,
                    }),
                  },
                  [e("pages-alipay-index", { slot: "page" })],
                );
              },
            },
            meta: {
              name: "pages-alipay-index",
              isNVue: !1,
              maxWidth: 0,
              pagePath: "pages/alipay/index",
              windowTop: 44,
            },
          },
          {
            path: "/pages/alipay/paid",
            component: {
              render: function (e) {
                return e(
                  "Page",
                  {
                    props: Object.assign({}, __uniConfig.globalStyle, {
                      navigationBarTitleText: "支付完成请手动返回微信",
                      enablePullDownRefresh: !0,
                    }),
                  },
                  [e("pages-alipay-paid", { slot: "page" })],
                );
              },
            },
            meta: {
              name: "pages-alipay-paid",
              isNVue: !1,
              maxWidth: 0,
              pagePath: "pages/alipay/paid",
              windowTop: 44,
            },
          },
          {
            path: "/pages/user/withdraw",
            component: {
              render: function (e) {
                return e(
                  "Page",
                  {
                    props: Object.assign({}, __uniConfig.globalStyle, {
                      navigationBarTitleText: "申请提现",
                      enablePullDownRefresh: !0,
                    }),
                  },
                  [e("pages-user-withdraw", { slot: "page" })],
                );
              },
            },
            meta: {
              name: "pages-user-withdraw",
              isNVue: !1,
              maxWidth: 0,
              pagePath: "pages/user/withdraw",
              windowTop: 44,
            },
          },
          {
            path: "/pages/user/withdraw_log",
            component: {
              render: function (e) {
                return e(
                  "Page",
                  {
                    props: Object.assign({}, __uniConfig.globalStyle, {
                      navigationBarTitleText: "提现记录",
                      enablePullDownRefresh: !0,
                    }),
                  },
                  [e("pages-user-withdraw_log", { slot: "page" })],
                );
              },
            },
            meta: {
              name: "pages-user-withdraw_log",
              isNVue: !1,
              maxWidth: 0,
              pagePath: "pages/user/withdraw_log",
              windowTop: 44,
            },
          },
          {
            path: "/pages/user/money_log",
            component: {
              render: function (e) {
                return e(
                  "Page",
                  {
                    props: Object.assign({}, __uniConfig.globalStyle, {
                      navigationBarTitleText: "余额记录",
                      enablePullDownRefresh: !0,
                    }),
                  },
                  [e("pages-user-money_log", { slot: "page" })],
                );
              },
            },
            meta: {
              name: "pages-user-money_log",
              isNVue: !1,
              maxWidth: 0,
              pagePath: "pages/user/money_log",
              windowTop: 44,
            },
          },
          {
            path: "/pages/user/order_log",
            component: {
              render: function (e) {
                return e(
                  "Page",
                  {
                    props: Object.assign({}, __uniConfig.globalStyle, {
                      navigationBarTitleText: "冻结记录",
                      enablePullDownRefresh: !0,
                    }),
                  },
                  [e("pages-user-order_log", { slot: "page" })],
                );
              },
            },
            meta: {
              name: "pages-user-order_log",
              isNVue: !1,
              maxWidth: 0,
              pagePath: "pages/user/order_log",
              windowTop: 44,
            },
          },
          {
            path: "/pages/user/article",
            component: {
              render: function (e) {
                return e(
                  "Page",
                  {
                    props: Object.assign({}, __uniConfig.globalStyle, {
                      navigationBarTitleText: "详情",
                      enablePullDownRefresh: !0,
                    }),
                  },
                  [e("pages-user-article", { slot: "page" })],
                );
              },
            },
            meta: {
              name: "pages-user-article",
              isNVue: !1,
              maxWidth: 0,
              pagePath: "pages/user/article",
              windowTop: 44,
            },
          },
          {
            path: "/pages/user/deposit_withdraw",
            component: {
              render: function (e) {
                return e(
                  "Page",
                  {
                    props: Object.assign({}, __uniConfig.globalStyle, {
                      navigationBarTitleText: "保证金",
                      enablePullDownRefresh: !0,
                    }),
                  },
                  [e("pages-user-deposit_withdraw", { slot: "page" })],
                );
              },
            },
            meta: {
              name: "pages-user-deposit_withdraw",
              isNVue: !1,
              maxWidth: 0,
              pagePath: "pages/user/deposit_withdraw",
              windowTop: 44,
            },
          },
          {
            path: "/pages/user/certification",
            component: {
              render: function (e) {
                return e(
                  "Page",
                  {
                    props: Object.assign({}, __uniConfig.globalStyle, {
                      navigationBarTitleText: "收款信息",
                      enablePullDownRefresh: !0,
                    }),
                  },
                  [e("pages-user-certification", { slot: "page" })],
                );
              },
            },
            meta: {
              name: "pages-user-certification",
              isNVue: !1,
              maxWidth: 0,
              pagePath: "pages/user/certification",
              windowTop: 44,
            },
          },
          {
            path: "/pages/user/huifu",
            component: {
              render: function (e) {
                return e(
                  "Page",
                  {
                    props: Object.assign({}, __uniConfig.globalStyle, {
                      navigationBarTitleText: "汇付收款信息",
                      enablePullDownRefresh: !0,
                    }),
                  },
                  [e("pages-user-huifu", { slot: "page" })],
                );
              },
            },
            meta: {
              name: "pages-user-huifu",
              isNVue: !1,
              maxWidth: 0,
              pagePath: "pages/user/huifu",
              windowTop: 44,
            },
          },
          {
            path: "/pages/user/personal",
            component: {
              render: function (e) {
                return e(
                  "Page",
                  {
                    props: Object.assign({}, __uniConfig.globalStyle, {
                      navigationBarTitleText: "个人资料",
                      enablePullDownRefresh: !0,
                    }),
                  },
                  [e("pages-user-personal", { slot: "page" })],
                );
              },
            },
            meta: {
              name: "pages-user-personal",
              isNVue: !1,
              maxWidth: 0,
              pagePath: "pages/user/personal",
              windowTop: 44,
            },
          },
          {
            path: "/pages/pay/index",
            component: {
              render: function (e) {
                return e(
                  "Page",
                  {
                    props: Object.assign({}, __uniConfig.globalStyle, {
                      navigationBarTitleText: "收银台",
                      enablePullDownRefresh: !1,
                    }),
                  },
                  [e("pages-pay-index", { slot: "page" })],
                );
              },
            },
            meta: {
              name: "pages-pay-index",
              isNVue: !1,
              maxWidth: 0,
              pagePath: "pages/pay/index",
              windowTop: 44,
            },
          },
          {
            path: "/pages/pay/submit",
            component: {
              render: function (e) {
                return e(
                  "Page",
                  {
                    props: Object.assign({}, __uniConfig.globalStyle, {
                      navigationBarTitleText: "提交订单",
                      enablePullDownRefresh: !1,
                    }),
                  },
                  [e("pages-pay-submit", { slot: "page" })],
                );
              },
            },
            meta: {
              name: "pages-pay-submit",
              isNVue: !1,
              maxWidth: 0,
              pagePath: "pages/pay/submit",
              windowTop: 44,
            },
          },
          {
            path: "/pages/pay/raffle",
            component: {
              render: function (e) {
                return e(
                  "Page",
                  {
                    props: Object.assign({}, __uniConfig.globalStyle, {
                      navigationBarTitleText: "提交订单",
                      enablePullDownRefresh: !1,
                    }),
                  },
                  [e("pages-pay-raffle", { slot: "page" })],
                );
              },
            },
            meta: {
              name: "pages-pay-raffle",
              isNVue: !1,
              maxWidth: 0,
              pagePath: "pages/pay/raffle",
              windowTop: 44,
            },
          },
          {
            path: "/pages/index/incomer",
            component: {
              render: function (e) {
                return e(
                  "Page",
                  {
                    props: Object.assign({}, __uniConfig.globalStyle, {
                      navigationBarTitleText: "温馨提示",
                    }),
                  },
                  [e("pages-index-incomer", { slot: "page" })],
                );
              },
            },
            meta: {
              name: "pages-index-incomer",
              isNVue: !1,
              maxWidth: 0,
              pagePath: "pages/index/incomer",
              windowTop: 44,
            },
          },
          {
            path: "/pages/active/turntable",
            component: {
              render: function (e) {
                return e(
                  "Page",
                  {
                    props: Object.assign({}, __uniConfig.globalStyle, {
                      navigationBarTitleText: "幸运大转盘",
                      enablePullDownRefresh: !1,
                      navigationStyle: "custom",
                    }),
                  },
                  [e("pages-active-turntable", { slot: "page" })],
                );
              },
            },
            meta: {
              name: "pages-active-turntable",
              isNVue: !1,
              maxWidth: 0,
              pagePath: "pages/active/turntable",
              windowTop: 0,
            },
          },
          {
            path: "/pages/user/bind_mobile",
            component: {
              render: function (e) {
                return e(
                  "Page",
                  {
                    props: Object.assign({}, __uniConfig.globalStyle, {
                      navigationBarTitleText: "绑定手机号",
                      enablePullDownRefresh: !1,
                      navigationStyle: "custom",
                    }),
                  },
                  [e("pages-user-bind_mobile", { slot: "page" })],
                );
              },
            },
            meta: {
              name: "pages-user-bind_mobile",
              isNVue: !1,
              maxWidth: 0,
              pagePath: "pages/user/bind_mobile",
              windowTop: 0,
            },
          },
          {
            path: "/pages/agent/index",
            component: {
              render: function (e) {
                return e(
                  "Page",
                  {
                    props: Object.assign({}, __uniConfig.globalStyle, {
                      navigationBarTitleText: "分销中心",
                      enablePullDownRefresh: !0,
                      titleNView: !1,
                    }),
                  },
                  [e("pages-agent-index", { slot: "page" })],
                );
              },
            },
            meta: {
              name: "pages-agent-index",
              isNVue: !1,
              maxWidth: 0,
              pagePath: "pages/agent/index",
              windowTop: 0,
            },
          },
          {
            path: "/pages/agent/child",
            component: {
              render: function (e) {
                return e(
                  "Page",
                  {
                    props: Object.assign({}, __uniConfig.globalStyle, {
                      navigationBarTitleText: "邀请列表",
                      enablePullDownRefresh: !0,
                    }),
                  },
                  [e("pages-agent-child", { slot: "page" })],
                );
              },
            },
            meta: {
              name: "pages-agent-child",
              isNVue: !1,
              maxWidth: 0,
              pagePath: "pages/agent/child",
              windowTop: 44,
            },
          },
          {
            path: "/pages/agent/score_log",
            component: {
              render: function (e) {
                return e(
                  "Page",
                  {
                    props: Object.assign({}, __uniConfig.globalStyle, {
                      navigationBarTitleText: "佣金记录",
                      enablePullDownRefresh: !1,
                    }),
                  },
                  [e("pages-agent-score_log", { slot: "page" })],
                );
              },
            },
            meta: {
              name: "pages-agent-score_log",
              isNVue: !1,
              maxWidth: 0,
              pagePath: "pages/agent/score_log",
              windowTop: 44,
            },
          },
          {
            path: "/pages/agent/cash_score",
            component: {
              render: function (e) {
                return e(
                  "Page",
                  {
                    props: Object.assign({}, __uniConfig.globalStyle, {
                      navigationBarTitleText: "申请佣金提现",
                      enablePullDownRefresh: !0,
                    }),
                  },
                  [e("pages-agent-cash_score", { slot: "page" })],
                );
              },
            },
            meta: {
              name: "pages-agent-cash_score",
              isNVue: !1,
              maxWidth: 0,
              pagePath: "pages/agent/cash_score",
              windowTop: 44,
            },
          },
          {
            path: "/pages/agent/cash_score_log",
            component: {
              render: function (e) {
                return e(
                  "Page",
                  {
                    props: Object.assign({}, __uniConfig.globalStyle, {
                      navigationBarTitleText: "佣金提现记录",
                      enablePullDownRefresh: !0,
                    }),
                  },
                  [e("pages-agent-cash_score_log", { slot: "page" })],
                );
              },
            },
            meta: {
              name: "pages-agent-cash_score_log",
              isNVue: !1,
              maxWidth: 0,
              pagePath: "pages/agent/cash_score_log",
              windowTop: 44,
            },
          },
          {
            path: "/pages/index/error",
            component: {
              render: function (e) {
                return e(
                  "Page",
                  {
                    props: Object.assign({}, __uniConfig.globalStyle, {
                      navigationBarTitleText: "",
                      enablePullDownRefresh: !1,
                      navigationStyle: "custom",
                    }),
                  },
                  [e("pages-index-error", { slot: "page" })],
                );
              },
            },
            meta: {
              name: "pages-index-error",
              isNVue: !1,
              maxWidth: 0,
              pagePath: "pages/index/error",
              windowTop: 0,
            },
          },
          {
            path: "/pages/index/agree",
            component: {
              render: function (e) {
                return e(
                  "Page",
                  {
                    props: Object.assign({}, __uniConfig.globalStyle, {
                      navigationBarTitleText: "隐私提示页",
                      enablePullDownRefresh: !0,
                      titleNView: !1,
                    }),
                  },
                  [e("pages-index-agree", { slot: "page" })],
                );
              },
            },
            meta: {
              name: "pages-index-agree",
              isNVue: !1,
              maxWidth: 0,
              pagePath: "pages/index/agree",
              windowTop: 0,
            },
          },
          {
            path: "/pages/user/bind_mobile_weapp",
            component: {
              render: function (e) {
                return e(
                  "Page",
                  {
                    props: Object.assign({}, __uniConfig.globalStyle, {
                      navigationBarTitleText: "手机号登录",
                      enablePullDownRefresh: !0,
                      titleNView: !1,
                    }),
                  },
                  [e("pages-user-bind_mobile_weapp", { slot: "page" })],
                );
              },
            },
            meta: {
              name: "pages-user-bind_mobile_weapp",
              isNVue: !1,
              maxWidth: 0,
              pagePath: "pages/user/bind_mobile_weapp",
              windowTop: 0,
            },
          },
          {
            path: "/pages/chat/list",
            component: {
              render: function (e) {
                return e(
                  "Page",
                  {
                    props: Object.assign(
                      { isQuit: !0, isTabBar: !0, tabBarIndex: 3 },
                      __uniConfig.globalStyle,
                      {
                        navigationBarTitleText: "聊天列表",
                        enablePullDownRefresh: !0,
                        titleNView: !1,
                      },
                    ),
                  },
                  [e("pages-chat-list", { slot: "page" })],
                );
              },
            },
            meta: {
              id: 5,
              name: "pages-chat-list",
              isNVue: !1,
              maxWidth: 0,
              pagePath: "pages/chat/list",
              isQuit: !0,
              isTabBar: !0,
              tabBarIndex: 3,
              windowTop: 0,
            },
          },
          {
            path: "/pages/system/index",
            component: {
              render: function (e) {
                return e(
                  "Page",
                  {
                    props: Object.assign({}, __uniConfig.globalStyle, {
                      navigationBarTitleText: "同款搭建指引",
                      enablePullDownRefresh: !1,
                    }),
                  },
                  [e("pages-system-index", { slot: "page" })],
                );
              },
            },
            meta: {
              name: "pages-system-index",
              isNVue: !1,
              maxWidth: 0,
              pagePath: "pages/system/index",
              windowTop: 44,
            },
          },
          {
            path: "/pages/user/level",
            component: {
              render: function (e) {
                return e(
                  "Page",
                  {
                    props: Object.assign({}, __uniConfig.globalStyle, {
                      navigationBarTitleText: "等级详情",
                      enablePullDownRefresh: !1,
                      titleNView: !1,
                    }),
                  },
                  [e("pages-user-level", { slot: "page" })],
                );
              },
            },
            meta: {
              name: "pages-user-level",
              isNVue: !1,
              maxWidth: 0,
              pagePath: "pages/user/level",
              windowTop: 0,
            },
          },
          {
            path: "/pages/user/apply",
            component: {
              render: function (e) {
                return e(
                  "Page",
                  {
                    props: Object.assign({}, __uniConfig.globalStyle, {
                      navigationBarTitleText: "申请成为陪玩",
                      enablePullDownRefresh: !1,
                    }),
                  },
                  [e("pages-user-apply", { slot: "page" })],
                );
              },
            },
            meta: {
              name: "pages-user-apply",
              isNVue: !1,
              maxWidth: 0,
              pagePath: "pages/user/apply",
              windowTop: 44,
            },
          },
          {
            path: "/pages/user/fine_list",
            component: {
              render: function (e) {
                return e(
                  "Page",
                  {
                    props: Object.assign({}, __uniConfig.globalStyle, {
                      navigationBarTitleText: "罚款列表",
                      enablePullDownRefresh: !0,
                    }),
                  },
                  [e("pages-user-fine_list", { slot: "page" })],
                );
              },
            },
            meta: {
              name: "pages-user-fine_list",
              isNVue: !1,
              maxWidth: 0,
              pagePath: "pages/user/fine_list",
              windowTop: 44,
            },
          },
          {
            path: "/pages_sub1/chat/index",
            component: {
              render: function (e) {
                return e(
                  "Page",
                  {
                    props: Object.assign({}, __uniConfig.globalStyle, {
                      navigationBarTitleText: "客服工作台",
                      enablePullDownRefresh: !0,
                      navigationStyle: "custom",
                    }),
                  },
                  [e("pages_sub1-chat-index", { slot: "page" })],
                );
              },
            },
            meta: {
              name: "pages_sub1-chat-index",
              isNVue: !1,
              maxWidth: 0,
              pagePath: "pages_sub1/chat/index",
              windowTop: 0,
            },
          },
          {
            path: "/pages_sub1/chat/info",
            component: {
              render: function (e) {
                return e(
                  "Page",
                  {
                    props: Object.assign({}, __uniConfig.globalStyle, {
                      navigationBarTitleText: "聊天页面",
                      enablePullDownRefresh: !1,
                      navigationStyle: "custom",
                      titleNView: !1,
                    }),
                  },
                  [e("pages_sub1-chat-info", { slot: "page" })],
                );
              },
            },
            meta: {
              name: "pages_sub1-chat-info",
              isNVue: !1,
              maxWidth: 0,
              pagePath: "pages_sub1/chat/info",
              windowTop: 0,
            },
          },
          {
            path: "/pages_sub1/chat/notice",
            component: {
              render: function (e) {
                return e(
                  "Page",
                  {
                    props: Object.assign({}, __uniConfig.globalStyle, {
                      navigationBarTitleText: "系统通知",
                      enablePullDownRefresh: !1,
                    }),
                  },
                  [e("pages_sub1-chat-notice", { slot: "page" })],
                );
              },
            },
            meta: {
              name: "pages_sub1-chat-notice",
              isNVue: !1,
              maxWidth: 0,
              pagePath: "pages_sub1/chat/notice",
              windowTop: 44,
            },
          },
          {
            path: "/pages_sub1/chat/history",
            component: {
              render: function (e) {
                return e(
                  "Page",
                  {
                    props: Object.assign({}, __uniConfig.globalStyle, {
                      navigationBarTitleText: "客服聊天记录",
                      enablePullDownRefresh: !0,
                    }),
                  },
                  [e("pages_sub1-chat-history", { slot: "page" })],
                );
              },
            },
            meta: {
              name: "pages_sub1-chat-history",
              isNVue: !1,
              maxWidth: 0,
              pagePath: "pages_sub1/chat/history",
              windowTop: 44,
            },
          },
          {
            path: "/pages_sub1/chat/test",
            component: {
              render: function (e) {
                return e(
                  "Page",
                  {
                    props: Object.assign({}, __uniConfig.globalStyle, {
                      navigationBarTitleText: "test",
                      enablePullDownRefresh: !1,
                    }),
                  },
                  [e("pages_sub1-chat-test", { slot: "page" })],
                );
              },
            },
            meta: {
              name: "pages_sub1-chat-test",
              isNVue: !1,
              maxWidth: 0,
              pagePath: "pages_sub1/chat/test",
              windowTop: 44,
            },
          },
          {
            path: "/pages_sub1/kefu/daka",
            component: {
              render: function (e) {
                return e(
                  "Page",
                  {
                    props: Object.assign({}, __uniConfig.globalStyle, {
                      navigationBarTitleText: "打卡",
                      enablePullDownRefresh: !0,
                    }),
                  },
                  [e("pages_sub1-kefu-daka", { slot: "page" })],
                );
              },
            },
            meta: {
              name: "pages_sub1-kefu-daka",
              isNVue: !1,
              maxWidth: 0,
              pagePath: "pages_sub1/kefu/daka",
              windowTop: 44,
            },
          },
          {
            path: "/pages_sub1/kefu/order",
            component: {
              render: function (e) {
                return e(
                  "Page",
                  {
                    props: Object.assign({}, __uniConfig.globalStyle, {
                      navigationBarTitleText: "客服 - 订单列表",
                      enablePullDownRefresh: !0,
                      titleNView: !1,
                    }),
                  },
                  [e("pages_sub1-kefu-order", { slot: "page" })],
                );
              },
            },
            meta: {
              name: "pages_sub1-kefu-order",
              isNVue: !1,
              maxWidth: 0,
              pagePath: "pages_sub1/kefu/order",
              windowTop: 0,
            },
          },
          {
            path: "/pages_sub1/kefu/audit",
            component: {
              render: function (e) {
                return e(
                  "Page",
                  {
                    props: Object.assign({}, __uniConfig.globalStyle, {
                      navigationBarTitleText: "客服-审核列表",
                      enablePullDownRefresh: !0,
                      titleNView: !1,
                    }),
                  },
                  [e("pages_sub1-kefu-audit", { slot: "page" })],
                );
              },
            },
            meta: {
              name: "pages_sub1-kefu-audit",
              isNVue: !1,
              maxWidth: 0,
              pagePath: "pages_sub1/kefu/audit",
              windowTop: 0,
            },
          },
          {
            path: "/pages_sub1/kefu/audit_detail",
            component: {
              render: function (e) {
                return e(
                  "Page",
                  {
                    props: Object.assign({}, __uniConfig.globalStyle, {
                      navigationBarTitleText: "客服-审核详情",
                      titleNView: !1,
                    }),
                  },
                  [e("pages_sub1-kefu-audit_detail", { slot: "page" })],
                );
              },
            },
            meta: {
              name: "pages_sub1-kefu-audit_detail",
              isNVue: !1,
              maxWidth: 0,
              pagePath: "pages_sub1/kefu/audit_detail",
              windowTop: 0,
            },
          },
          {
            path: "/pages_sub1/kefu/info",
            component: {
              render: function (e) {
                return e(
                  "Page",
                  {
                    props: Object.assign({}, __uniConfig.globalStyle, {
                      navigationBarTitleText: "客服 - 订单详情",
                      enablePullDownRefresh: !0,
                      titleNView: !1,
                    }),
                  },
                  [e("pages_sub1-kefu-info", { slot: "page" })],
                );
              },
            },
            meta: {
              name: "pages_sub1-kefu-info",
              isNVue: !1,
              maxWidth: 0,
              pagePath: "pages_sub1/kefu/info",
              windowTop: 0,
            },
          },
          {
            path: "/pages_sub1/kefu/service",
            component: {
              render: function (e) {
                return e(
                  "Page",
                  {
                    props: Object.assign({}, __uniConfig.globalStyle, {
                      navigationBarTitleText: "客服 - 售后详情",
                      enablePullDownRefresh: !0,
                      navigationStyle: "custom",
                    }),
                  },
                  [e("pages_sub1-kefu-service", { slot: "page" })],
                );
              },
            },
            meta: {
              name: "pages_sub1-kefu-service",
              isNVue: !1,
              maxWidth: 0,
              pagePath: "pages_sub1/kefu/service",
              windowTop: 0,
            },
          },
          {
            path: "/pages_sub1/kefu/total",
            component: {
              render: function (e) {
                return e(
                  "Page",
                  {
                    props: Object.assign({}, __uniConfig.globalStyle, {
                      navigationBarTitleText: "单量总和",
                      enablePullDownRefresh: !0,
                    }),
                  },
                  [e("pages_sub1-kefu-total", { slot: "page" })],
                );
              },
            },
            meta: {
              name: "pages_sub1-kefu-total",
              isNVue: !1,
              maxWidth: 0,
              pagePath: "pages_sub1/kefu/total",
              windowTop: 44,
            },
          },
          {
            path: "/pages_sub1/kefu/test",
            component: {
              render: function (e) {
                return e(
                  "Page",
                  {
                    props: Object.assign({}, __uniConfig.globalStyle, {
                      navigationBarTitleText: "test",
                      enablePullDownRefresh: !0,
                    }),
                  },
                  [e("pages_sub1-kefu-test", { slot: "page" })],
                );
              },
            },
            meta: {
              name: "pages_sub1-kefu-test",
              isNVue: !1,
              maxWidth: 0,
              pagePath: "pages_sub1/kefu/test",
              windowTop: 44,
            },
          },
          {
            path: "/pages_sub1/kefu/fine_list",
            component: {
              render: function (e) {
                return e(
                  "Page",
                  {
                    props: Object.assign({}, __uniConfig.globalStyle, {
                      navigationBarTitleText: "罚款管理",
                      enablePullDownRefresh: !0,
                    }),
                  },
                  [e("pages_sub1-kefu-fine_list", { slot: "page" })],
                );
              },
            },
            meta: {
              name: "pages_sub1-kefu-fine_list",
              isNVue: !1,
              maxWidth: 0,
              pagePath: "pages_sub1/kefu/fine_list",
              windowTop: 44,
            },
          },
          {
            path: "/pages_sub1/kefu/fine_add",
            component: {
              render: function (e) {
                return e(
                  "Page",
                  {
                    props: Object.assign({}, __uniConfig.globalStyle, {
                      navigationBarTitleText: "添加罚款",
                      enablePullDownRefresh: !1,
                    }),
                  },
                  [e("pages_sub1-kefu-fine_add", { slot: "page" })],
                );
              },
            },
            meta: {
              name: "pages_sub1-kefu-fine_add",
              isNVue: !1,
              maxWidth: 0,
              pagePath: "pages_sub1/kefu/fine_add",
              windowTop: 44,
            },
          },
          {
            path: "/pages_sub1/kefu/fine_detail",
            component: {
              render: function (e) {
                return e(
                  "Page",
                  {
                    props: Object.assign({}, __uniConfig.globalStyle, {
                      navigationBarTitleText: "罚款详情",
                      enablePullDownRefresh: !1,
                    }),
                  },
                  [e("pages_sub1-kefu-fine_detail", { slot: "page" })],
                );
              },
            },
            meta: {
              name: "pages_sub1-kefu-fine_detail",
              isNVue: !1,
              maxWidth: 0,
              pagePath: "pages_sub1/kefu/fine_detail",
              windowTop: 44,
            },
          },
          {
            path: "/pages_sub1/kefu/fine_edit",
            component: {
              render: function (e) {
                return e(
                  "Page",
                  {
                    props: Object.assign({}, __uniConfig.globalStyle, {
                      navigationBarTitleText: "编辑罚款",
                      enablePullDownRefresh: !1,
                    }),
                  },
                  [e("pages_sub1-kefu-fine_edit", { slot: "page" })],
                );
              },
            },
            meta: {
              name: "pages_sub1-kefu-fine_edit",
              isNVue: !1,
              maxWidth: 0,
              pagePath: "pages_sub1/kefu/fine_edit",
              windowTop: 44,
            },
          },
          {
            path: "/pages_sub1/seller/index",
            component: {
              render: function (e) {
                return e(
                  "Page",
                  {
                    props: Object.assign({}, __uniConfig.globalStyle, {
                      navigationBarTitleText: "打手中心",
                      enablePullDownRefresh: !0,
                    }),
                  },
                  [e("pages_sub1-seller-index", { slot: "page" })],
                );
              },
            },
            meta: {
              name: "pages_sub1-seller-index",
              isNVue: !1,
              maxWidth: 0,
              pagePath: "pages_sub1/seller/index",
              windowTop: 44,
            },
          },
          {
            path: "/pages_sub1/order/index",
            component: {
              render: function (e) {
                return e(
                  "Page",
                  {
                    props: Object.assign({}, __uniConfig.globalStyle, {
                      navigationBarTitleText: "订单列表",
                      enablePullDownRefresh: !0,
                      titleNView: !1,
                    }),
                  },
                  [e("pages_sub1-order-index", { slot: "page" })],
                );
              },
            },
            meta: {
              name: "pages_sub1-order-index",
              isNVue: !1,
              maxWidth: 0,
              pagePath: "pages_sub1/order/index",
              windowTop: 0,
            },
          },
          {
            path: "/pages_sub1/order/info",
            component: {
              render: function (e) {
                return e(
                  "Page",
                  {
                    props: Object.assign({}, __uniConfig.globalStyle, {
                      navigationBarTitleText: "用户 - 订单详情",
                      enablePullDownRefresh: !0,
                    }),
                  },
                  [e("pages_sub1-order-info", { slot: "page" })],
                );
              },
            },
            meta: {
              name: "pages_sub1-order-info",
              isNVue: !1,
              maxWidth: 0,
              pagePath: "pages_sub1/order/info",
              windowTop: 44,
            },
          },
          {
            path: "/pages_sub1/order/seller",
            component: {
              render: function (e) {
                return e(
                  "Page",
                  {
                    props: Object.assign({}, __uniConfig.globalStyle, {
                      navigationBarTitleText: "打手中心 - 订单列表",
                      enablePullDownRefresh: !0,
                      titleNView: !1,
                    }),
                  },
                  [e("pages_sub1-order-seller", { slot: "page" })],
                );
              },
            },
            meta: {
              name: "pages_sub1-order-seller",
              isNVue: !1,
              maxWidth: 0,
              pagePath: "pages_sub1/order/seller",
              windowTop: 0,
            },
          },
          {
            path: "/pages_sub1/order/seller_info",
            component: {
              render: function (e) {
                return e(
                  "Page",
                  {
                    props: Object.assign({}, __uniConfig.globalStyle, {
                      navigationBarTitleText: "打手 - 订单详情",
                      enablePullDownRefresh: !0,
                    }),
                  },
                  [e("pages_sub1-order-seller_info", { slot: "page" })],
                );
              },
            },
            meta: {
              name: "pages_sub1-order-seller_info",
              isNVue: !1,
              maxWidth: 0,
              pagePath: "pages_sub1/order/seller_info",
              windowTop: 44,
            },
          },
          {
            path: "/pages_sub1/order/audit_list",
            component: {
              render: function (e) {
                return e(
                  "Page",
                  {
                    props: Object.assign({}, __uniConfig.globalStyle, {
                      navigationBarTitleText: "审核订单-列表",
                      enablePullDownRefresh: !0,
                    }),
                  },
                  [e("pages_sub1-order-audit_list", { slot: "page" })],
                );
              },
            },
            meta: {
              name: "pages_sub1-order-audit_list",
              isNVue: !1,
              maxWidth: 0,
              pagePath: "pages_sub1/order/audit_list",
              windowTop: 44,
            },
          },
          {
            path: "/pages_sub1/order/audit_detail",
            component: {
              render: function (e) {
                return e(
                  "Page",
                  {
                    props: Object.assign({}, __uniConfig.globalStyle, {
                      navigationBarTitleText: "审核订单-详情",
                      enablePullDownRefresh: !0,
                    }),
                  },
                  [e("pages_sub1-order-audit_detail", { slot: "page" })],
                );
              },
            },
            meta: {
              name: "pages_sub1-order-audit_detail",
              isNVue: !1,
              maxWidth: 0,
              pagePath: "pages_sub1/order/audit_detail",
              windowTop: 44,
            },
          },
          {
            path: "/pages_sub1/order/service",
            component: {
              render: function (e) {
                return e(
                  "Page",
                  {
                    props: Object.assign({}, __uniConfig.globalStyle, {
                      navigationBarTitleText: "订单售后",
                      enablePullDownRefresh: !0,
                    }),
                  },
                  [e("pages_sub1-order-service", { slot: "page" })],
                );
              },
            },
            meta: {
              name: "pages_sub1-order-service",
              isNVue: !1,
              maxWidth: 0,
              pagePath: "pages_sub1/order/service",
              windowTop: 44,
            },
          },
          {
            path: "/pages_sub1/order/seller_service",
            component: {
              render: function (e) {
                return e(
                  "Page",
                  {
                    props: Object.assign({}, __uniConfig.globalStyle, {
                      navigationBarTitleText: "订单售后",
                      enablePullDownRefresh: !0,
                    }),
                  },
                  [e("pages_sub1-order-seller_service", { slot: "page" })],
                );
              },
            },
            meta: {
              name: "pages_sub1-order-seller_service",
              isNVue: !1,
              maxWidth: 0,
              pagePath: "pages_sub1/order/seller_service",
              windowTop: 44,
            },
          },
          {
            path: "/pages_sub1/order/comment",
            component: {
              render: function (e) {
                return e(
                  "Page",
                  {
                    props: Object.assign({}, __uniConfig.globalStyle, {
                      navigationBarTitleText: "发表评价",
                      enablePullDownRefresh: !0,
                    }),
                  },
                  [e("pages_sub1-order-comment", { slot: "page" })],
                );
              },
            },
            meta: {
              name: "pages_sub1-order-comment",
              isNVue: !1,
              maxWidth: 0,
              pagePath: "pages_sub1/order/comment",
              windowTop: 44,
            },
          },
          {
            path: "/pages_sub1/order/invite_fupei",
            component: {
              render: function (e) {
                return e(
                  "Page",
                  {
                    props: Object.assign({}, __uniConfig.globalStyle, {
                      navigationBarTitleText: "邀请副陪",
                      enablePullDownRefresh: !0,
                      titleNView: !1,
                    }),
                  },
                  [e("pages_sub1-order-invite_fupei", { slot: "page" })],
                );
              },
            },
            meta: {
              name: "pages_sub1-order-invite_fupei",
              isNVue: !1,
              maxWidth: 0,
              pagePath: "pages_sub1/order/invite_fupei",
              windowTop: 0,
            },
          },
          {
            path: "/pages_sub1/seller/invited",
            component: {
              render: function (e) {
                return e(
                  "Page",
                  {
                    props: Object.assign({}, __uniConfig.globalStyle, {
                      navigationBarTitleText: "受邀订单",
                      enablePullDownRefresh: !1,
                      titleNView: !1,
                    }),
                  },
                  [e("pages_sub1-seller-invited", { slot: "page" })],
                );
              },
            },
            meta: {
              name: "pages_sub1-seller-invited",
              isNVue: !1,
              maxWidth: 0,
              pagePath: "pages_sub1/seller/invited",
              windowTop: 0,
            },
          },
          {
            path: "/pages_sub1/seller/rank",
            component: {
              render: function (e) {
                return e(
                  "Page",
                  {
                    props: Object.assign({}, __uniConfig.globalStyle, {
                      navigationBarTitleText: "排行榜",
                    }),
                  },
                  [e("pages_sub1-seller-rank", { slot: "page" })],
                );
              },
            },
            meta: {
              name: "pages_sub1-seller-rank",
              isNVue: !1,
              maxWidth: 0,
              pagePath: "pages_sub1/seller/rank",
              windowTop: 44,
            },
          },
          {
            path: "/pages_sub1/seller/hall",
            component: {
              render: function (e) {
                return e(
                  "Page",
                  {
                    props: Object.assign({}, __uniConfig.globalStyle, {
                      navigationBarTitleText: "接单大厅",
                      titleNView: !1,
                    }),
                  },
                  [e("pages_sub1-seller-hall", { slot: "page" })],
                );
              },
            },
            meta: {
              name: "pages_sub1-seller-hall",
              isNVue: !1,
              maxWidth: 0,
              pagePath: "pages_sub1/seller/hall",
              windowTop: 0,
            },
          },
          {
            path: "/pages_sub1/seller/hall_info",
            component: {
              render: function (e) {
                return e(
                  "Page",
                  {
                    props: Object.assign({}, __uniConfig.globalStyle, {
                      navigationBarTitleText: "接单大厅 - 订单详情",
                    }),
                  },
                  [e("pages_sub1-seller-hall_info", { slot: "page" })],
                );
              },
            },
            meta: {
              name: "pages_sub1-seller-hall_info",
              isNVue: !1,
              maxWidth: 0,
              pagePath: "pages_sub1/seller/hall_info",
              windowTop: 44,
            },
          },
          {
            path: "/pages_sub1/seller/seller_pay",
            component: {
              render: function (e) {
                return e(
                  "Page",
                  {
                    props: Object.assign({}, __uniConfig.globalStyle, {
                      navigationBarTitleText: "开通接单权限",
                    }),
                  },
                  [e("pages_sub1-seller-seller_pay", { slot: "page" })],
                );
              },
            },
            meta: {
              name: "pages_sub1-seller-seller_pay",
              isNVue: !1,
              maxWidth: 0,
              pagePath: "pages_sub1/seller/seller_pay",
              windowTop: 44,
            },
          },
          {
            path: "/pages_sub1/seller/message",
            component: {
              render: function (e) {
                return e(
                  "Page",
                  {
                    props: Object.assign({}, __uniConfig.globalStyle, {
                      navigationBarTitleText: "订阅消息授权",
                      enablePullDownRefresh: !0,
                    }),
                  },
                  [e("pages_sub1-seller-message", { slot: "page" })],
                );
              },
            },
            meta: {
              name: "pages_sub1-seller-message",
              isNVue: !1,
              maxWidth: 0,
              pagePath: "pages_sub1/seller/message",
              windowTop: 44,
            },
          },
          {
            path: "/pages_sub1/seller/notice",
            component: {
              render: function (e) {
                return e(
                  "Page",
                  {
                    props: Object.assign({}, __uniConfig.globalStyle, {
                      navigationBarTitleText: "平台通知",
                      enablePullDownRefresh: !0,
                    }),
                  },
                  [e("pages_sub1-seller-notice", { slot: "page" })],
                );
              },
            },
            meta: {
              name: "pages_sub1-seller-notice",
              isNVue: !1,
              maxWidth: 0,
              pagePath: "pages_sub1/seller/notice",
              windowTop: 44,
            },
          },
          {
            path: "/pages_sub1/seller/notice_detail",
            component: {
              render: function (e) {
                return e(
                  "Page",
                  {
                    props: Object.assign({}, __uniConfig.globalStyle, {
                      navigationBarTitleText: "通知详情",
                      enablePullDownRefresh: !1,
                    }),
                  },
                  [e("pages_sub1-seller-notice_detail", { slot: "page" })],
                );
              },
            },
            meta: {
              name: "pages_sub1-seller-notice_detail",
              isNVue: !1,
              maxWidth: 0,
              pagePath: "pages_sub1/seller/notice_detail",
              windowTop: 44,
            },
          },
          {
            path: "/pages_sub1/seller/edit_profile",
            component: {
              render: function (e) {
                return e(
                  "Page",
                  {
                    props: Object.assign({}, __uniConfig.globalStyle, {
                      navigationBarTitleText: "编辑资料",
                      enablePullDownRefresh: !1,
                    }),
                  },
                  [e("pages_sub1-seller-edit_profile", { slot: "page" })],
                );
              },
            },
            meta: {
              name: "pages_sub1-seller-edit_profile",
              isNVue: !1,
              maxWidth: 0,
              pagePath: "pages_sub1/seller/edit_profile",
              windowTop: 44,
            },
          },
          {
            path: "/pages_sub1/active/lucky_draw",
            component: {
              render: function (e) {
                return e(
                  "Page",
                  {
                    props: Object.assign({}, __uniConfig.globalStyle, {
                      navigationBarTitleText: "幸运大转盘",
                      enablePullDownRefresh: !1,
                      navigationStyle: "custom",
                      titleNView: !1,
                    }),
                  },
                  [e("pages_sub1-active-lucky_draw", { slot: "page" })],
                );
              },
            },
            meta: {
              name: "pages_sub1-active-lucky_draw",
              isNVue: !1,
              maxWidth: 0,
              pagePath: "pages_sub1/active/lucky_draw",
              windowTop: 0,
            },
          },
          {
            path: "/choose-location",
            component: {
              render: function (e) {
                return e("Page", { props: { navigationStyle: "custom" } }, [
                  e("system-choose-location", { slot: "page" }),
                ]);
              },
            },
            meta: { name: "choose-location", pagePath: "/choose-location" },
          },
          {
            path: "/open-location",
            component: {
              render: function (e) {
                return e("Page", { props: { navigationStyle: "custom" } }, [
                  e("system-open-location", { slot: "page" }),
                ]);
              },
            },
            meta: { name: "open-location", pagePath: "/open-location" },
          },
        ]),
        e.UniApp && new e.UniApp();
    }).call(this, t("0ee4"));
  },
  b0e1: function (e, n, t) {
    "use strict";
    t("6a54");
    var a = t("f5bd").default;
    Object.defineProperty(n, "__esModule", { value: !0 }),
      (n.default = void 0),
      t("64aa");
    var i,
      o,
      r = a(t("9b1b")),
      s = {
        props: (0, r.default)(
          {
            icon: { type: String, default: "" },
            text: { type: String, default: "" },
            textColor: { type: String, default: "#c0c4cc" },
            textSize: { type: [String, Number], default: 14 },
            iconColor: { type: String, default: "#c0c4cc" },
            iconSize: { type: [String, Number], default: 90 },
            mode: { type: String, default: "data" },
            width: { type: [String, Number], default: 160 },
            height: { type: [String, Number], default: 160 },
            show: { type: Boolean, default: !0 },
            marginTop: { type: [String, Number], default: 0 },
          },
          null === (i = uni.$uv) ||
            void 0 === i ||
            null === (o = i.props) ||
            void 0 === o
            ? void 0
            : o.empty,
        ),
      };
    n.default = s;
  },
  b3c8: function (e, n, t) {
    "use strict";
    t.d(n, "b", function () {
      return a;
    }),
      t.d(n, "c", function () {
        return i;
      }),
      t.d(n, "a", function () {});
    var a = function () {
        var e = this,
          n = e.$createElement,
          t = e._self._c || n;
        return t(
          "v-uni-view",
          {
            staticClass: "uv-icon",
            class: ["uv-icon--" + e.labelPos],
            on: {
              click: function (n) {
                (arguments[0] = n = e.$handleEvent(n)),
                  e.clickHandler.apply(void 0, arguments);
              },
            },
          },
          [
            e.isImg
              ? t("v-uni-image", {
                  staticClass: "uv-icon__img",
                  style: [e.imgStyle, e.$uv.addStyle(e.customStyle)],
                  attrs: { src: e.name, mode: e.imgMode },
                })
              : t(
                  "v-uni-text",
                  {
                    staticClass: "uv-icon__icon",
                    class: e.uClasses,
                    style: [e.iconStyle, e.$uv.addStyle(e.customStyle)],
                    attrs: { "hover-class": e.hoverClass },
                  },
                  [e._v(e._s(e.icon))],
                ),
            "" !== e.label
              ? t(
                  "v-uni-text",
                  {
                    staticClass: "uv-icon__label",
                    style: {
                      color: e.labelColor,
                      fontSize: e.$uv.addUnit(e.labelSize),
                      marginLeft:
                        "right" == e.labelPos ? e.$uv.addUnit(e.space) : 0,
                      marginTop:
                        "bottom" == e.labelPos ? e.$uv.addUnit(e.space) : 0,
                      marginRight:
                        "left" == e.labelPos ? e.$uv.addUnit(e.space) : 0,
                      marginBottom:
                        "top" == e.labelPos ? e.$uv.addUnit(e.space) : 0,
                    },
                  },
                  [e._v(e._s(e.label))],
                )
              : e._e(),
          ],
          1,
        );
      },
      i = [];
  },
  b50f: function (e, n, t) {
    "use strict";
    var a = t("239e"),
      i = t.n(a);
    i.a;
  },
  b713: function (e, n, t) {
    "use strict";
    var a = t("3b2d"),
      i = t.n(a);
    i.a;
  },
  b8de: function (e, n, t) {
    var a = t("c86c");
    (n = a(!1)),
      n.push([
        e.i,
        '@charset "UTF-8";\r\n/**\r\n * 这里是uni-app内置的常用样式变量\r\n *\r\n * uni-app 官方扩展插件及插件市场（https://ext.dcloud.net.cn）上很多三方插件均使用了这些样式变量\r\n * 如果你是插件开发者，建议你使用scss预处理，并在插件代码中直接使用这些变量（无需 import 这个文件），方便用户通过搭积木的方式开发整体风格一致的App\r\n *\r\n */\r\n/**\r\n * 如果你是App开发者（插件使用者），你可以通过修改这些变量来定制自己的插件主题，实现自定义主题功能\r\n *\r\n * 如果你的项目同样使用了scss预处理，你也可以直接在你的 scss 代码中使用如下变量，同时无需 import 这个文件\r\n */\r\n/* 颜色变量 */\r\n/* 行为相关颜色 */\r\n/* 文字基本颜色 */\r\n/* 背景颜色 */\r\n/* 边框颜色 */\r\n/* 尺寸变量 */\r\n/* 文字尺寸 */\r\n/* 图片尺寸 */\r\n/* Border Radius */\r\n/* 水平间距 */\r\n/* 垂直间距 */\r\n/* 透明度 */\r\n/* 文章场景相关 */uni-view[data-v-9c879764], uni-scroll-view[data-v-9c879764], uni-swiper-item[data-v-9c879764]{display:flex;flex-direction:column;flex-shrink:0;flex-grow:0;flex-basis:auto;align-items:stretch;align-content:flex-start}.uv-loading-icon[data-v-9c879764]{flex-direction:row;align-items:center;justify-content:center;color:#c8c9cc}.uv-loading-icon__text[data-v-9c879764]{margin-left:4px;color:#606266;font-size:14px;line-height:20px}.uv-loading-icon__spinner[data-v-9c879764]{width:30px;height:30px;position:relative;box-sizing:border-box;max-width:100%;max-height:100%;-webkit-animation:uv-rotate-data-v-9c879764 1s linear infinite;animation:uv-rotate-data-v-9c879764 1s linear infinite}.uv-loading-icon__spinner--semicircle[data-v-9c879764]{border-width:2px;border-color:transparent;border-top-right-radius:100px;border-top-left-radius:100px;border-bottom-left-radius:100px;border-bottom-right-radius:100px;border-style:solid}.uv-loading-icon__spinner--circle[data-v-9c879764]{border-top-right-radius:100px;border-top-left-radius:100px;border-bottom-left-radius:100px;border-bottom-right-radius:100px;border-width:2px;border-top-color:#e5e5e5;border-right-color:#e5e5e5;border-bottom-color:#e5e5e5;border-left-color:#e5e5e5;border-style:solid}.uv-loading-icon--vertical[data-v-9c879764]{flex-direction:column}[data-v-9c879764]:host{font-size:0;line-height:1}.uv-loading-icon__spinner--spinner[data-v-9c879764]{-webkit-animation-timing-function:steps(12);animation-timing-function:steps(12)}.uv-loading-icon__text[data-v-9c879764]:empty{display:none}.uv-loading-icon--vertical .uv-loading-icon__text[data-v-9c879764]{margin:6px 0 0;color:#606266}.uv-loading-icon__dot[data-v-9c879764]{position:absolute;top:0;left:0;width:100%;height:100%}.uv-loading-icon__dot[data-v-9c879764]:before{display:block;width:2px;height:25%;margin:0 auto;background-color:currentColor;border-radius:40%;content:" "}.uv-loading-icon__dot[data-v-9c879764]:nth-of-type(1){-webkit-transform:rotate(30deg);transform:rotate(30deg);opacity:1}.uv-loading-icon__dot[data-v-9c879764]:nth-of-type(2){-webkit-transform:rotate(60deg);transform:rotate(60deg);opacity:.9375}.uv-loading-icon__dot[data-v-9c879764]:nth-of-type(3){-webkit-transform:rotate(90deg);transform:rotate(90deg);opacity:.875}.uv-loading-icon__dot[data-v-9c879764]:nth-of-type(4){-webkit-transform:rotate(120deg);transform:rotate(120deg);opacity:.8125}.uv-loading-icon__dot[data-v-9c879764]:nth-of-type(5){-webkit-transform:rotate(150deg);transform:rotate(150deg);opacity:.75}.uv-loading-icon__dot[data-v-9c879764]:nth-of-type(6){-webkit-transform:rotate(180deg);transform:rotate(180deg);opacity:.6875}.uv-loading-icon__dot[data-v-9c879764]:nth-of-type(7){-webkit-transform:rotate(210deg);transform:rotate(210deg);opacity:.625}.uv-loading-icon__dot[data-v-9c879764]:nth-of-type(8){-webkit-transform:rotate(240deg);transform:rotate(240deg);opacity:.5625}.uv-loading-icon__dot[data-v-9c879764]:nth-of-type(9){-webkit-transform:rotate(270deg);transform:rotate(270deg);opacity:.5}.uv-loading-icon__dot[data-v-9c879764]:nth-of-type(10){-webkit-transform:rotate(300deg);transform:rotate(300deg);opacity:.4375}.uv-loading-icon__dot[data-v-9c879764]:nth-of-type(11){-webkit-transform:rotate(330deg);transform:rotate(330deg);opacity:.375}.uv-loading-icon__dot[data-v-9c879764]:nth-of-type(12){-webkit-transform:rotate(1turn);transform:rotate(1turn);opacity:.3125}@-webkit-keyframes uv-rotate-data-v-9c879764{0%{-webkit-transform:rotate(0deg);transform:rotate(0deg)}to{-webkit-transform:rotate(1turn);transform:rotate(1turn)}}@keyframes uv-rotate-data-v-9c879764{0%{-webkit-transform:rotate(0deg);transform:rotate(0deg)}to{-webkit-transform:rotate(1turn);transform:rotate(1turn)}}',
        "",
      ]),
      (e.exports = n);
  },
  b92c: function (e, n, t) {
    "use strict";
    t("6a54");
    var a = t("f5bd").default;
    Object.defineProperty(n, "__esModule", { value: !0 }),
      (n.default = void 0),
      t("64aa");
    var i,
      o,
      r = a(t("9b1b")),
      s = {
        props: (0, r.default)(
          {
            isDot: { type: Boolean, default: !1 },
            value: { type: [Number, String], default: "" },
            show: { type: Boolean, default: !0 },
            max: { type: [Number, String], default: 999 },
            type: { type: [String, void 0, null], default: "error" },
            showZero: { type: Boolean, default: !1 },
            bgColor: { type: [String, null], default: null },
            color: { type: [String, null], default: null },
            shape: { type: [String, void 0, null], default: "circle" },
            numberType: { type: [String, void 0, null], default: "overflow" },
            offset: {
              type: Array,
              default: function () {
                return [];
              },
            },
            inverted: { type: Boolean, default: !1 },
            absolute: { type: Boolean, default: !1 },
          },
          null === (i = uni.$uv) ||
            void 0 === i ||
            null === (o = i.props) ||
            void 0 === o
            ? void 0
            : o.badge,
        ),
      };
    n.default = s;
  },
  b987: function (e, n, t) {
    "use strict";
    t.r(n);
    var a = t("49a9"),
      i = t.n(a);
    for (var o in a)
      ["default"].indexOf(o) < 0 &&
        (function (e) {
          t.d(n, e, function () {
            return a[e];
          });
        })(o);
    n["default"] = i.a;
  },
  ba46: function (e, n, t) {
    var a = t("c86c");
    (n = a(!1)),
      n.push([
        e.i,
        '@charset "UTF-8";\r\n/**\r\n * 这里是uni-app内置的常用样式变量\r\n *\r\n * uni-app 官方扩展插件及插件市场（https://ext.dcloud.net.cn）上很多三方插件均使用了这些样式变量\r\n * 如果你是插件开发者，建议你使用scss预处理，并在插件代码中直接使用这些变量（无需 import 这个文件），方便用户通过搭积木的方式开发整体风格一致的App\r\n *\r\n */\r\n/**\r\n * 如果你是App开发者（插件使用者），你可以通过修改这些变量来定制自己的插件主题，实现自定义主题功能\r\n *\r\n * 如果你的项目同样使用了scss预处理，你也可以直接在你的 scss 代码中使用如下变量，同时无需 import 这个文件\r\n */\r\n/* 颜色变量 */\r\n/* 行为相关颜色 */\r\n/* 文字基本颜色 */\r\n/* 背景颜色 */\r\n/* 边框颜色 */\r\n/* 尺寸变量 */\r\n/* 文字尺寸 */\r\n/* 图片尺寸 */\r\n/* Border Radius */\r\n/* 水平间距 */\r\n/* 垂直间距 */\r\n/* 透明度 */\r\n/* 文章场景相关 */.uv-popup[data-v-549adfe2]{position:fixed;z-index:99}.uv-popup.top[data-v-549adfe2], .uv-popup.left[data-v-549adfe2], .uv-popup.right[data-v-549adfe2]{top:var(--window-top)}.uv-popup .uv-popup__content[data-v-549adfe2]{display:block;overflow:hidden;position:relative}.uv-popup .uv-popup__content.left[data-v-549adfe2], .uv-popup .uv-popup__content.right[data-v-549adfe2]{padding-top:var(--window-top);flex:1}.uv-popup .uv-popup__content__close[data-v-549adfe2]{position:absolute}.uv-popup .uv-popup__content__close--hover[data-v-549adfe2]{opacity:.4}.uv-popup .uv-popup__content__close--top-left[data-v-549adfe2]{top:15px;left:15px}.uv-popup .uv-popup__content__close--top-right[data-v-549adfe2]{top:15px;right:15px}.uv-popup .uv-popup__content__close--bottom-left[data-v-549adfe2]{bottom:15px;left:15px}.uv-popup .uv-popup__content__close--bottom-right[data-v-549adfe2]{right:15px;bottom:15px}.fixforpc-z-index[data-v-549adfe2]{z-index:999}.fixforpc-top[data-v-549adfe2]{top:0}',
        "",
      ]),
      (e.exports = n);
  },
  bce1: function (e, n, t) {
    "use strict";
    var a = t("3ae7"),
      i = t.n(a);
    i.a;
  },
  bd68: function (e, n, t) {
    "use strict";
    t.r(n);
    var a = t("131d"),
      i = t("ed9c");
    for (var o in i)
      ["default"].indexOf(o) < 0 &&
        (function (e) {
          t.d(n, e, function () {
            return i[e];
          });
        })(o);
    t("40c2");
    var r = t("828b"),
      s = Object(r["a"])(
        i["default"],
        a["b"],
        a["c"],
        !1,
        null,
        "6a10a26c",
        null,
        !1,
        a["a"],
        void 0,
      );
    n["default"] = s.exports;
  },
  bde0: function (e, n, t) {
    var a = t("c86c");
    (n = a(!1)),
      n.push([
        e.i,
        '@charset "UTF-8";\r\n/**\r\n * 这里是uni-app内置的常用样式变量\r\n *\r\n * uni-app 官方扩展插件及插件市场（https://ext.dcloud.net.cn）上很多三方插件均使用了这些样式变量\r\n * 如果你是插件开发者，建议你使用scss预处理，并在插件代码中直接使用这些变量（无需 import 这个文件），方便用户通过搭积木的方式开发整体风格一致的App\r\n *\r\n */\r\n/**\r\n * 如果你是App开发者（插件使用者），你可以通过修改这些变量来定制自己的插件主题，实现自定义主题功能\r\n *\r\n * 如果你的项目同样使用了scss预处理，你也可以直接在你的 scss 代码中使用如下变量，同时无需 import 这个文件\r\n */\r\n/* 颜色变量 */\r\n/* 行为相关颜色 */\r\n/* 文字基本颜色 */\r\n/* 背景颜色 */\r\n/* 边框颜色 */\r\n/* 尺寸变量 */\r\n/* 文字尺寸 */\r\n/* 图片尺寸 */\r\n/* Border Radius */\r\n/* 水平间距 */\r\n/* 垂直间距 */\r\n/* 透明度 */\r\n/* 文章场景相关 */.uv-safe-bottom[data-v-30d33ae6]{width:100%}.uv-safe-area-inset-top[data-v-30d33ae6]{padding-top:0;padding-top:constant(safe-area-inset-top);padding-top:env(safe-area-inset-top)}.uv-safe-area-inset-right[data-v-30d33ae6]{padding-right:0;padding-right:constant(safe-area-inset-right);padding-right:env(safe-area-inset-right)}.uv-safe-area-inset-bottom[data-v-30d33ae6]{padding-bottom:0;padding-bottom:constant(safe-area-inset-bottom);padding-bottom:env(safe-area-inset-bottom)}.uv-safe-area-inset-left[data-v-30d33ae6]{padding-left:0;padding-left:constant(safe-area-inset-left);padding-left:env(safe-area-inset-left)}',
        "",
      ]),
      (e.exports = n);
  },
  bf17: function (e, n, t) {
    "use strict";
    t.r(n);
    var a = t("6e0d"),
      i = t.n(a);
    for (var o in a)
      ["default"].indexOf(o) < 0 &&
        (function (e) {
          t.d(n, e, function () {
            return a[e];
          });
        })(o);
    n["default"] = i.a;
  },
  c4df: function (e, n, t) {
    "use strict";
    t.d(n, "b", function () {
      return a;
    }),
      t.d(n, "c", function () {
        return i;
      }),
      t.d(n, "a", function () {});
    var a = function () {
        var e = this,
          n = e.$createElement,
          t = e._self._c || n;
        return e.isShow
          ? t(
              "v-uni-view",
              {
                ref: "ani",
                class: e.customClass,
                style: e.transformStyles,
                attrs: { animation: e.animationData },
                on: {
                  click: function (n) {
                    (arguments[0] = n = e.$handleEvent(n)),
                      e.onClick.apply(void 0, arguments);
                  },
                },
              },
              [e._t("default")],
              2,
            )
          : e._e();
      },
      i = [];
  },
  c5a3: function (e, n, t) {
    "use strict";
    t("6a54");
    var a = t("f5bd").default;
    Object.defineProperty(n, "__esModule", { value: !0 }),
      (n.default = void 0),
      (n.divide = g),
      (n.enableBoundaryChecking = h),
      (n.minus = p),
      (n.plus = f),
      (n.round = _),
      (n.times = d);
    var i = a(t("9591"));
    t("e838"),
      t("64aa"),
      t("5c47"),
      t("dfcf"),
      t("c9b5"),
      t("bf0f"),
      t("ab80"),
      t("5ef2"),
      t("a1c1"),
      t("e062"),
      t("4259"),
      t("f7a5"),
      t("2797");
    var o = !0;
    function r(e) {
      var n =
        arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : 15;
      return +parseFloat(Number(e).toPrecision(n));
    }
    function s(e) {
      var n = e.toString().split(/[eE]/),
        t = (n[0].split(".")[1] || "").length - +(n[1] || 0);
      return t > 0 ? t : 0;
    }
    function u(e) {
      if (-1 === e.toString().indexOf("e"))
        return Number(e.toString().replace(".", ""));
      var n = s(e);
      return n > 0 ? r(Number(e) * Math.pow(10, n)) : Number(e);
    }
    function c(e) {
      o &&
        (e > Number.MAX_SAFE_INTEGER || e < Number.MIN_SAFE_INTEGER) &&
        console.warn("".concat(e, " 超出了精度限制，结果可能不正确"));
    }
    function l(e, n) {
      var t = (0, i.default)(e),
        a = t[0],
        o = t[1],
        r = t.slice(2),
        s = n(a, o);
      return (
        r.forEach(function (e) {
          s = n(s, e);
        }),
        s
      );
    }
    function d() {
      for (var e = arguments.length, n = new Array(e), t = 0; t < e; t++)
        n[t] = arguments[t];
      if (n.length > 2) return l(n, d);
      var a = n[0],
        i = n[1],
        o = u(a),
        r = u(i),
        f = s(a) + s(i),
        p = o * r;
      return c(p), p / Math.pow(10, f);
    }
    function f() {
      for (var e = arguments.length, n = new Array(e), t = 0; t < e; t++)
        n[t] = arguments[t];
      if (n.length > 2) return l(n, f);
      var a = n[0],
        i = n[1],
        o = Math.pow(10, Math.max(s(a), s(i)));
      return (d(a, o) + d(i, o)) / o;
    }
    function p() {
      for (var e = arguments.length, n = new Array(e), t = 0; t < e; t++)
        n[t] = arguments[t];
      if (n.length > 2) return l(n, p);
      var a = n[0],
        i = n[1],
        o = Math.pow(10, Math.max(s(a), s(i)));
      return (d(a, o) - d(i, o)) / o;
    }
    function g() {
      for (var e = arguments.length, n = new Array(e), t = 0; t < e; t++)
        n[t] = arguments[t];
      if (n.length > 2) return l(n, g);
      var a = n[0],
        i = n[1],
        o = u(a),
        f = u(i);
      return c(o), c(f), d(o / f, r(Math.pow(10, s(i) - s(a))));
    }
    function _(e, n) {
      var t = Math.pow(10, n),
        a = g(Math.round(Math.abs(d(e, t))), t);
      return e < 0 && 0 !== a && (a = d(a, -1)), a;
    }
    function h() {
      var e =
        !(arguments.length > 0 && void 0 !== arguments[0]) || arguments[0];
      o = e;
    }
    var m = {
      times: d,
      plus: f,
      minus: p,
      divide: g,
      round: _,
      enableBoundaryChecking: h,
    };
    n.default = m;
  },
  c653: function (e, n, t) {
    "use strict";
    t.d(n, "b", function () {
      return a;
    }),
      t.d(n, "c", function () {
        return i;
      }),
      t.d(n, "a", function () {});
    var a = function () {
        var e = this,
          n = e.$createElement,
          t = e._self._c || n;
        return t(
          "v-uni-view",
          {},
          [
            t("v-uni-view", { staticClass: "game-banner" }, [
              t("i", { staticClass: "diamond" }),
              t("span", { staticClass: "text-l" }),
              t("i", { staticClass: "split-line" }),
              t("span", { staticClass: "text-r" }, [
                e._v("游趣科技提供技术支持v6.1.5"),
              ]),
            ]),
            t(
              "v-uni-view",
              { staticClass: "personal-footer" },
              [
                t(
                  "v-uni-view",
                  {
                    staticClass: "esports-build-btn",
                    on: {
                      click: function (n) {
                        (arguments[0] = n = e.$handleEvent(n)),
                          e.jump("/pages/system/index");
                      },
                    },
                  },
                  [
                    t("v-uni-view", { staticClass: "btn-icon-box" }, [
                      e._v("🚀"),
                    ]),
                    t("v-uni-text", { staticClass: "btn-text" }, [
                      e._v("做电竞俱乐部就找我们"),
                    ]),
                  ],
                  1,
                ),
              ],
              1,
            ),
          ],
          1,
        );
      },
      i = [];
  },
  c724: function (e, n, t) {
    "use strict";
    (function (e) {
      var a = t("f5bd").default;
      Object.defineProperty(n, "__esModule", { value: !0 }),
        (n.default = void 0);
      var i = a(t("fcf3"));
      t("c1a3"),
        t("bf0f"),
        t("18f7"),
        t("de6c"),
        t("f3f7"),
        t("23f4"),
        t("7d2f"),
        t("5c47"),
        t("9c4e"),
        t("ab80"),
        t("7a76"),
        t("c9b5"),
        t("926e"),
        t("5ef2"),
        t("aa9c"),
        t("2797"),
        t("9a2c"),
        t("01a2"),
        t("6a54"),
        t("7f48");
      var o = (function () {
          function n(e, n) {
            return null != n && e instanceof n;
          }
          var t, a, o;
          try {
            t = Map;
          } catch (c) {
            t = function () {};
          }
          try {
            a = Set;
          } catch (c) {
            a = function () {};
          }
          try {
            o = Promise;
          } catch (c) {
            o = function () {};
          }
          function r(s, c, l, d, f) {
            "object" === (0, i.default)(c) &&
              ((l = c.depth),
              (d = c.prototype),
              (f = c.includeNonEnumerable),
              (c = c.circular));
            var p = [],
              g = [],
              _ = "undefined" != typeof e;
            return (
              "undefined" == typeof c && (c = !0),
              "undefined" == typeof l && (l = 1 / 0),
              (function s(l, h) {
                if (null === l) return null;
                if (0 === h) return l;
                var m, v;
                if ("object" != (0, i.default)(l)) return l;
                if (n(l, t)) m = new t();
                else if (n(l, a)) m = new a();
                else if (n(l, o))
                  m = new o(function (e, n) {
                    l.then(
                      function (n) {
                        e(s(n, h - 1));
                      },
                      function (e) {
                        n(s(e, h - 1));
                      },
                    );
                  });
                else if (r.__isArray(l)) m = [];
                else if (r.__isRegExp(l))
                  (m = new RegExp(l.source, u(l))),
                    l.lastIndex && (m.lastIndex = l.lastIndex);
                else if (r.__isDate(l)) m = new Date(l.getTime());
                else {
                  if (_ && e.isBuffer(l))
                    return (
                      e.from
                        ? (m = e.from(l))
                        : ((m = new e(l.length)), l.copy(m)),
                      m
                    );
                  n(l, Error)
                    ? (m = Object.create(l))
                    : "undefined" == typeof d
                      ? ((v = Object.getPrototypeOf(l)), (m = Object.create(v)))
                      : ((m = Object.create(d)), (v = d));
                }
                if (c) {
                  var b = p.indexOf(l);
                  if (-1 != b) return g[b];
                  p.push(l), g.push(m);
                }
                for (var y in (n(l, t) &&
                  l.forEach(function (e, n) {
                    var t = s(n, h - 1),
                      a = s(e, h - 1);
                    m.set(t, a);
                  }),
                n(l, a) &&
                  l.forEach(function (e) {
                    var n = s(e, h - 1);
                    m.add(n);
                  }),
                l)) {
                  var x = Object.getOwnPropertyDescriptor(l, y);
                  x && (m[y] = s(l[y], h - 1));
                  try {
                    var w = Object.getOwnPropertyDescriptor(l, y);
                    if ("undefined" === w.set) continue;
                    m[y] = s(l[y], h - 1);
                  } catch (A) {
                    if (A instanceof TypeError) continue;
                    if (A instanceof ReferenceError) continue;
                  }
                }
                if (Object.getOwnPropertySymbols) {
                  var C = Object.getOwnPropertySymbols(l);
                  for (y = 0; y < C.length; y++) {
                    var S = C[y],
                      k = Object.getOwnPropertyDescriptor(l, S);
                    (!k || k.enumerable || f) &&
                      ((m[S] = s(l[S], h - 1)), Object.defineProperty(m, S, k));
                  }
                }
                if (f) {
                  var P = Object.getOwnPropertyNames(l);
                  for (y = 0; y < P.length; y++) {
                    var T = P[y];
                    k = Object.getOwnPropertyDescriptor(l, T);
                    (k && k.enumerable) ||
                      ((m[T] = s(l[T], h - 1)), Object.defineProperty(m, T, k));
                  }
                }
                return m;
              })(s, l)
            );
          }
          function s(e) {
            return Object.prototype.toString.call(e);
          }
          function u(e) {
            var n = "";
            return (
              e.global && (n += "g"),
              e.ignoreCase && (n += "i"),
              e.multiline && (n += "m"),
              n
            );
          }
          return (
            (r.clonePrototype = function (e) {
              if (null === e) return null;
              var n = function () {};
              return (n.prototype = e), new n();
            }),
            (r.__objToStr = s),
            (r.__isDate = function (e) {
              return "object" === (0, i.default)(e) && "[object Date]" === s(e);
            }),
            (r.__isArray = function (e) {
              return (
                "object" === (0, i.default)(e) && "[object Array]" === s(e)
              );
            }),
            (r.__isRegExp = function (e) {
              return (
                "object" === (0, i.default)(e) && "[object RegExp]" === s(e)
              );
            }),
            (r.__getRegExpFlags = u),
            r
          );
        })(),
        r = o;
      n.default = r;
    }).call(this, t("12e3").Buffer);
  },
  ca70: function (e, n, t) {
    "use strict";
    t.r(n);
    var a = t("d046"),
      i = t("84e9");
    for (var o in i)
      ["default"].indexOf(o) < 0 &&
        (function (e) {
          t.d(n, e, function () {
            return i[e];
          });
        })(o);
    t("bce1");
    var r = t("828b"),
      s = Object(r["a"])(
        i["default"],
        a["b"],
        a["c"],
        !1,
        null,
        "e1d4828a",
        null,
        !1,
        a["a"],
        void 0,
      );
    n["default"] = s.exports;
  },
  ca83: function (e, n, t) {
    "use strict";
    t.d(n, "b", function () {
      return i;
    }),
      t.d(n, "c", function () {
        return o;
      }),
      t.d(n, "a", function () {
        return a;
      });
    var a = { uvSafeBottom: t("e787").default },
      i = function () {
        var e = this,
          n = e.$createElement,
          t = e._self._c || n;
        return t(
          "v-uni-view",
          { staticClass: "uv-tabbar" },
          [
            t(
              "v-uni-view",
              {
                ref: "uv-tabbar__content",
                staticClass: "uv-tabbar__content",
                class: [
                  e.border && "uv-border-top",
                  e.fixed && "uv-tabbar--fixed",
                ],
                style: [e.tabbarStyle],
                on: {
                  touchmove: function (n) {
                    n.stopPropagation(),
                      n.preventDefault(),
                      (arguments[0] = n = e.$handleEvent(n)),
                      e.noop.apply(void 0, arguments);
                  },
                },
              },
              [
                t(
                  "v-uni-view",
                  { staticClass: "uv-tabbar__content__item-wrapper" },
                  [e._t("default")],
                  2,
                ),
                e.safeAreaInsetBottom ? t("uv-safe-bottom") : e._e(),
              ],
              1,
            ),
            e.placeholder
              ? t("v-uni-view", {
                  staticClass: "uv-tabbar__placeholder",
                  style: { height: e.placeholderHeight + "px" },
                })
              : e._e(),
          ],
          1,
        );
      },
      o = [];
  },
  caef: function (e, n, t) {
    "use strict";
    t.r(n);
    var a = t("5ad5"),
      i = t("d0c0");
    for (var o in i)
      ["default"].indexOf(o) < 0 &&
        (function (e) {
          t.d(n, e, function () {
            return i[e];
          });
        })(o);
    t("f194");
    var r = t("828b"),
      s = Object(r["a"])(
        i["default"],
        a["b"],
        a["c"],
        !1,
        null,
        "b6f66da4",
        null,
        !1,
        a["a"],
        void 0,
      );
    n["default"] = s.exports;
  },
  cc43: function (e, n, t) {
    var a = t("25cd");
    a.__esModule && (a = a.default),
      "string" === typeof a && (a = [[e.i, a, ""]]),
      a.locals && (e.exports = a.locals);
    var i = t("967d").default;
    i("65d4690b", a, !0, { sourceMap: !1, shadowMode: !1 });
  },
  ce8a: function (e, n, t) {
    "use strict";
    t.r(n);
    var a = t("46e2"),
      i = t("3774");
    for (var o in i)
      ["default"].indexOf(o) < 0 &&
        (function (e) {
          t.d(n, e, function () {
            return i[e];
          });
        })(o);
    t("6382");
    var r = t("828b"),
      s = Object(r["a"])(
        i["default"],
        a["b"],
        a["c"],
        !1,
        null,
        "549adfe2",
        null,
        !1,
        a["a"],
        void 0,
      );
    n["default"] = s.exports;
  },
  d011: function (e, n, t) {
    "use strict";
    var a = t("d68a"),
      i = t.n(a);
    i.a;
  },
  d025: function (e, n, t) {
    "use strict";
    t.r(n);
    var a = t("2bc3"),
      i = t("533b");
    for (var o in i)
      ["default"].indexOf(o) < 0 &&
        (function (e) {
          t.d(n, e, function () {
            return i[e];
          });
        })(o);
    t("7264");
    var r = t("828b"),
      s = Object(r["a"])(
        i["default"],
        a["b"],
        a["c"],
        !1,
        null,
        "55b48544",
        null,
        !1,
        a["a"],
        void 0,
      );
    n["default"] = s.exports;
  },
  d046: function (e, n, t) {
    "use strict";
    t.d(n, "b", function () {
      return i;
    }),
      t.d(n, "c", function () {
        return o;
      }),
      t.d(n, "a", function () {
        return a;
      });
    var a = { uvTabbar: t("2144").default, uvTabbarItem: t("620b").default },
      i = function () {
        var e = this,
          n = e.$createElement,
          t = e._self._c || n;
        return t(
          "v-uni-view",
          {},
          [
            t(
              "uv-tabbar",
              {
                attrs: {
                  value: e.currentTab,
                  fixed: !0,
                  placeholder: !0,
                  safeAreaInsetBottom: !0,
                  inactiveColor: "#666",
                  activeColor: "#000",
                },
                on: {
                  change: function (n) {
                    (arguments[0] = n = e.$handleEvent(n)),
                      e.setSelected.apply(void 0, arguments);
                  },
                },
              },
              e._l(e.filteredTabs, function (n, a) {
                return t("uv-tabbar-item", {
                  key: a,
                  attrs: { name: n.name, text: n.text },
                  scopedSlots: e._u(
                    [
                      {
                        key: "active-icon",
                        fn: function () {
                          return [
                            t("v-uni-image", {
                              staticClass: "icon",
                              attrs: { src: n.activeIcon },
                            }),
                          ];
                        },
                        proxy: !0,
                      },
                      {
                        key: "inactive-icon",
                        fn: function () {
                          return [
                            t("v-uni-image", {
                              staticClass: "icon",
                              attrs: { src: n.inactiveIcon },
                            }),
                          ];
                        },
                        proxy: !0,
                      },
                    ],
                    null,
                    !0,
                  ),
                });
              }),
              1,
            ),
          ],
          1,
        );
      },
      o = [];
  },
  d06d: function (e, n, t) {
    "use strict";
    t.r(n);
    var a = t("1239"),
      i = t.n(a);
    for (var o in a)
      ["default"].indexOf(o) < 0 &&
        (function (e) {
          t.d(n, e, function () {
            return a[e];
          });
        })(o);
    n["default"] = i.a;
  },
  d0c0: function (e, n, t) {
    "use strict";
    t.r(n);
    var a = t("2650"),
      i = t.n(a);
    for (var o in a)
      ["default"].indexOf(o) < 0 &&
        (function (e) {
          t.d(n, e, function () {
            return a[e];
          });
        })(o);
    n["default"] = i.a;
  },
  d235: function (e, n, t) {
    "use strict";
    t.r(n);
    var a = t("ec20"),
      i = t("214f");
    for (var o in i)
      ["default"].indexOf(o) < 0 &&
        (function (e) {
          t.d(n, e, function () {
            return i[e];
          });
        })(o);
    t("10e0");
    var r = t("828b"),
      s = Object(r["a"])(
        i["default"],
        a["b"],
        a["c"],
        !1,
        null,
        "1a80c36c",
        null,
        !1,
        a["a"],
        void 0,
      );
    n["default"] = s.exports;
  },
  d3f5: function (e, n, t) {
    "use strict";
    t("6a54");
    var a = t("f5bd").default;
    Object.defineProperty(n, "__esModule", { value: !0 }), (n.default = void 0);
    var i = a(t("4d8f0")),
      o = a(t("9463")),
      r = a(t("9766")),
      s = {
        name: "uv-search",
        emits: [
          "click",
          "input",
          "change",
          "clear",
          "search",
          "custom",
          "focus",
          "blur",
          "clickIcon",
          "update:modelValue",
        ],
        mixins: [i.default, o.default, r.default],
        data: function () {
          return { keyword: "", showClear: !1, show: !1, focused: this.focus };
        },
        created: function () {
          this.keyword = this.value;
        },
        watch: {
          value: function (e) {
            this.keyword = e;
          },
          modelValue: function (e) {
            this.keyword = e;
          },
        },
        computed: {
          showActionBtn: function () {
            return !this.animation && this.showAction;
          },
        },
        methods: {
          keywordChange: function () {
            this.$emit("input", this.keyword),
              this.$emit("update:modelValue", this.keyword),
              this.$emit("change", this.keyword);
          },
          inputChange: function (e) {
            (this.keyword = e.detail.value), this.keywordChange();
          },
          clear: function () {
            var e = this;
            (this.keyword = ""),
              this.$nextTick(function () {
                e.$emit("clear");
              }),
              this.keywordChange();
          },
          search: function (e) {
            this.$emit("search", e.detail.value);
            try {
              uni.hideKeyboard();
            } catch (e) {}
          },
          custom: function () {
            this.$emit("custom", this.keyword);
            try {
              uni.hideKeyboard();
            } catch (e) {}
          },
          getFocus: function () {
            (this.focused = !0),
              this.animation && this.showAction && (this.show = !0),
              this.$emit("focus", this.keyword);
          },
          blur: function () {
            var e = this;
            setTimeout(function () {
              e.focused = !1;
            }, 100),
              (this.show = !1),
              this.$emit("blur", this.keyword);
          },
          clickHandler: function () {
            this.disabled && this.$emit("click");
          },
          clickIcon: function () {
            this.$emit("clickIcon");
          },
        },
      };
    n.default = s;
  },
  d68a: function (e, n, t) {
    var a = t("ad5b");
    a.__esModule && (a = a.default),
      "string" === typeof a && (a = [[e.i, a, ""]]),
      a.locals && (e.exports = a.locals);
    var i = t("967d").default;
    i("80308f3c", a, !0, { sourceMap: !1, shadowMode: !1 });
  },
  d755: function (e, n, t) {
    "use strict";
    t("6a54");
    var a = t("f5bd").default;
    Object.defineProperty(n, "__esModule", { value: !0 }), (n.default = void 0);
    var i = a(t("9b1b")),
      o = a(t("fcf3"));
    t("bf0f"), t("2797"), t("4626"), t("5ac7");
    var r = a(t("f1ac")),
      s = a(t("0232")),
      u = a(t("509e")),
      c = t("117a"),
      l = function (e, n) {
        var t = {};
        return (
          e.forEach(function (e) {
            (0, c.isUndefined)(n[e]) || (t[e] = n[e]);
          }),
          t
        );
      };
    n.default = function (e) {
      return new Promise(function (n, t) {
        var a,
          c = (0, r.default)(
            (0, s.default)(e.baseURL, e.url),
            e.params,
            e.paramsSerializer,
          ),
          d = {
            url: c,
            header: e.header,
            complete: function (a) {
              (e.fullPath = c), (a.config = e), (a.rawData = a.data);
              try {
                var i = !1,
                  r = (0, o.default)(e.forcedJSONParsing);
                if ("boolean" === r) i = e.forcedJSONParsing;
                else if ("object" === r) {
                  var s = e.forcedJSONParsing.include || [];
                  i = s.includes(e.method);
                }
                i &&
                  "string" === typeof a.data &&
                  (a.data = JSON.parse(a.data));
              } catch (l) {}
              (0, u.default)(n, t, a);
            },
          };
        if ("UPLOAD" === e.method) {
          delete d.header["content-type"], delete d.header["Content-Type"];
          var f = { filePath: e.filePath, name: e.name };
          a = uni.uploadFile(
            (0, i.default)(
              (0, i.default)((0, i.default)({}, d), f),
              l(["files", "file", "timeout", "formData"], e),
            ),
          );
        } else if ("DOWNLOAD" === e.method) {
          a = uni.downloadFile(
            (0, i.default)((0, i.default)({}, d), l(["timeout"], e)),
          );
        } else {
          a = uni.request(
            (0, i.default)(
              (0, i.default)({}, d),
              l(
                [
                  "data",
                  "method",
                  "timeout",
                  "dataType",
                  "responseType",
                  "withCredentials",
                ],
                e,
              ),
            ),
          );
        }
        e.getTask && e.getTask(a, e);
      });
    };
  },
  d932: function (e, n, t) {
    "use strict";
    t.d(n, "b", function () {
      return i;
    }),
      t.d(n, "c", function () {
        return o;
      }),
      t.d(n, "a", function () {
        return a;
      });
    var a = { uvIcon: t("1a07").default, uvBadge: t("0261").default },
      i = function () {
        var e = this,
          n = e.$createElement,
          t = e._self._c || n;
        return t(
          "v-uni-view",
          {
            staticClass: "uv-tabbar-item",
            style: [e.$uv.addStyle(e.customStyle)],
            on: {
              click: function (n) {
                (arguments[0] = n = e.$handleEvent(n)),
                  e.clickHandler.apply(void 0, arguments);
              },
            },
          },
          [
            t(
              "v-uni-view",
              { staticClass: "uv-tabbar-item__icon" },
              [
                e.icon
                  ? t("uv-icon", {
                      attrs: {
                        name: e.icon,
                        color: e.isActive
                          ? e.parentData.activeColor
                          : e.parentData.inactiveColor,
                        size: e.iconSize ? e.iconSize : e.parentData.iconSize,
                      },
                    })
                  : [e.isActive ? e._t("active-icon") : e._t("inactive-icon")],
                t("uv-badge", {
                  attrs: {
                    absolute: !0,
                    offset: [
                      0,
                      e.dot ? "34rpx" : e.badge > 9 ? "14rpx" : "20rpx",
                    ],
                    customStyle: e.badgeStyle,
                    isDot: e.dot,
                    value: e.badge || (e.dot ? 1 : null),
                    show: e.dot || e.badge > 0,
                  },
                }),
              ],
              2,
            ),
            e._t("text", [
              t(
                "v-uni-text",
                {
                  staticClass: "uv-tabbar-item__text",
                  style: {
                    color: e.isActive
                      ? e.parentData.activeColor
                      : e.parentData.inactiveColor,
                  },
                },
                [e._v(e._s(e.text))],
              ),
            ]),
          ],
          2,
        );
      },
      o = [];
  },
  da5e: function (e, n, t) {
    "use strict";
    t("6a54");
    var a = t("f5bd").default;
    Object.defineProperty(n, "__esModule", { value: !0 }),
      (n.default = void 0),
      t("64aa"),
      t("5ef2");
    var i,
      o,
      r = a(t("9b1b")),
      s = a(t("ea56")),
      u = a(t("4d8f0")),
      c = a(t("9463")),
      l = {
        name: "uv-popup",
        components: { keypress: s.default },
        mixins: [u.default, c.default],
        emits: ["change", "maskClick"],
        props: (0, r.default)(
          {
            mode: { type: String, default: "center" },
            duration: { type: [String, Number], default: 300 },
            zIndex: { type: [String, Number], default: 997 },
            bgColor: { type: String, default: "#ffffff" },
            safeArea: { type: Boolean, default: !0 },
            overlay: { type: Boolean, default: !0 },
            closeOnClickOverlay: { type: Boolean, default: !0 },
            overlayOpacity: { type: [Number, String], default: 0.4 },
            overlayStyle: { type: [Object, String], default: "" },
            safeAreaInsetBottom: { type: Boolean, default: !0 },
            safeAreaInsetTop: { type: Boolean, default: !1 },
            closeable: { type: Boolean, default: !1 },
            closeIconPos: { type: String, default: "top-right" },
            zoom: { type: Boolean, default: !0 },
            round: { type: [Number, String], default: 0 },
          },
          null === (i = uni.$uv) ||
            void 0 === i ||
            null === (o = i.props) ||
            void 0 === o
            ? void 0
            : o.popup,
        ),
        watch: {
          type: {
            handler: function (e) {
              this.config[e] && this[this.config[e]](!0);
            },
            immediate: !0,
          },
          isDesktop: {
            handler: function (e) {
              this.config[e] && this[this.config[this.mode]](!0);
            },
            immediate: !0,
          },
          showPopup: function (e) {
            document.getElementsByTagName("body")[0].style.overflow = e
              ? "hidden"
              : "visible";
          },
        },
        data: function () {
          return {
            ani: [],
            showPopup: !1,
            showTrans: !1,
            popupWidth: 0,
            popupHeight: 0,
            config: {
              top: "top",
              bottom: "bottom",
              center: "center",
              left: "left",
              right: "right",
              message: "top",
              dialog: "center",
              share: "bottom",
            },
            transitionStyle: { position: "fixed", left: 0, right: 0 },
            maskShow: !0,
            mkclick: !0,
            popupClass: this.isDesktop ? "fixforpc-top" : "top",
            direction: "",
          };
        },
        computed: {
          isDesktop: function () {
            return this.popupWidth >= 500 && this.popupHeight >= 500;
          },
          bg: function () {
            return "" === this.bgColor ||
              "none" === this.bgColor ||
              this.$uv.getPx(this.round) > 0
              ? "transparent"
              : this.bgColor;
          },
          contentStyle: function () {
            var e = {};
            if ((this.bgColor && (e.backgroundColor = this.bg), this.round)) {
              var n = this.$uv.addUnit(this.round),
                t = this.direction ? this.direction : this.mode;
              (e.backgroundColor = this.bgColor),
                "top" === t
                  ? ((e.borderBottomLeftRadius = n),
                    (e.borderBottomRightRadius = n))
                  : "bottom" === t
                    ? ((e.borderTopLeftRadius = n),
                      (e.borderTopRightRadius = n))
                    : "center" === t && (e.borderRadius = n);
            }
            return this.$uv.deepMerge(e, this.$uv.addStyle(this.customStyle));
          },
        },
        destroyed: function () {
          this.setH5Visible();
        },
        created: function () {
          (this.messageChild = null), (this.clearPropagation = !1);
        },
        methods: {
          setH5Visible: function () {
            document.getElementsByTagName("body")[0].style.overflow = "visible";
          },
          closeMask: function () {
            this.maskShow = !1;
          },
          clear: function (e) {
            e.stopPropagation(), (this.clearPropagation = !0);
          },
          open: function (e) {
            if (!this.showPopup) {
              if (
                (e &&
                -1 !==
                  [
                    "top",
                    "center",
                    "bottom",
                    "left",
                    "right",
                    "message",
                    "dialog",
                    "share",
                  ].indexOf(e)
                  ? (this.direction = e)
                  : (e = this.mode),
                !this.config[e])
              )
                return this.$uv.error("缺少类型：".concat(e));
              this[this.config[e]](),
                this.$emit("change", { show: !0, type: e });
            }
          },
          close: function (e) {
            var n = this;
            (this.showTrans = !1),
              this.$emit("change", { show: !1, type: this.mode }),
              clearTimeout(this.timer),
              (this.timer = setTimeout(function () {
                n.showPopup = !1;
              }, 300));
          },
          touchstart: function () {
            this.clearPropagation = !1;
          },
          onTap: function () {
            this.clearPropagation
              ? (this.clearPropagation = !1)
              : (this.$emit("maskClick"),
                this.closeOnClickOverlay && this.close());
          },
          top: function (e) {
            var n = this;
            (this.popupClass = this.isDesktop ? "fixforpc-top" : "top"),
              (this.ani = ["slide-top"]),
              (this.transitionStyle = {
                position: "fixed",
                zIndex: this.zIndex,
                left: 0,
                right: 0,
                backgroundColor: this.bg,
              }),
              e ||
                ((this.showPopup = !0),
                (this.showTrans = !0),
                this.$nextTick(function () {
                  n.messageChild &&
                    "message" === n.mode &&
                    n.messageChild.timerClose();
                }));
          },
          bottom: function (e) {
            (this.popupClass = "bottom"),
              (this.ani = ["slide-bottom"]),
              (this.transitionStyle = {
                position: "fixed",
                zIndex: this.zIndex,
                left: 0,
                right: 0,
                bottom: 0,
                backgroundColor: this.bg,
              }),
              e || ((this.showPopup = !0), (this.showTrans = !0));
          },
          center: function (e) {
            (this.popupClass = "center"),
              (this.ani = this.zoom ? ["zoom-in", "fade"] : ["fade"]),
              (this.transitionStyle = {
                position: "fixed",
                zIndex: this.zIndex,
                display: "flex",
                flexDirection: "column",
                bottom: 0,
                left: 0,
                right: 0,
                top: 0,
                justifyContent: "center",
                alignItems: "center",
              }),
              e || ((this.showPopup = !0), (this.showTrans = !0));
          },
          left: function (e) {
            (this.popupClass = "left"),
              (this.ani = ["slide-left"]),
              (this.transitionStyle = {
                position: "fixed",
                zIndex: this.zIndex,
                left: 0,
                bottom: 0,
                top: 0,
                backgroundColor: this.bg,
                display: "flex",
                flexDirection: "column",
              }),
              e || ((this.showPopup = !0), (this.showTrans = !0));
          },
          right: function (e) {
            (this.popupClass = "right"),
              (this.ani = ["slide-right"]),
              (this.transitionStyle = {
                position: "fixed",
                zIndex: this.zIndex,
                bottom: 0,
                right: 0,
                top: 0,
                backgroundColor: this.bg,
                display: "flex",
                flexDirection: "column",
              }),
              e || ((this.showPopup = !0), (this.showTrans = !0));
          },
        },
      };
    n.default = l;
  },
  ddaa: function (e, n, t) {
    "use strict";
    t("6a54");
    var a = t("f5bd").default;
    Object.defineProperty(n, "__esModule", { value: !0 }), (n.default = void 0);
    var i = a(t("2634")),
      o = a(t("2fdc"));
    t("fd3c");
    var r = a(t("4d8f0")),
      s = a(t("9463")),
      u = a(t("fea9")),
      c = {
        name: "uv-tabbar",
        mixins: [r.default, s.default, u.default],
        data: function () {
          return { placeholderHeight: 0 };
        },
        computed: {
          tabbarStyle: function () {
            var e = { zIndex: this.zIndex };
            return this.$uv.deepMerge(e, this.$uv.addStyle(this.customStyle));
          },
          updateChild: function () {
            return [this.value, this.activeColor, this.inactiveColor];
          },
          updatePlaceholder: function () {
            return [this.fixed, this.placeholder];
          },
        },
        watch: {
          updateChild: function () {
            this.updateChildren();
          },
          updatePlaceholder: function () {
            this.setPlaceholderHeight();
          },
        },
        created: function () {
          this.children = [];
        },
        mounted: function () {
          this.setPlaceholderHeight();
        },
        methods: {
          updateChildren: function () {
            this.children.length &&
              this.children.map(function (e) {
                return e.updateFromParent();
              });
          },
          setPlaceholderHeight: function () {
            var e = this;
            return (0, o.default)(
              (0, i.default)().mark(function n() {
                return (0, i.default)().wrap(function (n) {
                  while (1)
                    switch ((n.prev = n.next)) {
                      case 0:
                        if (e.fixed && e.placeholder) {
                          n.next = 2;
                          break;
                        }
                        return n.abrupt("return");
                      case 2:
                        return (n.next = 4), e.$uv.sleep(20);
                      case 4:
                        e.$uvGetRect(".uv-tabbar__content").then(function (n) {
                          var t = n.height,
                            a = void 0 === t ? 50 : t;
                          e.placeholderHeight = a;
                        });
                      case 5:
                      case "end":
                        return n.stop();
                    }
                }, n);
              }),
            )();
          },
        },
      };
    n.default = c;
  },
  de33: function (e, n, t) {
    var a = t("c86c");
    (n = a(!1)),
      n.push([
        e.i,
        '@charset "UTF-8";\r\n/**\r\n * 这里是uni-app内置的常用样式变量\r\n *\r\n * uni-app 官方扩展插件及插件市场（https://ext.dcloud.net.cn）上很多三方插件均使用了这些样式变量\r\n * 如果你是插件开发者，建议你使用scss预处理，并在插件代码中直接使用这些变量（无需 import 这个文件），方便用户通过搭积木的方式开发整体风格一致的App\r\n *\r\n */\r\n/**\r\n * 如果你是App开发者（插件使用者），你可以通过修改这些变量来定制自己的插件主题，实现自定义主题功能\r\n *\r\n * 如果你的项目同样使用了scss预处理，你也可以直接在你的 scss 代码中使用如下变量，同时无需 import 这个文件\r\n */\r\n/* 颜色变量 */\r\n/* 行为相关颜色 */\r\n/* 文字基本颜色 */\r\n/* 背景颜色 */\r\n/* 边框颜色 */\r\n/* 尺寸变量 */\r\n/* 文字尺寸 */\r\n/* 图片尺寸 */\r\n/* Border Radius */\r\n/* 水平间距 */\r\n/* 垂直间距 */\r\n/* 透明度 */\r\n/* 文章场景相关 */.uv-line-1[data-v-6a10a26c]{display:-webkit-box!important;overflow:hidden;text-overflow:ellipsis;word-break:break-all;-webkit-line-clamp:1;-webkit-box-orient:vertical!important}.uv-line-2[data-v-6a10a26c]{display:-webkit-box!important;overflow:hidden;text-overflow:ellipsis;word-break:break-all;-webkit-line-clamp:2;-webkit-box-orient:vertical!important}.uv-line-3[data-v-6a10a26c]{display:-webkit-box!important;overflow:hidden;text-overflow:ellipsis;word-break:break-all;-webkit-line-clamp:3;-webkit-box-orient:vertical!important}.uv-line-4[data-v-6a10a26c]{display:-webkit-box!important;overflow:hidden;text-overflow:ellipsis;word-break:break-all;-webkit-line-clamp:4;-webkit-box-orient:vertical!important}.uv-line-5[data-v-6a10a26c]{display:-webkit-box!important;overflow:hidden;text-overflow:ellipsis;word-break:break-all;-webkit-line-clamp:5;-webkit-box-orient:vertical!important}uni-view[data-v-6a10a26c], uni-scroll-view[data-v-6a10a26c], uni-swiper-item[data-v-6a10a26c]{display:flex;flex-direction:column;flex-shrink:0;flex-grow:0;flex-basis:auto;align-items:stretch;align-content:flex-start}.uv-loadmore[data-v-6a10a26c]{display:flex;flex-direction:row;align-items:center;justify-content:center;flex:1}.uv-loadmore__content[data-v-6a10a26c]{margin:0 15px;display:flex;flex-direction:row;align-items:center;justify-content:center}.uv-loadmore__content__icon-wrap[data-v-6a10a26c]{margin-right:8px}.uv-loadmore__content__text[data-v-6a10a26c]{font-size:14px;color:#606266}.uv-loadmore__content__dot-text[data-v-6a10a26c]{font-size:15px;color:#909193}',
        "",
      ]),
      (e.exports = n);
  },
  e0a2: function (e, n, t) {
    var a = t("f286");
    a.__esModule && (a = a.default),
      "string" === typeof a && (a = [[e.i, a, ""]]),
      a.locals && (e.exports = a.locals);
    var i = t("967d").default;
    i("05b49e42", a, !0, { sourceMap: !1, shadowMode: !1 });
  },
  e1c2: function (e, n, t) {
    "use strict";
    t("6a54"),
      Object.defineProperty(n, "__esModule", { value: !0 }),
      (n.default = function (e, n) {
        return n ? e.replace(/\/+$/, "") + "/" + n.replace(/^\/+/, "") : e;
      }),
      t("5c47"),
      t("a1c1");
  },
  e249: function (e, n, t) {
    var a = t("ba46");
    a.__esModule && (a = a.default),
      "string" === typeof a && (a = [[e.i, a, ""]]),
      a.locals && (e.exports = a.locals);
    var i = t("967d").default;
    i("19a3b624", a, !0, { sourceMap: !1, shadowMode: !1 });
  },
  e2a3: function (e, n, t) {
    "use strict";
    t.r(n);
    var a = t("445c"),
      i = t.n(a);
    for (var o in a)
      ["default"].indexOf(o) < 0 &&
        (function (e) {
          t.d(n, e, function () {
            return a[e];
          });
        })(o);
    n["default"] = i.a;
  },
  e320: function (e, n, t) {
    var a = t("e3d7");
    a.__esModule && (a = a.default),
      "string" === typeof a && (a = [[e.i, a, ""]]),
      a.locals && (e.exports = a.locals);
    var i = t("967d").default;
    i("30b9ad0c", a, !0, { sourceMap: !1, shadowMode: !1 });
  },
  e3d7: function (e, n, t) {
    var a = t("c86c"),
      i = t("2ec5"),
      o = t("f5b6");
    n = a(!1);
    var r = i(o);
    n.push([
      e.i,
      '@charset "UTF-8";\r\n/**\r\n * 这里是uni-app内置的常用样式变量\r\n *\r\n * uni-app 官方扩展插件及插件市场（https://ext.dcloud.net.cn）上很多三方插件均使用了这些样式变量\r\n * 如果你是插件开发者，建议你使用scss预处理，并在插件代码中直接使用这些变量（无需 import 这个文件），方便用户通过搭积木的方式开发整体风格一致的App\r\n *\r\n */\r\n/**\r\n * 如果你是App开发者（插件使用者），你可以通过修改这些变量来定制自己的插件主题，实现自定义主题功能\r\n *\r\n * 如果你的项目同样使用了scss预处理，你也可以直接在你的 scss 代码中使用如下变量，同时无需 import 这个文件\r\n */\r\n/* 颜色变量 */\r\n/* 行为相关颜色 */\r\n/* 文字基本颜色 */\r\n/* 背景颜色 */\r\n/* 边框颜色 */\r\n/* 尺寸变量 */\r\n/* 文字尺寸 */\r\n/* 图片尺寸 */\r\n/* Border Radius */\r\n/* 水平间距 */\r\n/* 垂直间距 */\r\n/* 透明度 */\r\n/* 文章场景相关 */uni-view[data-v-14309c6b], uni-scroll-view[data-v-14309c6b], uni-swiper-item[data-v-14309c6b]{display:flex;flex-direction:column;flex-shrink:0;flex-grow:0;flex-basis:auto;align-items:stretch;align-content:flex-start}@font-face{font-family:uvicon-iconfont;src:url(' +
        r +
        ') format("truetype")}.uv-icon[data-v-14309c6b]{display:flex;align-items:center}.uv-icon--left[data-v-14309c6b]{flex-direction:row-reverse;align-items:center}.uv-icon--right[data-v-14309c6b]{flex-direction:row;align-items:center}.uv-icon--top[data-v-14309c6b]{flex-direction:column-reverse;justify-content:center}.uv-icon--bottom[data-v-14309c6b]{flex-direction:column;justify-content:center}.uv-icon__icon[data-v-14309c6b]{font-family:uvicon-iconfont;position:relative;display:flex;flex-direction:row;align-items:center}.uv-icon__icon--primary[data-v-14309c6b]{color:#3c9cff}.uv-icon__icon--success[data-v-14309c6b]{color:#5ac725}.uv-icon__icon--error[data-v-14309c6b]{color:#f56c6c}.uv-icon__icon--warning[data-v-14309c6b]{color:#f9ae3d}.uv-icon__icon--info[data-v-14309c6b]{color:#909399}.uv-icon__img[data-v-14309c6b]{height:auto;will-change:transform}.uv-icon__label[data-v-14309c6b]{line-height:1}',
      "",
    ]),
      (e.exports = n);
  },
  e5ca: function (e, n, t) {
    "use strict";
    t.r(n);
    var a = t("d3f5"),
      i = t.n(a);
    for (var o in a)
      ["default"].indexOf(o) < 0 &&
        (function (e) {
          t.d(n, e, function () {
            return a[e];
          });
        })(o);
    n["default"] = i.a;
  },
  e74a: function (e, n, t) {
    "use strict";
    t("6a54"),
      Object.defineProperty(n, "__esModule", { value: !0 }),
      (n.isWexin = function () {
        var e = window.navigator.userAgent.toLowerCase();
        return "micromessenger" == e.match(/MicroMessenger/i)
          ? (console.log("这是微信浏览器"), 1)
          : (console.log("这是普通浏览器"), 0);
      }),
      (n.weappLogin = n.send = n.post2 = n.post = void 0),
      t("bf0f"),
      t("aa9c"),
      t("5ef2"),
      t("5c47"),
      t("2c10");
    var a = t("15b8");
    getApp();
    n.send = function (e, n) {
      var t =
          !(arguments.length > 2 && void 0 !== arguments[2]) || arguments[2],
        a = uni.getStorageSync("token");
      return new Promise(function (o, r) {
        i(e, n, a, t)
          .then(function (e) {
            o(e);
          })
          .catch(function (e) {
            r(e);
          });
      });
    };
    var i = function (e, n, t, i) {
      return (
        0 == a.dubug ? (n.token = t) : (n.token = "Hns8jk2njsk"),
        (n.platform = "h5"),
        (n.system_type = uni.getSystemInfoSync().platform),
        new Promise(function (t, o) {
          (0, a.sendPost)({ url: e, method: "POST", data: n })
            .then(function (e) {
              var n = e.status,
                o = e.msg,
                r = (e.data, e.auth_url);
              if (3 == n) {
                uni.setStorageSync("token", ""),
                  uni.setStorageSync("auth_url", r),
                  uni.$uv.toast("请先登录");
                var s = navigator.userAgent.toLowerCase(),
                  u = "/pages/user/login";
                return -1 == s.indexOf("micromessenger") && 0 == a.dubug
                  ? ((u = "/pages/user/login_old"),
                    void setTimeout(function () {
                      uni.navigateTo({ url: u });
                    }, 1e3))
                  : void setTimeout(function () {
                      (function () {
                        var e = uni.getStorageSync("auth_url");
                        if ("" == e) return uni.$uv.toast("授权域名配置异常");
                        var n = window.location.href,
                          t = encodeURIComponent(n);
                        e += "?back_url=" + t;
                        var a = uni.getStorageSync("share_code");
                        a && (e += "&share_code=" + a);
                        window.location.href = e;
                      })();
                    }, 1e3);
              }
              return 4 == n
                ? uni.reLaunch({ url: "/pages/index/incomer" })
                : 5 == n
                  ? uni.reLaunch({ url: "/pages/index/unauth" })
                  : 40016 == n
                    ? uni.reLaunch({ url: "/pages/index/error" })
                    : 1 != n && 1 == i
                      ? uni.showToast({ title: o, icon: "none", duration: 3e3 })
                      : void t(e);
            })
            .catch(function (e) {
              o(e);
            });
        })
      );
    };
    n.post = i;
    var o = function () {
      return (
        uni.showLoading({ title: "正在加载.." }),
        new Promise(function (e, n) {
          uni.login({
            success: function (t) {
              var i = t.code;
              if (i) {
                var o = uni.getSystemInfoSync(),
                  r = o.brand,
                  s = o.system,
                  u = o.version,
                  c = o.model,
                  l = uni.getStorageSync("share_code");
                (0, a.sendPost)({
                  url: "/wechat/WeappUser/login",
                  method: "POST",
                  data: {
                    code: i,
                    brand: r,
                    system: s,
                    version: u,
                    model: c,
                    share_code: l,
                  },
                })
                  .then(function (n) {
                    uni.hideLoading();
                    var t = n.status,
                      a = n.msg,
                      i = n.data;
                    if (1 != t)
                      return uni.showToast({
                        title: a,
                        icon: "none",
                        duration: 5e3,
                      });
                    1 == i.deadline_status &&
                      uni.showModal({
                        title: "温馨提示",
                        content: "当前小程序已到期, 请联系管理员",
                        showCancel: !1,
                        success: function (e) {
                          return uni.exitMiniProgram({
                            success: function () {},
                            fail: function () {},
                          });
                        },
                      }),
                      1 == i.debug_status &&
                        uni.showModal({
                          title: "温馨提示",
                          content: "小程序正在维护升级中,请稍后重试",
                          showCancel: !1,
                          success: function (e) {
                            return uni.exitMiniProgram({
                              success: function () {},
                              fail: function () {},
                            });
                          },
                        }),
                      uni.setStorageSync("token", i.token),
                      e(n);
                  })
                  .catch(function (e) {
                    console.log(e);
                  });
              } else
                console.log("获取用户登录态失败：" + t.errMsg),
                  n("获取用户登录态失败：" + t.errMsg);
            },
          });
        })
      );
    };
    n.weappLogin = o;
    n.post2 = function (e, n) {
      return (
        (n.platform = "h5"),
        (n.system_type = uni.getSystemInfoSync().platform),
        new Promise(function (t, i) {
          (0, a.sendPost)({ url: e, method: "POST", data: n })
            .then(function (e) {
              var n = e.status;
              e.msg;
              if (4 == n) return uni.reLaunch({ url: "/pages/other/incomer" });
              t(e);
            })
            .catch(function (e) {
              i(e);
            });
        })
      );
    };
  },
  e787: function (e, n, t) {
    "use strict";
    t.r(n);
    var a = t("913f"),
      i = t("9527");
    for (var o in i)
      ["default"].indexOf(o) < 0 &&
        (function (e) {
          t.d(n, e, function () {
            return i[e];
          });
        })(o);
    t("b713");
    var r = t("828b"),
      s = Object(r["a"])(
        i["default"],
        a["b"],
        a["c"],
        !1,
        null,
        "30d33ae6",
        null,
        !1,
        a["a"],
        void 0,
      );
    n["default"] = s.exports;
  },
  ea33: function (e, n, t) {
    "use strict";
    t.r(n);
    var a = t("4f84"),
      i = t.n(a);
    for (var o in a)
      ["default"].indexOf(o) < 0 &&
        (function (e) {
          t.d(n, e, function () {
            return a[e];
          });
        })(o);
    n["default"] = i.a;
  },
  ea56: function (e, n, t) {
    "use strict";
    t("6a54"),
      Object.defineProperty(n, "__esModule", { value: !0 }),
      (n.default = void 0),
      t("aa77"),
      t("bf0f"),
      t("dc8a"),
      t("4626"),
      t("5ac7");
    var a = {
      name: "Keypress",
      props: { disable: { type: Boolean, default: !1 } },
      mounted: function () {
        var e = this,
          n = {
            esc: ["Esc", "Escape"],
            tab: "Tab",
            enter: "Enter",
            space: [" ", "Spacebar"],
            up: ["Up", "ArrowUp"],
            left: ["Left", "ArrowLeft"],
            right: ["Right", "ArrowRight"],
            down: ["Down", "ArrowDown"],
            delete: ["Backspace", "Delete", "Del"],
          };
        document.addEventListener("keyup", function (t) {
          if (!e.disable) {
            var a = Object.keys(n).find(function (e) {
              var a = t.key,
                i = n[e];
              return i === a || (Array.isArray(i) && i.includes(a));
            });
            a &&
              setTimeout(function () {
                e.$emit(a, {});
              }, 0);
          }
        });
      },
      render: function () {},
    };
    n.default = a;
  },
  ec20: function (e, n, t) {
    "use strict";
    t.d(n, "b", function () {
      return i;
    }),
      t.d(n, "c", function () {
        return o;
      }),
      t.d(n, "a", function () {
        return a;
      });
    var a = {
        uvTabbar: t("2144").default,
        uvTabbarItem: t("620b").default,
        uvPopup: t("ce8a").default,
      },
      i = function () {
        var e = this,
          n = e.$createElement,
          t = e._self._c || n;
        return t(
          "v-uni-view",
          {},
          [
            t(
              "uv-tabbar",
              {
                attrs: {
                  value: e.curIndex,
                  fixed: !0,
                  placeholder: !0,
                  safeAreaInsetBottom: !0,
                  inactiveColor: "#666",
                  activeColor: "#000",
                },
                on: {
                  change: function (n) {
                    (arguments[0] = n = e.$handleEvent(n)),
                      e.setSelected.apply(void 0, arguments);
                  },
                },
              },
              [
                e._l(e.nav_list, function (n, a) {
                  return t("uv-tabbar-item", {
                    key: a,
                    attrs: {
                      text: n.name,
                      badge: "/pages/chat/list" == n.path ? e.new_msg_num : 0,
                    },
                    scopedSlots: e._u(
                      [
                        {
                          key: "active-icon",
                          fn: function () {
                            return [
                              t("v-uni-image", {
                                staticClass: "icon",
                                attrs: { src: n.cur_icon },
                              }),
                            ];
                          },
                          proxy: !0,
                        },
                        {
                          key: "inactive-icon",
                          fn: function () {
                            return [
                              t("v-uni-image", {
                                staticClass: "icon",
                                attrs: { src: n.icon },
                              }),
                            ];
                          },
                          proxy: !0,
                        },
                      ],
                      null,
                      !0,
                    ),
                  });
                }),
                "mp-weixin" == e.palte && 3 == e.kefu.kefu_weapp_type
                  ? t("v-uni-button", {
                      staticClass: "up_button",
                      attrs: {
                        "open-type": "contact",
                        bindcontact: "handleContact",
                      },
                    })
                  : e._e(),
              ],
              2,
            ),
            t(
              "uv-popup",
              {
                ref: "popup1",
                attrs: {
                  mode: "center",
                  bgColor: "none",
                  closeOnClickOverlay: !0,
                },
              },
              [
                t(
                  "v-uni-view",
                  { staticClass: "ysShow" },
                  [
                    t("v-uni-view", { staticClass: "title" }, [
                      e._v("隐私保护指引"),
                    ]),
                    t(
                      "v-uni-view",
                      { staticClass: "con_box" },
                      [
                        e._v(" 使用当前系统下单之前，请仔细阅读 "),
                        t(
                          "v-uni-text",
                          {
                            staticClass: "blue",
                            on: {
                              click: function (n) {
                                (arguments[0] = n = e.$handleEvent(n)),
                                  e.jump("/pages/user/article?id=1");
                              },
                            },
                          },
                          [e._v("《充值协议》")],
                        ),
                        e._v("、 "),
                        t(
                          "v-uni-text",
                          {
                            staticClass: "blue",
                            on: {
                              click: function (n) {
                                (arguments[0] = n = e.$handleEvent(n)),
                                  e.jump("/pages/user/article?id=3");
                              },
                            },
                          },
                          [e._v("《用户服务协议》")],
                        ),
                        e._v("和 "),
                        t(
                          "v-uni-text",
                          {
                            staticClass: "blue",
                            on: {
                              click: function (n) {
                                (arguments[0] = n = e.$handleEvent(n)),
                                  e.jump("/pages/user/article?id=2");
                              },
                            },
                          },
                          [e._v("《隐私政策》")],
                        ),
                        e._v(
                          ' 。如果你同意以上所有协议，请点击"同意"开始使用。 ',
                        ),
                      ],
                      1,
                    ),
                    t(
                      "v-uni-view",
                      { staticClass: "btn_box flex_box" },
                      [
                        t("v-uni-view", { staticClass: "cancle" }, [
                          e._v("拒绝"),
                        ]),
                        t(
                          "v-uni-view",
                          {
                            on: {
                              click: function (n) {
                                (arguments[0] = n = e.$handleEvent(n)),
                                  e.agreeYs();
                              },
                            },
                          },
                          [e._v("同意")],
                        ),
                      ],
                      1,
                    ),
                  ],
                  1,
                ),
              ],
              1,
            ),
            t(
              "uv-popup",
              { ref: "popup2", attrs: { mode: "center", bgColor: "none" } },
              [
                t(
                  "v-uni-view",
                  { staticClass: "gzhShow" },
                  [
                    t("v-uni-view", { staticClass: "title" }, [
                      e._v("关注公众号"),
                    ]),
                    t("img", {
                      staticClass: "qrcode",
                      attrs: { src: e.qrcode },
                    }),
                    t("v-uni-view", { staticClass: "tips" }, [
                      e._v("请先长按扫码关注公众号"),
                    ]),
                  ],
                  1,
                ),
              ],
              1,
            ),
          ],
          1,
        );
      },
      o = [];
  },
  ed43: function (e, n, t) {
    "use strict";
    t.d(n, "b", function () {
      return a;
    }),
      t.d(n, "c", function () {
        return i;
      }),
      t.d(n, "a", function () {});
    var a = function () {
        var e = this.$createElement,
          n = this._self._c || e;
        return n("v-uni-view", {
          staticClass: "status-bar",
          style: { height: this.statusBarHeight + "px" },
        });
      },
      i = [];
  },
  ed9c: function (e, n, t) {
    "use strict";
    t.r(n);
    var a = t("f941"),
      i = t.n(a);
    for (var o in a)
      ["default"].indexOf(o) < 0 &&
        (function (e) {
          t.d(n, e, function () {
            return a[e];
          });
        })(o);
    n["default"] = i.a;
  },
  f0f3: function (e, n, t) {
    var a = t("c86c");
    (n = a(!1)),
      n.push([
        e.i,
        '@charset "UTF-8";\r\n/**\r\n * 这里是uni-app内置的常用样式变量\r\n *\r\n * uni-app 官方扩展插件及插件市场（https://ext.dcloud.net.cn）上很多三方插件均使用了这些样式变量\r\n * 如果你是插件开发者，建议你使用scss预处理，并在插件代码中直接使用这些变量（无需 import 这个文件），方便用户通过搭积木的方式开发整体风格一致的App\r\n *\r\n */\r\n/**\r\n * 如果你是App开发者（插件使用者），你可以通过修改这些变量来定制自己的插件主题，实现自定义主题功能\r\n *\r\n * 如果你的项目同样使用了scss预处理，你也可以直接在你的 scss 代码中使用如下变量，同时无需 import 这个文件\r\n */\r\n/* 颜色变量 */\r\n/* 行为相关颜色 */\r\n/* 文字基本颜色 */\r\n/* 背景颜色 */\r\n/* 边框颜色 */\r\n/* 尺寸变量 */\r\n/* 文字尺寸 */\r\n/* 图片尺寸 */\r\n/* Border Radius */\r\n/* 水平间距 */\r\n/* 垂直间距 */\r\n/* 透明度 */\r\n/* 文章场景相关 */.uv-border-top[data-v-469f4a54]{border-top-width:.5px!important;border-color:#dadbde!important;border-top-style:solid}uni-view[data-v-469f4a54], uni-scroll-view[data-v-469f4a54], uni-swiper-item[data-v-469f4a54]{display:flex;flex-direction:column;flex-shrink:0;flex-grow:0;flex-basis:auto;align-items:stretch;align-content:flex-start}.uv-tabbar[data-v-469f4a54]{display:flex;flex-direction:column;flex:1;justify-content:center}.uv-tabbar__content[data-v-469f4a54]{display:flex;flex-direction:column;background-color:#fff}.uv-tabbar__content__item-wrapper[data-v-469f4a54]{height:50px;display:flex;flex-direction:row}.uv-tabbar--fixed[data-v-469f4a54]{position:fixed;bottom:0;left:0;right:0}',
        "",
      ]),
      (e.exports = n);
  },
  f10e: function (e, n, t) {
    "use strict";
    t.r(n);
    var a = t("9767"),
      i = t("1dedb");
    for (var o in i)
      ["default"].indexOf(o) < 0 &&
        (function (e) {
          t.d(n, e, function () {
            return i[e];
          });
        })(o);
    t("4942");
    var r = t("828b"),
      s = Object(r["a"])(
        i["default"],
        a["b"],
        a["c"],
        !1,
        null,
        null,
        null,
        !1,
        a["a"],
        void 0,
      );
    n["default"] = s.exports;
  },
  f194: function (e, n, t) {
    "use strict";
    var a = t("ad8a"),
      i = t.n(a);
    i.a;
  },
  f1ac: function (e, n, t) {
    "use strict";
    t("6a54");
    var a = t("3639").default;
    Object.defineProperty(n, "__esModule", { value: !0 }),
      (n.default = function (e, n, t) {
        if (!n) return e;
        var a;
        if (t) a = t(n);
        else if (i.isURLSearchParams(n)) a = n.toString();
        else {
          var r = [];
          i.forEach(n, function (e, n) {
            null !== e &&
              "undefined" !== typeof e &&
              (i.isArray(e) ? (n += "[]") : (e = [e]),
              i.forEach(e, function (e) {
                i.isDate(e)
                  ? (e = e.toISOString())
                  : i.isObject(e) && (e = JSON.stringify(e)),
                  r.push(o(n) + "=" + o(e));
              }));
          }),
            (a = r.join("&"));
        }
        if (a) {
          var s = e.indexOf("#");
          -1 !== s && (e = e.slice(0, s)),
            (e += (-1 === e.indexOf("?") ? "?" : "&") + a);
        }
        return e;
      }),
      t("5c47"),
      t("a1c1"),
      t("c9b5"),
      t("bf0f"),
      t("ab80"),
      t("d4b5"),
      t("aa9c"),
      t("5ef2"),
      t("f7a5");
    var i = a(t("117a"));
    function o(e) {
      return encodeURIComponent(e)
        .replace(/%40/gi, "@")
        .replace(/%3A/gi, ":")
        .replace(/%24/g, "$")
        .replace(/%2C/gi, ",")
        .replace(/%20/g, "+")
        .replace(/%5B/gi, "[")
        .replace(/%5D/gi, "]");
    }
  },
  f1e6: function (e, n, t) {
    "use strict";
    t("6a54");
    var a = t("f5bd").default;
    Object.defineProperty(n, "__esModule", { value: !0 }),
      (n.default = void 0),
      t("5ef2");
    var i = a(t("4d8f0")),
      o = a(t("9463")),
      r = a(t("0c56")),
      s = {
        name: "uv-status-bar",
        mixins: [i.default, o.default, r.default],
        data: function () {
          return {};
        },
        computed: {
          style: function () {
            var e = {};
            return (
              (e.height = this.$uv.addUnit(
                this.$uv.sys().statusBarHeight,
                "px",
              )),
              this.bgColor &&
                (this.bgColor.indexOf("gradient") > -1
                  ? (e.backgroundImage = this.bgColor)
                  : (e.background = this.bgColor)),
              this.$uv.deepMerge(e, this.$uv.addStyle(this.customStyle))
            );
          },
        },
      };
    n.default = s;
  },
  f286: function (e, n, t) {
    var a = t("c86c");
    (n = a(!1)),
      n.push([
        e.i,
        '@charset "UTF-8";\r\n/**\r\n * 这里是uni-app内置的常用样式变量\r\n *\r\n * uni-app 官方扩展插件及插件市场（https://ext.dcloud.net.cn）上很多三方插件均使用了这些样式变量\r\n * 如果你是插件开发者，建议你使用scss预处理，并在插件代码中直接使用这些变量（无需 import 这个文件），方便用户通过搭积木的方式开发整体风格一致的App\r\n *\r\n */\r\n/**\r\n * 如果你是App开发者（插件使用者），你可以通过修改这些变量来定制自己的插件主题，实现自定义主题功能\r\n *\r\n * 如果你的项目同样使用了scss预处理，你也可以直接在你的 scss 代码中使用如下变量，同时无需 import 这个文件\r\n */\r\n/* 颜色变量 */\r\n/* 行为相关颜色 */\r\n/* 文字基本颜色 */\r\n/* 背景颜色 */\r\n/* 边框颜色 */\r\n/* 尺寸变量 */\r\n/* 文字尺寸 */\r\n/* 图片尺寸 */\r\n/* Border Radius */\r\n/* 水平间距 */\r\n/* 垂直间距 */\r\n/* 透明度 */\r\n/* 文章场景相关 */uni-view[data-v-2a4c32bc], uni-scroll-view[data-v-2a4c32bc], uni-swiper-item[data-v-2a4c32bc]{display:flex;flex-direction:column;flex-shrink:0;flex-grow:0;flex-basis:auto;align-items:stretch;align-content:flex-start}[type="search"][data-v-2a4c32bc]::-webkit-search-decoration{display:none}.uv-search[data-v-2a4c32bc]{display:flex;flex-direction:row;align-items:center;flex:1}.uv-search__content[data-v-2a4c32bc]{position:relative;display:flex;flex-direction:row;align-items:center;padding:0 10px;flex:1;justify-content:space-between;border-width:1px;border-color:transparent;border-style:solid;overflow:hidden}.uv-search__content__icon[data-v-2a4c32bc]{display:flex;flex-direction:row;align-items:center}.uv-search__content__label[data-v-2a4c32bc]{color:#303133;font-size:14px;margin:0 4px}.uv-search__content__close[data-v-2a4c32bc]{width:20px;height:20px;border-top-left-radius:100px;border-top-right-radius:100px;border-bottom-left-radius:100px;border-bottom-right-radius:100px;background-color:#c6c7cb;display:flex;flex-direction:row;align-items:center;justify-content:center;-webkit-transform:scale(.82);transform:scale(.82)}.uv-search__content__input[data-v-2a4c32bc]{flex:1;font-size:14px;line-height:1;margin:0 15px 0 5px;color:#303133}.uv-search__content__input--placeholder[data-v-2a4c32bc]{color:#909193}.uv-search__content__disabled[data-v-2a4c32bc]{position:absolute;left:0;top:0;bottom:0;right:0;z-index:2}.uv-search__action[data-v-2a4c32bc]{font-size:14px;color:#303133;width:0;overflow:hidden;transition-property:width;transition-duration:.3s;white-space:nowrap;text-align:center}.uv-search__action--active[data-v-2a4c32bc]{width:40px;margin-left:5px}',
        "",
      ]),
      (e.exports = n);
  },
  f510: function (e, n, t) {
    var a = t("9264");
    a.__esModule && (a = a.default),
      "string" === typeof a && (a = [[e.i, a, ""]]),
      a.locals && (e.exports = a.locals);
    var i = t("967d").default;
    i("37bcb991", a, !0, { sourceMap: !1, shadowMode: !1 });
  },
  f5b6: function (e, n, t) {
    e.exports = t.p + "assets/uvicons.f0fbf8a0.ttf";
  },
  f941: function (e, n, t) {
    "use strict";
    t("6a54");
    var a = t("f5bd").default;
    Object.defineProperty(n, "__esModule", { value: !0 }), (n.default = void 0);
    var i = a(t("4d8f0")),
      o = a(t("9463")),
      r = a(t("0ed3")),
      s = {
        name: "uv-loadmore",
        mixins: [i.default, o.default, r.default],
        data: function () {
          return { dotText: "●" };
        },
        computed: {
          loadTextStyle: function () {
            return {
              color: this.color,
              fontSize: this.$uv.addUnit(this.fontSize),
              lineHeight: this.$uv.addUnit(this.fontSize),
              backgroundColor: this.bgColor,
            };
          },
          showText: function () {
            var e = "";
            return (
              (e =
                "loadmore" == this.status
                  ? this.loadmoreText
                  : "loading" == this.status
                    ? this.loadingText
                    : "nomore" == this.status && this.isDot
                      ? this.dotText
                      : this.nomoreText),
              e
            );
          },
        },
        methods: {
          loadMore: function () {
            "loadmore" == this.status && this.$emit("loadmore");
          },
        },
      };
    n.default = s;
  },
  fa53: function (e, n, t) {
    "use strict";
    t("6a54");
    var a = t("f5bd").default;
    Object.defineProperty(n, "__esModule", { value: !0 }), (n.default = void 0);
    var i = a(t("b7c7"));
    t("64aa"), t("aa9c");
    var o = t("e74a"),
      r = {
        name: "GoodsSelect",
        props: {
          show: { type: Boolean, default: !1 },
          seller_id: { type: [Number, String], default: 0 },
        },
        data: function () {
          return {
            keyword: "",
            showCat: !1,
            cat1_list: [],
            cat2_list: [],
            cat3_list: [],
            cat1_id: 0,
            cat2_id: 0,
            cat3_id: 0,
            list: [],
            page: 1,
            no_more: 0,
            status: "loading",
            loading: !1,
            switchLock: !1,
            inited: !1,
            showSpecPopup: !1,
            currentGoods: {},
            childList: [],
            selectId: 0,
            specViewMode: "img",
            specLoading: !1,
          };
        },
        watch: {
          show: {
            handler: function (e) {
              var n = this;
              e
                ? (this.$nextTick(function () {
                    n.$refs.popup && n.$refs.popup.open();
                  }),
                  this.inited || ((this.inited = !0), this.getCatList()))
                : this.$nextTick(function () {
                    n.$refs.popup && n.$refs.popup.close();
                  });
            },
            immediate: !0,
          },
        },
        methods: {
          popupChange: function (e) {
            e.show || this.showSpecPopup || this.$emit("close");
          },
          close: function () {
            this.$emit("close");
          },
          getCatList: function () {
            var e = this;
            (0, o.send)(
              "/wechat/Cat/getCatList23",
              { cat1_id: this.cat1_id, seller_id: this.seller_id },
              !1,
            ).then(function (n) {
              var t = n.status,
                a = n.msg,
                i = n.data;
              if (1 != t) return uni.$uv.toast(a);
              (e.cat1_list = i.cat || []),
                0 == e.cat1_id
                  ? (e.cat2_list = [])
                  : (e.cat2_list = i.list || []),
                (e.cat2_id = 0),
                (e.cat3_id = 0),
                (e.cat3_list = []),
                e.resetList(),
                e.getGoodsList();
            });
          },
          changeCat1: function (e) {
            this.switchLock ||
              this.cat1_id == e.id ||
              (this.lockSwitch(),
              (this.cat1_id = e.id),
              (this.cat2_id = 0),
              (this.cat3_id = 0),
              (this.cat2_list = []),
              (this.cat3_list = []),
              0 == e.id
                ? (this.resetList(), this.getGoodsList())
                : this.getCatList());
          },
          changeCat2: function (e) {
            this.switchLock ||
              this.cat2_id == e.id ||
              (this.lockSwitch(),
              (this.cat2_id = e.id),
              (this.cat3_list = e.child || []),
              this.cat3_list.length > 0
                ? (this.cat3_id = this.cat3_list[0].id)
                : (this.cat3_id = 0),
              this.resetList(),
              this.getGoodsList());
          },
          changeCat3: function (e) {
            this.switchLock ||
              this.cat3_id == e.id ||
              (this.lockSwitch(),
              (this.cat3_id = e.id),
              this.resetList(),
              this.getGoodsList());
          },
          lockSwitch: function () {
            var e = this;
            (this.switchLock = !0),
              clearTimeout(this._switchTimer),
              (this._switchTimer = setTimeout(function () {
                e.switchLock = !1;
              }, 1e3));
          },
          resetList: function () {
            (this.page = 1),
              (this.no_more = 0),
              (this.status = "loading"),
              (this.list = []);
          },
          searchFun: function () {
            this.resetList(), uni.$uv.throttle(this.getGoodsList, 1500);
          },
          clearSearch: function () {
            (this.keyword = ""), this.resetList(), this.getGoodsList();
          },
          getGoodsList: function () {
            var e = this;
            this.loading ||
              ((this.loading = !0),
              (0, o.send)(
                "/wechat/Goods/getCatGoodsList",
                {
                  cat1_id: this.keyword ? 0 : this.cat1_id,
                  cat3_id: this.keyword ? 0 : this.cat3_id,
                  cat2_id: this.keyword ? 0 : this.cat2_id,
                  keyword: this.keyword,
                  sort: 0,
                  page: this.page,
                  seller_id: this.seller_id,
                },
                !1,
              )
                .then(function (n) {
                  e.loading = !1;
                  var t,
                    a = n.status,
                    o = n.msg,
                    r = n.data;
                  if (1 != a) return uni.$uv.toast(o);
                  e.page > 1
                    ? (t = e.list).push.apply(t, (0, i.default)(r.list))
                    : (e.list = r.list);
                  1 == r.no_more && ((e.status = "nomore"), (e.no_more = 1));
                })
                .catch(function () {
                  e.loading = !1;
                }));
          },
          loadMore: function () {
            0 != this.no_more ||
              this.loading ||
              (this.page++, this.getGoodsList());
          },
          initSpecMode: function () {
            var e = this;
            uni.$specConfig
              ? (this.specViewMode =
                  1 == uni.$specConfig.spec_text_switch ? "text" : "img")
              : (0, o.send)("/wechat/Wechat/getSpecConfig", {}, !1)
                  .then(function (n) {
                    (uni.$specConfig = n.data || {}),
                      (e.specViewMode =
                        1 == uni.$specConfig.spec_text_switch ? "text" : "img");
                  })
                  .catch(function () {});
          },
          selectGoods: function (e) {
            var n = this;
            e.child_num > 0
              ? (this.initSpecMode(),
                (this.currentGoods = e),
                (this.childList = []),
                (this.selectId = 0),
                (this.showSpecPopup = !0),
                this.$nextTick(function () {
                  n.$refs.specsPop && n.$refs.specsPop.open();
                }),
                this.loadChildGoods(e.id))
              : this.$emit("select", e.id);
          },
          loadChildGoods: function (e) {
            var n = this;
            (this.specLoading = !0),
              (0, o.send)("/wechat/Goods/getChildGoodsList", { id: e }, !1)
                .then(function (e) {
                  n.specLoading = !1;
                  var t = e.status,
                    a = e.msg,
                    i = e.data;
                  if (1 != t) return uni.$uv.toast(a);
                  n.childList = i;
                })
                .catch(function () {
                  n.specLoading = !1;
                });
          },
          selectSpec: function (e) {
            (this.currentGoods = e), (this.selectId = e.id);
          },
          confirmSpec: function () {
            if (0 == this.selectId) return uni.$uv.toast("请选择商品规格");
            this.$refs.specsPop && this.$refs.specsPop.close(),
              (this.showSpecPopup = !1),
              this.$emit("select", this.selectId);
          },
          specPopupChange: function (e) {
            e.show || (this.showSpecPopup = !1);
          },
        },
      };
    n.default = r;
  },
  fbc9: function (e, n, t) {
    var a = t("c86c");
    (n = a(!1)),
      n.push([
        e.i,
        '@charset "UTF-8";\r\n/**\r\n * 这里是uni-app内置的常用样式变量\r\n *\r\n * uni-app 官方扩展插件及插件市场（https://ext.dcloud.net.cn）上很多三方插件均使用了这些样式变量\r\n * 如果你是插件开发者，建议你使用scss预处理，并在插件代码中直接使用这些变量（无需 import 这个文件），方便用户通过搭积木的方式开发整体风格一致的App\r\n *\r\n */\r\n/**\r\n * 如果你是App开发者（插件使用者），你可以通过修改这些变量来定制自己的插件主题，实现自定义主题功能\r\n *\r\n * 如果你的项目同样使用了scss预处理，你也可以直接在你的 scss 代码中使用如下变量，同时无需 import 这个文件\r\n */\r\n/* 颜色变量 */\r\n/* 行为相关颜色 */\r\n/* 文字基本颜色 */\r\n/* 背景颜色 */\r\n/* 边框颜色 */\r\n/* 尺寸变量 */\r\n/* 文字尺寸 */\r\n/* 图片尺寸 */\r\n/* Border Radius */\r\n/* 水平间距 */\r\n/* 垂直间距 */\r\n/* 透明度 */\r\n/* 文章场景相关 */.uv-line[data-v-ff035a16]{vertical-align:middle}',
        "",
      ]),
      (e.exports = n);
  },
  fea9: function (e, n, t) {
    "use strict";
    t("6a54");
    var a = t("f5bd").default;
    Object.defineProperty(n, "__esModule", { value: !0 }),
      (n.default = void 0),
      t("64aa");
    var i,
      o,
      r = a(t("9b1b")),
      s = {
        props: (0, r.default)(
          {
            value: { type: [String, Number, null], default: null },
            safeAreaInsetBottom: { type: Boolean, default: !0 },
            border: { type: Boolean, default: !0 },
            zIndex: { type: [String, Number], default: 9 },
            activeColor: { type: String, default: "#1989fa" },
            inactiveColor: { type: String, default: "#7d7e80" },
            fixed: { type: Boolean, default: !0 },
            placeholder: { type: Boolean, default: !0 },
            iconSize: { type: [String, Number], default: 20 },
          },
          null === (i = uni.$uv) ||
            void 0 === i ||
            null === (o = i.props) ||
            void 0 === o
            ? void 0
            : o.tabbar,
        ),
      };
    n.default = s;
  },
  ff7b: function (e, n, t) {
    var a = t("b8de");
    a.__esModule && (a = a.default),
      "string" === typeof a && (a = [[e.i, a, ""]]),
      a.locals && (e.exports = a.locals);
    var i = t("967d").default;
    i("ff0d3a02", a, !0, { sourceMap: !1, shadowMode: !1 });
  },
});
//# sourceMappingURL=index.bb23f40d.js.map
